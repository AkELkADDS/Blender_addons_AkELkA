"""Bind / T-pose extraction from Body_Base GR2s (display + Blender Edit basis).

Encode never reads this — TransformTrack curves remain the sole GR2 write path.
"""

from __future__ import annotations

import json
import math
import re
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

FORMAT_ID = "gr2lab_bind"
FORMAT_VERSION = 1


def list_body_bases() -> List[Dict[str, Any]]:
    """Catalog Body_Base/*.GR2 for UI."""
    from paths import BODY_BASE, ensure_layout

    ensure_layout()
    out = []
    for p in sorted(BODY_BASE.glob("*.GR2")) + sorted(BODY_BASE.glob("*.gr2")):
        out.append({"name": p.name, "path": str(p), "size": p.stat().st_size})
    # de-dupe by name
    seen = set()
    uniq = []
    for b in out:
        if b["name"] in seen:
            continue
        seen.add(b["name"])
        uniq.append(b)
    return uniq


def resolve_body_base(name: str) -> Path:
    from paths import BODY_BASE, ensure_layout

    ensure_layout()
    safe = Path(name).name
    p = BODY_BASE / safe
    if not p.is_file():
        raise FileNotFoundError(f"Body base not found: {safe}")
    if p.suffix.lower() != ".gr2":
        raise ValueError("Body base must be a .GR2")
    return p


def match_body_base_for_source(source_gr2_name: str) -> Optional[str]:
    """TIF_FS_Rig_... → TIF_FS_Base.GR2; tail/head-aware via rig_catalog."""
    try:
        from rig_catalog import match_body_base_detail

        detail = match_body_base_detail(source_gr2_name)
        return detail.get("matched")
    except Exception:
        pass
    stem = Path(Path(source_gr2_name or "").name).stem
    if not stem:
        return None
    # Fallback: longest matching Base stem
    bases = list_body_bases()
    if not bases:
        return None
    candidates: List[Tuple[int, str]] = []
    for b in bases:
        bstem = Path(b["name"]).stem  # e.g. TIF_FS_Base
        prefix = bstem
        if prefix.lower().endswith("_base"):
            prefix = prefix[: -len("_base")]
        sl = stem.lower()
        pl = prefix.lower()
        if sl == pl or sl.startswith(pl + "_"):
            candidates.append((len(pl), b["name"]))
    if not candidates:
        return None
    candidates.sort(key=lambda x: -x[0])
    return candidates[0][1]


def _mat_to_trs(m: Sequence[float]) -> Tuple[List[float], List[float], List[float]]:
    """Collada row-major 4x4 → translation, quat xyzw, scale."""
    r00, r01, r02, tx = float(m[0]), float(m[1]), float(m[2]), float(m[3])
    r10, r11, r12, ty = float(m[4]), float(m[5]), float(m[6]), float(m[7])
    r20, r21, r22, tz = float(m[8]), float(m[9]), float(m[10]), float(m[11])
    sx = math.sqrt(r00 * r00 + r10 * r10 + r20 * r20) or 1.0
    sy = math.sqrt(r01 * r01 + r11 * r11 + r21 * r21) or 1.0
    sz = math.sqrt(r02 * r02 + r12 * r12 + r22 * r22) or 1.0
    r00, r10, r20 = r00 / sx, r10 / sx, r20 / sx
    r01, r11, r21 = r01 / sy, r11 / sy, r21 / sy
    r02, r12, r22 = r02 / sz, r12 / sz, r22 / sz
    tr = r00 + r11 + r22
    if tr > 0:
        S = math.sqrt(tr + 1.0) * 2.0
        w = 0.25 * S
        x = (r21 - r12) / S
        y = (r02 - r20) / S
        z = (r10 - r01) / S
    elif r00 > r11 and r00 > r22:
        S = math.sqrt(1.0 + r00 - r11 - r22) * 2.0
        w = (r21 - r12) / S
        x = 0.25 * S
        y = (r01 + r10) / S
        z = (r02 + r20) / S
    elif r11 > r22:
        S = math.sqrt(1.0 + r11 - r00 - r22) * 2.0
        w = (r02 - r20) / S
        x = (r01 + r10) / S
        y = 0.25 * S
        z = (r12 + r21) / S
    else:
        S = math.sqrt(1.0 + r22 - r00 - r11) * 2.0
        w = (r10 - r01) / S
        x = (r02 + r20) / S
        y = (r12 + r21) / S
        z = 0.25 * S
    return [tx, ty, tz], [x, y, z, w], [sx, sy, sz]


def parse_bind_from_dae(dae_text: str, *, source_gr2: str = "") -> Dict[str, Any]:
    """Parse Divine Collada JOINT hierarchy into bind_pose doc."""
    stack: List[str] = []
    bones: Dict[str, Dict[str, Any]] = {}
    token_re = re.compile(
        r'(<node id="Bone_([^"]+)" name="([^"]+)"[^>]*type="JOINT">)'
        r'|(<matrix sid="Transform">([^<]+)</matrix>)'
        r'|(</node>)'
    )
    for m in token_re.finditer(dae_text):
        if m.group(1):
            name = m.group(3)
            parent = stack[-1] if stack else None
            stack.append(name)
            bones[name] = {
                "name": name,
                "parent_name": parent,
                "bind_translation": [0.0, 0.0, 0.0],
                "bind_rotation": [0.0, 0.0, 0.0, 1.0],
                "bind_scale": [1.0, 1.0, 1.0],
            }
        elif m.group(4):
            if not stack:
                continue
            name = stack[-1]
            vals = [float(x) for x in m.group(5).split()]
            if len(vals) >= 16:
                t, r, s = _mat_to_trs(vals)
                bones[name]["bind_translation"] = t
                bones[name]["bind_rotation"] = r
                bones[name]["bind_scale"] = s
        elif m.group(6):
            if stack:
                stack.pop()

    ordered = list(bones.values())
    root = ordered[0]["name"] if ordered else ""
    for b in ordered:
        if not b.get("parent_name"):
            root = b["name"]
            break
    return {
        "format": FORMAT_ID,
        "version": FORMAT_VERSION,
        "source_gr2": source_gr2,
        "root": root,
        "bones": ordered,
    }


def bind_sidecar_path(base_gr2: Path) -> Path:
    """Shipped T-pose JSON next to Body_Base GR2 (no Divine at runtime)."""
    p = Path(base_gr2)
    return p.with_name(f"{p.stem}.bind_pose.json")


def extract_bind_pose(
    base_gr2: Path,
    *,
    work_dir: Optional[Path] = None,
    force_divine: bool = False,
) -> Dict[str, Any]:
    """Body_Base GR2 → bind_pose document.

    Prefers the shipped ``*.bind_pose.json`` sidecar so zip installs work
    without Divine.exe. Divine is only a fallback for regenerating sidecars.
    """
    from gr2_dump import try_divine_dae

    base_gr2 = Path(base_gr2)
    sidecar = bind_sidecar_path(base_gr2)
    if not force_divine and sidecar.is_file():
        doc = load_bind_pose(sidecar)
        if not doc.get("source_gr2"):
            doc["source_gr2"] = base_gr2.name
        return doc

    if work_dir is None:
        work_dir = Path(tempfile.mkdtemp(prefix="gr2lab_bind_"))
    else:
        work_dir = Path(work_dir)
        work_dir.mkdir(parents=True, exist_ok=True)
    ok = try_divine_dae(base_gr2, work_dir)
    dae = work_dir / "decoded.dae"
    if not ok or not dae.is_file():
        raise RuntimeError(
            f"No T-pose bind for {base_gr2.name}: missing {sidecar.name} and Divine.exe. "
            "Character rest pose will be wrong. Reinstall GR2 Lab 2.1+ (includes bind JSON)."
        )
    text = dae.read_text(encoding="utf-8", errors="replace")
    doc = parse_bind_from_dae(text, source_gr2=base_gr2.name)
    if not doc.get("bones"):
        raise RuntimeError(f"No JOINT bones in DAE for {base_gr2.name}")
    return doc


def bake_bind_sidecar(base_gr2: Path, *, work_dir: Optional[Path] = None) -> Path:
    """Run Divine and write ``<stem>.bind_pose.json`` next to the Body_Base GR2."""
    base_gr2 = Path(base_gr2)
    doc = extract_bind_pose(base_gr2, work_dir=work_dir, force_divine=True)
    return write_bind_pose(doc, bind_sidecar_path(base_gr2))


def bake_all_bind_sidecars(*, force_divine: bool = True) -> List[Dict[str, Any]]:
    """Bake bind JSON for every Body_Base/*.GR2. Used when shipping the addon."""
    results: List[Dict[str, Any]] = []
    for info in list_body_bases():
        path = Path(info["path"])
        sidecar = bind_sidecar_path(path)
        try:
            if force_divine:
                out = bake_bind_sidecar(path)
            elif sidecar.is_file():
                out = sidecar
            else:
                out = bake_bind_sidecar(path)
            doc = load_bind_pose(out)
            results.append(
                {
                    "ok": True,
                    "base": path.name,
                    "sidecar": str(out),
                    "bones": len(doc.get("bones") or []),
                }
            )
        except Exception as e:
            results.append({"ok": False, "base": path.name, "error": str(e)})
    return results


def write_bind_pose(doc: Dict[str, Any], path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    return path


def load_bind_pose(path: Path) -> Dict[str, Any]:
    doc = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_bind_pose(doc)
    return doc


def validate_bind_pose(doc: Any) -> None:
    if not isinstance(doc, dict):
        raise ValueError("bind_pose: root must be object")
    if doc.get("format") != FORMAT_ID:
        raise ValueError(f"bind_pose: expected format={FORMAT_ID!r}")
    if not isinstance(doc.get("bones"), list) or not doc["bones"]:
        raise ValueError("bind_pose: missing bones[]")


def extract_bind_to_dump(
    dump_dir: Path,
    base_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Extract bind into OUT_FILES/<run>/bind_pose.json + BIND_SOURCE.txt."""
    from paths import OUT_FILES

    dump_dir = Path(dump_dir)
    if not dump_dir.is_dir():
        # allow run id
        dump_dir = OUT_FILES / Path(str(dump_dir)).name
    if not dump_dir.is_dir():
        raise FileNotFoundError(f"Dump not found: {dump_dir}")

    if not base_name:
        # try SOURCE.txt then BIND_SOURCE
        src = ""
        src_txt = dump_dir / "SOURCE.txt"
        if src_txt.is_file():
            for line in src_txt.read_text(encoding="utf-8", errors="replace").splitlines():
                if line.startswith("name="):
                    src = line.split("=", 1)[1].strip()
                    break
        base_name = match_body_base_for_source(src)
        if not base_name:
            raise ValueError(
                "No Body_Base match for this dump — pick a base in the UI "
                f"(source={src or '?'})"
            )

    base_path = resolve_body_base(base_name)
    work = dump_dir / "_bind_divine"
    doc = extract_bind_pose(base_path, work_dir=work)
    write_bind_pose(doc, dump_dir / "bind_pose.json")
    (dump_dir / "BIND_SOURCE.txt").write_text(
        f"name={base_path.name}\npath={base_path.resolve()}\n",
        encoding="utf-8",
    )
    return {
        "ok": True,
        "run_id": dump_dir.name,
        "source_gr2": base_path.name,
        "bones": len(doc["bones"]),
        "root": doc.get("root"),
        "path": str(dump_dir / "bind_pose.json"),
    }


def load_bind_for_dump(dump_dir: Path) -> Optional[Dict[str, Any]]:
    p = Path(dump_dir) / "bind_pose.json"
    if not p.is_file():
        return None
    return load_bind_pose(p)


def apply_bind_parents_to_skeleton(
    skel: Dict[str, Any],
    bind: Dict[str, Any],
) -> Dict[str, Any]:
    """Override skeleton parent_name from Body_Base bind (LSLib-accurate hierarchy)."""
    by_bind = {b["name"]: b for b in bind.get("bones") or [] if b.get("name")}
    bones = []
    for b in skel.get("bones") or []:
        name = b.get("name")
        bb = by_bind.get(name) if name else None
        if bb is not None:
            nb = dict(b)
            # Prefer bind parent even when None (root); only fall back if key absent
            if "parent_name" in bb:
                nb["parent_name"] = bb.get("parent_name")
            bones.append(nb)
        else:
            bones.append(b)
    out = dict(skel)
    out["bones"] = bones
    return out


def merge_bind_with_clip_skeleton(
    bind: Dict[str, Any],
    clip_skel: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Per anim bone: use bind TRS when name matches, else clip rest_*."""
    by_bind = {b["name"]: b for b in bind.get("bones") or [] if b.get("name")}
    out = []
    for b in clip_skel.get("bones") or []:
        name = b.get("name")
        if not name:
            continue
        bb = by_bind.get(name)
        if bb:
            # Bind parent wins (Body_Base / LSLib hierarchy) — required for IK targets
            out.append(
                {
                    "name": name,
                    "parent_name": bb.get("parent_name"),
                    "bind_translation": list(bb.get("bind_translation") or [0, 0, 0]),
                    "bind_rotation": list(bb.get("bind_rotation") or [0, 0, 0, 1]),
                    "bind_scale": list(bb.get("bind_scale") or [1, 1, 1]),
                    "from": "bind",
                }
            )
        else:
            out.append(
                {
                    "name": name,
                    "parent_name": b.get("parent_name"),
                    "bind_translation": list(b.get("rest_translation") or [0, 0, 0]),
                    "bind_rotation": list(b.get("rest_rotation") or [0, 0, 0, 1]),
                    "bind_scale": list(b.get("rest_scale") or [1, 1, 1]),
                    "from": "clip_t0",
                }
            )
    return out
