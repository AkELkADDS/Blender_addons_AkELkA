"""Blender armature bridge + Import/Export operators (no HTTP server)."""

from __future__ import annotations

import json
import math
import os
import tempfile
import time
import traceback
import uuid
from array import array
from bisect import bisect_left, bisect_right
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper
from mathutils import Matrix, Quaternion, Vector

# ---------------------------------------------------------------------------
# Local in-process codec (no always-on server)
# ---------------------------------------------------------------------------


class Gr2LabApiError(RuntimeError):
    def __init__(self, message: str, *, payload: Optional[dict] = None):
        super().__init__(message)
        self.payload = payload or {}


class Gr2LabProgress:
    """Header progress + status text. UI paints when a modal op yields (TIMER)."""

    def __init__(self, context):
        self._context = context
        self._wm = context.window_manager
        self._active = False
        self._last_ui = 0.0

    def begin(self, maximum: int = 100) -> None:
        self._wm.progress_begin(0, max(1, int(maximum)))
        self._active = True
        self._last_ui = 0.0

    def step(self, value: int, label: str = "", *, force_ui: bool = False) -> None:
        if not self._active:
            return
        self._wm.progress_update(int(value))
        now = time.perf_counter()
        if not force_ui and (now - self._last_ui) < 0.25:
            return
        self._last_ui = now
        if label:
            try:
                self._wm.status_text_set(f"GR2 LAB: {label}")
            except (AttributeError, TypeError):
                pass
        _redraw_windows(self._context)

    def end(self) -> None:
        if self._active:
            self._wm.progress_end()
            self._active = False
        try:
            self._wm.status_text_set(None)
        except (AttributeError, TypeError):
            try:
                self._wm.status_text_set("")
            except (AttributeError, TypeError):
                pass
        _redraw_windows(self._context)


def _redraw_windows(context, *, swap: bool = False) -> None:
    # tag_redraw only — never redraw_timer inside a blocking operator (causes freezes).
    wm = context.window_manager
    for window in wm.windows:
        screen = window.screen
        if not screen:
            continue
        for area in screen.areas:
            area.tag_redraw()

def _apply_layout_from_prefs(context=None) -> None:
    """Sync codec cache/Body_Base roots from addon preferences."""
    from .local_pipeline import apply_prefs

    prefs = None
    try:
        if context is not None:
            prefs = context.preferences.addons[__package__].preferences
        else:
            prefs = _addon_prefs()
    except Exception:
        prefs = None
    cache = getattr(prefs, "cache_root", "") if prefs else ""
    body_dir = getattr(prefs, "body_base_dir", "") if prefs else ""
    apply_prefs(cache_root=cache or "", body_base=body_dir or "")


def fetch_body_bases(
    base_url: str = "",
    *,
    source: Optional[str] = None,
) -> dict:
    _apply_layout_from_prefs()
    from .local_pipeline import list_body_bases_local

    return list_body_bases_local(source=source)


def _import_body_base_enum_items(self, context) -> List[Tuple[str, str, str]]:
    items = [("AUTO", "Auto-match", "Match Body_Base from source GR2 name")]
    try:
        _apply_layout_from_prefs(context)
        src = ""
        fp = getattr(self, "filepath", "") or ""
        if fp:
            src = Path(fp).name
        data = fetch_body_bases(source=src or None)
        matched = (data.get("matched") or "").strip()
        for b in data.get("bases") or []:
            name = str(b.get("name") or "")
            if not name:
                continue
            label = name
            if matched and name == matched:
                label = f"{name} (matched)"
            items.append((name, label, name))
    except Exception:
        pass
    if len(items) == 1:
        items.append(
            ("NONE", "(no Body_Base folder)", "Set Body_Base folder in addon preferences")
        )
    return items


def _sync_import_body_base(op, context) -> None:
    fp = getattr(op, "filepath", "") or ""
    synced = getattr(op, "bb_synced_for", "") or ""
    if not fp or synced == fp:
        return
    try:
        op.bb_synced_for = fp
    except Exception:
        pass
    try:
        data = fetch_body_bases(source=Path(fp).name)
        matched = (data.get("matched") or "").strip()
        if matched:
            op.body_base = matched
            hint = f"Auto: {matched}"
        else:
            op.body_base = "AUTO"
            hint = "No auto Body_Base match"
    except Exception as e:
        hint = str(e)[:80]
    try:
        op.bb_hint = hint
    except Exception:
        pass


def _resolve_body_base_for_import(
    *,
    choice: str,
    bb_hint: str,
    prefs_base: str,
    source_gr2: str,
) -> Optional[str]:
    """Pick Body_Base for import.

    Priority:
      1) bb_hint \"Auto: Name.GR2\" (enum often lies / sticks on DGB_*)
      2) explicit non-AUTO choice (user picked DGB_F etc.)
      3) filename match
      4) prefs default
    """
    hint = (bb_hint or "").strip()
    if hint.lower().startswith("auto:"):
        auto_name = hint.split(":", 1)[1].strip()
        if auto_name.lower().endswith(".gr2"):
            return Path(auto_name).name

    c = (choice or "").strip()
    if c and c not in {"AUTO", "NONE"}:
        return Path(c).name

    try:
        from bind_pose import match_body_base_for_source  # type: ignore

        matched = match_body_base_for_source(Path(source_gr2).name)
        if matched:
            return matched
    except Exception:
        pass
    return (prefs_base or "").strip() or None


def _resolve_body_base_choice(
    choice: str,
    prefs_base: str = "",
    *,
    source_gr2: str = "",
) -> Optional[str]:
    """Compat wrapper."""
    return _resolve_body_base_for_import(
        choice=choice,
        bb_hint="",
        prefs_base=prefs_base,
        source_gr2=source_gr2,
    )


def import_gr2_pipeline(
    base_url: str,
    gr2_path: str,
    *,
    body_base: Optional[str] = None,
    progress: Optional["Gr2LabProgress"] = None,
) -> tuple[dict, dict]:
    """Decode + densify in-process. base_url ignored (compat)."""
    _apply_layout_from_prefs()
    from .local_pipeline import import_gr2_pipeline_local

    return import_gr2_pipeline_local(gr2_path, body_base=body_base, progress=progress)


def pack_encode_gr2(
    base_url: str,
    run_id: str,
    doc: dict,
    dest_gr2_path: str,
    *,
    source_gr2: Optional[str] = None,
    progress: Optional["Gr2LabProgress"] = None,
    timer=None,
) -> dict:
    _apply_layout_from_prefs()
    from .local_pipeline import dump_still_exists, pack_encode_local

    if not dump_still_exists(run_id):
        raise Gr2LabApiError(
            f"Decode dump “{run_id}” not found in local cache. "
            "Re-import the GR2 via File → Import → GR2, then export again."
        )
    return pack_encode_local(
        run_id,
        doc,
        dest_gr2_path,
        source_gr2=source_gr2,
        progress=progress,
        timer=timer,
    )


def export_gr2_pipeline(
    base_url: str,
    run_id: str,
    doc: dict,
    dest_gr2_path: str,
    *,
    source_gr2: Optional[str] = None,
    gr2lab_path: Optional[str] = None,
    progress: Optional["Gr2LabProgress"] = None,
) -> dict:
    if gr2lab_path and Path(gr2lab_path).is_file():
        doc = json.loads(Path(gr2lab_path).read_text(encoding="utf-8"))
    doc = dict(doc)
    doc["run_id"] = run_id
    return pack_encode_gr2(
        base_url,
        run_id,
        doc,
        dest_gr2_path,
        source_gr2=source_gr2,
        progress=progress,
    )


def import_scene_partner_pipeline(*_a, **_k):
    raise Gr2LabApiError(
        "Scene partner import needs the optional site tools (not in standalone addon yet)."
    )



# ---------------------------------------------------------------------------
# GR2LAB bridge (armature + F-curves)
# ---------------------------------------------------------------------------

FORMAT_ID = "gr2lab"
FPS_DEFAULT = 30.0
TIME_EPS = 1e-4  # snap F-curve seconds back onto template knot times
NOOP_POS_EPS = 2e-4
NOOP_QUAT_DOT_EPS = 0.999
# Whole-character placement — keep template unless user-affected + real delta.
PROTECTED_ROOT_BONES = frozenset({"Dummy_Root", "Root_M"})

# Blender Z-up Dummy_Root rest is Rx(+90°). Body_Base templates sometimes store that
# as an orientation track; applying it as Granny anim tips the character 90° on site.
_RX90_QUAT = (0.7071067811865475, 0.0, 0.0, 0.7071067811865475)
_RX_NEG90_QUAT = (-0.7071067811865475, 0.0, 0.0, 0.7071067811865475)


def _quat_dot_abs(a, b) -> float:
    return abs(
        float(a[0]) * float(b[0])
        + float(a[1]) * float(b[1])
        + float(a[2]) * float(b[2])
        + float(a[3]) * float(b[3])
    )


def _is_blender_zup_root_ori(q) -> bool:
    """True when quat is ~Rx(±90°) — Blender Z-up Dummy_Root rest, not Granny anim."""
    if not q or len(q) < 4:
        return False
    return (
        _quat_dot_abs(q, _RX90_QUAT) >= 0.995
        or _quat_dot_abs(q, _RX_NEG90_QUAT) >= 0.995
    )


def _identity_ori_channel() -> Dict[str, Any]:
    return {
        "edit_mode": "none",
        "editable": False,
        "times": [0.0],
        "values": [[0.0, 0.0, 0.0, 1.0]],
        "note": "identity orientation",
    }


def _sanitize_dummy_root_ori(ori: Dict[str, Any]) -> Dict[str, Any]:
    """Drop false Blender Z-up Rx(90°) Dummy_Root anim — keep Granny identity."""
    vals = ori.get("values") or []
    if not vals:
        return _identity_ori_channel()
    if all(_is_blender_zup_root_ori(v) for v in vals):
        return _identity_ori_channel()
    return ori


def _uniform_time_grid(duration: float, fps: float) -> List[float]:
    dur = max(0.0, float(duration))
    rate = max(1.0, float(fps))
    n = max(2, int(dur * rate) + 1)
    if dur <= 1e-12:
        return [0.0]
    return [i * dur / (n - 1) for i in range(n)]


def _lerp_sample_n(
    knots: Sequence[float], controls: Sequence[Sequence[float]], t: float
) -> List[float]:
    if not knots or not controls:
        return []
    if len(knots) == 1 or t <= knots[0]:
        return list(controls[0])
    if t >= knots[-1]:
        return list(controls[-1])
    for i in range(len(knots) - 1):
        if knots[i] <= t <= knots[i + 1]:
            span = knots[i + 1] - knots[i]
            u = 0.0 if span <= 1e-12 else (t - knots[i]) / span
            a, b = controls[i], controls[i + 1]
            return [float(a[j]) + (float(b[j]) - float(a[j])) * u for j in range(len(a))]
    return list(controls[0])


def _ensure_hemi_quats(controls: Sequence[Sequence[float]]) -> List[List[float]]:
    out: List[List[float]] = [list(controls[0])]
    for q in controls[1:]:
        prev = out[-1]
        dot = sum(float(prev[i]) * float(q[i]) for i in range(4))
        if dot < 0:
            out.append([-float(q[0]), -float(q[1]), -float(q[2]), -float(q[3])])
        else:
            out.append(list(q))
    return out


def _pad_knots(knots: Sequence[float], degree: int) -> List[float]:
    t0 = float(knots[0])
    t1 = float(knots[-1])
    return [t0] + [float(k) for k in knots] + [t1] * int(degree)


def _bspline_span(u_vec: Sequence[float], degree: int, n_ctrl: int, t: float) -> int:
    if t >= u_vec[n_ctrl]:
        return n_ctrl - 1
    if t <= u_vec[degree]:
        return degree
    low, high = degree, n_ctrl
    mid = (low + high) // 2
    while t < u_vec[mid] or t >= u_vec[mid + 1]:
        if t < u_vec[mid]:
            high = mid
        else:
            low = mid
        mid = (low + high) // 2
    return mid


def _sample_bspline_py(
    degree: int,
    knots: Sequence[float],
    controls: Sequence[Sequence[float]],
    t: float,
    *,
    normalize: bool = False,
) -> List[float]:
    """Pure-Python Granny-style Deg2+ B-spline (no DLL). Deg≤1 → lerp."""
    n = len(knots)
    if n == 0 or not controls:
        return []
    dim = len(controls[0])
    degree = int(degree)
    if degree <= 1 or n < degree + 1:
        return _lerp_sample_n(knots, controls, t)
    t0, t1 = float(knots[0]), float(knots[-1])
    if float(t) <= t0:
        result = list(controls[0])
    elif float(t) >= t1:
        result = list(controls[-1])
    else:
        u_vec = _pad_knots(knots, degree)
        i = _bspline_span(u_vec, degree, n, float(t))
        d = [list(controls[i - degree + j]) for j in range(degree + 1)]
        for r in range(1, degree + 1):
            for j in range(degree, r - 1, -1):
                left = u_vec[i - degree + j]
                right = u_vec[i + 1 + j - r]
                denom = right - left
                alpha = 0.0 if abs(denom) < 1e-20 else (float(t) - left) / denom
                d[j] = [
                    (1.0 - alpha) * d[j - 1][c] + alpha * d[j][c] for c in range(dim)
                ]
        result = d[degree]
    if normalize and dim == 4:
        nrm = math.sqrt(sum(x * x for x in result)) or 1.0
        result = [x / nrm for x in result]
    return result


def _sample_bspline_quat_py(
    degree: int,
    knots: Sequence[float],
    quats: Sequence[Sequence[float]],
    t: float,
) -> List[float]:
    return _sample_bspline_py(
        degree, knots, _ensure_hemi_quats(quats), t, normalize=True
    )


def _ensure_doc_bspline_dense(doc: Dict[str, Any], fps: float) -> Dict[str, Any]:
    """Densify Deg≥2 channels onto an fps grid so Blender LINEAR looks game-smooth.

    Runs client-side even if the .gr2lab was not Download-for-Blender densified.
    Already-dense Deg1 channels are left alone. Root_M ori is marked display_densified.
    """
    duration = float(doc.get("duration") or 0.0)
    grid = _uniform_time_grid(duration, fps)
    fps_i = int(round(float(fps)))
    densified = 0
    for slot in doc.get("tracks") or []:
        name = slot.get("name") or ""
        for ch_key, is_quat in (("position", False), ("orientation", True)):
            ch = slot.get(ch_key) or {}
            mode = ch.get("edit_mode") or "none"
            if mode in ("none", "constant"):
                continue
            note = str(ch.get("note") or "")
            if "bspline_densified" in note or "k16_display_densified" in note:
                continue
            ts = [float(x) for x in (ch.get("times") or [])]
            vs = [list(map(float, v)) for v in (ch.get("values") or [])]
            if len(ts) < 2 or len(vs) != len(ts):
                continue
            # Already ~fps dense Deg1 — skip
            deg = int(ch.get("degree") or 0)
            if deg <= 1 and len(ts) >= max(8, int(duration * float(fps) * 0.85)):
                continue
            if name == "Dummy_Root" and ch_key == "orientation":
                continue
            # Save/24: Deg≥2 k16/float/quat → B-spline Deg1 float (not lerp).
            if deg < 2:
                deg = 2 if mode in ("quat_k16", "k16_offsets") else 1
            if deg < 2:
                continue
            samples = (
                [_sample_bspline_quat_py(deg, ts, vs, t) for t in grid]
                if is_quat
                else [_sample_bspline_py(deg, ts, vs, t) for t in grid]
            )
            display = name in ("Dummy_Root", "Root_M") or mode == "k16_offsets"
            slot[ch_key] = {
                "edit_mode": "float_controls",
                "editable": True,
                "format": 1,
                "capacity": len(grid),
                "times": list(grid),
                "values": samples,
                "degree": 1,
                "note": f"bspline_densified@{fps_i}",
                "source_interp": "bspline_dense",
                "display_densified": True if display else ch.get("display_densified"),
            }
            densified += 1
    doc["source_interp"] = "bspline_dense"
    doc["densify_fps"] = float(fps)
    doc["densified_channels"] = int(doc.get("densified_channels") or 0) + densified
    doc["blender_import_densified"] = densified
    return {"densified": densified, "grid": len(grid), "fps": float(fps)}


PROP_DOC = "gr2lab_json"
PROP_RUN = "gr2lab_run_id"
PROP_TEMPLATE_PATH = "gr2lab_template_path"
WM_LAST_TEMPLATE = "gr2lab_last_template"
WM_LAST_PACK_RUN = "gr2lab_last_pack_run"
WM_LAST_SOURCE_GR2 = "gr2lab_last_source_gr2"


def _quat_gr_to_bl(q: Sequence[float]) -> Quaternion:
    """Granny/Three [x,y,z,w] в†’ Blender Quaternion(w,x,y,z)."""
    x, y, z, w = float(q[0]), float(q[1]), float(q[2]), float(q[3])
    return Quaternion((w, x, y, z))


def _quat_bl_to_gr(q: Quaternion) -> List[float]:
    return [float(q.x), float(q.y), float(q.z), float(q.w)]


def _trs_matrix(t: Sequence[float], r: Sequence[float], s: Sequence[float]) -> Matrix:
    loc = Vector((float(t[0]), float(t[1]), float(t[2])))
    rot = _quat_gr_to_bl(r)
    scl = Vector((float(s[0]), float(s[1]), float(s[2])))
    return Matrix.LocRotScale(loc, rot, scl)


def _mat_to_trs(m: Matrix) -> Tuple[List[float], List[float], List[float]]:
    loc, rot, scl = m.decompose()
    return (
        [float(loc.x), float(loc.y), float(loc.z)],
        _quat_bl_to_gr(rot),
        [float(scl.x), float(scl.y), float(scl.z)],
    )


def _stabilize_local_cache_quats(
    local_cache: Dict[float, Dict[str, Tuple[List[float], List[float], List[float]]]],
) -> None:
    """
    Matrix.decompose() picks q or -q arbitrarily each frame. Consecutive sign flips
    look like shake after import (Granny/site lerp without a short-path fix on every path).
    Walk each bone's exported series and keep the short hemisphere.
    """
    if not local_cache:
        return
    frames = sorted(local_cache.keys())
    names = set()
    for fr in frames:
        names.update(local_cache[fr].keys())
    for name in names:
        prev: Optional[Quaternion] = None
        for fr in frames:
            bucket = local_cache.get(fr) or {}
            if name not in bucket:
                continue
            loc, quat_xyzw, scl = bucket[name]
            # Granny xyzw в†’ Blender wxyz
            cur = Quaternion(
                (
                    float(quat_xyzw[3]),
                    float(quat_xyzw[0]),
                    float(quat_xyzw[1]),
                    float(quat_xyzw[2]),
                )
            )
            cur.normalize()
            if prev is not None:
                cur.make_compatible(prev)
            prev = cur
            bucket[name] = (loc, _quat_bl_to_gr(cur), scl)


def _make_quat_series_compatible(values: List[List[float]]) -> None:
    """In-place Granny xyzw series в†’ short-arc consecutive keys."""
    prev: Optional[Quaternion] = None
    for i, q in enumerate(values):
        if not q or len(q) < 4:
            continue
        cur = Quaternion((float(q[3]), float(q[0]), float(q[1]), float(q[2])))
        cur.normalize()
        if prev is not None:
            cur.make_compatible(prev)
        prev = cur
        values[i] = _quat_bl_to_gr(cur)


def _load_doc(path: str) -> Dict[str, Any]:
    p = Path(path)
    low = p.name.lower()
    if low.endswith(".gr2"):
        raise ValueError(
            f"{p.name} is a game .GR2 file, not a .gr2lab bridge.\n"
            "Use File > Import > GR2 (via GR2 Lab) for .GR2 files."
        )
    raw = p.read_bytes()
    doc = _parse_gr2lab_bytes(raw)
    if not isinstance(doc.get("skeleton"), list) or not isinstance(doc.get("tracks"), list):
        raise ValueError(f"Invalid GR2LAB file (missing skeleton/tracks): {Path(path).name}")
    return doc


def _bone_order(skeleton: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Parents before children."""
    by_name = {b["name"]: b for b in skeleton if b.get("name")}
    remaining = set(by_name.keys())
    ordered: List[Dict[str, Any]] = []
    while remaining:
        progress = False
        for name in list(remaining):
            b = by_name[name]
            p = b.get("parent_name")
            if not p or p not in by_name or p not in remaining:
                ordered.append(b)
                remaining.remove(name)
                progress = True
        if not progress:
            # cycle / missing parent вЂ” append rest
            for name in sorted(remaining):
                ordered.append(by_name[name])
            break
    return ordered


def _rest_worlds(skeleton: List[Dict[str, Any]]) -> Dict[str, Matrix]:
    worlds: Dict[str, Matrix] = {}
    for b in _bone_order(skeleton):
        name = b["name"]
        local = _trs_matrix(
            b.get("rest_translation") or [0, 0, 0],
            b.get("rest_rotation") or [0, 0, 0, 1],
            b.get("rest_scale") or [1, 1, 1],
        )
        p = b.get("parent_name")
        worlds[name] = (worlds[p] @ local) if p in worlds else local
    return worlds


def _bind_map(doc: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    bind = doc.get("bind") or {}
    bones = bind.get("bones") if isinstance(bind, dict) else None
    if not bones:
        return {}
    return {b["name"]: b for b in bones if b.get("name")}


def _skeleton_with_bind_parents(
    skeleton: List[Dict[str, Any]], bind_by_name: Dict[str, Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """Override parent_name from bind (Body_Base / LSLib hierarchy) when present."""
    if not bind_by_name:
        return list(skeleton)
    out = []
    for b in skeleton:
        nb = dict(b)
        bb = bind_by_name.get(b.get("name") or "")
        if bb is not None and "parent_name" in bb:
            nb["parent_name"] = bb.get("parent_name")
        out.append(nb)
    return out


def _bind_local_for_bone(
    b: Dict[str, Any], bind_by_name: Dict[str, Dict[str, Any]]
) -> Matrix:
    """Edit-mode / pose basis local matrix: bind when present, else clip rest_*."""
    bb = bind_by_name.get(b["name"])
    if bb:
        return _trs_matrix(
            bb.get("bind_translation") or [0, 0, 0],
            bb.get("bind_rotation") or [0, 0, 0, 1],
            bb.get("bind_scale") or [1, 1, 1],
        )
    return _trs_matrix(
        b.get("rest_translation") or [0, 0, 0],
        b.get("rest_rotation") or [0, 0, 0, 1],
        b.get("rest_scale") or [1, 1, 1],
    )


def _bind_worlds(
    skeleton: List[Dict[str, Any]], bind_by_name: Dict[str, Dict[str, Any]]
) -> Dict[str, Matrix]:
    """FK worlds using skeleton parent_name (already bind-overridden when available)."""
    worlds: Dict[str, Matrix] = {}
    for b in _bone_order(skeleton):
        name = b["name"]
        local = _bind_local_for_bone(b, bind_by_name)
        p = b.get("parent_name")
        worlds[name] = (worlds[p] @ local) if p in worlds else local
    return worlds


def _track_map(doc: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    return {t["name"]: t for t in doc.get("tracks") or [] if t.get("name")}


def _sec_to_frame(t: float, fps: float) -> float:
    return 1.0 + float(t) * float(fps)


def _frame_to_sec(frame: float, fps: float) -> float:
    return max(0.0, (float(frame) - 1.0) / float(fps))


def _nearest_sorted(
    sorted_vals: Sequence[float], t: float
) -> Tuple[Optional[float], Optional[float]]:
    """Nearest value in a sorted list and |delta|. None if empty."""
    n = len(sorted_vals)
    if n == 0:
        return None, None
    i = bisect_left(sorted_vals, t)
    best: Optional[float] = None
    best_d: Optional[float] = None
    for j in (i - 1, i):
        if 0 <= j < n:
            d = abs(float(sorted_vals[j]) - float(t))
            if best_d is None or d < best_d:
                best_d = d
                best = float(sorted_vals[j])
    return best, best_d


def _snap_times_to_template(
    fc_times: Sequence[float],
    orig_times: Sequence[float],
    *,
    eps: float = TIME_EPS,
) -> List[float]:
    """Map F-curve seconds onto template knots; keep only truly new keys.

    Avoids densifying float/quat grids when sec-frame float noise would otherwise
    make ``set(orig) | set(fc)`` grow the curve on a no-op round-trip.
    """
    orig = [float(t) for t in orig_times] if orig_times else [0.0]
    orig_sorted = sorted(orig)
    if not fc_times:
        return list(orig) if orig else [0.0]
    out: List[float] = []
    seen = set()
    for raw in fc_times:
        t = float(raw)
        nearest, best = _nearest_sorted(orig_sorted, t)
        use = float(nearest) if nearest is not None and best is not None and best <= eps else t
        key = round(use, 6)
        if key in seen:
            continue
        seen.add(key)
        out.append(use)
    return sorted(out) or [0.0]


def _collapse_times_eps(
    times: Sequence[float],
    *,
    prefer: Optional[Sequence[float]] = None,
    eps: float = TIME_EPS,
) -> List[float]:
    """Merge times within eps; prefer frame-grid values when present in a cluster.

    Exact ``set()`` unions of template JSON floats and ``(frame-1)/fps`` create
    near-zero-Δt pairs with inconsistent samples → site/game finger flicker.
    """
    ordered = sorted({float(t) for t in times})
    if not ordered:
        return [0.0]
    pref = sorted({float(t) for t in (prefer or [])})
    out: List[float] = []
    cluster: List[float] = [ordered[0]]

    def flush(cl: List[float]) -> None:
        chosen = cl[-1]
        hit = None
        for c in cl:
            nearest, dist = _nearest_sorted(pref, c)
            if nearest is not None and dist is not None and dist <= eps:
                hit = nearest
                break
        if hit is not None:
            chosen = hit
        if out and abs(chosen - out[-1]) <= eps:
            nearest, dist = _nearest_sorted(pref, chosen)
            if nearest is not None and dist is not None and dist <= eps:
                out[-1] = chosen
            return
        out.append(chosen)

    for t in ordered[1:]:
        if t - cluster[-1] <= eps:
            cluster.append(t)
        else:
            flush(cluster)
            cluster = [t]
    flush(cluster)
    return out or [0.0]


def _lerp_vec3(
    times: Sequence[float],
    values: Sequence[Sequence[float]],
    t: float,
) -> List[float]:
    """Linear sample a vec3 series (matches site linear display)."""
    ts = [float(x) for x in times] if times else [0.0]
    vs = [list(v) for v in values] if values else []
    if not vs:
        return [0.0, 0.0, 0.0]
    if len(ts) == 1 or t <= ts[0]:
        return [float(vs[0][j]) for j in range(3)]
    if t >= ts[-1]:
        return [float(vs[-1][j]) for j in range(3)]
    i = bisect_right(ts, t) - 1
    i = max(0, min(i, len(ts) - 2))
    span = ts[i + 1] - ts[i]
    u = 0.0 if span <= 1e-12 else (t - ts[i]) / span
    a, b = vs[i], vs[i + 1]
    n = min(3, len(a), len(b))
    return [float(a[j]) + (float(b[j]) - float(a[j])) * u for j in range(n)]


def _k16_pos_matches_template(
    samples: Dict[float, List[float]],
    template_times: Sequence[float],
    template_vals: Sequence[Sequence[float]],
) -> bool:
    """True when exported Granny locals still match dequantized k16 template motion.

    Untouched display keys from import в†’ bias-only export (keep k16_offsets).
    Real multi-key edits that leave the template curve в†’ upgrade to float on site.
    """
    if not template_vals:
        return True
    if not samples:
        return True
    tmpl_t = [float(x) for x in template_times] if template_times else [0.0]
    for t, v in samples.items():
        expected = _lerp_vec3(tmpl_t, template_vals, float(t))
        if not _v3_close(v, expected, NOOP_POS_EPS):
            return False
    return True


def _root_samples_differ_from_template(
    samples: Dict[float, List[float]],
    template_ch: Dict[str, Any],
    *,
    is_quat: bool,
) -> bool:
    """True when sampled motion leaves the template beyond noop eps."""
    tmpl_t = [float(x) for x in (template_ch.get("times") or [0.0])]
    tmpl_v = template_ch.get("values") or []
    if not samples or not tmpl_v:
        return False
    if is_quat:
        for t, v in samples.items():
            expected = _sample_quat_channel(
                {"times": tmpl_t, "values": tmpl_v}, float(t)
            )
            if expected is None or not _quat_close(v, expected, NOOP_QUAT_DOT_EPS):
                return True
        return False
    for t, v in samples.items():
        expected = _lerp_vec3(tmpl_t, tmpl_v, float(t))
        if not _v3_close(v, expected, NOOP_POS_EPS):
            return True
    return False


def _channel_is_display_densified(ch: Dict[str, Any]) -> bool:
    note = str((ch or {}).get("note") or "")
    return (
        "bspline_densified" in note
        or "k16_display_densified" in note
        or bool((ch or {}).get("display_densified"))
    )


def _strip_root_display_densify(
    ch: Dict[str, Any], *, kind: str = "locomotion"
) -> Dict[str, Any]:
    """Mark a rewritten root channel as a real edit, not import display densify.

    Dense rewrites are always Degree=1 so BG3/LSLib linear-eval matches Blender.
    """
    out = dict(ch)
    out.pop("display_densified", None)
    note = str(out.get("note") or "")
    if (
        "bspline_densified" in note
        or "k16_display_densified" in note
        or not note
        or note.startswith("root_")
    ):
        out["note"] = f"root_{kind}_edit"
    out["degree"] = 1
    if len(out.get("times") or []) > 1:
        out["edit_mode"] = "float_controls"
        out["editable"] = True
    return out


def _allow_protected_root_rewrite(
    bone_affected: bool,
    samples: Dict[float, List[float]],
    template_ch: Dict[str, Any],
    *,
    is_quat: bool,
) -> bool:
    """Rewrite protected roots only when sampled motion actually leaves the template.

    Same motion (including bake densify of vanilla Root_M ori) → keep the original
    sparse curve. Different motion (NLA COMBINE / keyed loc+rot) → rewrite even
    on a dense 30fps grid. Constraint-affected is not required: NLA COMBINE is
    not a constraint, and Root_M Copy* constraints are often influence 0.
    """
    del bone_affected
    return _root_samples_differ_from_template(samples, template_ch, is_quat=is_quat)


def _is_mass_grid_densify_times(
    template_times: Sequence[float],
    sample_times: Sequence[float],
) -> bool:
    """True when F-curve times are a much denser grid than the template (frame bake)."""
    tmpl = [float(t) for t in template_times] if template_times else []
    samp = [float(t) for t in sample_times] if sample_times else []
    if not tmpl or not samp or len(samp) <= len(tmpl):
        return False
    cap = max(8, int(0.05 * len(tmpl) + 0.5))
    tmpl_sorted = sorted(tmpl)
    far = 0
    for t in samp:
        _nearest, best = _nearest_sorted(tmpl_sorted, t)
        if best is not None and best > TIME_EPS:
            far += 1
    return far > cap


def _drop_on_curve_extra_times(
    times: Sequence[float],
    samples: Dict[float, List[float]],
    template_times: Sequence[float],
    template_vals: Sequence[Sequence[float]],
    *,
    is_quat: bool,
) -> List[float]:
    """Keep template knots; drop extras whose sample matches the template curve.

    Stops Spine*_M-style on-curve densify keys from a Blender no-op export.
    """
    if not times:
        return [0.0]
    tmpl_t = [float(t) for t in template_times] if template_times else [0.0]
    tmpl_v = [list(v) for v in template_vals] if template_vals else []
    close = (
        (lambda a, b: _quat_close(a, b, NOOP_QUAT_DOT_EPS))
        if is_quat
        else (lambda a, b: _v3_close(a, b, NOOP_POS_EPS))
    )

    def on_template(t: float) -> bool:
        return any(abs(float(t) - o) <= TIME_EPS for o in tmpl_t)

    def sample_tmpl(t: float) -> List[float]:
        if not tmpl_v:
            return [0.0, 0.0, 0.0, 1.0] if is_quat else [0.0, 0.0, 0.0]
        ts = tmpl_t
        vs = tmpl_v
        if len(ts) == 1 or t <= ts[0]:
            return list(vs[0])
        if t >= ts[-1]:
            return list(vs[-1])
        for i in range(len(ts) - 1):
            if ts[i] <= t <= ts[i + 1]:
                span = ts[i + 1] - ts[i]
                u = 0.0 if span <= 1e-12 else (t - ts[i]) / span
                if is_quat:
                    qa = _quat_gr_to_bl(vs[i])
                    qb = _quat_gr_to_bl(vs[i + 1])
                    qb.make_compatible(qa)
                    return _quat_bl_to_gr(qa.slerp(qb, u))
                a, b = vs[i], vs[i + 1]
                n = min(len(a), len(b), 3)
                return [float(a[j]) + (float(b[j]) - float(a[j])) * u for j in range(n)]
        return list(vs[-1])

    out: List[float] = []
    for t in times:
        tf = float(t)
        if on_template(tf):
            out.append(tf)
            continue
        got = samples.get(tf)
        if got is None:
            continue
        if close(got, sample_tmpl(tf)):
            continue
        out.append(tf)
    return sorted(out) or list(tmpl_t[:1]) or [0.0]


def import_gr2lab_from_doc(
    context,
    doc: Dict[str, Any],
    *,
    fps: Optional[float] = None,
    y_up_display: bool = True,
    template_path: Optional[str] = None,
    progress: Optional[Gr2LabProgress] = None,
    template_doc: Optional[Dict[str, Any]] = None,
    timer=None,
) -> bpy.types.Object:
    """Build armature + action from a GR2LAB document dict."""
    fps = float(fps if fps is not None else doc.get("densify_fps") or FPS_DEFAULT)
    # Always densify Deg≥2 → fps grid so Blender LINEAR matches game B-spline,
    # even if the .gr2lab was saved without Download-for-Blender densify.
    densify_info = _ensure_doc_bspline_dense(doc, fps)
    if densify_info.get("densified"):
        print(
            f"GR2LAB: import densified {densify_info['densified']} channels "
            f"@ {densify_info['fps']:.0f}fps ({densify_info['grid']} keys)"
        )
    skeleton = doc.get("skeleton") or []
    tracks = _track_map(doc)
    duration = float(doc.get("duration") or 0.0)
    run_id = doc.get("run_id") or ""
    root_name = doc.get("root") or (skeleton[0]["name"] if skeleton else "Root")
    bind_by_name = _bind_map(doc)
    if not bind_by_name:
        print(
            "GR2LAB warning: no bind section — Edit mode uses clip t=0 rest "
            "(character imports need Body_Base/*.bind_pose.json from GR2 Lab 2.1+)"
        )

    # Hierarchy: prefer Body_Base / LSLib parents from bind (fixes flying IK)
    skeleton = _skeleton_with_bind_parents(skeleton, bind_by_name)

    # Leave any prior Edit/Pose mode without ops that need a VIEW_3D poll.
    prev = context.view_layer.objects.active
    if prev is not None and getattr(prev, "mode", "OBJECT") != "OBJECT":
        _mode_set_safe(context, "OBJECT", active=prev)
    _deselect_all_objects(context)

    arm_data = bpy.data.armatures.new(f"GR2LAB_{run_id or 'rig'}")
    arm_obj = bpy.data.objects.new(arm_data.name, arm_data)
    context.collection.objects.link(arm_obj)
    context.view_layer.objects.active = arm_obj
    arm_obj.select_set(True)

    # Optional display-only Y-up в†’ Z-up (rotate armature object, not keys)
    if y_up_display:
        arm_obj.rotation_euler = (math.radians(90.0), 0.0, 0.0)

    worlds = _bind_worlds(skeleton, bind_by_name)

    _mode_set_safe(context, "EDIT", active=arm_obj)
    edit_bones = arm_data.edit_bones
    created = {}
    for b in _bone_order(skeleton):
        name = b["name"]
        eb = edit_bones.new(name)
        # Unit-length bone along local +Y in rest (Blender bone axis)
        m = worlds.get(name, Matrix.Identity(4))
        head = m.to_translation()
        # Tail: small offset along bone's local Y (Blender convention)
        axis = (m.to_3x3() @ Vector((0.0, 0.05, 0.0)))
        if axis.length < 1e-8:
            axis = Vector((0.0, 0.05, 0.0))
        eb.head = head
        eb.tail = head + axis
        # Align roll via matrix
        eb.matrix = m
        created[name] = eb

    for b in skeleton:
        name = b.get("name")
        p = b.get("parent_name")
        if name in created and p in created:
            created[name].parent = created[p]
            created[name].use_connect = False

    _mode_set_safe(context, "POSE", active=arm_obj)

    # Stamp the pre-densify sparse pack (vanilla formats). Densified tracks are
    # F-curves only — export Root_M protect needs original quat_k16.
    stamp_src = template_doc if isinstance(template_doc, dict) else doc
    doc_store = dict(stamp_src)
    doc_store["skeleton"] = skeleton
    if doc_store.get("bind") and isinstance(doc_store["bind"], dict):
        pass
    from timing import maybe_timer

    with maybe_timer(timer, "stamp_id_props"):
        arm_obj[PROP_DOC] = json.dumps(doc_store, separators=(",", ":"), ensure_ascii=False)
        arm_obj[PROP_RUN] = run_id
        try:
            arm_obj[PROP_IMPORT_SNAPSHOT] = json.dumps(
                {
                    "tracks": doc_store.get("tracks") or [],
                    "duration": doc_store.get("duration"),
                },
                separators=(",", ":"),
                ensure_ascii=False,
            )
        except Exception:
            pass
        arm_obj["gr2lab_fps"] = float(fps)
        arm_obj["gr2lab_y_up_display"] = bool(y_up_display)
        arm_obj["gr2lab_has_bind"] = bool(bind_by_name)
        arm_obj["gr2lab_source_interp"] = str(doc.get("source_interp") or "")
        if doc.get("densify_fps") is not None:
            arm_obj["gr2lab_densify_fps"] = float(doc.get("densify_fps"))
        arm_obj["gr2lab_import_densified"] = int(densify_info.get("densified") or 0)
        if template_path:
            arm_obj[PROP_TEMPLATE_PATH] = str(Path(template_path).resolve())
            remember_template_path(template_path)

    # Bind (or clip-rest fallback) local matrices for basis conversion
    rest_local: Dict[str, Matrix] = {}
    for b in skeleton:
        name = b["name"]
        rest_local[name] = _bind_local_for_bone(b, bind_by_name)

    action = bpy.data.actions.new(name=f"GR2LAB_{run_id or 'anim'}")
    _assign_armature_action(arm_obj, action)
    fcurves = _ensure_action_fcurves(arm_obj, action)

    scene = context.scene
    scene.render.fps = int(round(fps))
    scene.frame_start = 1
    scene.frame_end = max(1, int(math.ceil(_sec_to_frame(duration, fps))))

    _t_keys = time.perf_counter()
    for bone_i, b in enumerate(skeleton):
        name = b["name"]
        if progress and bone_i % max(1, len(skeleton) // 24) == 0:
            progress.step(
                60 + int(38 * bone_i / max(1, len(skeleton))),
                f"Bone keys {bone_i + 1}/{len(skeleton)}: {name}",
            )
        pb = arm_obj.pose.bones.get(name)
        if not pb:
            continue
        pb.rotation_mode = "QUATERNION"
        tr = tracks.get(name) or {}
        rmat = rest_local[name]
        rinv = rmat.inverted()

        pos = tr.get("position") or {}
        ori = tr.get("orientation") or {}
        scl = tr.get("scale") or {}

        # Sample helpers вЂ” linear / slerp (matches site; game needs Degree=1 for these samples)
        def sample_vec(ch, t, n, default):
            ts = [float(x) for x in (ch.get("times") or [])]
            vs = ch.get("values") or []
            if not ts or not vs:
                return list(default)
            if len(ts) == 1:
                return list(vs[0])
            if t <= ts[0]:
                return list(vs[0])
            if t >= ts[-1]:
                return list(vs[-1])
            for i in range(len(ts) - 1):
                if ts[i] <= t <= ts[i + 1]:
                    span = ts[i + 1] - ts[i]
                    u = 0.0 if span <= 1e-12 else (t - ts[i]) / span
                    a, b = vs[i], vs[i + 1]
                    return [float(a[j]) + (float(b[j]) - float(a[j])) * u for j in range(n)]
            return list(vs[-1])

        def sample_quat(ch, t):
            ts = [float(x) for x in (ch.get("times") or [])]
            vs = ch.get("values") or []
            if not ts or not vs:
                return [0.0, 0.0, 0.0, 1.0]
            if len(ts) == 1:
                return list(vs[0])
            if t <= ts[0]:
                return list(vs[0])
            if t >= ts[-1]:
                return list(vs[-1])
            for i in range(len(ts) - 1):
                if ts[i] <= t <= ts[i + 1]:
                    span = ts[i + 1] - ts[i]
                    u = 0.0 if span <= 1e-12 else (t - ts[i]) / span
                    qa = _quat_gr_to_bl(vs[i])
                    qb = _quat_gr_to_bl(vs[i + 1])
                    qb.make_compatible(qa)
                    q = qa.slerp(qb, u)
                    return _quat_bl_to_gr(q)
            return list(vs[-1])

        # For constant channels, only need one key (t=0)
        pos_mode = pos.get("edit_mode") or "none"
        ori_mode = ori.get("edit_mode") or "none"
        scl_mode = scl.get("edit_mode") or "none"

        def channel_times(ch, mode):
            # constant / none: single bias key (Save cannot rewrite those formats).
            # k16_offsets: full dequantized keys for playback (foot IK / Root locomotion).
            # Export collapses untouched k16 display keys back to bias-only.
            if mode in ("constant", "none"):
                return [0.0]
            ts = [float(t) for t in (ch.get("times") or [0.0])]
            return ts if ts else [0.0]

        # Key EACH channel only on its own times — never union.
        # (Union bloated float position past GR2 capacity on export.)
        # Playback: site uses linear lerp/slerp between knots — use LINEAR
        # F-curves (not Bezier, not CONSTANT step-hold).
        def basis_trs(t):
            pt = sample_vec(pos, t, 3, b.get("rest_translation") or [0, 0, 0])
            qt = sample_quat(ori, t)
            st = sample_vec(scl, t, 3, b.get("rest_scale") or [1, 1, 1])
            key_local = _trs_matrix(pt, qt, st)
            basis = rinv @ key_local
            return basis.decompose()

        def bulk_prop(prop, times_list, pick):
            frames = []
            comps = None
            for t in times_list:
                loc, rot, sc = basis_trs(t)
                vec = pick(loc, rot, sc)
                if comps is None:
                    comps = [[] for _ in range(len(vec))]
                frames.append(_sec_to_frame(t, fps))
                for i, v in enumerate(vec):
                    comps[i].append(float(v))
            if frames and comps:
                _bulk_fcurve_channel(fcurves, name, prop, frames, comps)

        loc0, rot0, sc0 = basis_trs(0.0)
        pb.location = loc0
        pb.rotation_quaternion = rot0
        pb.scale = sc0

        bulk_prop(
            "location",
            channel_times(pos, pos_mode if pos_mode not in ("none",) else "constant"),
            lambda loc, rot, sc: (loc.x, loc.y, loc.z),
        )
        bulk_prop(
            "rotation_quaternion",
            channel_times(ori, ori_mode if ori_mode not in ("none",) else "constant"),
            lambda loc, rot, sc: (rot.w, rot.x, rot.y, rot.z),
        )

        if scl.get("editable") and scl_mode != "none":
            bulk_prop(
                "scale",
                channel_times(scl, scl_mode),
                lambda loc, rot, sc: (sc.x, sc.y, sc.z),
            )
        else:
            _bulk_fcurve_channel(
                fcurves,
                name,
                "scale",
                [_sec_to_frame(0.0, fps)],
                [[sc0.x], [sc0.y], [sc0.z]],
            )

        # LINEAR в‰€ Granny/site lerpВ·slerp. Avoid default Bezier (overshoot) and
        # CONSTANT (steppy/clingy). Stabilize quat signs against long-path flips.
        _finalize_pose_bone_fcurves(
            action, name, anim_data=arm_obj.animation_data
        )

        # Scale stays locked (v1). Loc/rot unlocked вЂ” site upgrades formats.
        pb.lock_scale = (True, True, True)
        pb["gr2lab_pos_mode"] = pos_mode
        pb["gr2lab_ori_mode"] = ori_mode
        pb["gr2lab_scl_mode"] = scl_mode
        # Full k16 location keys are display/playback only until the user edits them.
        if pos_mode == "k16_offsets":
            pb["gr2lab_k16_display_keys"] = True

    if timer is not None:
        timer.add("bone_keys", time.perf_counter() - _t_keys)

    _mode_set_safe(context, "OBJECT", active=arm_obj)
    scene.frame_set(1)
    if progress:
        progress.step(99, "Import done")
    return arm_obj


def import_gr2lab(
    context,
    filepath: str,
    *,
    fps: float = FPS_DEFAULT,
    y_up_display: bool = True,
    progress: Optional[Gr2LabProgress] = None,
) -> bpy.types.Object:
    if progress:
        progress.step(10, f"Reading {Path(filepath).name}…")
    doc = _load_doc(filepath)
    return import_gr2lab_from_doc(
        context,
        doc,
        fps=fps,
        y_up_display=y_up_display,
        template_path=filepath,
        progress=progress,
    )


def _assign_armature_action(arm_obj, action) -> None:
    """Assign action (+ slot on Blender 4.4+) so keyframe_insert writes F-curves."""
    if arm_obj is None or action is None:
        return
    if not arm_obj.animation_data:
        arm_obj.animation_data_create()
    ad = arm_obj.animation_data
    ad.action = action
    if not hasattr(ad, "action_slot"):
        return
    suitable = list(getattr(ad, "action_suitable_slots", None) or [])
    cur = getattr(ad, "action_slot", None)
    if suitable:
        if cur is None or cur not in suitable:
            ad.action_slot = suitable[0]
        return
    # Pose-bone keys live on the armature Object (OB), not Armature data (AR).
    if cur is not None:
        ad.action_slot = None
    slots = getattr(action, "slots", None)
    if slots is None:
        return
    owner_type = str(getattr(arm_obj, "id_type", "OBJECT") or "OBJECT")
    slot_name = (arm_obj.name or "Armature")[:63]
    try:
        slot = slots.new(id_type=owner_type, name=slot_name)
    except TypeError:
        try:
            slot = slots.new(owner_type, slot_name)
        except Exception:
            return
    ad.action_slot = slot


def _ensure_action_fcurves(arm_obj, action):
    """FCurve collection for new keys (slotted channelbag on Blender 4.4+/5, else action.fcurves)."""
    ad = getattr(arm_obj, "animation_data", None)
    if ad is None or action is None:
        return getattr(action, "fcurves", None)
    try:
        from bpy_extras import anim_utils

        ensure_slot = getattr(anim_utils, "action_ensure_channelbag_for_slot", None)
        slot = getattr(ad, "action_slot", None)
        if ensure_slot is not None and slot is not None:
            bag = ensure_slot(action, slot)
            if bag is not None and hasattr(bag, "fcurves"):
                return bag.fcurves
        ensure_ad = getattr(anim_utils, "animdata_ensure_channelbag_for_assigned_slot", None)
        if ensure_ad is not None:
            bag = ensure_ad(ad)
            if bag is not None and hasattr(bag, "fcurves"):
                return bag.fcurves
        get_bag = getattr(anim_utils, "animdata_get_channelbag_for_assigned_slot", None)
        if get_bag is not None:
            bag = get_bag(ad)
            if bag is not None and hasattr(bag, "fcurves"):
                return bag.fcurves
    except (ImportError, AttributeError, TypeError):
        pass
    layers = getattr(action, "layers", None)
    slot = getattr(ad, "action_slot", None) if ad else None
    if layers is not None and slot is not None:
        try:
            if len(layers) == 0:
                layers.new("Layer")
            layer = layers[0]
            strips = getattr(layer, "strips", None)
            if strips is not None:
                if len(strips) == 0:
                    try:
                        strips.new(type="KEYFRAME")
                    except TypeError:
                        strips.new()
                strip = strips[0]
                cb = getattr(strip, "channelbag", None)
                if callable(cb):
                    bag = cb(slot, ensure=True)
                    if bag is not None:
                        return bag.fcurves
        except Exception:
            pass
    return action.fcurves


def _bulk_fcurve_channel(fcurves, bone_name: str, prop: str, frames, component_values) -> None:
    """Write LINEAR F-curves via foreach_set (same keys as keyframe_insert)."""
    if not fcurves or not frames:
        return
    data_path = f'pose.bones["{bone_name}"].{prop}'
    n = len(frames)
    for index, values in enumerate(component_values):
        if len(values) != n:
            continue
        fc = None
        try:
            fc = fcurves.find(data_path, index=index)
        except TypeError:
            try:
                fc = fcurves.find(data_path, index)
            except Exception:
                fc = None
        if fc is None:
            try:
                fc = fcurves.new(data_path, index=index, action_group=bone_name)
            except TypeError:
                try:
                    fc = fcurves.new(data_path, index=index)
                except TypeError:
                    fc = fcurves.new(data_path, index)
        try:
            fc.keyframe_points.clear()
        except Exception:
            pass
        fc.keyframe_points.add(n)
        co = [0.0] * (n * 2)
        for i in range(n):
            co[i * 2] = float(frames[i])
            co[i * 2 + 1] = float(values[i])
        fc.keyframe_points.foreach_set("co", co)
        try:
            fc.update()
        except Exception:
            pass
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"


def _bulk_object_channel(fcurves, prop: str, frames, component_values) -> None:
    """Object-level F-curves (location/rotation/scale) via foreach_set."""
    if not fcurves or not frames:
        return
    n = len(frames)
    for index, values in enumerate(component_values):
        if len(values) != n:
            continue
        fc = None
        try:
            fc = fcurves.find(prop, index=index)
        except TypeError:
            try:
                fc = fcurves.find(prop, index)
            except Exception:
                fc = None
        if fc is None:
            try:
                fc = fcurves.new(prop, index=index)
            except TypeError:
                fc = fcurves.new(prop, index)
        try:
            fc.keyframe_points.clear()
        except Exception:
            pass
        fc.keyframe_points.add(n)
        co = [0.0] * (n * 2)
        for i in range(n):
            co[i * 2] = float(frames[i])
            co[i * 2 + 1] = float(values[i])
        fc.keyframe_points.foreach_set("co", co)
        try:
            fc.update()
        except Exception:
            pass
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"


def _iter_action_fcurves(action, *, anim_data=None):
    """Yield F-curves from legacy action.fcurves (≤4.5) and slotted channelbags (4.4+/5.x).

    Blender 4.4+/5.x RNA reuses the same Python proxy while iterating a
    channelbag's fcurves collection. Deduping by id(fc) then drops almost all
    keys (baked Action.* exports look like rest-pose in GR2). Materialize with
    list() and dedupe by (data_path, array_index) instead.
    """
    if not action:
        return
    seen: set[Tuple[str, int]] = set()

    def _emit(fcs):
        if fcs is None:
            return
        try:
            curves = list(fcs)
        except TypeError:
            return
        for fc in curves:
            try:
                key = (str(fc.data_path), int(fc.array_index))
            except Exception:
                continue
            if key in seen:
                continue
            seen.add(key)
            yield fc

    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        yield from _emit(legacy)

    if anim_data is not None:
        try:
            from bpy_extras import anim_utils

            bag = anim_utils.animdata_get_channelbag_for_assigned_slot(anim_data)
            if bag is not None:
                yield from _emit(getattr(bag, "fcurves", None))
        except (ImportError, AttributeError, TypeError):
            pass

    if hasattr(action, "layers"):
        for layer in action.layers:
            for strip in getattr(layer, "strips", []) or []:
                for bag in getattr(strip, "channelbags", []) or []:
                    yield from _emit(getattr(bag, "fcurves", None))


def _finalize_pose_bone_fcurves(action, bone_name: str, *, anim_data=None) -> None:
    """LINEAR interpolation + quaternion continuity (matches Granny/site lerpВ·slerp)."""
    if not action or not bone_name:
        return
    needle = f'pose.bones["{bone_name}"]'
    quat_fcs: Dict[int, Any] = {}
    for fc in _iter_action_fcurves(action, anim_data=anim_data):
        if needle not in fc.data_path:
            continue
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"
        if fc.data_path.endswith("rotation_quaternion"):
            quat_fcs[fc.array_index] = fc
    # Make consecutive quat keys take the short arc (w,x,y,z = indices 0..3)
    if not all(i in quat_fcs for i in range(4)):
        return
    w_fc, x_fc, y_fc, z_fc = quat_fcs[0], quat_fcs[1], quat_fcs[2], quat_fcs[3]
    n = len(w_fc.keyframe_points)
    if n < 2 or not (
        len(x_fc.keyframe_points) == n
        and len(y_fc.keyframe_points) == n
        and len(z_fc.keyframe_points) == n
    ):
        return
    prev = Quaternion(
        (
            w_fc.keyframe_points[0].co[1],
            x_fc.keyframe_points[0].co[1],
            y_fc.keyframe_points[0].co[1],
            z_fc.keyframe_points[0].co[1],
        )
    )
    for i in range(1, n):
        cur = Quaternion(
            (
                w_fc.keyframe_points[i].co[1],
                x_fc.keyframe_points[i].co[1],
                y_fc.keyframe_points[i].co[1],
                z_fc.keyframe_points[i].co[1],
            )
        )
        cur.make_compatible(prev)
        w_fc.keyframe_points[i].co[1] = cur.w
        x_fc.keyframe_points[i].co[1] = cur.x
        y_fc.keyframe_points[i].co[1] = cur.y
        z_fc.keyframe_points[i].co[1] = cur.z
        prev = cur


def _build_fcurve_index(
    action, *, anim_data=None
) -> Dict[str, Dict[Tuple[str, int], Any]]:
    """bone_name -> {(data_path, array_index): fcurve}."""
    out: Dict[str, Dict[Tuple[str, int], Any]] = {}
    prefix = 'pose.bones["'
    for fc in _iter_action_fcurves(action, anim_data=anim_data):
        dp = fc.data_path
        if not dp.startswith(prefix):
            continue
        end = dp.find('"]', len(prefix))
        if end < 0:
            continue
        bone = dp[len(prefix) : end]
        prop = dp[end + 2 :]
        if prop.startswith("."):
            prop = prop[1:]
        bucket = out.setdefault(bone, {})
        bucket[(prop, int(fc.array_index))] = fc
    return out


def _all_action_frames(action, *, anim_data=None) -> List[float]:
    frames = set()
    for fc in _iter_action_fcurves(action, anim_data=anim_data):
        for kp in fc.keyframe_points:
            frames.add(round(float(kp.co[0]), 6))
    return sorted(frames)


def _deselect_all_objects(context) -> None:
    """Deselect without bpy.ops (File Browser / wrong area breaks select_all.poll)."""
    for obj in context.view_layer.objects:
        try:
            obj.select_set(False)
        except RuntimeError:
            pass


def _temp_view3d_override(context, *, active=None, selected=None):
    """Build a VIEW_3D temp_override dict for mode_set / bake when context is thin."""
    win = context.window
    scr = win.screen if win else None
    area = next((a for a in (scr.areas if scr else []) if a.type == "VIEW_3D"), None)
    region = None
    if area is not None:
        region = next((r for r in area.regions if r.type == "WINDOW"), None)
        if region is None and area.regions:
            region = area.regions[-1]
    act = active or context.view_layer.objects.active
    sel = list(selected) if selected is not None else ([act] if act else [])
    override = {
        "window": win,
        "screen": scr,
        "area": area,
        "region": region,
        "active_object": act,
        "object": act,
        "selected_objects": sel,
        "selected_editable_objects": sel,
    }
    return {k: v for k, v in override.items() if v is not None}


def _mode_set_safe(context, mode: str, *, active=None) -> None:
    """object.mode_set with VIEW_3D override fallback (import from File Browser)."""
    if active is not None:
        context.view_layer.objects.active = active
        try:
            active.select_set(True)
        except RuntimeError:
            pass
    try:
        bpy.ops.object.mode_set(mode=mode)
        return
    except RuntimeError:
        pass
    override = _temp_view3d_override(context, active=active)
    with context.temp_override(**override):
        bpy.ops.object.mode_set(mode=mode)


def _resolve_action(arm_obj) -> Any:
    """Active action on armature (NLA strip fallback when action slot is empty)."""
    ad = arm_obj.animation_data if arm_obj else None
    if not ad:
        return None
    if ad.action:
        return ad.action
    if ad.nla_tracks:
        for track in ad.nla_tracks:
            if track.mute:
                continue
            for strip in track.strips:
                if strip.mute or not strip.action:
                    continue
                return strip.action
    return None


def _export_frame_list(context, arm_obj, action) -> List[float]:
    """Every scene frame in range + F-curve/NLA key times (what you see when scrubbing)."""
    scene = context.scene
    start = int(scene.frame_start)
    end = int(scene.frame_end)
    if end < start:
        start, end = end, start
    frames: set = set(range(start, end + 1))
    ad = arm_obj.animation_data if arm_obj else None
    for fr in _all_action_frames(action, anim_data=ad):
        frames.add(int(round(fr)))
    if ad and ad.nla_tracks:
        for track in ad.nla_tracks:
            if track.mute:
                continue
            for strip in track.strips:
                if strip.mute or not strip.action:
                    continue
                base = float(strip.action_frame_start or 0.0)
                for fr in _all_action_frames(strip.action):
                    frames.add(int(round(strip.frame_start + fr - base)))
    return sorted(float(f) for f in frames) if frames else [1.0]


def _imported_clip_frame_end(arm_obj, scene) -> Optional[int]:
    """Last scene frame of the imported GR2 clip, or None if not an import."""
    if not arm_obj or not scene:
        return None
    raw_fp = arm_obj.get(PROP_IMPORT_FP)
    if not raw_fp:
        return None
    try:
        fp = json.loads(raw_fp) if isinstance(raw_fp, str) else raw_fp
        dur = float((fp or {}).get("duration") or 0)
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if dur <= 0:
        return None
    fps = float(arm_obj.get("gr2lab_fps") or scene.render.fps or FPS_DEFAULT)
    start = int(scene.frame_start)
    n = max(2, int(round(dur * fps)) + 1)
    return start + n - 1


def _import_locked_frame_list(
    context, arm_obj, action
) -> List[float]:
    """Scene/NLA/F-curve frames, capped to the imported GR2 duration when present."""
    frames: set = set(_export_frame_list(context, arm_obj, action))
    fps = float(
        arm_obj.get("gr2lab_fps") or context.scene.render.fps or FPS_DEFAULT
    )
    start = int(context.scene.frame_start)
    lock_end = _imported_clip_frame_end(arm_obj, context.scene)
    raw_fp = arm_obj.get(PROP_IMPORT_FP) if arm_obj else None
    if raw_fp:
        try:
            fp = json.loads(raw_fp) if isinstance(raw_fp, str) else raw_fp
            dur = float((fp or {}).get("duration") or 0)
            if dur > 0:
                n = max(2, int(round(dur * fps)) + 1)
                for i in range(n):
                    frames.add(float(start + i))
        except (TypeError, ValueError, json.JSONDecodeError):
            pass
    if lock_end is not None:
        frames = {f for f in frames if start - 1e-6 <= float(f) <= float(lock_end) + 1e-6}
    return sorted(frames) if frames else [1.0]


def _frames_for_props(fcs: Dict[Tuple[str, int], Any], props: Sequence[str]) -> List[float]:
    frames = set()
    for (prop, _idx), fc in fcs.items():
        if prop not in props:
            continue
        for kp in fc.keyframe_points:
            frames.add(round(float(kp.co[0]), 6))
    return sorted(frames)


def _v3_close(a: Sequence[float], b: Sequence[float], eps: float = 1e-5) -> bool:
    return all(abs(float(a[i]) - float(b[i])) <= eps for i in range(3))


def _quat_close(a: Sequence[float], b: Sequence[float], eps: float = 0.99999) -> bool:
    if len(a) < 4 or len(b) < 4:
        return False
    dot = abs(
        float(a[0]) * float(b[0])
        + float(a[1]) * float(b[1])
        + float(a[2]) * float(b[2])
        + float(a[3]) * float(b[3])
    )
    return dot >= eps


def _eval_prop(
    fcs: Dict[Tuple[str, int], Any],
    prop: str,
    n: int,
    frame: float,
    defaults: Sequence[float],
) -> List[float]:
    vals = []
    for i in range(n):
        fc = fcs.get((prop, i))
        if fc is not None:
            vals.append(float(fc.evaluate(frame)))
        else:
            vals.append(float(defaults[i]))
    return vals


def _pose_local_trs(pb) -> Tuple[List[float], List[float], List[float]]:
    """Parent-relative local TRS from evaluated pose (includes constraints)."""
    if pb.parent:
        local = pb.parent.matrix.inverted() @ pb.matrix
    else:
        local = pb.matrix.copy()
    return _mat_to_trs(local)


def _constraint_affected_bones(arm_obj) -> set:
    """Bones with constraints, their targets, and IK chain members."""
    affected = set()
    for pb in arm_obj.pose.bones:
        for c in pb.constraints:
            affected.add(pb.name)
            st = getattr(c, "subtarget", None) or ""
            if st:
                affected.add(st)
            if c.type == "IK":
                chain = max(1, int(getattr(c, "chain_count", 1) or 1))
                cur = pb
                for _ in range(chain):
                    if not cur:
                        break
                    affected.add(cur.name)
                    cur = cur.parent
    return affected


def _parse_arm_doc(arm_obj) -> Optional[Dict[str, Any]]:
    """Read stamped gr2lab_json from an armature, or None if missing."""
    if not arm_obj:
        return None
    raw = arm_obj.get(PROP_DOC)
    if not raw:
        return None
    if isinstance(raw, dict):
        return dict(raw)
    doc = json.loads(raw)
    if not isinstance(doc, dict):
        raise ValueError(f"{arm_obj.name}: gr2lab_json is not an object")
    return doc


def _iter_stamped_armatures(context, *, exclude=None):
    """Scene armatures that carry GR2LAB bridge data."""
    exclude_name = exclude.name if exclude else None
    for obj in context.scene.objects:
        if obj.type != "ARMATURE":
            continue
        if exclude_name and obj.name == exclude_name:
            continue
        if obj.get(PROP_DOC):
            yield obj


def _addon_prefs():
    addon = bpy.context.preferences.addons.get(__package__)
    if addon is None:
        addon = bpy.context.preferences.addons.get("gr2lab_blender")
    return addon.preferences if addon else None


def remember_template_path(path: str) -> None:
    """Persist last .gr2lab template so Export can run with one click."""
    if not path:
        return
    try:
        resolved = str(Path(path).expanduser().resolve())
    except OSError:
        resolved = str(path)
    if not Path(resolved).is_file():
        return
    prefs = _addon_prefs()
    if prefs is not None and hasattr(prefs, "last_template"):
        prefs.last_template = resolved
    try:
        bpy.context.window_manager[WM_LAST_TEMPLATE] = resolved
    except Exception:
        pass


def _is_gr2lab_path(path: Path) -> bool:
    low = path.name.lower()
    return low.endswith(".gr2lab") or low.endswith(".gr2lab.json")


def _blend_dir_gr2lab_files() -> List[Path]:
    """*.gr2lab next to the current .blend (newest first)."""
    if not bpy.data.filepath:
        return []
    parent = Path(bpy.data.filepath).parent
    if not parent.is_dir():
        return []
    found: List[Path] = []
    for p in parent.iterdir():
        if p.is_file() and _is_gr2lab_path(p):
            found.append(p)
    found.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return found


def auto_template_path(context, arm_obj=None) -> Optional[str]:
    """
    Find a .gr2lab without the user picking one.
    Order: armature path в†’ prefs в†’ window manager в†’ single/newest file next to .blend
    """
    candidates: List[str] = []
    if arm_obj:
        stored = arm_obj.get(PROP_TEMPLATE_PATH)
        if stored:
            candidates.append(str(stored))
    prefs = _addon_prefs()
    last_tpl = getattr(prefs, "last_template", None) if prefs else None
    if last_tpl:
        candidates.append(str(last_tpl))
    try:
        wm_path = bpy.context.window_manager.get(WM_LAST_TEMPLATE)
        if wm_path:
            candidates.append(str(wm_path))
    except Exception:
        pass
    for p in _blend_dir_gr2lab_files():
        candidates.append(str(p))

    seen = set()
    for raw in candidates:
        if not raw or raw in seen:
            continue
        seen.add(raw)
        path = Path(raw).expanduser()
        if path.is_file() and _is_gr2lab_path(path):
            return str(path.resolve())
    return None


def _is_synthesized_gr2lab_doc(doc: Dict[str, Any]) -> bool:
    """True for synthesize_gr2lab_from_armature stamps (run_id blender / empty)."""
    rid = (doc.get("run_id") or "").strip()
    return not rid or rid == "blender"


def _pack_run_id(arm_obj) -> str:
    if not arm_obj:
        return ""
    for key in (PROP_PACK_RUN, PROP_RUN):
        raw = str(arm_obj.get(key) or "").strip()
        if raw and raw != "blender":
            return raw
    return ""


def _find_scene_template_armature(
    context, arm_obj, pack_run: str
) -> Optional[Tuple[Any, Dict[str, Any]]]:
    """Scene armature with matching pack run and a real (non-synthesized) template."""
    if not pack_run or not context:
        return None
    for obj in _iter_stamped_armatures(context, exclude=arm_obj):
        if _pack_run_id(obj) != pack_run:
            continue
        doc = _parse_arm_doc(obj)
        if doc and not _is_synthesized_gr2lab_doc(doc):
            return obj, doc
    return None


def peek_export_template_hint(context, arm_obj=None) -> Tuple[str, str]:
    """
    UI hint: (status, detail).
    status: 'native' | 'auto' | 'synthesize'
    """
    arm_obj = arm_obj or (context.view_layer.objects.active if context else None)
    if arm_obj and arm_obj.type == "ARMATURE" and _parse_arm_doc(arm_obj) is not None:
        active_doc = _parse_arm_doc(arm_obj)
        if active_doc and _is_synthesized_gr2lab_doc(active_doc):
            match = _find_scene_template_armature(
                context, arm_obj, _pack_run_id(arm_obj)
            )
            if match:
                return "auto", match[0].name
        rid = arm_obj.get(PROP_RUN) or ""
        return "native", str(rid)
    path = auto_template_path(context, arm_obj)
    if path:
        return "auto", Path(path).name
    stamped = list(_iter_stamped_armatures(context, exclude=arm_obj)) if context else []
    if len(stamped) == 1:
        return "auto", stamped[0].name
    if arm_obj and arm_obj.type == "ARMATURE":
        n = len(arm_obj.data.bones)
        return "synthesize", f"{n} bones"
    return "synthesize", ""


def _bone_rest_local_matrix(bone) -> Matrix:
    """Parent-relative rest matrix in armature space."""
    if bone.parent:
        return bone.parent.matrix_local.inverted() @ bone.matrix_local
    return bone.matrix_local.copy()


# Blender Z-up armature space в†’ Granny / BG3 Y-up
_RX_NEG_90 = Matrix.Rotation(math.radians(-90.0), 4, "X")


def _is_granny_armature_space(arm_obj) -> bool:
    """
    True when armature bone data is already Granny Y-up (GR2LAB Import).

    GR2LAB Import puts Granny locals into the armature and rotates the *object*
    +90В° X for Blender display. LSLib / Body_Base rigs keep Blender Z-up in the
    bones (Dummy_Root rest often ~90В° X) with no display offset вЂ” those need
    Blenderв†’Granny conversion on export.
    """
    if not arm_obj:
        return False
    if not arm_obj.get("gr2lab_y_up_display"):
        return False
    ex = abs(float(arm_obj.matrix_world.to_euler("XYZ").x))
    return abs(ex - math.radians(90.0)) < math.radians(20.0)


def _topo_bone_names(
    names: Sequence[str], parents: Dict[str, Optional[str]]
) -> List[str]:
    """Parents before children (needed for FK world build)."""
    name_set = set(names)
    remaining = set(names)
    ordered: List[str] = []
    while remaining:
        progress = False
        for name in list(remaining):
            p = parents.get(name) or None
            if not p or p not in name_set or p not in remaining:
                ordered.append(name)
                remaining.remove(name)
                progress = True
        if not progress:
            ordered.extend(sorted(remaining))
            break
    return ordered


def _blender_zup_locals_to_granny(
    parent_rel: Dict[str, Matrix],
    parents: Dict[str, Optional[str]],
) -> Dict[str, Tuple[List[float], List[float], List[float]]]:
    """
    Parent-relative Blender Z-up armature locals в†’ Granny Y-up parent-relative TRS.

    Builds Blender FK worlds, applies Rx(-90В°), re-extracts locals. Fixes Dummy_Root
    location that otherwise maps Blender horizontal motion onto Granny +Y (flies up).
    """
    order = _topo_bone_names(list(parent_rel.keys()), parents)
    worlds_bl: Dict[str, Matrix] = {}
    for name in order:
        local = parent_rel.get(name)
        if local is None:
            continue
        p = parents.get(name) or None
        worlds_bl[name] = (
            (worlds_bl[p] @ local) if p and p in worlds_bl else local.copy()
        )
    worlds_g = {n: _RX_NEG_90 @ w for n, w in worlds_bl.items()}
    out: Dict[str, Tuple[List[float], List[float], List[float]]] = {}
    for name in order:
        if name not in worlds_g:
            continue
        p = parents.get(name) or None
        if p and p in worlds_g:
            local = worlds_g[p].inverted() @ worlds_g[name]
        else:
            local = worlds_g[name]
        out[name] = _mat_to_trs(local)
    return out


def synthesize_gr2lab_from_armature(arm_obj, context) -> Tuple[Dict[str, Any], float]:
    """
    Build a .gr2lab document from a plain LSLib / Body_Base-like armature.
    No site template required вЂ” site Import uses Pack-from dump + bone-name match.

    Rests are converted Blender Z-up в†’ Granny Y-up (same as export sampling).
    """
    if not arm_obj or arm_obj.type != "ARMATURE":
        raise ValueError("Select an armature to export")
    fps = float(arm_obj.get("gr2lab_fps") or context.scene.render.fps or FPS_DEFAULT)
    scene = context.scene
    duration = max(0.0, (float(scene.frame_end) - 1.0) / fps)

    bl_rest: Dict[str, Matrix] = {}
    parents: Dict[str, Optional[str]] = {}
    order: List[str] = []
    for bone in arm_obj.data.bones:
        order.append(bone.name)
        bl_rest[bone.name] = _bone_rest_local_matrix(bone)
        parents[bone.name] = bone.parent.name if bone.parent else None

    if _is_granny_armature_space(arm_obj):
        granny_rest = {n: _mat_to_trs(m) for n, m in bl_rest.items()}
    else:
        granny_rest = _blender_zup_locals_to_granny(bl_rest, parents)

    skeleton: List[Dict[str, Any]] = []
    tracks: List[Dict[str, Any]] = []
    root_name = ""
    for i, name in enumerate(order):
        t, r, s = granny_rest.get(name) or ([0, 0, 0], [0, 0, 0, 1], [1, 1, 1])
        parent = parents.get(name) or ""
        if not parent and not root_name:
            root_name = name
        skeleton.append(
            {
                "name": name,
                "index": i,
                "parent_name": parent or None,
                "rest_translation": t,
                "rest_rotation": r,
                "rest_scale": s,
            }
        )
        tracks.append(
            {
                "name": name,
                "index": i,
                "position": {
                    "edit_mode": "float_controls",
                    "editable": True,
                    "times": [0.0],
                    "values": [t],
                },
                "orientation": {
                    "edit_mode": "float_controls",
                    "editable": True,
                    "times": [0.0],
                    "values": [r],
                },
                "scale": {
                    "edit_mode": "constant",
                    "editable": False,
                    "times": [0.0],
                    "values": [s],
                },
            }
        )

    if not skeleton:
        raise ValueError("Armature has no bones")

    doc: Dict[str, Any] = {
        "format": FORMAT_ID,
        "version": 1,
        "run_id": "blender",
        "source_gr2": "",
        "duration": float(duration),
        "root": root_name or skeleton[0]["name"],
        "skeleton": skeleton,
        "tracks": tracks,
    }
    return doc, fps


def resolve_export_template(
    context,
    arm_obj,
    *,
    template_armature=None,
    template_filepath: Optional[str] = None,
) -> Tuple[Dict[str, Any], float, str]:
    """
    Resolve (doc, fps, source_label) for export.

    Order: explicit file → explicit scene armature → native stamp (non-synthesized)
    → matching pack-run scene template → other stamped scene armatures
    → synthesized active stamp → auto file → synthesize from armature.
    """
    path = (template_filepath or "").strip()
    if path:
        doc = _load_doc(path)
        fps = float(arm_obj.get("gr2lab_fps") or context.scene.render.fps or FPS_DEFAULT)
        remember_template_path(path)
        if arm_obj:
            arm_obj[PROP_TEMPLATE_PATH] = str(Path(path).resolve())
        return doc, fps, Path(path).name

    if template_armature and getattr(template_armature, "type", None) == "ARMATURE":
        doc = _parse_arm_doc(template_armature)
        if doc is not None:
            fps = float(
                template_armature.get("gr2lab_fps")
                or arm_obj.get("gr2lab_fps")
                or context.scene.render.fps
                or FPS_DEFAULT
            )
            return doc, fps, template_armature.name

    active_doc = _parse_arm_doc(arm_obj)
    if active_doc is not None and not _is_synthesized_gr2lab_doc(active_doc):
        fps = float(arm_obj.get("gr2lab_fps") or context.scene.render.fps or FPS_DEFAULT)
        return active_doc, fps, "active armature"

    pack_run = _pack_run_id(arm_obj)
    match = _find_scene_template_armature(context, arm_obj, pack_run)
    if match:
        obj, doc = match
        fps = float(
            obj.get("gr2lab_fps")
            or arm_obj.get("gr2lab_fps")
            or context.scene.render.fps
            or FPS_DEFAULT
        )
        return doc, fps, obj.name

    stamped = list(_iter_stamped_armatures(context, exclude=arm_obj))
    for obj in stamped:
        doc = _parse_arm_doc(obj)
        if doc and not _is_synthesized_gr2lab_doc(doc):
            fps = float(
                obj.get("gr2lab_fps")
                or arm_obj.get("gr2lab_fps")
                or context.scene.render.fps
                or FPS_DEFAULT
            )
            return doc, fps, obj.name
    if len(stamped) == 1:
        doc = _parse_arm_doc(stamped[0])
        if doc is not None:
            fps = float(
                stamped[0].get("gr2lab_fps")
                or context.scene.render.fps
                or FPS_DEFAULT
            )
            return doc, fps, stamped[0].name

    if active_doc is not None:
        fps = float(arm_obj.get("gr2lab_fps") or context.scene.render.fps or FPS_DEFAULT)
        return active_doc, fps, "active armature"

    path = auto_template_path(context, arm_obj) or ""
    if path:
        doc = _load_doc(path)
        fps = float(arm_obj.get("gr2lab_fps") or context.scene.render.fps or FPS_DEFAULT)
        remember_template_path(path)
        if arm_obj:
            arm_obj[PROP_TEMPLATE_PATH] = str(Path(path).resolve())
        return doc, fps, Path(path).name

    # Naked LSLib / Body_Base-like rig: build bridge from the armature itself
    doc, fps = synthesize_gr2lab_from_armature(arm_obj, context)
    return doc, fps, "synthesize"


def stamp_gr2lab_on_armature(
    arm_obj,
    doc: Dict[str, Any],
    *,
    fps: float = FPS_DEFAULT,
    y_up_display: Optional[bool] = None,
    template_path: Optional[str] = None,
) -> None:
    """Stamp bridge metadata onto an armature without rebuilding bones."""
    if not arm_obj or arm_obj.type != "ARMATURE":
        raise ValueError("Select an armature to attach GR2LAB data")
    doc_store = dict(doc)
    bind_by_name = _bind_map(doc_store)
    skeleton = _skeleton_with_bind_parents(doc_store.get("skeleton") or [], bind_by_name)
    doc_store["skeleton"] = skeleton
    doc_store["format"] = FORMAT_ID
    arm_obj[PROP_DOC] = json.dumps(doc_store)
    arm_obj[PROP_RUN] = doc_store.get("run_id") or ""
    arm_obj["gr2lab_fps"] = float(fps)
    if y_up_display is not None:
        arm_obj["gr2lab_y_up_display"] = bool(y_up_display)
    elif "gr2lab_y_up_display" not in arm_obj:
        # False for naked LSLib attach/synthesize; Import GR2LAB sets True explicitly
        arm_obj["gr2lab_y_up_display"] = False
    arm_obj["gr2lab_has_bind"] = bool(bind_by_name)
    if template_path:
        try:
            arm_obj[PROP_TEMPLATE_PATH] = str(Path(template_path).resolve())
            remember_template_path(template_path)
        except OSError:
            arm_obj[PROP_TEMPLATE_PATH] = str(template_path)


def _sample_quat_channel(ch: dict, t: float) -> Optional[List[float]]:
    times = [float(x) for x in (ch.get("times") or [])]
    vals = ch.get("values") or []
    if not vals:
        return None
    if len(times) == 1 or t <= times[0]:
        return list(vals[0])
    if t >= times[-1]:
        return list(vals[-1])
    i = bisect_right(times, t) - 1
    i = max(0, min(i, len(times) - 2))
    span = times[i + 1] - times[i]
    u = 0.0 if span <= 1e-12 else (t - times[i]) / span
    qa = _quat_gr_to_bl(vals[i])
    qb = _quat_gr_to_bl(vals[i + 1])
    qb.make_compatible(qa)
    return _quat_bl_to_gr(qa.slerp(qb, u))


def _sample_vec_channel(ch: dict, t: float) -> Optional[List[float]]:
    times = [float(x) for x in (ch.get("times") or [])]
    vals = ch.get("values") or []
    if not vals:
        return None
    if len(times) == 1 or t <= times[0]:
        return list(vals[0])
    if t >= times[-1]:
        return list(vals[-1])
    i = bisect_right(times, t) - 1
    i = max(0, min(i, len(times) - 2))
    span = times[i + 1] - times[i]
    u = 0.0 if span <= 1e-12 else (t - times[i]) / span
    a, b = vals[i], vals[i + 1]
    return [float(a[j]) + (float(b[j]) - float(a[j])) * u for j in range(3)]


def _count_motion_delta_bones(tmpl_doc: dict, export_doc: dict) -> int:
    """How export differs from the import snapshot (duration, keys, pose samples)."""
    t_dur = float(tmpl_doc.get("duration") or 0.0)
    e_dur = float(export_doc.get("duration") or 0.0)
    if abs(t_dur - e_dur) > 1e-4:
        return max(1, len(export_doc.get("tracks") or []))

    tm = {t["name"]: t for t in (tmpl_doc.get("tracks") or []) if t.get("name")}
    probes = [0.0]
    if e_dur > 0:
        probes.extend([e_dur * 0.25, e_dur * 0.5, e_dur * 0.75, max(0.0, e_dur - 1e-4)])
    probes = sorted(set(probes))
    changed = 0
    for tr in export_doc.get("tracks") or []:
        name = tr.get("name")
        if not name or name not in tm:
            continue
        tb = tm[name]
        bone_changed = False
        for ch_key, is_quat in (("orientation", True), ("position", False)):
            ea = tr.get(ch_key) or {}
            eb = tb.get(ch_key) or {}
            ta = [float(x) for x in (ea.get("times") or [])]
            tb_t = [float(x) for x in (eb.get("times") or [])]
            if len(ta) != len(tb_t):
                bone_changed = True
                break
            if ta and tb_t and max(abs(a - b) for a, b in zip(ta, tb_t)) > 1e-3:
                bone_changed = True
                break
            sampler = _sample_quat_channel if is_quat else _sample_vec_channel
            close = (
                (lambda a, b: _quat_close(a, b, 0.9995))
                if is_quat
                else (lambda a, b: _v3_close(a, b, 2e-4))
            )
            for t in probes:
                sa = sampler(ea, t)
                sb = sampler(eb, t)
                if sa and sb and not close(sa, sb):
                    bone_changed = True
                    break
            if bone_changed:
                break
        if bone_changed:
            changed += 1
    return changed


def _trim_channel_to_duration(ch: dict, max_t: float) -> dict:
    out = dict(ch)
    times = [float(t) for t in (ch.get("times") or [])]
    vals = ch.get("values") or []
    if not times:
        return out
    nt, nv = [], []
    for t, v in zip(times, vals):
        if float(t) <= max_t + TIME_EPS:
            nt.append(float(t))
            nv.append(v)
    if not nt:
        nt, nv = [0.0], [vals[0]]
    out["times"] = nt
    out["values"] = nv
    return out


def _trim_tracks_to_duration(tracks: List[dict], duration: float) -> None:
    for tr in tracks:
        for key in ("position", "orientation", "scale"):
            ch = tr.get(key)
            if ch:
                tr[key] = _trim_channel_to_duration(ch, duration)


def _granny_local_from_pose(
    name: str,
    fr: float,
    *,
    pb,
    fcs: Dict,
    rest_local: Dict[str, Matrix],
    identity_loc,
    identity_quat,
    identity_scl,
    use_matrix_eval: bool,
) -> Matrix:
    """Inverse of import: basis F-curves -> rest @ basis = Granny local (preferred)."""
    if use_matrix_eval and pb is not None:
        if pb.parent:
            return pb.parent.matrix.inverted() @ pb.matrix
        return pb.matrix.copy()
    loc = _eval_prop(fcs, "location", 3, fr, identity_loc)
    qwxyz = _eval_prop(fcs, "rotation_quaternion", 4, fr, identity_quat)
    scl = _eval_prop(fcs, "scale", 3, fr, identity_scl)
    w, x, y, z = qwxyz
    nrm = math.sqrt(w * w + x * x + y * y + z * z)
    if nrm > 1e-12:
        w, x, y, z = w / nrm, x / nrm, y / nrm, z / nrm
    else:
        w, x, y, z = 1.0, 0.0, 0.0, 0.0
    basis = Matrix.LocRotScale(
        Vector(loc), Quaternion((w, x, y, z)), Vector(scl)
    )
    return rest_local[name] @ basis


def _nla_active_strips(ad) -> List[Any]:
    """Unmuted NLA strips that carry an action."""
    if not ad or not ad.nla_tracks:
        return []
    out: List[Any] = []
    for track in ad.nla_tracks:
        if track.mute:
            continue
        for strip in track.strips:
            if strip.mute or not strip.action:
                continue
            out.append(strip)
    return out


def _nla_strips_overlap(a, b) -> bool:
    return float(a.frame_start) < float(b.frame_end) and float(b.frame_start) < float(
        a.frame_end
    )


def _nla_strips_active(arm_obj) -> bool:
    """True when unmuted NLA strips will influence the visible pose."""
    ad = arm_obj.animation_data if arm_obj else None
    if not ad:
        return False
    strips = _nla_active_strips(ad)
    if not strips:
        return False
    # use_nla blends strips; without an action the strips are the only source.
    return bool(ad.use_nla) or not ad.action


def _nla_needs_flatten(arm_obj) -> bool:
    """True when multiple NLA strips must be blended (multi-track / overlap / retime)."""
    ad = arm_obj.animation_data if arm_obj else None
    if not ad:
        return False
    strips = _nla_active_strips(ad)
    if len(strips) <= 1:
        if not strips:
            return False
        scale = float(getattr(strips[0], "scale", 1.0) or 1.0)
        return abs(scale - 1.0) > 1e-5
    for i, a in enumerate(strips):
        if abs(float(getattr(a, "scale", 1.0) or 1.0) - 1.0) > 1e-5:
            return True
        for b in strips[i + 1:]:
            if _nla_strips_overlap(a, b):
                return True
    active_tracks = 0
    for track in ad.nla_tracks:
        if track.mute:
            continue
        if any(not s.mute and s.action for s in track.strips):
            active_tracks += 1
    return active_tracks > 1


def _armature_has_constraints(arm_obj) -> bool:
    """True when the armature object or any pose bone has constraints."""
    if not arm_obj or arm_obj.type != "ARMATURE":
        return False
    if len(arm_obj.constraints) > 0:
        return True
    if arm_obj.pose:
        for pb in arm_obj.pose.bones:
            if len(pb.constraints) > 0:
                return True
    return False


def _export_should_bake(arm_obj, mode: str = "AUTO") -> bool:
    """
    ALWAYS: destructive visual flatten (NLA + constraints → one Action).
    AUTO: flatten when unmuted NLA strips and/or any constraints are present.
    NEVER: no mutation — F-curves + constraint-affected depsgraph eval.
    """
    m = (mode or "AUTO").upper()
    if m == "ALWAYS":
        return True
    if m == "NEVER":
        return False
    return _nla_strips_active(arm_obj) or _armature_has_constraints(arm_obj)


def _export_sampling_hint(arm_obj, bake_mode: str = "AUTO") -> str:
    """Short label for export UI / stats."""
    if _export_should_bake(arm_obj, bake_mode):
        return "visual_flatten"
    if _nla_strips_active(arm_obj):
        if _nla_needs_flatten(arm_obj):
            return "nla_eval_blend"
        return "nla_eval_strip"
    if _armature_has_constraints(arm_obj):
        return "fcurve_constraint_eval"
    return "fcurves"


def _bake_action_frame_range(action) -> Optional[Tuple[int, int]]:
    if action is None:
        return None
    if hasattr(action, "curve_frame_range"):
        lo, hi = action.curve_frame_range
        if hi >= lo and any(True for _ in _iter_action_fcurves(action)):
            return int(round(lo)), int(round(hi))
        if hi >= lo and not hasattr(action, "layers"):
            return int(round(lo)), int(round(hi))
    lo = hi = None
    for fc in _iter_action_fcurves(action):
        for kp in fc.keyframe_points:
            f = kp.co[0]
            lo = f if lo is None else min(lo, f)
            hi = f if hi is None else max(hi, f)
    if lo is None:
        return None
    return int(round(lo)), int(round(hi))


def _bake_nla_frame_range(anim) -> Optional[Tuple[int, int]]:
    if anim is None:
        return None
    lo = hi = None
    for track in anim.nla_tracks:
        if track.mute:
            continue
        for strip in track.strips:
            if strip.mute:
                continue
            lo = strip.frame_start if lo is None else min(lo, strip.frame_start)
            hi = strip.frame_end if hi is None else max(hi, strip.frame_end)
    if lo is None:
        return None
    return int(round(lo)), int(round(hi))


def _bake_union_ranges(*ranges: Optional[Tuple[int, int]]) -> Optional[Tuple[int, int]]:
    lo = hi = None
    for r in ranges:
        if not r:
            continue
        a, b = r
        lo = a if lo is None else min(lo, a)
        hi = b if hi is None else max(hi, b)
    if lo is None:
        return None
    return int(lo), int(hi)


def determine_bake_range(obj, scene) -> Tuple[int, int]:
    """Frame range from Action ∪ NLA strips, else scene range.

    Imported GR2 clips stay locked to the source duration so bake/export
    cannot stretch 9.000 s → 9.033 s from a longer scene range.
    """
    anim = obj.animation_data
    action_range = _bake_action_frame_range(anim.action if anim else None)
    nla_range = _bake_nla_frame_range(anim)
    combined = _bake_union_ranges(action_range, nla_range)
    if combined:
        lo, hi = combined
    else:
        lo, hi = int(scene.frame_start), int(scene.frame_end)
    lock_end = _imported_clip_frame_end(obj, scene)
    if lock_end is not None:
        lo = int(scene.frame_start)
        hi = min(int(hi), int(lock_end))
        if hi < lo:
            hi = lo
    return lo, hi


def _prepare_anim_for_eval(obj) -> None:
    anim = obj.animation_data
    if anim is None:
        return
    if getattr(anim, "use_tweak_mode", False):
        anim.use_tweak_mode = False
    anim.use_nla = True


def _clear_nla_tracks(obj) -> int:
    anim = obj.animation_data
    if anim is None:
        return 0
    if getattr(anim, "use_tweak_mode", False):
        anim.use_tweak_mode = False
    count = len(anim.nla_tracks)
    while anim.nla_tracks:
        anim.nla_tracks.remove(anim.nla_tracks[0])
    return count


def _clear_all_constraints(obj) -> Tuple[int, int]:
    obj_count = len(obj.constraints)
    while obj.constraints:
        obj.constraints.remove(obj.constraints[0])
    bone_count = 0
    if obj.pose:
        for pb in obj.pose.bones:
            bone_count += len(pb.constraints)
            while pb.constraints:
                pb.constraints.remove(pb.constraints[0])
    return obj_count, bone_count


def _decompose_local(mat: Matrix, rotation_mode: str):
    loc, rot_quat, scale = mat.decompose()
    if rotation_mode == "QUATERNION":
        rot = rot_quat
    elif rotation_mode == "AXIS_ANGLE":
        axis, angle = rot_quat.to_axis_angle()
        rot = (angle, axis.x, axis.y, axis.z)
    else:
        rot = rot_quat.to_euler(rotation_mode)
    return loc, rot, scale


def _apply_bone_transform(pb, loc, rot, scale, rotation_mode: str) -> None:
    pb.location = loc
    pb.scale = scale
    if rotation_mode == "QUATERNION":
        pb.rotation_quaternion = rot
    elif rotation_mode == "AXIS_ANGLE":
        pb.rotation_axis_angle = rot
    else:
        pb.rotation_euler = rot


def _keyframe_bone(pb, frame: int) -> None:
    group = pb.name
    pb.keyframe_insert(data_path="location", frame=frame, group=group)
    pb.keyframe_insert(data_path="scale", frame=frame, group=group)
    mode = pb.rotation_mode
    if mode == "QUATERNION":
        pb.keyframe_insert(data_path="rotation_quaternion", frame=frame, group=group)
    elif mode == "AXIS_ANGLE":
        pb.keyframe_insert(data_path="rotation_axis_angle", frame=frame, group=group)
    else:
        pb.keyframe_insert(data_path="rotation_euler", frame=frame, group=group)


def _keyframe_object(obj, frame: int) -> None:
    obj.keyframe_insert(data_path="location", frame=frame)
    obj.keyframe_insert(data_path="scale", frame=frame)
    mode = obj.rotation_mode
    if mode == "QUATERNION":
        obj.keyframe_insert(data_path="rotation_quaternion", frame=frame)
    elif mode == "AXIS_ANGLE":
        obj.keyframe_insert(data_path="rotation_axis_angle", frame=frame)
    else:
        obj.keyframe_insert(data_path="rotation_euler", frame=frame)


def _find_coll_fcurve(fcurves, data_path: str, index: int):
    if fcurves is None:
        return None
    try:
        return fcurves.find(data_path, index=index)
    except TypeError:
        try:
            return fcurves.find(data_path, index)
        except Exception:
            return None


_BEZT_IPO_LIN = 1  # DNA IpoInterpolationMode; foreach_set rejects "LINEAR" strings


def _fcurve_set_linear_bulk(fc, n: int) -> None:
    """LINEAR via int enum only. String foreach_set TypeError can smash BezTriples."""
    kps = fc.keyframe_points
    for payload in (
        [_BEZT_IPO_LIN] * n,
        array("i", [_BEZT_IPO_LIN]) * n,
        array("b", [_BEZT_IPO_LIN] * n),
    ):
        try:
            kps.foreach_set("interpolation", payload)
            return
        except Exception:
            continue
    for kp in kps:
        kp.interpolation = "LINEAR"


def _fcurve_keys_match_samples(fc, frames, values) -> bool:
    """Read back first/mid/last keys so a fast write cannot silently keep rest pose."""
    try:
        kps = fc.keyframe_points
        n = len(frames)
        if len(kps) != n:
            return False
        probes = (0, n // 2, n - 1) if n >= 3 else range(n)
        for i in probes:
            co = kps[i].co
            if abs(float(co[0]) - float(frames[i])) > 0.51:
                return False
            if abs(float(co[1]) - float(values[i])) > 1e-3:
                return False
        return True
    except Exception:
        return False


def _fcurve_replace_keys(fc, frames, values) -> bool:
    """Replace all keys in one RNA call. True only when read-back matches samples."""
    if fc is None or not frames:
        return False
    n = len(frames)
    if len(values) != n:
        return False
    kps = fc.keyframe_points
    try:
        kps.clear()
    except Exception:
        pass
    try:
        if len(kps) != 0:
            kps.clear()
    except Exception:
        pass
    try:
        kps.add(n)
    except Exception:
        return False
    if len(kps) != n:
        return False
    co = [0.0] * (n * 2)
    for i in range(n):
        co[i * 2] = float(frames[i])
        co[i * 2 + 1] = float(values[i])
    try:
        kps.foreach_set("co", co)
    except Exception:
        return False
    try:
        fc.update()
    except Exception:
        pass
    try:
        _fcurve_set_linear_bulk(fc, n)
    except Exception:
        pass
    return _fcurve_keys_match_samples(fc, frames, values)


def _pack_baked_bone_channels(pb, frames, bone_samples):
    """Parallel loc/rot/scale arrays for one bone (quat signs made compatible)."""
    name = pb.name
    mode = pb.rotation_mode
    n = len(frames)
    loc_cs = [[0.0] * n for _ in range(3)]
    scl_cs = [[0.0] * n for _ in range(3)]
    if mode == "QUATERNION":
        rot_cs = [[0.0] * n for _ in range(4)]
        rot_prop = "rotation_quaternion"
    elif mode == "AXIS_ANGLE":
        rot_cs = [[0.0] * n for _ in range(4)]
        rot_prop = "rotation_axis_angle"
    else:
        rot_cs = [[0.0] * n for _ in range(3)]
        rot_prop = "rotation_euler"
    prev_q = None
    for i, f in enumerate(frames):
        loc, rot, scale, _mode = bone_samples[f][name]
        loc_cs[0][i] = float(loc.x)
        loc_cs[1][i] = float(loc.y)
        loc_cs[2][i] = float(loc.z)
        scl_cs[0][i] = float(scale.x)
        scl_cs[1][i] = float(scale.y)
        scl_cs[2][i] = float(scale.z)
        if mode == "QUATERNION":
            q = rot
            if prev_q is not None:
                q = q.copy()
                q.make_compatible(prev_q)
            prev_q = q
            rot_cs[0][i] = float(q.w)
            rot_cs[1][i] = float(q.x)
            rot_cs[2][i] = float(q.y)
            rot_cs[3][i] = float(q.z)
        elif mode == "AXIS_ANGLE":
            rot_cs[0][i] = float(rot[0])
            rot_cs[1][i] = float(rot[1])
            rot_cs[2][i] = float(rot[2])
            rot_cs[3][i] = float(rot[3])
        else:
            rot_cs[0][i] = float(rot[0])
            rot_cs[1][i] = float(rot[1])
            rot_cs[2][i] = float(rot[2])
    return loc_cs, rot_cs, scl_cs, rot_prop


def _bulk_write_existing_channels(fcurves, data_path: str, frames_f, component_values) -> bool:
    """foreach_set onto curves that keyframe_insert already created. No fcurves.new."""
    if fcurves is None:
        return False
    for index, values in enumerate(component_values):
        fc = _find_coll_fcurve(fcurves, data_path, index)
        if not _fcurve_replace_keys(fc, frames_f, values):
            return False
    return True


def _object_visual_basis_matrix(obj, eval_obj) -> Matrix:
    """Matrix_basis that reproduces evaluated world transform without constraints."""
    mw = eval_obj.matrix_world.copy()
    if obj.parent:
        parent_world = obj.parent.matrix_world @ obj.matrix_parent_inverse
        return parent_world.inverted_safe() @ mw
    return mw


def _set_action_fcurves_linear(action, *, anim_data=None) -> None:
    for fc in _iter_action_fcurves(action, anim_data=anim_data):
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"


def _fcurve_is_object_transform(data_path: str) -> bool:
    return data_path in {
        "location",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "scale",
    } or data_path.startswith("rotation")


def _has_object_motion_or_constraints(obj) -> bool:
    if len(obj.constraints) > 0:
        return True
    anim = obj.animation_data
    if anim and anim.action:
        for fc in _iter_action_fcurves(anim.action, anim_data=anim):
            if _fcurve_is_object_transform(fc.data_path):
                return True
    if anim:
        for track in anim.nla_tracks:
            for strip in track.strips:
                act = strip.action
                if not act:
                    continue
                for fc in _iter_action_fcurves(act):
                    if _fcurve_is_object_transform(fc.data_path):
                        return True
    return False


_BAKE_ISO_NAME = "_GR2LAB_BAKE"
_CONSTRAINT_OBJ_ATTRS = ("target", "pole_target", "space_object")


def _bake_keep_objects(obj):
    """Armature plus constraint/parent/driver targets that must stay in the depsgraph."""
    keep = {obj}
    parent = getattr(obj, "parent", None)
    while parent is not None:
        keep.add(parent)
        parent = getattr(parent, "parent", None)

    def add_id(ident):
        if ident is None:
            return
        if isinstance(ident, bpy.types.Object):
            keep.add(ident)
            p = ident.parent
            while p is not None:
                keep.add(p)
                p = p.parent

    def add_constraint(con):
        for attr in _CONSTRAINT_OBJ_ATTRS:
            add_id(getattr(con, attr, None))

    for con in obj.constraints:
        add_constraint(con)
    if obj.pose is not None:
        for pb in obj.pose.bones:
            for con in pb.constraints:
                add_constraint(con)
    ad = obj.animation_data
    if ad is not None:
        for fc in getattr(ad, "drivers", []) or []:
            drv = getattr(fc, "driver", None)
            if drv is None:
                continue
            for var in drv.variables:
                for tgt in var.targets:
                    add_id(getattr(tgt, "id", None))
    return keep


def _iter_layer_collections(lc):
    yield lc
    for child in lc.children:
        yield from _iter_layer_collections(child)


def _find_layer_collection(root_lc, col):
    for lc in _iter_layer_collections(root_lc):
        if lc.collection == col:
            return lc
    return None


def _layer_collection_path(root_lc, target):
    def walk(lc, trail):
        here = trail + [lc]
        if lc == target:
            return here
        for child in lc.children:
            hit = walk(child, here)
            if hit:
                return hit
        return None

    return walk(root_lc, [])


def _bake_view_isolate(context, obj):
    """Hide/exclude everything except this rig so frame_set is cheap.

    Viewport hide + collection exclude. Constraint/parent/driver targets stay.
    Always pair with _bake_view_restore.
    """
    scene = getattr(context, "scene", None)
    view_layer = getattr(context, "view_layer", None)
    if scene is None or view_layer is None or obj is None:
        return None
    keep = _bake_keep_objects(obj)
    if not keep:
        return None
    iso = bpy.data.collections.get(_BAKE_ISO_NAME)
    if iso is None:
        iso = bpy.data.collections.new(_BAKE_ISO_NAME)
    iso.hide_viewport = False
    iso.hide_render = False
    try:
        if iso.name not in scene.collection.children:
            scene.collection.children.link(iso)
    except RuntimeError:
        pass
    for ob in keep:
        try:
            if ob.name not in iso.objects:
                iso.objects.link(ob)
        except RuntimeError:
            pass
    try:
        view_layer.update()
    except Exception:
        pass

    root_lc = view_layer.layer_collection
    iso_lc = _find_layer_collection(root_lc, iso)
    keep_lc = set()
    if iso_lc is not None:
        keep_lc.update(_layer_collection_path(root_lc, iso_lc) or [])
        keep_lc.add(iso_lc)

    exclude_saved = []
    for lc in _iter_layer_collections(root_lc):
        if lc == root_lc:
            continue
        try:
            exclude_saved.append((lc, bool(lc.exclude)))
            lc.exclude = lc not in keep_lc
        except Exception:
            pass
    if iso_lc is not None:
        try:
            iso_lc.exclude = False
            if hasattr(iso_lc, "hide_viewport"):
                iso_lc.hide_viewport = False
        except Exception:
            pass

    unlinked_root = []
    for ob in list(scene.collection.objects):
        if ob in keep:
            continue
        try:
            scene.collection.objects.unlink(ob)
            unlinked_root.append(ob)
        except RuntimeError:
            pass

    hide_saved = []
    for ob in list(getattr(view_layer, "objects", []) or []):
        if ob in keep:
            continue
        try:
            hide_saved.append(
                (ob, bool(ob.hide_get()), bool(getattr(ob, "hide_viewport", False)))
            )
            ob.hide_set(True)
            ob.hide_viewport = True
        except Exception:
            pass

    try:
        view_layer.update()
    except Exception:
        pass
    n_excl = 0
    for lc, _was in exclude_saved:
        try:
            if lc.exclude:
                n_excl += 1
        except Exception:
            pass
    print(
        f"[GR2 LAB] bake isolate keep={len(keep)} hidden={len(hide_saved)} "
        f"excluded_cols={n_excl} iso_lc={'yes' if iso_lc else 'NO'}"
    )
    return {
        "iso": iso,
        "exclude": exclude_saved,
        "unlinked_root": unlinked_root,
        "hide": hide_saved,
        "scene": scene,
        "view_layer": view_layer,
    }


def _bake_view_restore(context, state) -> None:
    if not state:
        return
    scene = state.get("scene") or getattr(context, "scene", None)
    view_layer = state.get("view_layer") or getattr(context, "view_layer", None)
    for ob, was_hide, was_vp in state.get("hide") or []:
        try:
            ob.hide_set(was_hide)
            ob.hide_viewport = was_vp
        except Exception:
            pass
    for lc, was in state.get("exclude") or []:
        try:
            if lc is not None:
                lc.exclude = was
        except Exception:
            pass
    iso = state.get("iso")
    if iso is not None:
        for ob in list(getattr(iso, "objects", []) or []):
            try:
                iso.objects.unlink(ob)
            except RuntimeError:
                pass
        if scene is not None:
            try:
                if iso.name in scene.collection.children:
                    scene.collection.children.unlink(iso)
            except RuntimeError:
                pass
        try:
            bpy.data.collections.remove(iso)
        except Exception:
            pass
    if scene is not None:
        for ob in state.get("unlinked_root") or []:
            try:
                if ob.name not in scene.collection.objects:
                    scene.collection.objects.link(ob)
            except (RuntimeError, ReferenceError):
                pass
    if view_layer is not None:
        try:
            view_layer.update()
        except Exception:
            pass


def bake_armature_nla_and_constraints(
    context,
    obj,
    frame_start: Optional[int] = None,
    frame_end: Optional[int] = None,
    step: int = 1,
    bake_object: Optional[bool] = None,
    *,
    push_undo: bool = True,
):
    """
    Bake evaluated NLA + constraints into one Action, then remove NLA + constraints.

    Generator: yields (pct, label) progress tuples; returns result dict via StopIteration.value.
    """
    if not obj or obj.type != "ARMATURE" or obj.pose is None:
        raise TypeError("Active object must be an Armature")
    if obj.library or obj.override_library:
        raise RuntimeError(
            f"'{obj.name}' is linked/overridden. Make a local copy before baking."
        )

    if push_undo:
        try:
            bpy.ops.ed.undo_push(message="GR2 LAB: Bake NLA + Constraints")
        except Exception:
            pass

    scene = context.scene
    if frame_start is None or frame_end is None:
        auto_s, auto_e = determine_bake_range(obj, scene)
        frame_start = auto_s if frame_start is None else frame_start
        frame_end = auto_e if frame_end is None else frame_end

    frame_start = int(frame_start)
    frame_end = int(frame_end)
    step = max(1, int(step))
    if frame_end < frame_start:
        raise ValueError(f"Invalid frame range: {frame_start} .. {frame_end}")

    if bake_object is None:
        bake_object = _has_object_motion_or_constraints(obj)

    _prepare_anim_for_eval(obj)
    pose_bones = list(obj.pose.bones)
    if not pose_bones:
        raise RuntimeError(f"Armature '{obj.name}' has no pose bones")

    frames = list(range(frame_start, frame_end + 1, step))
    if frames and frames[-1] != frame_end:
        frames.append(frame_end)
    if not frames:
        raise ValueError(f"Empty bake frame list: {frame_start} .. {frame_end}")

    iso_state = None
    try:
        iso_state = _bake_view_isolate(context, obj)
    except Exception as exc:
        print(f"[GR2 LAB] bake isolate skipped: {exc}")
        iso_state = None

    try:
        yield (3, "Isolating scene for bake…")
        yield (4, f"Sampling visual pose ({len(frames)} frames)…")

        bone_samples: Dict[int, Dict[str, tuple]] = {}
        object_samples: Dict[int, tuple] = {}
        view_layer = context.view_layer
        n_frames = len(frames)
        sample_s = 0.0
        write_s = 0.0
        write_mode = "insert"
        t_sample = time.perf_counter()
        for i, f in enumerate(frames):
            scene.frame_set(f)
            view_layer.update()
            depsgraph = context.evaluated_depsgraph_get()
            eval_obj = obj.evaluated_get(depsgraph)

            frame_bones = {}
            for pb in pose_bones:
                eval_pb = eval_obj.pose.bones[pb.name]
                # Original Object/PoseBone + evaluated pose matrix (convert_space on
                # evaluated IDs is unreliable across Blender versions).
                local_mat = obj.convert_space(
                    pose_bone=pb,
                    matrix=eval_pb.matrix.copy(),
                    from_space="POSE",
                    to_space="LOCAL",
                )
                loc, rot, scale = _decompose_local(local_mat, pb.rotation_mode)
                frame_bones[pb.name] = (
                    Vector(loc),
                    rot.copy() if hasattr(rot, "copy") else tuple(rot),
                    Vector(scale),
                    pb.rotation_mode,
                )
            bone_samples[f] = frame_bones

            if bake_object:
                basis = _object_visual_basis_matrix(obj, eval_obj)
                loc, rot, scale = _decompose_local(basis, obj.rotation_mode)
                object_samples[f] = (
                    Vector(loc),
                    rot.copy() if hasattr(rot, "copy") else tuple(rot),
                    Vector(scale),
                    obj.rotation_mode,
                )

            if i == 0 or i == n_frames - 1 or (i % 8) == 0:
                pct = 4 + int(4 * (i + 1) / max(1, n_frames))
                yield (pct, f"Sampling visual pose {i + 1}/{n_frames}…")
        sample_s = time.perf_counter() - t_sample

        yield (8, "Clearing NLA + constraints…")
        nla_removed = _clear_nla_tracks(obj)
        obj_c_removed, bone_c_removed = _clear_all_constraints(obj)

        action_name = f"{obj.name}_Baked"
        existing = bpy.data.actions.get(action_name)
        if existing is not None:
            if obj.animation_data and obj.animation_data.action == existing:
                obj.animation_data.action = None
            bpy.data.actions.remove(existing)

        action = bpy.data.actions.new(action_name)
        _assign_armature_action(obj, action)
        if obj.animation_data:
            obj.animation_data.use_nla = True
            obj.animation_data.use_tweak_mode = False

        yield (8, f"Writing Action '{action_name}'…")
        t_write = time.perf_counter()
        f0 = frames[0]
        for pb in pose_bones:
            loc, rot, scale, mode = bone_samples[f0][pb.name]
            _apply_bone_transform(pb, loc, rot, scale, mode)
            _keyframe_bone(pb, f0)
        if bake_object and f0 in object_samples:
            loc, rot, scale, mode = object_samples[f0]
            obj.location = loc
            obj.scale = scale
            if mode == "QUATERNION":
                obj.rotation_quaternion = rot
            elif mode == "AXIS_ANGLE":
                obj.rotation_axis_angle = rot
            else:
                obj.rotation_euler = rot
            _keyframe_object(obj, f0)

        fcurves = _ensure_action_fcurves(obj, action)
        frames_f = [float(f) for f in frames]
        n_bones = max(1, len(pose_bones))
        bulk_bones = 0
        fallback_bones = 0
        bone_chunk = 8
        for bi, pb in enumerate(pose_bones):
            loc_cs, rot_cs, scl_cs, rot_prop = _pack_baked_bone_channels(
                pb, frames, bone_samples
            )
            loc_path = f'pose.bones["{pb.name}"].location'
            rot_path = f'pose.bones["{pb.name}"].{rot_prop}'
            scl_path = f'pose.bones["{pb.name}"].scale'
            ok = (
                _bulk_write_existing_channels(fcurves, loc_path, frames_f, loc_cs)
                and _bulk_write_existing_channels(fcurves, rot_path, frames_f, rot_cs)
                and _bulk_write_existing_channels(fcurves, scl_path, frames_f, scl_cs)
            )
            if ok:
                bulk_bones += 1
            else:
                fallback_bones += 1
                if fallback_bones == 1:
                    print(
                        f"[GR2 LAB] bake write fallback bone={pb.name!r} "
                        "(bulk keys missing or values did not match samples)"
                    )
                for f in frames:
                    loc, rot, scale, mode = bone_samples[f][pb.name]
                    _apply_bone_transform(pb, loc, rot, scale, mode)
                    _keyframe_bone(pb, f)
            if bi == 0 or bi + 1 == n_bones or ((bi + 1) % bone_chunk) == 0:
                yield (
                    8,
                    f"Writing Action '{action_name}' ({bi + 1}/{n_bones} bones)…",
                )

        if bake_object and object_samples:
            obj_mode = obj.rotation_mode
            n = len(frames)
            o_loc = [[0.0] * n for _ in range(3)]
            o_scl = [[0.0] * n for _ in range(3)]
            if obj_mode == "QUATERNION":
                o_rot = [[0.0] * n for _ in range(4)]
                o_prop = "rotation_quaternion"
            elif obj_mode == "AXIS_ANGLE":
                o_rot = [[0.0] * n for _ in range(4)]
                o_prop = "rotation_axis_angle"
            else:
                o_rot = [[0.0] * n for _ in range(3)]
                o_prop = "rotation_euler"
            obj_ok = True
            for i, f in enumerate(frames):
                if f not in object_samples:
                    obj_ok = False
                    break
                loc, rot, scale, mode = object_samples[f]
                o_loc[0][i] = float(loc.x)
                o_loc[1][i] = float(loc.y)
                o_loc[2][i] = float(loc.z)
                o_scl[0][i] = float(scale.x)
                o_scl[1][i] = float(scale.y)
                o_scl[2][i] = float(scale.z)
                if mode == "QUATERNION":
                    o_rot[0][i] = float(rot.w)
                    o_rot[1][i] = float(rot.x)
                    o_rot[2][i] = float(rot.y)
                    o_rot[3][i] = float(rot.z)
                elif mode == "AXIS_ANGLE":
                    o_rot[0][i] = float(rot[0])
                    o_rot[1][i] = float(rot[1])
                    o_rot[2][i] = float(rot[2])
                    o_rot[3][i] = float(rot[3])
                else:
                    o_rot[0][i] = float(rot[0])
                    o_rot[1][i] = float(rot[1])
                    o_rot[2][i] = float(rot[2])
            if obj_ok:
                obj_ok = (
                    _bulk_write_existing_channels(fcurves, "location", frames_f, o_loc)
                    and _bulk_write_existing_channels(fcurves, o_prop, frames_f, o_rot)
                    and _bulk_write_existing_channels(fcurves, "scale", frames_f, o_scl)
                )
            if not obj_ok:
                for f in frames:
                    if f not in object_samples:
                        continue
                    loc, rot, scale, mode = object_samples[f]
                    obj.location = loc
                    obj.scale = scale
                    if mode == "QUATERNION":
                        obj.rotation_quaternion = rot
                    elif mode == "AXIS_ANGLE":
                        obj.rotation_axis_angle = rot
                    else:
                        obj.rotation_euler = rot
                    _keyframe_object(obj, f)

        write_s = time.perf_counter() - t_write
        write_mode = "bulk" if fallback_bones == 0 else (
            "insert" if bulk_bones == 0 else "mixed"
        )
        print(
            f"[GR2 LAB] bake write {write_mode} bulk_bones={bulk_bones} "
            f"fallback_bones={fallback_bones} {write_s:.2f}s"
        )

        final_action = obj.animation_data.action if obj.animation_data else action
        if final_action and fallback_bones:
            _set_action_fcurves_linear(
                final_action,
                anim_data=obj.animation_data,
            )

        nla_removed += _clear_nla_tracks(obj)
        oc2, bc2 = _clear_all_constraints(obj)
        obj_c_removed += oc2
        bone_c_removed += bc2

        if obj.animation_data:
            obj.animation_data.use_tweak_mode = False
            obj.animation_data.action = final_action
            _assign_armature_action(obj, final_action)

        yield (9, "Bake done")
        return {
            "object": obj.name,
            "action": final_action.name if final_action else action_name,
            "frame_start": frame_start,
            "frame_end": frame_end,
            "step": step,
            "frames_keyed": len(frames),
            "bones": len(pose_bones),
            "baked_object": bool(bake_object),
            "nla_tracks_removed": nla_removed,
            "object_constraints_removed": obj_c_removed,
            "bone_constraints_removed": bone_c_removed,
            "sample_s": float(sample_s),
            "write_s": float(write_s),
            "write_mode": write_mode,
        }
    finally:
        _bake_view_restore(context, iso_state)


def _bake_timeline_for_export(context, arm_obj):
    """
    Visual flatten for export. Always a generator: yields (pct, label);
    returns result dict (or None) via StopIteration.value.
    """
    if not arm_obj or arm_obj.type != "ARMATURE":
        return None
        yield  # pragma: no cover — keep generator type
    gen = bake_armature_nla_and_constraints(context, arm_obj, push_undo=True)
    try:
        while True:
            yield next(gen)
    except StopIteration as stop:
        return stop.value
    finally:
        try:
            gen.close()
        except Exception:
            pass


BAKE_MODE_ITEMS = (
    (
        "AUTO",
        "Auto",
        "Flatten when unmuted NLA strips and/or constraints are present (destructive)",
    ),
    (
        "ALWAYS",
        "Always",
        "Always flatten NLA + constraints into one Action (destructive, slow)",
    ),
    (
        "NEVER",
        "Never",
        "Never flatten — F-curves + constraint-affected depsgraph eval only",
    ),
)


def export_gr2lab(
    context,
    filepath: str,
    *,
    arm_obj=None,
    template_armature=None,
    template_filepath: Optional[str] = None,
    progress: Optional[Gr2LabProgress] = None,
    bake_mode: str = "AUTO",
    cooperative: bool = False,
    timer=None,
):
    """
    Export tracks from arm_obj by exact bone-name match against a GR2LAB template.
    F-curves by default; evaluated pose for constraint-affected bones.
    When cooperative=True, yields (pct, label) so a modal TIMER can refresh the UI,
    then returns stats via StopIteration.value.
    """
    from timing import StageTimer

    timer = timer or StageTimer("export")
    arm_obj = arm_obj or context.view_layer.objects.active
    if not arm_obj or arm_obj.type != "ARMATURE":
        raise ValueError("Select an armature to export animation from")

    baked = False
    bake_info = None
    should_bake = _export_should_bake(arm_obj, bake_mode)
    sampling_hint = _export_sampling_hint(arm_obj, bake_mode)
    _t_bake = time.perf_counter()
    if cooperative:
        yield (2, "Preparing export…")
    if should_bake:
        if progress:
            progress.step(4, "Flattening NLA + constraints…")
        if cooperative:
            yield (4, "Flattening NLA + constraints…")
        bake_gen = _bake_timeline_for_export(context, arm_obj)
        try:
            while True:
                item = next(bake_gen)
                if progress:
                    progress.step(int(item[0]), str(item[1]))
                if cooperative:
                    yield item
        except StopIteration as stop:
            bake_info = stop.value
        baked = bool(bake_info)
        if baked:
            sampling_hint = "visual_flatten"
        done_label = (
            f"Bake done ({bake_info.get('action')})"
            if baked and isinstance(bake_info, dict)
            else "Bake skipped — sampling F-curves…"
        )
        if progress:
            progress.step(9, done_label)
        if cooperative:
            yield (9, done_label)
    elif progress:
        progress.step(4, "Skipping bake (action F-curves)…")
    if cooperative and not should_bake:
        yield (4, "Skipping bake (action F-curves)…")
    timer.add("bake", time.perf_counter() - _t_bake)
    if isinstance(bake_info, dict):
        if bake_info.get("sample_s") is not None:
            timer.add("bake_sample", float(bake_info["sample_s"]))
        if bake_info.get("write_s") is not None:
            timer.add("bake_write", float(bake_info["write_s"]))

    _t_tpl = time.perf_counter()
    if progress:
        progress.step(10, "Loading export template…")
    active_doc_before = _parse_arm_doc(arm_obj)
    had_stamp = active_doc_before is not None
    active_was_synthesized = (
        had_stamp
        and active_doc_before is not None
        and _is_synthesized_gr2lab_doc(active_doc_before)
    )
    doc, fps, template_source = resolve_export_template(
        context,
        arm_obj,
        template_armature=template_armature,
        template_filepath=template_filepath,
    )
    snapshot_raw = arm_obj.get(PROP_IMPORT_SNAPSHOT) if arm_obj else None
    snapshot_doc = None
    if snapshot_raw:
        try:
            snapshot_doc = json.loads(snapshot_raw)
        except Exception:
            snapshot_doc = None
    delta_ref_doc = snapshot_doc if snapshot_doc else doc
    # First export from a plain rig: stamp template onto the armature so later
    # exports are native (no scene GR2LAB_* / no re-picking the file).
    stamped_native = False
    if not had_stamp:
        tpl_path = (template_filepath or "").strip() or auto_template_path(context, arm_obj)
        stamp_gr2lab_on_armature(arm_obj, doc, fps=fps, template_path=tpl_path)
        stamped_native = True
    bind_by_name = _bind_map(doc)
    skeleton = _skeleton_with_bind_parents(doc.get("skeleton") or [], bind_by_name)
    tracks = _track_map(doc)
    ad0 = arm_obj.animation_data
    prev_action = ad0.action if ad0 else None
    # NLA-only (empty action slot): do not assign the first strip. That REPLACE
    # action hides COMBINE extra-fix / location tracks during depsgraph sample.
    nla_only = bool(ad0 and prev_action is None and _nla_strips_active(arm_obj) and not baked)
    action = _resolve_action(arm_obj)
    if ad0 and action and not nla_only:
        _assign_armature_action(arm_obj, action)
    fc_index = _build_fcurve_index(action, anim_data=arm_obj.animation_data)

    template_names = {b["name"] for b in skeleton if b.get("name")}
    arm_bone_names = {b.name for b in arm_obj.data.bones}
    matched_names = template_names & arm_bone_names
    extras = len(arm_bone_names - template_names)

    # F-curve quat keys may already flip hemispheres (paste / bake). Fix before sample.
    # Skip on NLA-only — would mutate the vanilla strip action, not the stack.
    if action and not nla_only:
        for _bn in matched_names:
            if _bn in fc_index:
                _finalize_pose_bone_fcurves(
                    action, _bn, anim_data=arm_obj.animation_data
                )

    # Two spaces:
    # - GR2LAB Import (+90В° object): armature bones are already Granny вЂ” rest @ basis
    # - LSLib / Body_Base (Z-up bones): sample Blender locals, convert Rx(-90В°) в†’ Granny
    granny_space = _is_granny_armature_space(arm_obj)

    rest_local: Dict[str, Matrix] = {}
    parents: Dict[str, Optional[str]] = {}
    for b in skeleton:
        name = b["name"]
        bone = arm_obj.data.bones.get(name)
        if granny_space:
            rest_local[name] = _bind_local_for_bone(b, bind_by_name)
            parents[name] = b.get("parent_name") or (
                bone.parent.name if bone and bone.parent else None
            )
        else:
            # Always Blender rest for Z-up в†’ Granny convert (ignore template rests)
            if bone:
                rest_local[name] = _bone_rest_local_matrix(bone)
                parents[name] = bone.parent.name if bone.parent else None
            else:
                rest_local[name] = _bind_local_for_bone(b, bind_by_name)
                parents[name] = b.get("parent_name") or None

    affected = _constraint_affected_bones(arm_obj)
    nla_eval = _nla_strips_active(arm_obj) and not baked
    # After bake, visual pose is in F-curves — skip depsgraph.
    # NLA (single strip or blended): eval all matched bones so push-down matches action export.
    # Empty F-curve index on a slotted bake (Blender 5 RNA) → eval pose so we never
    # export rest-only tracks while the viewport shows motion.
    fcurve_bones = {n for n in matched_names if fc_index.get(n)}
    sparse_fcurves = bool(action) and len(fcurve_bones) < max(1, int(0.5 * len(matched_names)))
    if baked:
        need_eval_names: set = set()
        sample_names = set(matched_names)
    elif nla_eval or sparse_fcurves:
        need_eval_names = set(matched_names)
        sample_names = set(matched_names)
    else:
        need_eval_names = affected & matched_names
        sample_names = {n for n in matched_names if fc_index.get(n) or n in affected}

    identity_loc = (0.0, 0.0, 0.0)
    identity_quat = (1.0, 0.0, 0.0, 0.0)
    identity_scl = (1.0, 1.0, 1.0)

    scene = context.scene
    prev_frame = scene.frame_current
    frame_list = _import_locked_frame_list(context, arm_obj, action)

    local_cache: Dict[float, Dict[str, Tuple[List[float], List[float], List[float]]]] = {}
    fr_total = max(1, len(frame_list))
    # Smaller batches when depsgraph eval is needed; larger for pure F-curve path.
    sample_batch = 4 if need_eval_names else 48
    timer.add("load_template", time.perf_counter() - _t_tpl)
    _t_samp = time.perf_counter()
    try:
        fi = 0
        while fi < len(frame_list):
            batch_end = min(fi + sample_batch, len(frame_list))
            for fr in frame_list[fi:batch_end]:
                key = round(fr, 6)
                bl_bucket: Dict[str, Matrix] = {}
                arm_eval = None
                if need_eval_names:
                    scene.frame_set(int(round(fr)))
                    depsgraph = context.evaluated_depsgraph_get()
                    arm_eval = arm_obj.evaluated_get(depsgraph)
                for name in sample_names:
                    if name not in rest_local:
                        continue
                    fcs = fc_index.get(name) or {}
                    pb = arm_eval.pose.bones.get(name) if arm_eval else None
                    use_matrix = name in need_eval_names and pb is not None
                    bl_bucket[name] = _granny_local_from_pose(
                        name,
                        fr,
                        pb=pb,
                        fcs=fcs,
                        rest_local=rest_local,
                        identity_loc=identity_loc,
                        identity_quat=identity_quat,
                        identity_scl=identity_scl,
                        use_matrix_eval=use_matrix,
                    )
                for name in sample_names:
                    if name not in bl_bucket and name in rest_local:
                        bl_bucket[name] = rest_local[name].copy()

                if granny_space:
                    local_cache[key] = {
                        n: _mat_to_trs(m) for n, m in bl_bucket.items()
                    }
                else:
                    local_cache[key] = _blender_zup_locals_to_granny(bl_bucket, parents)
            fi = batch_end
            pct = 12 + int(56 * fi / max(1, fr_total))
            label = f"Sampling frames {fi}/{fr_total}…"
            if progress:
                progress.step(pct, label)
            if cooperative:
                yield (pct, label)
    finally:
        if need_eval_names:
            scene.frame_set(prev_frame)
        ad_now = arm_obj.animation_data
        if ad_now is not None and ad_now.action is not prev_action:
            ad_now.action = prev_action

    timer.add("sample", time.perf_counter() - _t_samp)

    # Decompose + Z-up convert both pick q/-q per frame — kill export shake here.
    _stabilize_local_cache_quats(local_cache)
    cache_keys_sorted = sorted(local_cache.keys())

    def sample_at(name: str, frame: float) -> Tuple[List[float], List[float], List[float]]:
        key = round(frame, 6)
        bucket = local_cache.get(key)
        if bucket is None:
            if not cache_keys_sorted:
                if granny_space:
                    return _mat_to_trs(rest_local.get(name, Matrix.Identity(4)))
                rest_g = _blender_zup_locals_to_granny(rest_local, parents)
                return rest_g.get(name) or ([0, 0, 0], [0, 0, 0, 1], [1, 1, 1])
            nearest, _dist = _nearest_sorted(cache_keys_sorted, key)
            bucket = local_cache.get(nearest) if nearest is not None else None
        if bucket and name in bucket:
            return bucket[name]
        if granny_space:
            return _mat_to_trs(rest_local.get(name, Matrix.Identity(4)))
        return ([0.0, 0.0, 0.0], [0.0, 0.0, 0.0, 1.0], [1.0, 1.0, 1.0])

    def times_collapse(samples: Dict[float, List[float]], is_quat: bool) -> List[float]:
        items = sorted(samples.items())
        if not items:
            return [0.0]
        _t0, v0 = items[0]
        close = _quat_close if is_quat else _v3_close
        if all(close(v0, v) for _, v in items):
            return [0.0]
        return [float(t) for t, _ in items]

    _t_tr = time.perf_counter()
    new_tracks = []
    global_times = [_frame_to_sec(fr, fps) for fr in frame_list]
    matched = 0
    missing = 0
    # Prefer import-time channels for protected roots (not a later densified stamp).
    snap_tracks = _track_map(snapshot_doc) if snapshot_doc else {}

    track_batch = 6
    for bi, b in enumerate(skeleton):
        name = b["name"]
        tr = tracks.get(name) or {
            "name": name,
            "position": {
                "edit_mode": "none",
                "editable": False,
                "times": [0.0],
                "values": [[0, 0, 0]],
            },
            "orientation": {
                "edit_mode": "none",
                "editable": False,
                "times": [0.0],
                "values": [[0, 0, 0, 1]],
            },
            "scale": {
                "edit_mode": "none",
                "editable": False,
                "times": [0.0],
                "values": [[1, 1, 1]],
            },
        }

        # Template bone not on this armature — keep original track values
        if name not in matched_names:
            missing += 1
            new_tracks.append(
                {
                    "name": name,
                    "index": tr.get("index", b.get("index")),
                    "position": dict(tr.get("position") or {}),
                    "orientation": dict(tr.get("orientation") or {}),
                    "scale": dict(tr.get("scale") or {}),
                }
            )
            continue

        # Rest-only (no F-curves, not constraint/NLA eval): leave template track.
        if name not in sample_names:
            matched += 1
            new_tracks.append(
                {
                    "name": name,
                    "index": tr.get("index", b.get("index")),
                    "position": dict(tr.get("position") or {}),
                    "orientation": dict(tr.get("orientation") or {}),
                    "scale": dict(tr.get("scale") or {}),
                }
            )
            continue

        matched += 1
        pos = dict(tr.get("position") or {})
        ori = dict(tr.get("orientation") or {})
        scl = dict(tr.get("scale") or {})
        pos_mode = pos.get("edit_mode") or "none"
        ori_mode = ori.get("edit_mode") or "none"
        scl_mode = scl.get("edit_mode") or "none"
        fcs = fc_index.get(name) or {}
        bone_affected = name in affected

        def base_times(ch, mode, props, *, upgradable: bool):
            if mode == "none" and not upgradable:
                return []
            orig = [float(t) for t in (ch.get("times") or [0.0])] or [0.0]
            fc_times = [_frame_to_sec(fr, fps) for fr in _frames_for_props(fcs, props)]
            export_t = global_times
            # NLA stack eval: extra-fix loc/rot may live on COMBINE strips, not
            # the first-strip F-curves. Sample the evaluated pose grid.
            if nla_eval and upgradable and mode in ("constant", "none", "k16_offsets"):
                return _collapse_times_eps(
                    list(orig) + fc_times + export_t, prefer=export_t
                ) or [0.0]
            if mode == "constant" and not upgradable:
                return [0.0]
            if mode == "k16_offsets" and not upgradable:
                return [0.0]
            # k16: import places full dequantized display keys; snap to template.
            # Collapse to bias-only later when samples still match the template.
            if mode == "k16_offsets":
                if len(fc_times) <= 1:
                    return [0.0]
                return _snap_times_to_template(fc_times, orig) or [0.0]
            # constant: F-curve keys only. Extra location keys = user wants multi-key
            # в†’ site upgrades to float.
            if mode == "constant":
                if len(fc_times) <= 1:
                    return [0.0]
                return sorted(set(fc_times)) or [0.0]
            # float / quat_k16: template knots + every exported scene frame (dense bake).
            # Collapse float-noise near-dups; prefer exact frame-grid times.
            snapped = _snap_times_to_template(fc_times, orig)
            merged = _collapse_times_eps(
                list(snapped) + export_t, prefer=export_t
            )
            if bone_affected and upgradable:
                merged = _collapse_times_eps(
                    list(merged) + export_t, prefer=export_t
                ) or [0.0]
            return merged or [0.0]

        cand_pos = base_times(pos, pos_mode, ("location",), upgradable=True)
        cand_ori = base_times(ori, ori_mode, ("rotation_quaternion",), upgradable=True)
        cand_scl = base_times(scl, scl_mode, ("scale",), upgradable=False)

        all_t = _collapse_times_eps(
            list(cand_pos or []) + list(cand_ori or []) + list(cand_scl or []),
            prefer=global_times,
        )
        cache: Dict[float, Tuple[List[float], List[float], List[float]]] = {}
        for t in all_t:
            cache[t] = sample_at(name, _sec_to_frame(t, fps))

        pos_samples = {t: cache[t][0] for t in (cand_pos or [0.0]) if t in cache}
        ori_samples = {t: cache[t][1] for t in (cand_ori or [0.0]) if t in cache}

        if pos_mode == "none" and not pos.get("editable"):
            # Identity Granny position (DaIdentity). Still ship if the user
            # added location motion — encode upgrades none → float Deg1.
            collapsed = times_collapse(pos_samples, False)
            need_pos = collapsed if len(collapsed) > 1 else []
        elif pos_mode == "k16_offsets":
            # Untouched display keys в†’ bias-only; frame-bake densify / real edits в†’ multi-key
            tmpl_t = [float(t) for t in (pos.get("times") or [0.0])]
            tmpl_v = pos.get("values") or []
            sample_times = list(pos_samples.keys())
            if _is_mass_grid_densify_times(tmpl_t, sample_times):
                need_pos = times_collapse(pos_samples, False)
            elif _channel_is_display_densified(pos) and len(sample_times) > 1:
                need_pos = times_collapse(pos_samples, False)
            elif _k16_pos_matches_template(pos_samples, tmpl_t, tmpl_v):
                need_pos = [0.0]
            else:
                need_pos = times_collapse(pos_samples, False)
        elif pos_mode in ("constant", "none"):
            # Collapse flat bias; keep multi-key only when F-curves actually vary
            need_pos = times_collapse(pos_samples, False)
        else:
            # Keep snapped F-curve times; collapse float-noise near-dups onto frame grid.
            need_pos = _collapse_times_eps(
                list(pos_samples.keys()), prefer=global_times
            ) or [0.0]

        if ori_mode == "none" and not ori.get("editable"):
            collapsed_ori = times_collapse(ori_samples, True)
            need_ori = collapsed_ori if len(collapsed_ori) > 1 else []
        elif ori_mode in ("constant", "none"):
            need_ori = times_collapse(ori_samples, True)
        else:
            need_ori = _collapse_times_eps(
                list(ori_samples.keys()), prefer=global_times
            ) or [0.0]

        # Never collapse real location/rotation motion back to a single bias key.
        # Compare against the template curve (not "does this channel vary over
        # time") so untouched k16 locomotion is not densified on a no-op export.
        if len(need_pos) <= 1 and _root_samples_differ_from_template(
            pos_samples, pos, is_quat=False
        ):
            need_pos = times_collapse(pos_samples, False)
        if len(need_ori) <= 1 and _root_samples_differ_from_template(
            ori_samples, ori, is_quat=True
        ):
            need_ori = times_collapse(ori_samples, True)

        need_scl = [0.0]

        def rewrite_channel(ch, mode, times_list, pick, *, upgradable: bool):
            out = dict(ch)
            if mode == "none" and not upgradable:
                return out
            if mode in ("constant", "k16_offsets") and not upgradable:
                t0 = 0.0
                if t0 not in cache:
                    cache[t0] = sample_at(name, _sec_to_frame(t0, fps))
                out["times"] = [0.0]
                out["values"] = [pick(cache[t0])]
                return out
            if not times_list:
                return out
            times = []
            values = []
            seen = set()
            for t in times_list:
                key = round(t, 6)
                if key in seen:
                    continue
                seen.add(key)
                if t not in cache:
                    cache[t] = sample_at(name, _sec_to_frame(t, fps))
                times.append(float(t))
                values.append(pick(cache[t]))
            out["times"] = times
            out["values"] = values
            if mode in ("constant", "k16_offsets", "none") and len(times) > 1:
                out["editable"] = True
                out["edit_mode"] = "float_controls"
                out["degree"] = 1
            return out

        # Protect Dummy_Root / Root_M: keep original channels unless sampled
        # motion actually leaves the template (NLA COMBINE / keyed loc+rot).
        # Same-motion bake densify must not remake Root_M quat_k16.
        protect_root = name in PROTECTED_ROOT_BONES
        root_keep = snap_tracks.get(name) or tr
        allow_root_pos = (not protect_root) or _allow_protected_root_rewrite(
            bone_affected, pos_samples, pos, is_quat=False
        )
        allow_root_ori = (not protect_root) or _allow_protected_root_rewrite(
            bone_affected, ori_samples, ori, is_quat=True
        )
        if allow_root_pos:
            pos = rewrite_channel(
                pos, pos_mode, need_pos, lambda s: s[0], upgradable=True
            )
            if protect_root:
                pos = _strip_root_display_densify(pos, kind="locomotion")
        else:
            pos = dict(root_keep.get("position") or tr.get("position") or {})
        if allow_root_ori:
            ori = rewrite_channel(
                ori, ori_mode, need_ori, lambda s: s[1], upgradable=True
            )
            if ori.get("values") and len(ori["values"]) > 1:
                _make_quat_series_compatible(ori["values"])
            if protect_root:
                ori = _strip_root_display_densify(ori, kind="ori")
        else:
            ori = dict(root_keep.get("orientation") or tr.get("orientation") or {})
            # Same-motion keep: never ship import display densify (that used to
            # remake Root_M quat_k16 as Deg1×~600 of the *vanilla* curve).
            if protect_root and (
                _channel_is_display_densified(ori)
                or (
                    (ori.get("edit_mode") or "") == "float_controls"
                    and len(ori.get("times") or []) >= 100
                )
            ):
                sparse = dict(tr.get("orientation") or {})
                if not _channel_is_display_densified(sparse) and not (
                    (sparse.get("edit_mode") or "") == "float_controls"
                    and len(sparse.get("times") or []) >= 100
                ):
                    ori = sparse
        # Body_Base / DGB templates often bake Dummy_Root rest Rx(90°) into the
        # orientation track. Protect-keep would ship that as Granny anim → 90° tip.
        if name == "Dummy_Root":
            ori = _sanitize_dummy_root_ori(ori)
        scl = rewrite_channel(scl, scl_mode, need_scl, lambda s: s[2], upgradable=False)

        new_tracks.append(
            {
                "name": name,
                "index": tr.get("index", b.get("index")),
                "position": pos,
                "orientation": ori,
                "scale": scl,
            }
        )
        if (bi + 1) % track_batch == 0 or bi + 1 == len(skeleton):
            pct = 70 + int(18 * (bi + 1) / max(1, len(skeleton)))
            label = f"Building tracks {bi + 1}/{len(skeleton)}…"
            if progress:
                progress.step(pct, label)
            if cooperative:
                yield (pct, label)

    timer.add("build_tracks", time.perf_counter() - _t_tr)
    out_doc = dict(doc)
    out_doc["skeleton"] = skeleton
    out_doc["tracks"] = new_tracks
    export_duration = max(0.0, (float(frame_list[-1]) - 1.0) / float(fps))
    out_doc["duration"] = export_duration
    _trim_tracks_to_duration(new_tracks, export_duration)
    out_doc["blender_full_export"] = True
    out_doc["format"] = FORMAT_ID
    out_doc["version"] = int(out_doc.get("version") or 1)
    if not out_doc.get("run_id"):
        out_doc["run_id"] = "blender"
    # Forensic stamp for root-shift investigation (server writes EXPORT_META.json)
    try:
        euler = arm_obj.rotation_euler
        euler_x_deg = float(euler[0]) * 180.0 / 3.141592653589793
    except Exception:
        euler_x_deg = None
    y_up = False
    try:
        y_up = bool(arm_obj.get("gr2lab_y_up_display"))
    except Exception:
        y_up = False
    out_doc["export_meta"] = {
        "space": "granny" if granny_space else "blender_zup->granny",
        "granny_space": bool(granny_space),
        "y_up_display": y_up,
        "object_euler_x_deg": euler_x_deg,
        "frames_sampled": len(frame_list),
        "duration_sec": export_duration,
        "baked": bool(baked),
        "nla_eval": bool(nla_eval),
        "sampling": sampling_hint,
        "template_source": template_source,
        "fps": float(fps),
    }
    out_doc["export_space"] = out_doc["export_meta"]["space"]
    if progress:
        progress.step(92, "Writing GR2LAB document…")
    if cooperative:
        yield (92, "Writing GR2LAB document…")
    if filepath:
        Path(filepath).write_text(
            json.dumps(out_doc, separators=(",", ":"), ensure_ascii=False),
            encoding="utf-8",
        )
    if stamped_native or template_source == "synthesize":
        stamp_gr2lab_on_armature(
            arm_obj,
            out_doc,
            fps=fps,
            y_up_display=False if template_source == "synthesize" else None,
        )
    elif active_was_synthesized and template_source != "active armature":
        stamp_gr2lab_on_armature(arm_obj, out_doc, fps=fps, y_up_display=False)
    if progress:
        progress.step(94, "GR2LAB document ready")
    stats = {
        "matched": matched,
        "missing": missing,
        "extras": extras,
        "template_source": template_source,
        "run_id": out_doc.get("run_id") or "",
        "stamped_native": stamped_native or template_source == "synthesize",
        "space": "granny" if granny_space else "blender_zup->granny",
        "frames_sampled": len(frame_list),
        "duration_sec": export_duration,
        "motion_delta_bones": _count_motion_delta_bones(delta_ref_doc, out_doc),
        "baked": baked,
        "nla_eval": bool(nla_eval),
        "sampling": sampling_hint,
        "eval_bones": len(need_eval_names),
        "doc": out_doc,
        "_stage_timer": timer,
    }
    if cooperative:
        return stats
    return stats


def _consume_export_gr2lab(gen_or_stats):
    """Run cooperative export generator to completion (or pass through dict)."""
    if isinstance(gen_or_stats, dict):
        return gen_or_stats
    last = None
    try:
        while True:
            last = next(gen_or_stats)
    except StopIteration as stop:
        stats = stop.value
        if isinstance(stats, dict):
            return stats
        raise RuntimeError("Export generator finished without stats") from stop
    raise RuntimeError(f"Export generator stalled at {last!r}")


def export_gr2lab_doc(
    context,
    *,
    arm_obj=None,
    template_armature=None,
    template_filepath: Optional[str] = None,
    progress: Optional[Gr2LabProgress] = None,
    bake_mode: str = "AUTO",
    cooperative: bool = False,
):
    """Build export document in memory (for GR2 Lab server encode).

    cooperative=True → returns a generator yielding (pct, label), final stats in StopIteration.value.
    """
    if cooperative:
        return export_gr2lab(
            context,
            "",
            arm_obj=arm_obj,
            template_armature=template_armature,
            template_filepath=template_filepath,
            progress=progress,
            bake_mode=bake_mode,
            cooperative=True,
        )
    stats = _consume_export_gr2lab(
        export_gr2lab(
            context,
            "",
            arm_obj=arm_obj,
            template_armature=template_armature,
            template_filepath=template_filepath,
            progress=progress,
            bake_mode=bake_mode,
            cooperative=True,
        )
    )
    return stats


# ---------------------------------------------------------------------------
# Blender operators
# ---------------------------------------------------------------------------

PROP_PACK_RUN = "gr2lab_full_pack_run"
PROP_SOURCE_GR2 = "gr2lab_full_source_gr2"
PROP_IMPORT_FP = "gr2lab_import_fp"
PROP_IMPORT_SNAPSHOT = "gr2lab_import_snapshot"
PROP_PARTNER_RUN = "gr2lab_partner_run"
PROP_PARTNER_OF = "gr2lab_partner_of"
PROP_PARTNER_PRIMARY = "gr2lab_partner_primary_run"


def _active_armature(context):
    """Prefer active armature; else first selected armature; else None."""
    obj = getattr(context.view_layer.objects, "active", None)
    if obj and obj.type == "ARMATURE":
        return obj
    for obj in getattr(context, "selected_objects", None) or []:
        if obj.type == "ARMATURE":
            return obj
    return None


def _normalize_run_id(run_id: str) -> str:
    rid = (run_id or "").strip()
    if not rid or rid == "blender":
        return ""
    # Blender may rename duplicates: GR2LAB_nightfall.001
    if "." in rid and rid.rsplit(".", 1)[-1].isdigit():
        rid = rid.rsplit(".", 1)[0]
    return rid


def _pack_run_id(arm_obj) -> str:
    if not arm_obj:
        return ""
    rid = _normalize_run_id(str(arm_obj.get(PROP_PACK_RUN) or ""))
    if rid:
        return rid
    return _normalize_run_id(str(arm_obj.get(PROP_RUN) or ""))


def remember_pack_run(run_id: str, source_gr2: str = "") -> None:
    """Remember last Import GR2 dump so Export can pack even after retarget."""
    rid = _normalize_run_id(run_id)
    if not rid:
        return
    prefs = _addon_prefs()
    if prefs is not None and hasattr(prefs, "last_pack_run"):
        prefs.last_pack_run = rid
        if source_gr2 and hasattr(prefs, "last_source_gr2"):
            prefs.last_source_gr2 = str(source_gr2)
    try:
        wm = bpy.context.window_manager
        wm[WM_LAST_PACK_RUN] = rid
        if source_gr2:
            wm[WM_LAST_SOURCE_GR2] = str(source_gr2)
    except Exception:
        pass


def _remembered_pack_run() -> Tuple[str, str]:
    prefs = _addon_prefs()
    rid = ""
    src = ""
    if prefs is not None:
        rid = _normalize_run_id(str(getattr(prefs, "last_pack_run", "") or ""))
        src = str(getattr(prefs, "last_source_gr2", "") or "").strip()
    try:
        wm = bpy.context.window_manager
        rid = rid or _normalize_run_id(str(wm.get(WM_LAST_PACK_RUN) or ""))
        src = src or str(wm.get(WM_LAST_SOURCE_GR2) or "").strip()
    except Exception:
        pass
    return rid, src


def _iter_pack_armatures(context, *, exclude=None):
    """Scene armatures that carry a decode pack run id."""
    exclude_name = exclude.name if exclude else None
    for obj in context.scene.objects:
        if obj.type != "ARMATURE":
            continue
        if exclude_name and obj.name == exclude_name:
            continue
        if _pack_run_id(obj):
            yield obj


def _iter_arm_actions(arm_obj):
    """Yield Action datablocks used by the armature (active + NLA strips)."""
    if not arm_obj or not getattr(arm_obj, "animation_data", None):
        return
    ad = arm_obj.animation_data
    if ad.action:
        yield ad.action
    for tr in ad.nla_tracks:
        for st in tr.strips:
            if getattr(st, "action", None):
                yield st.action


def _run_id_from_action_name(action) -> str:
    if not action:
        return ""
    name = str(getattr(action, "name", "") or "")
    if not name.startswith("GR2LAB_"):
        return ""
    return _normalize_run_id(name[len("GR2LAB_") :])


def _find_pack_donor(context, arm_obj) -> Tuple[Any, str, str]:
    """Find imported GR2LAB armature / run matching this arm's action or NLA.

    Returns (donor_arm_or_None, run_id, source_gr2).
    """
    if not context or not arm_obj:
        return None, "", ""
    actions = list(_iter_arm_actions(arm_obj))
    if not actions:
        return None, "", ""

    # Same Action datablock as an imported GR2LAB_* armature (usual paste workflow).
    for act in actions:
        for obj in context.scene.objects:
            if obj.type != "ARMATURE" or obj == arm_obj:
                continue
            oad = obj.animation_data
            if not oad or oad.action != act:
                continue
            rid = _pack_run_id(obj)
            if rid:
                return obj, rid, str(obj.get(PROP_SOURCE_GR2) or "").strip()

    # Action / object named GR2LAB_<run>
    for act in actions:
        rid = _run_id_from_action_name(act)
        if not rid:
            continue
        for obj in context.scene.objects:
            if obj.type != "ARMATURE" or obj == arm_obj:
                continue
            if _pack_run_id(obj) == rid:
                return obj, rid, str(obj.get(PROP_SOURCE_GR2) or "").strip()
            oname = obj.name or ""
            if oname == f"GR2LAB_{rid}" or oname.startswith(f"GR2LAB_{rid}."):
                orun = _pack_run_id(obj) or rid
                return obj, orun, str(obj.get(PROP_SOURCE_GR2) or "").strip()
        return None, rid, ""

    return None, "", ""


def _stamp_pack_from_donor(arm_obj, donor) -> None:
    """Copy dump/pack stamps from imported GR2LAB arm onto a working retarget arm."""
    if not arm_obj or not donor:
        return
    rid = _pack_run_id(donor)
    src = str(donor.get(PROP_SOURCE_GR2) or "").strip()
    stamp_pack_run(arm_obj, rid, src)
    for key in (
        PROP_IMPORT_SNAPSHOT,
        PROP_IMPORT_FP,
        "gr2lab_y_up_display",
        "gr2lab_source_interp",
        "gr2lab_densify_fps",
        "gr2lab_import_densified",
    ):
        if key in donor:
            try:
                arm_obj[key] = donor[key]
            except Exception:
                pass


def link_pack_from_action(context, arm_obj, *, force: bool = False) -> Tuple[str, str, str]:
    """Stamp pack dump onto arm from its GR2LAB_* action / donor. Returns (rid, src, note)."""
    if not arm_obj:
        return "", "", ""
    donor, rid, src = _find_pack_donor(context, arm_obj)
    current = _pack_run_id(arm_obj)
    if not rid:
        return current, str(arm_obj.get(PROP_SOURCE_GR2) or "").strip(), ""
    if not force and current == rid:
        return current, str(arm_obj.get(PROP_SOURCE_GR2) or src).strip(), "already linked"
    if donor:
        _stamp_pack_from_donor(arm_obj, donor)
        remember_pack_run(rid, str(arm_obj.get(PROP_SOURCE_GR2) or src))
        return rid, str(arm_obj.get(PROP_SOURCE_GR2) or src).strip(), f"linked from {donor.name}"
    stamp_pack_run(arm_obj, rid, src)
    remember_pack_run(rid, src)
    return rid, src, f"from action GR2LAB_{rid}"


def _decode_run_ids(base_url: str = "") -> set:
    """Legacy helper — prefer dump_still_exists(run_id) (no full cache scan)."""
    _apply_layout_from_prefs()
    from .local_pipeline import decode_run_ids
    try:
        return set(decode_run_ids())
    except Exception:
        return set()


def _pack_dump_exists(run_id: str) -> bool:
    """Cheap single-folder check (does not scan all dumps)."""
    if not (run_id or "").strip():
        return False
    _apply_layout_from_prefs()
    try:
        from .local_pipeline import dump_still_exists

        return bool(dump_still_exists(run_id))
    except Exception:
        return False

def resolve_pack_run(context, arm_obj=None) -> Tuple[str, str]:
    """
    Resolve (run_id, source_gr2) for Export GR2.

    Order:
      1) GR2LAB_* action / donor armature (NLA paste workflow) — overrides stale props
      2) stamps on the active arm
      3) single other stamped scene arm
      4) last Import GR2 remember
    """
    arm_obj = arm_obj or _active_armature(context)
    if context and arm_obj:
        rid, src, _note = link_pack_from_action(context, arm_obj, force=False)
        if rid:
            return rid, src

    rid = _pack_run_id(arm_obj)
    src = str(arm_obj.get(PROP_SOURCE_GR2) or "").strip() if arm_obj else ""
    if rid:
        return rid, src

    stamped = list(_iter_pack_armatures(context, exclude=arm_obj)) if context else []
    if len(stamped) == 1:
        other = stamped[0]
        return _pack_run_id(other), str(other.get(PROP_SOURCE_GR2) or "").strip()

    return _remembered_pack_run()


def stamp_pack_run(arm_obj, run_id: str, source_gr2: str = "") -> None:
    if not arm_obj:
        return
    rid = _normalize_run_id(run_id)
    if not rid:
        return
    arm_obj[PROP_PACK_RUN] = rid
    arm_obj[PROP_RUN] = rid
    if source_gr2:
        arm_obj[PROP_SOURCE_GR2] = source_gr2


def _server_url(context) -> str:
    return "local"



class GR2LabFullPreferences(bpy.types.AddonPreferences):
    bl_idname = "gr2lab_blender"

    cache_root: StringProperty(
        name="Cache folder",
        description="Local dump/encode cache (OUT_FILES / OUT_GR2). Empty = %TEMP%/gr2lab_blender_cache",
        default="",
        subtype="DIR_PATH",
    )
    body_base_dir: StringProperty(
        name="Body_Base folder",
        description="Folder of *_Base.GR2 bind poses. Empty = addon bundled Body_Base",
        default="",
        subtype="DIR_PATH",
    )
    body_base: StringProperty(
        name="Default Body base name",
        description="Optional default Body_Base GR2 name when Auto-match fails",
        default="",
    )
    y_up_display: BoolProperty(
        name="Y-up display on GR2 import",
        description="Rotate imported armature +90 deg X for Blender Z-up view",
        default=True,
    )
    last_template: StringProperty(
        name="Last GR2LAB template",
        description="Last .gr2lab used as export template (auto-filled)",
        default="",
        subtype="FILE_PATH",
    )
    last_pack_run: StringProperty(
        name="Last pack dump",
        description="Decode run_id from last Import GR2",
        default="",
    )
    last_source_gr2: StringProperty(
        name="Last source GR2",
        description="Source .GR2 path from last Import GR2",
        default="",
    )

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Support the development:")
        op = box.operator("wm.url_open", text="Support on Patreon", icon="FUND")
        op.url = "https://www.patreon.com/c/AkELkA"
        layout.separator()
        layout.label(text="Import → edit → Export. No server. Leave paths empty.", icon="INFO")
        layout.prop(self, "y_up_display")
        layout.operator(
            "gr2lab_full.root_gate",
            icon="VIEWZOOM",
            text="Check root motion (active armature)",
        )
        box = layout.box()
        box.label(text="Advanced (optional overrides)")
        box.prop(self, "cache_root")
        box.prop(self, "body_base_dir")
        box.prop(self, "body_base")
        # last_* are auto-filled by Import/Export — not for daily editing
        row = box.row()
        row.enabled = False
        row.prop(self, "last_pack_run")
        row = box.row()
        row.enabled = False
        row.prop(self, "last_source_gr2")
        row = box.row()
        row.enabled = False
        row.prop(self, "last_template")


class GR2LABFULL_FH_gr2(bpy.types.FileHandler):
    """Drag-and-drop .GR2 into the 3D View → import via GR2 Lab."""

    bl_idname = "GR2LABFULL_FH_gr2"
    bl_label = "GR2 (GR2 Lab)"
    bl_import_operator = "import_scene.gr2_full"
    bl_file_extensions = ".gr2;.GR2"

    @classmethod
    def poll_drop(cls, context):
        area = getattr(context, "area", None)
        return area is not None and area.type in {"VIEW_3D", "OUTLINER"}


class IMPORT_OT_gr2_full(bpy.types.Operator, ImportHelper):
    """Decode GR2 in-process, densify B-splines, import rig + animation"""

    bl_idname = "import_scene.gr2_full"
    bl_label = "GR2 (GR2 Lab)"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".GR2"
    filter_glob: StringProperty(default="*.GR2;*.gr2", options={"HIDDEN"})
    filepath: StringProperty(subtype="FILE_PATH", options={"SKIP_SAVE"})
    fps: FloatProperty(name="FPS", default=FPS_DEFAULT, min=1.0, max=120.0)
    body_base: EnumProperty(
        name="Body Base",
        description="Body_Base GR2 for bind pose and IK hierarchy (same as site Decode)",
        items=_import_body_base_enum_items,
        default=0,
    )
    # Blender 5.x: do not use leading-underscore RNA property names
    bb_hint: StringProperty(name="Body Base Hint", default="", options={"HIDDEN"})
    bb_synced_for: StringProperty(name="Body Base Synced", default="", options={"HIDDEN"})

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "fps")
        try:
            _sync_import_body_base(self, context)
        except Exception:
            pass
        layout.prop(self, "body_base", text="Body Base")
        hint = getattr(self, "bb_hint", "") or ""
        if hint:
            layout.label(text=hint, icon="INFO")

    def execute(self, context):
        path = self.filepath
        if not path or not Path(path).is_file():
            self.report({"ERROR"}, "Select a .GR2 file")
            return {"CANCELLED"}
        prefs = context.preferences.addons[__package__].preferences
        base = _resolve_body_base_for_import(
            choice=(self.body_base or "AUTO").strip(),
            bb_hint=(getattr(self, "bb_hint", "") or ""),
            prefs_base=prefs.body_base,
            source_gr2=path,
        )
        print(
            f"[GR2 LAB] import body_base resolve: choice={self.body_base!r} "
            f"hint={getattr(self, 'bb_hint', '')!r} -> {base!r}"
        )
        url = _server_url(context)
        progress = Gr2LabProgress(context)
        progress.begin(100)
        dec = doc = arm = None
        try:
            progress.step(1, "Starting import…")
            dec, doc = import_gr2_pipeline(
                url, path, body_base=base, progress=progress
            )
            timer = dec.get("timer") if isinstance(dec, dict) else None
            arm = import_gr2lab_from_doc(
                context,
                doc,
                fps=self.fps,
                y_up_display=bool(prefs.y_up_display),
                template_path=None,
                progress=progress,
                template_doc=dec.get("sparse_doc") if isinstance(dec, dict) else None,
                timer=timer,
            )
        except Gr2LabApiError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        except Exception as e:
            traceback.print_exc()
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        finally:
            progress.end()

        run_id = dec.get("run_id") or doc.get("run_id") or ""

        arm[PROP_PACK_RUN] = run_id
        arm[PROP_SOURCE_GR2] = str(Path(path).resolve())
        remember_pack_run(run_id, str(Path(path).resolve()))
        try:
            arm[PROP_IMPORT_FP] = json.dumps(
                {"bones": len(doc.get("skeleton") or []), "duration": doc.get("duration")}
            )
        except Exception:
            pass
        dens = doc.get("densified_channels")
        interp = doc.get("source_interp") or ""
        imp_d = arm.get("gr2lab_import_densified")
        msg = (
            f"Imported {Path(path).name} · run={run_id} · "
            f"{len(doc.get('skeleton') or [])} bones"
        )
        if interp:
            msg += f" · {interp}"
        if dens:
            msg += f" · densified={dens}"
        if imp_d:
            msg += f" · import-bake={imp_d}"
        self.report({"INFO"}, msg)
        timer = dec.get("timer") if isinstance(dec, dict) else None
        if timer is not None:
            try:
                timer.print_block()
                dump_dir = Path(str(dec.get("files_dir") or dec.get("dump_dir") or ""))
                if dump_dir.is_dir():
                    timer.write_json(dump_dir / "TIMING.json")
            except Exception:
                pass
            self.report({"INFO"}, timer.format_compact())
        if base:
            self.report({"INFO"}, f"Body base: {Path(base).name}")
        if dec.get("bind_warning"):
            bw = str(dec["bind_warning"])
            if dec.get("bind_optional"):
                self.report({"INFO"}, bw)
            else:
                self.report({"WARNING"}, bw)
        elif dec.get("bind"):
            self.report(
                {"INFO"},
                f"Bind T-pose OK ({(dec.get('bind') or {}).get('bones', '?')} bones)",
            )
        elif not dec.get("bind_optional"):
            self.report(
                {"WARNING"},
                "No T-pose bind — rest pose / NLA on other rigs will be wrong.",
            )
        return {"FINISHED"}


class EXPORT_OT_gr2_full(bpy.types.Operator, ExportHelper):
    """Encode GR2 in-process — modal TIMER so Blender stays responsive."""

    bl_idname = "export_scene.gr2_full"
    bl_label = "GR2 (GR2 Lab)"
    bl_options = {"REGISTER"}

    filename_ext = ".GR2"
    filter_glob: StringProperty(default="*.GR2;*.gr2", options={"HIDDEN"})
    arm_name: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    pack_run: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    source_gr2: StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    bake_mode: EnumProperty(
        name="Bake before export",
        description=(
            "Visual flatten: sample NLA+constraints into one Action, then clear "
            "NLA tracks and constraints (destructive; Ctrl+Z undoes)"
        ),
        items=BAKE_MODE_ITEMS,
        default="AUTO",
    )

    def _resolve_live_pack(self, context, arm) -> Tuple[str, str]:
        """Resolve pack dump; if missing on disk, relink from GR2LAB_* action."""
        rid, src = resolve_pack_run(context, arm)
        if rid and not _pack_dump_exists(rid):
            # Stale custom prop after re-import under a new lyric suffix.
            if arm and arm.get(PROP_PACK_RUN) == rid:
                try:
                    del arm[PROP_PACK_RUN]
                except Exception:
                    arm[PROP_PACK_RUN] = ""
            link_pack_from_action(context, arm, force=True)
            rid, src = resolve_pack_run(context, arm)
            if rid and not _pack_dump_exists(rid):
                rem_rid, rem_src = _remembered_pack_run()
                if rem_rid and _pack_dump_exists(rem_rid):
                    stamp_pack_run(arm, rem_rid, rem_src)
                    rid, src = rem_rid, rem_src
        if arm and rid:
            stamp_pack_run(arm, rid, src)
            remember_pack_run(rid, src)
        return rid, src

    def invoke(self, context, event):
        arm = _active_armature(context)
        rid, src = self._resolve_live_pack(context, arm) if arm else ("", "")
        self.arm_name = arm.name if arm else ""
        self.pack_run = rid
        self.source_gr2 = src
        # Prefer a short default name in the current/home dir — do NOT open the
        # original IN_GR2 path (huge folders make the file browser crawl).
        stem = Path(src).stem if src else (Path(str(arm.get(PROP_SOURCE_GR2) or "export")).stem if arm else "export")
        if not stem:
            stem = "export"
        self.filepath = str(Path(stem + "_encoded.GR2"))
        # Cache UI bits once — draw() must stay cheap (file browser redraws a lot)
        self._ui_rid = rid
        self._ui_bake = False
        self._ui_hint = ""
        if arm:
            try:
                self._ui_bake = bool(_export_should_bake(arm, self.bake_mode))
            except Exception:
                self._ui_bake = False
            try:
                status, detail = peek_export_template_hint(context, arm)
                self._ui_hint = f"{status}" + (f" ({detail})" if detail else "")
            except Exception:
                self._ui_hint = ""
        return ExportHelper.invoke(self, context, event)

    def draw(self, context):
        # Keep this trivial — Blender calls draw on every file-browser refresh.
        layout = self.layout
        rid = (getattr(self, "_ui_rid", None) or self.pack_run or "").strip()
        if rid:
            layout.label(text=f"Pack from dump: {rid}", icon="CHECKMARK")
        else:
            layout.label(text="No pack run — Import GR2 first", icon="ERROR")
        hint = getattr(self, "_ui_hint", "") or ""
        if hint:
            layout.label(text=f"Export source: {hint}")
        if getattr(self, "_ui_bake", False):
            layout.label(text="Will flatten NLA + constraints", icon="TIME")
        layout.prop(self, "bake_mode")
        layout.label(text="Encode runs in background (Esc cancels)")
    def execute(self, context):
        arm = None
        if self.arm_name and self.arm_name in bpy.data.objects:
            obj = bpy.data.objects[self.arm_name]
            if obj.type == "ARMATURE":
                arm = obj
        arm = arm or _active_armature(context)
        if not arm:
            self.report({"ERROR"}, "Select the animated armature")
            return {"CANCELLED"}
        run_id, source_gr2 = self._resolve_live_pack(context, arm)
        source_gr2 = source_gr2 or str(arm.get(PROP_SOURCE_GR2) or "").strip() or None
        if not run_id:
            self.report(
                {"ERROR"},
                "No decode run_id — Import GR2 (via GR2 Lab), keep that action "
                "(GR2LAB_<dump>) on this armature / NLA, then Export again",
            )
            return {"CANCELLED"}
        stamp_pack_run(arm, run_id, source_gr2 or "")
        remember_pack_run(run_id, source_gr2 or "")
        self.pack_run = run_id
        self.source_gr2 = source_gr2 or ""

        self._arm_name = arm.name
        self._run_id = run_id
        self._source_gr2 = source_gr2
        self._server_url = _server_url(context)
        self._phase = "sample"
        self._net_thread = None
        self._net_result = None
        self._net_error = None
        self._stats = None
        self._progress = Gr2LabProgress(context)
        self._progress.begin(100)
        self._progress.step(1, "Starting export…")
        self._gen = export_gr2lab_doc(
            context,
            arm_obj=arm,
            progress=self._progress,
            bake_mode=self.bake_mode,
            cooperative=True,
        )
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.02, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _cleanup_timer(self, context):
        wm = context.window_manager
        if getattr(self, "_timer", None) is not None:
            try:
                wm.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if getattr(self, "_progress", None) is not None:
            self._progress.end()
            self._progress = None

    def _start_network(self):
        stats = self._stats or {}
        doc = dict(stats.get("doc") or {})
        doc["run_id"] = self._run_id
        url = self._server_url
        run_id = self._run_id
        timer = stats.get("_stage_timer")
        dest = self.filepath
        source_gr2 = self._source_gr2

        def worker():
            try:
                self._net_result = pack_encode_gr2(
                    url,
                    run_id,
                    doc,
                    dest,
                    source_gr2=source_gr2,
                    progress=None,
                    timer=timer,
                )
            except Exception as ex:
                self._net_error = ex

        self._phase = "network"
        self._progress.step(86, "Encoding GR2…")
        self._net_thread = __import__("threading").Thread(target=worker, daemon=True)
        self._net_thread.start()

    def modal(self, context, event):
        if event.type == "ESC":
            gen = getattr(self, "_gen", None)
            if gen is not None:
                try:
                    gen.close()
                except Exception:
                    pass
                self._gen = None
            self._cleanup_timer(context)
            self.report({"WARNING"}, "Export cancelled")
            return {"CANCELLED"}
        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        if self._phase == "sample":
            try:
                pct, label = next(self._gen)
                if self._progress:
                    self._progress.step(int(pct), label)
            except StopIteration as stop:
                self._stats = stop.value if isinstance(stop.value, dict) else None
                if not self._stats or "doc" not in self._stats:
                    self._cleanup_timer(context)
                    self.report({"ERROR"}, "Export produced no document")
                    return {"CANCELLED"}
                self._start_network()
            except Exception as e:
                traceback.print_exc()
                self._cleanup_timer(context)
                self.report({"ERROR"}, str(e))
                return {"CANCELLED"}
            return {"PASS_THROUGH"}

        if self._phase == "network":
            if self._net_thread and self._net_thread.is_alive():
                if self._progress:
                    self._progress.step(90, "Encoding GR2…")
                return {"PASS_THROUGH"}
            self._cleanup_timer(context)
            if self._net_error is not None:
                err = self._net_error
                if isinstance(err, Gr2LabApiError):
                    self.report({"ERROR"}, str(err))
                else:
                    traceback.print_exc()
                    self.report({"ERROR"}, str(err))
                return {"CANCELLED"}
            enc = self._net_result or {}
            if enc.get("ok") is False:
                self.report(
                    {"ERROR"},
                    str(enc.get("error") or enc.get("message") or "Export refused"),
                )
                return {"CANCELLED"}
            imp = enc.get("import_result") or {}
            stats = self._stats or {}
            mode = enc.get("mode") or enc.get("badge") or "encoded"
            bones_applied = int(imp.get("bones_edited") or 0)
            ops_applied = int(imp.get("ops") or 0)
            apply_noop = bool(enc.get("apply_noop")) or not bool(imp.get("changed"))
            bake_note = (
                "baked" if stats.get("baked") else f"fcurve+eval{stats.get('eval_bones', 0)}"
            )
            self.report(
                {"INFO"},
                f"Wrote {Path(self.filepath).name} · dump={self._run_id} · {mode} · "
                f"{bake_note} · applied {bones_applied} bones / {ops_applied} ops · "
                f"{stats.get('matched', 0)} matched · {stats.get('frames_sampled', 0)} frames",
            )
            if apply_noop:
                self.report({"INFO"}, "Motion matched dump (noop apply) — GR2 still written")
            elif enc.get("warning"):
                self.report({"WARNING"}, str(enc["warning"]))
            if enc.get("hybrid_warning"):
                self.report({"INFO"}, str(enc["hybrid_warning"]))
            if enc.get("root_gate_warning"):
                self.report({"WARNING"}, str(enc["root_gate_warning"]))
            if stats.get("missing"):
                self.report(
                    {"WARNING"},
                    f"{stats['missing']} template bones missing — original tracks kept",
                )
            timer = enc.get("timer") or stats.get("_stage_timer")
            if timer is not None:
                try:
                    timer.print_block()
                except Exception:
                    pass
                self.report({"INFO"}, timer.format_compact())
            return {"FINISHED"}

        return {"PASS_THROUGH"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None



class IMPORT_OT_gr2lab_full(bpy.types.Operator, ImportHelper):
    bl_idname = "import_scene.gr2lab_full"
    bl_label = "GR2LAB (.gr2lab)"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".gr2lab"
    filter_glob: StringProperty(default="*.gr2lab;*.gr2lab.json", options={"HIDDEN"})
    filepath: StringProperty(subtype="FILE_PATH", options={"SKIP_SAVE"})
    fps: FloatProperty(name="FPS", default=FPS_DEFAULT, min=1.0, max=120.0)

    def execute(self, context):
        progress = Gr2LabProgress(context)
        progress.begin(100)
        try:
            progress.step(5, "Reading GR2LAB…")
            import_gr2lab(
                context,
                self.filepath,
                fps=self.fps,
                progress=progress,
            )
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        finally:
            progress.end()
        self.report({"INFO"}, f"Imported {Path(self.filepath).name}")
        return {"FINISHED"}


class EXPORT_OT_gr2lab_full(bpy.types.Operator, ExportHelper):
    bl_idname = "export_scene.gr2lab_full"
    bl_label = "GR2LAB (.gr2lab)"
    bl_options = {"REGISTER"}

    filename_ext = ".gr2lab"
    filter_glob: StringProperty(default="*.gr2lab;*.gr2lab.json", options={"HIDDEN"})
    bake_mode: EnumProperty(
        name="Bake before export",
        description=(
            "Visual flatten: sample NLA+constraints into one Action, then clear "
            "NLA tracks and constraints (destructive; Ctrl+Z undoes)"
        ),
        items=BAKE_MODE_ITEMS,
        default="AUTO",
    )

    def draw(self, context):
        self.layout.prop(self, "bake_mode")

    def execute(self, context):
        arm = _active_armature(context)
        if not arm:
            self.report({"ERROR"}, "Select an armature")
            return {"CANCELLED"}
        progress = Gr2LabProgress(context)
        progress.begin(100)
        try:
            progress.step(2, "Exporting GR2LAB…", force_ui=True)
            stats = _consume_export_gr2lab(
                export_gr2lab(
                    context,
                    self.filepath,
                    arm_obj=arm,
                    progress=progress,
                    bake_mode=self.bake_mode,
                    cooperative=True,
                )
            )
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        finally:
            progress.end()
        bake_note = "baked" if stats.get("baked") else f"fcurve+eval{stats.get('eval_bones', 0)}"
        self.report(
            {"INFO"},
            f"Exported · {stats.get('matched', 0)} matched · {bake_note} · "
            f"source={stats.get('template_source')}",
        )
        return {"FINISHED"}


class OBJECT_OT_gr2lab_bake_nla_constraints(bpy.types.Operator):
    """Bake armature NLA + constraints into one Action, then clear NLA and constraints."""

    bl_idname = "object.gr2lab_bake_nla_constraints"
    bl_label = "GR2 Lab: Bake NLA + Constraints"
    bl_description = (
        "Sample evaluated pose (NLA + constraints), write one Action, "
        "then remove all NLA tracks and constraints"
    )
    bl_options = {"REGISTER", "UNDO"}

    frame_start: bpy.props.IntProperty(name="Start", default=1)
    frame_end: bpy.props.IntProperty(name="End", default=250)
    step: bpy.props.IntProperty(name="Step", default=1, min=1)
    auto_range: BoolProperty(
        name="Auto Frame Range",
        default=True,
        description="Detect frame range from NLA strips / Action",
    )
    bake_object: BoolProperty(
        name="Bake Object Transform",
        default=True,
        description="Also bake the armature object's visual Loc/Rot/Scale",
    )

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None

    def invoke(self, context, event):
        obj = _active_armature(context)
        fs, fe = determine_bake_range(obj, context.scene)
        self.frame_start = fs
        self.frame_end = fe
        self.bake_object = _has_object_motion_or_constraints(obj)
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "auto_range")
        col = layout.column(align=True)
        col.enabled = not self.auto_range
        col.prop(self, "frame_start")
        col.prop(self, "frame_end")
        layout.prop(self, "step")
        layout.prop(self, "bake_object")
        layout.separator()
        layout.label(text="Result: 1 Action, no NLA, no constraints.", icon="INFO")

    def execute(self, context):
        obj = _active_armature(context)
        if not obj:
            self.report({"ERROR"}, "Select an Armature")
            return {"CANCELLED"}

        prev_mode = obj.mode
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        try:
            bpy.ops.object.mode_set(mode="POSE")
        except Exception:
            pass

        fs = None if self.auto_range else self.frame_start
        fe = None if self.auto_range else self.frame_end
        try:
            gen = bake_armature_nla_and_constraints(
                context,
                obj,
                frame_start=fs,
                frame_end=fe,
                step=self.step,
                bake_object=self.bake_object,
                push_undo=False,  # operator already has UNDO
            )
            result = None
            try:
                while True:
                    next(gen)
            except StopIteration as stop:
                result = stop.value
            finally:
                try:
                    gen.close()
                except Exception:
                    pass
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        try:
            if prev_mode in {"POSE", "OBJECT", "EDIT"}:
                bpy.ops.object.mode_set(
                    mode=prev_mode if prev_mode != "EDIT" else "POSE"
                )
            else:
                bpy.ops.object.mode_set(mode="POSE")
        except Exception:
            pass

        if not result:
            self.report({"ERROR"}, "Bake produced no result")
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            (
                f"Baked '{result['action']}' "
                f"[{result['frame_start']}-{result['frame_end']}] | "
                f"NLA tracks removed: {result['nla_tracks_removed']} | "
                f"Constraints removed: "
                f"{result['object_constraints_removed']}+{result['bone_constraints_removed']}"
            ),
        )
        return {"FINISHED"}


class OBJECT_OT_gr2lab_import_partner(bpy.types.Operator):
    bl_idname = "object.gr2lab_import_partner"
    bl_label = "GR2 Lab: Import scene partner"
    bl_description = "Not available in standalone addon yet (optional site tools)"
    bl_options = {"REGISTER"}

    def execute(self, context):
        self.report(
            {"ERROR"},
            "Scene partner is not in the standalone addon yet. Use the optional site for dual-character preview.",
        )
        return {"CANCELLED"}


class OBJECT_OT_gr2lab_link_dump(bpy.types.Operator):
    """Stamp GR2 Lab dump id onto the active armature from its GR2LAB_* action / NLA."""

    bl_idname = "object.gr2lab_link_dump"
    bl_label = "GR2 Lab: Link dump from action"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        arm = _active_armature(context)
        if not arm:
            self.report({"ERROR"}, "Select an armature")
            return {"CANCELLED"}
        rid, src, note = link_pack_from_action(context, arm, force=True)
        if not rid:
            self.report(
                {"ERROR"},
                "No GR2LAB_* action/NLA found — Import GR2 first, then paste that action here",
            )
            return {"CANCELLED"}
        ids = _decode_run_ids(_server_url(context))
        if ids and rid not in ids:
            self.report(
                {"WARNING"},
                f"Linked dump={rid} but it is not on GR2 Lab right now — re-import that GR2",
            )
        else:
            self.report({"INFO"}, f"Dump={rid}" + (f" · {note}" if note else ""))
        if src:
            self.report({"INFO"}, f"Source GR2: {src}")
        return {"FINISHED"}

    @classmethod
    def poll(cls, context):
        return _active_armature(context) is not None



class OBJECT_OT_gr2lab_root_gate(bpy.types.Operator):
    bl_idname = "gr2lab_full.root_gate"
    bl_label = "GR2 Lab: Check root motion"
    bl_description = "Compare source vs last encoded GR2 for Dummy_Root / Root_M shift"
    bl_options = {"REGISTER"}

    encoded_path: StringProperty(
        name="Encoded GR2",
        description="Encoded .GR2 to validate",
        default="",
        subtype="FILE_PATH",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        self.layout.prop(self, "encoded_path")

    def execute(self, context):
        _apply_layout_from_prefs(context)
        arm = _active_armature(context)
        if not arm:
            self.report({"ERROR"}, "Select a GR2 Lab armature")
            return {"CANCELLED"}
        rid = (arm.get(PROP_PACK_RUN) or "").strip()
        src = (arm.get(PROP_SOURCE_GR2) or "").strip()
        enc = (self.encoded_path or "").strip()
        if not src or not Path(src).is_file():
            self.report({"ERROR"}, "Armature missing source GR2 path — re-import first")
            return {"CANCELLED"}
        if not enc or not Path(enc).is_file():
            self.report({"ERROR"}, "Set Encoded GR2 path")
            return {"CANCELLED"}
        try:
            from .codec.root_gate import validate_root_export
            from .local_pipeline import resolve_dump_dir

            dump = None
            if rid:
                try:
                    dump = resolve_dump_dir(rid)
                except Exception:
                    dump = None
            report = validate_root_export(
                Path(src),
                Path(enc),
                dump=dump if dump and dump.is_dir() else None,
                allow_root_delta=False,
                expect_noop=False,
            )
        except Exception as e:
            traceback.print_exc()
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        ok = report.get("ok")
        badge = report.get("badge") or ("PASS" if ok else "FAIL")
        lat = report.get("max_root_lateral")
        msg = f"Root gate {badge}"
        if isinstance(lat, (int, float)):
            msg += f" · lateral={lat:.4f}m"
        if ok:
            self.report({"INFO"}, msg)
            return {"FINISHED"}
        fails = report.get("fails") or []
        self.report(
            {"ERROR"},
            msg + ((" · " + "; ".join(map(str, fails[:3]))) if fails else ""),
        )
        return {"CANCELLED"}



def menu_import(self, context):
    self.layout.operator(IMPORT_OT_gr2_full.bl_idname, text="GR2 (GR2 Lab)")
    self.layout.operator(IMPORT_OT_gr2lab_full.bl_idname, text="GR2LAB (.gr2lab)")


def menu_export(self, context):
    self.layout.operator(EXPORT_OT_gr2_full.bl_idname, text="GR2 (GR2 Lab)")
    self.layout.operator(EXPORT_OT_gr2lab_full.bl_idname, text="GR2LAB (.gr2lab)")


def menu_object(self, context):
    self.layout.separator()
    self.layout.operator(OBJECT_OT_gr2lab_bake_nla_constraints.bl_idname, icon="ACTION")
    self.layout.operator(OBJECT_OT_gr2lab_link_dump.bl_idname)
    self.layout.operator(OBJECT_OT_gr2lab_root_gate.bl_idname, icon="VIEWZOOM")
    self.layout.operator(OBJECT_OT_gr2lab_import_partner.bl_idname)


classes = (
    GR2LabFullPreferences,
    GR2LABFULL_FH_gr2,
    IMPORT_OT_gr2_full,
    EXPORT_OT_gr2_full,
    IMPORT_OT_gr2lab_full,
    EXPORT_OT_gr2lab_full,
    OBJECT_OT_gr2lab_bake_nla_constraints,
    OBJECT_OT_gr2lab_link_dump,
    OBJECT_OT_gr2lab_root_gate,
    OBJECT_OT_gr2lab_import_partner,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_export)
    bpy.types.VIEW3D_MT_object.append(menu_object)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_export)
    bpy.types.VIEW3D_MT_object.remove(menu_object)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
