"""Stage timing for GR2 Lab decode/encode (console + TIMING.json)."""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, Optional


def _ms(sec: float) -> int:
    return int(round(sec * 1000.0))


class StageTimer:
    def __init__(self, label: str = "") -> None:
        self.label = label
        self._t0 = time.perf_counter()
        self._mark = self._t0
        self.stages: Dict[str, int] = {}

    def span(self, name: str) -> "_StageSpan":
        return _StageSpan(self, name)

    def add(self, name: str, seconds: float) -> None:
        self.stages[name] = self.stages.get(name, 0) + _ms(seconds)

    def mark(self, name: str) -> None:
        now = time.perf_counter()
        self.stages[name] = self.stages.get(name, 0) + _ms(now - self._mark)
        self._mark = now

    def total_ms(self) -> int:
        return _ms(time.perf_counter() - self._t0)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "label": self.label,
            "total_ms": self.total_ms(),
            "stages_ms": dict(self.stages),
        }

    def format_block(self) -> str:
        total_s = self.total_ms() / 1000.0
        parts = [f"{k}={v / 1000.0:.2f}s" for k, v in self.stages.items()]
        body = "  ".join(parts) if parts else "(no stages)"
        return f"[GR2 LAB timing] {self.label} total={total_s:.2f}s\n  {body}"

    def format_compact(self) -> str:
        total_s = self.total_ms() / 1000.0
        bits = [f"{k} {v / 1000.0:.1f}" for k, v in self.stages.items()]
        return f"timing {total_s:.1f}s · " + " · ".join(bits)

    def print_block(self) -> None:
        print(self.format_block(), flush=True)

    def write_json(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(self.as_dict(), separators=(",", ":"), ensure_ascii=False),
            encoding="utf-8",
        )


class _StageSpan:
    def __init__(self, timer: StageTimer, name: str) -> None:
        self._timer = timer
        self._name = name
        self._t0 = 0.0

    def __enter__(self) -> "_StageSpan":
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, *exc: Any) -> None:
        self._timer.add(self._name, time.perf_counter() - self._t0)


def dump_json_compact(obj: Any, path: Path) -> None:
    Path(path).write_text(
        json.dumps(obj, separators=(",", ":"), ensure_ascii=False),
        encoding="utf-8",
    )


def maybe_timer(timer: Optional[StageTimer], name: str):
    if timer is None:
        return _NullSpan()
    return timer.span(name)


class _NullSpan:
    def __enter__(self) -> "_NullSpan":
        return self

    def __exit__(self, *exc: Any) -> None:
        return None
