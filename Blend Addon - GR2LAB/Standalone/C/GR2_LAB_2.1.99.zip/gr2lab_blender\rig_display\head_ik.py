"""DGB-style head IK helpers for GR2 LAB imports (viewport only).

Reproduces Armature_KARLACH_DGB:
  IK_Head (child of Neck_M) → IK constraint to IK_Head_Target bone (chain 5)
  IK_Head.001 (connected visual extension)
  IK_Head_Target bone (child of Dummy_Root) — pose this; IK target
  IK_Head_Target mesh object — Copy Location / Copy Rotation Target (no bone)
  UI_Head_* floating 2D HUD (IK / Extra / Kiss) parented to Dummy_Root
  Head_M / Neck_M / Chest_M copy-rotation constraints driven by those sliders

Helper bones are use_deform=False and must not be encoded into GR2.
"""
from __future__ import annotations

import math
from typing import Any, Callable, List, Optional, Tuple

import bpy
from mathutils import Vector

HELPER_BONES = frozenset(
    (
        "IK_Head",
        "IK_Head.001",
        "IK_Head_Target",
        "UI_Head",
        "UI_Head_IK",
        "UI_Head_IK_Track",
        "UI_Head_Spine",
        "UI_Head_Spine_Track",
        "UI_Head_Kiss",
        "UI_Head_Kiss_Track",
    )
)

_TARGET = "IK_Head_Target"
_TARGET_OBJECT = "IK_Head_Target"
_IK_HEAD = "IK_Head"
_IK_HEAD_TIP = "IK_Head.001"
_UI_ROOT = "UI_Head"
_UI_IK = "UI_Head_IK"
_UI_SPINE = "UI_Head_Spine"
_UI_KISS = "UI_Head_Kiss"
_KISS_OBJECT = "Lips"
_KISS_KEY = "gr2lab_kiss_target"
_KISS_SIZE = 0.045
# Floating 2D HUD in UI_Head bone space (XY metres, origin = panel bottom-left).
UI_PANEL_W = 0.22
UI_PANEL_H = 0.18
UI_MARGIN = 0.012
UI_TITLE_H = 0.028
UI_KNOB_LEN = 0.030
UI_KNOB_WID = 0.016
UI_FIELD_H = 0.026
UI_LABEL_W = 0.066
UI_FIELD_PAD = 0.006
_KNOB_CLEARANCE = 0.008
_VISIBLE = frozenset(
    (
        _TARGET,
        _UI_ROOT,
        _UI_IK,
        _UI_SPINE,
        _UI_KISS,
    )
)
_SELECTABLE = frozenset((_TARGET, _UI_ROOT, _UI_IK, _UI_SPINE, _UI_KISS))

_COLL = {
    _IK_HEAD: "Extra",
    _IK_HEAD_TIP: "Extra",
    _TARGET: "IK",
    _UI_ROOT: "IK",
    _UI_IK: "IK",
    _UI_SPINE: "IK",
    _UI_KISS: "IK",
    f"{_UI_IK}_Track": "IK",
    f"{_UI_SPINE}_Track": "IK",
    f"{_UI_KISS}_Track": "IK",
}

ModeSet = Callable[..., None]


def is_helper_bone(name: str) -> bool:
    return name in HELPER_BONES or name.startswith("UI_Head")


def _set_mode(ctx, mode: str, arm_obj, mode_set: Optional[ModeSet]) -> None:
    if mode_set is not None:
        mode_set(ctx, mode, active=arm_obj)
        return
    ctx.view_layer.objects.active = arm_obj
    if arm_obj.mode != mode:
        bpy.ops.object.mode_set(mode=mode)


def ui_field_x() -> float:
    return UI_MARGIN + UI_LABEL_W


def ui_field_x1() -> float:
    return UI_PANEL_W - UI_MARGIN


def ui_knob_inset() -> float:
    """Keep the knob capsule inside the field's rounded caps."""
    r_track = UI_FIELD_H * 0.5
    r_knob = UI_KNOB_WID * 0.5
    return max(r_track - r_knob, 0.0) + _KNOB_CLEARANCE


def ui_knob_rest_x() -> float:
    return ui_field_x() + UI_KNOB_LEN * 0.5 + ui_knob_inset()


def ui_travel() -> float:
    span = ui_field_x1() - ui_field_x()
    return max(span - UI_KNOB_LEN - 2.0 * ui_knob_inset(), 1e-4)


def ui_row_y(index: int) -> float:
    """Vertical center of slider row 0=IK, 1=Kiss, 2=Extra (panel space)."""
    top = UI_PANEL_H - UI_MARGIN - UI_TITLE_H
    bottom = UI_MARGIN + 0.010
    row_h = (top - bottom) / 3.0
    return top - (index + 0.5) * row_h


def ui_panel_center() -> Vector:
    """Pivot of UI_Head — middle of the card, not the bottom-left corner."""
    return Vector((UI_PANEL_W * 0.5, UI_PANEL_H * 0.5, 0.0))


def _ensure_edit_bone(
    ebones,
    name: str,
    *,
    parent,
    head,
    tail,
    use_connect: bool,
    roll=None,
):
    bone = ebones.get(name)
    if bone is None:
        bone = ebones.new(name)
    bone.parent = parent
    bone.use_connect = bool(use_connect)
    bone.head = Vector(head)
    bone.tail = Vector(tail)
    bone.use_deform = False
    aim = Vector(roll) if roll is not None else Vector((0.0, 1.0, 0.0))
    try:
        bone.align_roll(aim)
    except Exception:
        pass
    return bone


def _float_slider(pb, name: str, value: float, description: str) -> None:
    pb[name] = float(value)
    try:
        ui = pb.id_properties_ui(name)
        ui.update(min=0.0, max=1.0, default=0.0, description=description)
    except Exception:
        pass
    try:
        pb.property_overridable_library_set(f'["{name}"]', True)
    except Exception:
        pass


def _ensure_constraint(pb, con_type: str, name: str):
    for c in pb.constraints:
        if c.name == name:
            return c
    con = pb.constraints.new(con_type)
    con.name = name
    return con


def _prop_path(var_name: str) -> str:
    if var_name in ("_Kiss", "_Influence"):
        return f'pose.bones["{_TARGET}"]["!Kiss"]'
    if var_name == "Extra":
        return f'pose.bones["{_TARGET}"]["Extra"]'
    return f'pose.bones["{_TARGET}"]["IK"]'


def _remove_driver(arm_obj, data_path: str) -> None:
    ad = arm_obj.animation_data
    if ad is None:
        return
    for fcu in list(ad.drivers):
        if fcu.data_path == data_path:
            try:
                ad.drivers.remove(fcu)
            except Exception:
                pass


def _drive_from_ui_bone(arm_obj, data_path: str, ui_bone: str) -> None:
    """Map UI slider local Y (0..ui_travel()) onto 0..1."""
    travel = ui_travel()
    if arm_obj.animation_data is None:
        arm_obj.animation_data_create()
    _remove_driver(arm_obj, data_path)
    fcu = arm_obj.driver_add(data_path)
    drv = fcu.driver
    drv.type = "SCRIPTED"
    drv.expression = f"min(1.0, max(0.0, loc / {travel}))"
    while drv.variables:
        drv.variables.remove(drv.variables[0])
    var = drv.variables.new()
    var.name = "loc"
    var.type = "SINGLE_PROP"
    tgt = var.targets[0]
    tgt.id_type = "OBJECT"
    tgt.id = arm_obj
    tgt.data_path = f'pose.bones["{ui_bone}"].location[1]'


def _lock_slider(pb) -> None:
    pb.lock_location = (True, False, True)
    pb.lock_rotation = (True, True, True)
    pb.lock_scale = (True, True, True)
    try:
        pb.lock_rotation_w = True
    except Exception:
        pass
    lim = None
    for c in pb.constraints:
        if c.type == "LIMIT_LOCATION" and c.name == "UI Slider":
            lim = c
            break
    if lim is None:
        lim = pb.constraints.new("LIMIT_LOCATION")
        lim.name = "UI Slider"
    lim.owner_space = "LOCAL"
    lim.use_min_x = lim.use_max_x = True
    lim.use_min_y = lim.use_max_y = True
    lim.use_min_z = lim.use_max_z = True
    lim.min_x = lim.max_x = 0.0
    lim.min_z = lim.max_z = 0.0
    lim.min_y = 0.0
    lim.max_y = ui_travel()
    try:
        lim.use_transform_limit = True
    except Exception:
        pass


def _constraint_to_index(pb, name: str, index: int) -> None:
    names = [c.name for c in pb.constraints]
    if name not in names:
        return
    src = names.index(name)
    try:
        pb.constraints.move(src, index)
    except Exception:
        pass


_KISS_MESH = "GR2LAB_Lips"


def _kiss_mesh():
    """Two rings + cross — the Copy Loc/Rot target mesh. Not the bone arrow."""
    verts = []
    edges = []
    for radius, segs in ((1.0, 24), (0.42, 16)):
        base = len(verts)
        for i in range(segs):
            a = (2.0 * math.pi * i) / segs
            verts.append((math.cos(a), 0.0, math.sin(a)))
            edges.append((base + i, base + ((i + 1) % segs)))
    gap = 0.10
    for p0, p1 in (
        ((-1.0, 0.0, 0.0), (-gap, 0.0, 0.0)),
        ((gap, 0.0, 0.0), (1.0, 0.0, 0.0)),
        ((0.0, 0.0, -1.0), (0.0, 0.0, -gap)),
        ((0.0, 0.0, gap), (0.0, 0.0, 1.0)),
    ):
        b = len(verts)
        verts.extend((p0, p1))
        edges.append((b, b + 1))
    me = bpy.data.meshes.get(_KISS_MESH)
    if me is None:
        me = bpy.data.meshes.new(_KISS_MESH)
        me.from_pydata(verts, edges, [])
        me.update()
        return me
    if len(me.vertices) >= 40:
        return me
    fresh = bpy.data.meshes.new(_KISS_MESH)
    fresh.from_pydata(verts, edges, [])
    fresh.update()
    return fresh


def _mouth_world(arm_obj) -> Vector:
    for name in ("Dummy_MouthFX", "Dummy_HeadFX", "Head_M"):
        pb = arm_obj.pose.bones.get(name)
        if pb is not None:
            loc = (arm_obj.matrix_world @ pb.matrix).to_translation()
            fwd = (arm_obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, -1.0))).normalized()
            return loc + fwd * 0.03
    return arm_obj.matrix_world.translation.copy()


def _parent_object_to_armature(obj, arm_obj) -> None:
    """Object-parent Lips so moving the armature takes it along.

    First attach snaps to the mouth; later display applies leave a posed Lips alone.
    """
    if obj is None or arm_obj is None:
        return
    already = obj.parent == arm_obj and getattr(obj, "parent_type", "OBJECT") == "OBJECT"
    if already:
        return
    obj.matrix_world.translation = _mouth_world(arm_obj)
    mw = obj.matrix_world.copy()
    obj.parent = arm_obj
    try:
        obj.parent_type = "OBJECT"
    except Exception:
        pass
    try:
        obj.parent_bone = ""
    except Exception:
        pass
    obj.matrix_world = mw


def ensure_kiss_object(arm_obj, context=None, src_wgt=None) -> Optional[Any]:
    """Scene mesh for IK_Head_Target Copy Location / Copy Rotation Target."""
    if arm_obj is None:
        return None
    obj = None
    for existing in bpy.data.objects:
        if existing.get(_KISS_KEY) == arm_obj.name:
            obj = existing
            break
    if obj is None:
        existing = bpy.data.objects.get(_KISS_OBJECT)
        if existing is not None and existing.get(_KISS_KEY) in (None, arm_obj.name):
            obj = existing
            obj[_KISS_KEY] = arm_obj.name
    reticle = _kiss_mesh()
    if obj is None:
        obj = bpy.data.objects.new(_KISS_OBJECT, reticle)
        obj[_KISS_KEY] = arm_obj.name
        linked = False
        ctx = context or bpy.context
        for coll in arm_obj.users_collection:
            try:
                coll.objects.link(obj)
                linked = True
            except RuntimeError:
                pass
            break
        if not linked:
            try:
                ctx.scene.collection.objects.link(obj)
            except RuntimeError:
                pass
        obj.matrix_world.translation = _mouth_world(arm_obj)
    else:
        obj.data = reticle
    _parent_object_to_armature(obj, arm_obj)
    obj.scale = (_KISS_SIZE, _KISS_SIZE, _KISS_SIZE)
    obj.hide_render = True
    obj.hide_viewport = False
    try:
        obj.hide_select = False
    except Exception:
        pass
    obj.display_type = "WIRE"
    try:
        obj.show_in_front = True
    except Exception:
        pass
    return obj


def bind_lookat_object(arm_obj, obj) -> None:
    """Neck Copy Rotation Target is the follower mesh (object, no bone)."""
    if arm_obj is None or obj is None:
        return
    pb = arm_obj.pose.bones.get(_TARGET)
    if pb is None:
        return
    for name in ("Follow Object", "Follow Object Rot"):
        for c in list(pb.constraints):
            if c.name == name:
                try:
                    pb.constraints.remove(c)
                except Exception:
                    pass
    pb_neck = arm_obj.pose.bones.get("Neck_M")
    if pb_neck is not None:
        ncr = None
        for c in pb_neck.constraints:
            if c.type == "COPY_ROTATION" and c.name == "Copy Rotation":
                ncr = c
                break
        if ncr is not None:
            ncr.target = obj
            ncr.subtarget = ""
            ncr.target_space = "WORLD"


def bind_kiss_object(arm_obj, obj) -> None:
    """IK_Head_Target Copy Loc/Rot Target = scene mesh object, not a bone."""
    if arm_obj is None or obj is None:
        return
    pb = arm_obj.pose.bones.get(_TARGET)
    if pb is None:
        return
    for c in pb.constraints:
        if c.type in {"COPY_LOCATION", "COPY_ROTATION"} and c.name in (
            "Copy Location",
            "Copy Rotation",
        ):
            c.target = obj
            c.subtarget = ""
            c.target_space = "WORLD"
            c.owner_space = "WORLD"


def _set_influence_driver(
    arm_obj,
    data_path: str,
    *,
    var_name: str,
    expression: str,
    scripted: bool,
) -> None:
    if arm_obj.animation_data is None:
        arm_obj.animation_data_create()
    _remove_driver(arm_obj, data_path)
    fcu = arm_obj.driver_add(data_path)
    drv = fcu.driver
    drv.type = "SCRIPTED" if scripted else "AVERAGE"
    drv.expression = expression
    while drv.variables:
        drv.variables.remove(drv.variables[0])
    var = drv.variables.new()
    var.name = var_name
    var.type = "SINGLE_PROP"
    tgt = var.targets[0]
    tgt.id_type = "OBJECT"
    tgt.id = arm_obj
    tgt.data_path = _prop_path(var_name)


def _assign_collection(arm_obj, bone_name: str) -> None:
    data = arm_obj.data
    colls = getattr(data, "collections", None)
    if colls is None:
        return
    dest_name = _COLL.get(bone_name)
    if not dest_name:
        return
    dest = colls.get(dest_name) if hasattr(colls, "get") else None
    if dest is None:
        idx = colls.find(dest_name) if hasattr(colls, "find") else -1
        dest = colls[idx] if idx >= 0 else None
    if dest is None:
        dest = colls.new(dest_name)
    bone = data.bones.get(bone_name)
    if bone is None:
        return
    try:
        dest.assign(bone)
    except Exception:
        pass
    for col in list(bone.collections):
        if col != dest:
            try:
                col.unassign(bone)
            except Exception:
                pass


def _create_ui_bones(eb, head_m, dummy) -> None:
    """2D HUD to the character's right, parented to Dummy_Root so it floats."""
    right = Vector((1.0, 0.0, 0.0))
    up = Vector((0.0, 1.0, 0.0))
    forward = Vector((0.0, 0.0, -1.0))
    z_roll = Vector((0.0, 0.0, 1.0))
    origin = Vector(head_m.head) + right * 0.30 + forward * 0.04 - up * 0.07
    center = origin + ui_panel_center()
    _ensure_edit_bone(
        eb,
        _UI_ROOT,
        parent=dummy,
        head=center,
        tail=center + up * 0.002,
        use_connect=False,
        roll=z_roll,
    )
    ui_root = eb[_UI_ROOT]
    field_x = ui_knob_rest_x()
    for i, knob in enumerate((_UI_IK, _UI_KISS, _UI_SPINE)):
        h = origin + Vector((field_x, ui_row_y(i), 0.0))
        _ensure_edit_bone(
            eb,
            knob,
            parent=ui_root,
            head=h,
            tail=h + Vector((0.002, 0.0, 0.0)),
            use_connect=False,
            roll=z_roll,
        )
        track = eb.get(f"{knob}_Track")
        if track is not None:
            eb.remove(track)
        child = eb.get(knob)
        if child is not None:
            try:
                child.inherit_scale = "FULL"
            except Exception:
                pass


def setup_head_ik_on_armature(
    arm_obj,
    *,
    context=None,
    mode_set: Optional[ModeSet] = None,
) -> Tuple[List[str], List[str]]:
    """Create helper bones, 3D UI sliders, constraints, and drivers."""
    if not arm_obj or arm_obj.type != "ARMATURE":
        return [], ["No armature"]
    data = arm_obj.data
    if data.bones.get("Head_M") is None or data.bones.get("Neck_M") is None:
        return [], ["Head_M/Neck_M missing — skip head IK"]
    if data.bones.get("Dummy_Root") is None:
        return [], ["Dummy_Root missing — skip head IK"]

    ctx = context or bpy.context
    errors: List[str] = []
    ok: List[str] = []
    try:
        _set_mode(ctx, "EDIT", arm_obj, mode_set)
        eb = data.edit_bones
        head_m = eb["Head_M"]
        neck = eb["Neck_M"]
        dummy = eb["Dummy_Root"]
        # DGB Z-up layout mapped into this Y-up armature: forward = local -Z, up = +Y.
        forward = Vector((0.0, 0.0, -1.0))
        up = Vector((0.0, 1.0, 0.0))
        origin = Vector(head_m.head)
        ik_head = origin + forward * 0.007 - up * 0.013
        ik_tail = ik_head + forward * 0.221
        tip_tail = ik_tail + up * 0.083
        tgt_tail = ik_tail + forward * 0.092
        _ensure_edit_bone(
            eb, _IK_HEAD, parent=neck, head=ik_head, tail=ik_tail, use_connect=False
        )
        _ensure_edit_bone(
            eb,
            _IK_HEAD_TIP,
            parent=eb[_IK_HEAD],
            head=ik_tail,
            tail=tip_tail,
            use_connect=True,
        )
        _ensure_edit_bone(
            eb, _TARGET, parent=dummy, head=ik_tail, tail=tgt_tail, use_connect=False
        )
        _create_ui_bones(eb, head_m, dummy)
        ok.append("helper bones")
    except Exception as exc:
        errors.append(str(exc))
        return ok, errors
    finally:
        try:
            _set_mode(ctx, "POSE", arm_obj, mode_set)
        except Exception:
            pass

    for name in HELPER_BONES:
        db = data.bones.get(name)
        if db is None:
            continue
        db.use_deform = False
        db.hide = name not in _VISIBLE
        try:
            db.hide_select = name not in _SELECTABLE
        except Exception:
            pass
        if name in (_UI_ROOT, _UI_IK, _UI_SPINE, _UI_KISS, _TARGET):
            try:
                db.show_wire = False
            except Exception:
                pass
        _assign_collection(arm_obj, name)

    pb_ik = arm_obj.pose.bones.get(_IK_HEAD)
    pb_tgt = arm_obj.pose.bones.get(_TARGET)
    pb_head = arm_obj.pose.bones.get("Head_M")
    pb_neck = arm_obj.pose.bones.get("Neck_M")
    if not (pb_ik and pb_tgt and pb_head and pb_neck):
        errors.append("pose bones missing after create")
        return ok, errors

    _float_slider(pb_tgt, "IK", 0.0, "Head look-at IK (0 = animation, 1 = follow target)")
    _float_slider(pb_tgt, "Extra", 0.0, "Chest mix toward the head IK target")
    _float_slider(pb_tgt, "!Kiss", 0.0, "World copy from Lips mesh object")
    if "Spine" in pb_tgt:
        try:
            del pb_tgt["Spine"]
        except Exception:
            pass

    for knob in (_UI_IK, _UI_SPINE, _UI_KISS):
        pb_ui = arm_obj.pose.bones.get(knob)
        if pb_ui is not None:
            pb_ui.location[0] = 0.0
            pb_ui.location[2] = 0.0
            _lock_slider(pb_ui)
    pb_panel = arm_obj.pose.bones.get(_UI_ROOT)
    if pb_panel is not None:
        try:
            pb_panel.rotation_mode = "XYZ"
        except Exception:
            pass
        pb_panel.lock_location = (False, False, False)
        pb_panel.lock_rotation = (False, False, False)
        pb_panel.lock_scale = (False, False, False)
        try:
            pb_panel.lock_rotation_w = False
        except Exception:
            pass
    _remove_driver(arm_obj, f'pose.bones["{_TARGET}"]["Spine"]')
    _drive_from_ui_bone(arm_obj, f'pose.bones["{_TARGET}"]["IK"]', _UI_IK)
    _drive_from_ui_bone(arm_obj, f'pose.bones["{_TARGET}"]["Extra"]', _UI_SPINE)
    _drive_from_ui_bone(arm_obj, f'pose.bones["{_TARGET}"]["!Kiss"]', _UI_KISS)

    for pb in (pb_ik, pb_head, pb_neck):
        pb.ik_rotation_weight = 1.0
        pb.ik_linear_weight = 1.0
    pb_chest = arm_obj.pose.bones.get("Chest_M")
    if pb_chest is not None:
        pb_chest.ik_rotation_weight = 1.0
        pb_chest.ik_linear_weight = 1.0
    pb_sp2 = arm_obj.pose.bones.get("Spine2_M")
    if pb_sp2 is not None:
        pb_sp2.ik_rotation_weight = 1.0
        pb_sp2.ik_linear_weight = 1.0

    ik_con = _ensure_constraint(pb_ik, "IK", "IK")
    ik_con.target = arm_obj
    ik_con.subtarget = _TARGET
    ik_con.chain_count = 5
    ik_con.use_stretch = True
    ik_con.use_rotation = False
    ik_con.use_tail = True
    ik_con.influence = 0.0
    _set_influence_driver(
        arm_obj,
        f'pose.bones["{_IK_HEAD}"].constraints["IK"].influence',
        var_name="IK",
        expression="IK",
        scripted=False,
    )

    cr = _ensure_constraint(pb_head, "COPY_ROTATION", "Copy Rotation")
    cr.target = arm_obj
    cr.subtarget = _IK_HEAD
    cr.owner_space = "LOCAL"
    cr.target_space = "LOCAL_OWNER_ORIENT"
    cr.use_x = cr.use_y = cr.use_z = True
    cr.invert_x = cr.invert_y = cr.invert_z = False
    try:
        cr.mix_mode = "ADD"
    except Exception:
        pass
    if hasattr(cr, "use_offset"):
        cr.use_offset = True
    cr.influence = 1.0
    _set_influence_driver(
        arm_obj,
        f'pose.bones["Head_M"].constraints["Copy Rotation"].influence',
        var_name="_Kiss",
        expression="1-_Kiss",
        scripted=True,
    )

    cr2 = _ensure_constraint(pb_head, "COPY_ROTATION", "Copy Rotation.001")
    cr2.target = arm_obj
    cr2.subtarget = _IK_HEAD
    cr2.owner_space = "WORLD"
    cr2.target_space = "WORLD"
    cr2.use_x = cr2.use_y = cr2.use_z = True
    cr2.invert_x = cr2.invert_y = cr2.invert_z = False
    try:
        cr2.mix_mode = "REPLACE"
    except Exception:
        pass
    if hasattr(cr2, "use_offset"):
        cr2.use_offset = False
    cr2.influence = 0.0
    _set_influence_driver(
        arm_obj,
        f'pose.bones["Head_M"].constraints["Copy Rotation.001"].influence',
        var_name="_Kiss",
        expression="_Kiss",
        scripted=False,
    )

    ncr = _ensure_constraint(pb_neck, "COPY_ROTATION", "Copy Rotation")
    ncr.target = arm_obj
    ncr.subtarget = _TARGET
    ncr.owner_space = "LOCAL_WITH_PARENT"
    ncr.target_space = "LOCAL_OWNER_ORIENT"
    ncr.use_x = ncr.use_y = ncr.use_z = True
    ncr.invert_x = ncr.invert_y = ncr.invert_z = False
    try:
        ncr.mix_mode = "REPLACE"
    except Exception:
        pass
    if hasattr(ncr, "use_offset"):
        ncr.use_offset = False
    ncr.influence = 0.0
    _set_influence_driver(
        arm_obj,
        f'pose.bones["Neck_M"].constraints["Copy Rotation"].influence',
        var_name="IK",
        expression="IK/2",
        scripted=True,
    )

    if pb_chest is not None:
        ccr = _ensure_constraint(pb_chest, "COPY_ROTATION", "Copy Rotation")
        ccr.target = arm_obj
        ccr.subtarget = _IK_HEAD
        ccr.owner_space = "LOCAL"
        ccr.target_space = "LOCAL_OWNER_ORIENT"
        ccr.use_x = ccr.use_y = ccr.use_z = True
        ccr.invert_x = ccr.invert_y = ccr.invert_z = False
        try:
            ccr.mix_mode = "ADD"
        except Exception:
            pass
        if hasattr(ccr, "use_offset"):
            ccr.use_offset = True
        ccr.influence = 0.0
        _set_influence_driver(
            arm_obj,
            f'pose.bones["Chest_M"].constraints["Copy Rotation"].influence',
            var_name="Extra",
            expression="Extra",
            scripted=False,
        )

    lips = ensure_kiss_object(arm_obj, ctx)
    cloc = _ensure_constraint(pb_tgt, "COPY_LOCATION", "Copy Location")
    cloc.target = lips
    cloc.subtarget = ""
    cloc.owner_space = "WORLD"
    cloc.target_space = "WORLD"
    cloc.use_x = cloc.use_y = cloc.use_z = True
    if hasattr(cloc, "use_offset"):
        cloc.use_offset = False
    cloc.influence = 0.0
    _set_influence_driver(
        arm_obj,
        f'pose.bones["{_TARGET}"].constraints["Copy Location"].influence',
        var_name="_Influence",
        expression="_Influence",
        scripted=False,
    )

    crot = _ensure_constraint(pb_tgt, "COPY_ROTATION", "Copy Rotation")
    crot.target = lips
    crot.subtarget = ""
    crot.owner_space = "WORLD"
    crot.target_space = "WORLD"
    try:
        crot.mix_mode = "AFTER"
    except Exception:
        pass
    if hasattr(crot, "use_offset"):
        crot.use_offset = True
    crot.influence = 0.0
    _set_influence_driver(
        arm_obj,
        f'pose.bones["{_TARGET}"].constraints["Copy Rotation"].influence',
        var_name="_Influence",
        expression="_Influence",
        scripted=False,
    )

    ok.append("constraints+drivers")
    print("[GR2 LAB] Head IK: floating HUD UI_Head_IK / Extra / Kiss → IK_Head_Target")
    return ok, errors
