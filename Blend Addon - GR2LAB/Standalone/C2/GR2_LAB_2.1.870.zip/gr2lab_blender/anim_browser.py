"""Bottom 3D-view browser for unpacked BG3 character animations.

Hover renders five camera stills of the whole scene in a separate Blender.
The open file is not modified.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import pickle
import struct
import subprocess
import threading
import time
import traceback
import contextlib
import zlib
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import blf
import bpy
import gpu
from bpy_extras.view3d_utils import (
    location_3d_to_region_2d,
    region_2d_to_origin_3d,
    region_2d_to_vector_3d,
)
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix, Vector
from mathutils.geometry import intersect_line_plane

from .import_modal import _DECODE_LOCK

PREVIEW_REV = 4
PREVIEW_MAX_STILLS = 24
PREVIEW_PLAY_FPS = 12.0
PREVIEW_ASPECT = 16.0 / 9.0
PREVIEW_RENDER_W = 512
PREVIEW_RENDER_H = 288

STICK_SAMPLE_FPS = 50.0
STICK_MAX_FRAMES = 300
# Hover plays the real clip length. 12 Hz samples read as a slow blend.
STICK_HOVER_SAMPLE_FPS = 24.0
STICK_HOVER_MAX_FRAMES = 288
STICK_CACHE_VER = 8
STICK_HOVER_DEBOUNCE = 0.28
STICK_LOAD_TAG_INTERVAL = 0.22
STICK_BUSY_MOVE_INTERVAL = 0.055
STICK_PLAY_INTERVAL = 1.0 / 12.0
STICK_PARTNER_SHIFT = 1.15
# gr2_path -> (player empty, partner empty) in stick preview space
_STICK_STAGE_OFFSETS: Dict[str, Tuple[Optional[Vector], Optional[Vector]]] = {}
STRIP_MARGIN_X = 8.0
STRIP_MARGIN_Y = 6.0


def _window_ptr_key(window) -> str:
    """WindowManager ID props only store C-int-sized values; pointers need strings."""
    return str(int(window.as_pointer()))


def _modal_win_booted(wm, prop: str) -> set:
    booted = set()
    for raw in wm.get(prop) or ():
        try:
            booted.add(str(int(raw)))
        except (TypeError, ValueError):
            booted.add(str(raw))
    return booted


def _modal_win_set(wm, prop: str, booted: set) -> None:
    wm[prop] = [str(k) for k in booted]
STRIP_HEIGHT = 224.0
PANE_SCENE = 0.35
PANE_CLIP = 0.65
PREVIEW_PANE_W = 208.0
CLIP_DRAG_THRESHOLD = 10.0
_TOOLBAR_CHIP_KINDS = frozenset(
    {
        "act",
        "filter",
        "whole",
        "center",
        "edit",
        "recent",
        "explorer",
        "glasses",
        "prepare",
        "holo_mesh",
        "rig",
        "rig_shapes",
        "rig_limbs",
        "rig_head",
        "rig_tail",
        "rig_mesh",
        "rig_akelka",
    }
)
# Drag draws a hologram only. The rig is imported after the mouse button goes up.
CLIP_PRELOAD_TIMER_HZ = 20.0
CLIP_PRELOAD_PUMP_EVERY = 1
CLIP_PRELOAD_COMMIT_SLICES = 16
CLIP_PRELOAD_BUDGET_MOVE_S = 0.006
CLIP_PRELOAD_BUDGET_PAUSE_S = 0.014
CLIP_PRELOAD_BUDGET_IDLE_S = 0.02
CLIP_PRELOAD_SLICES_MOVE = 1
CLIP_PRELOAD_SLICES_PAUSE = 3
CLIP_PRELOAD_SLICES_IDLE = 5
CLIP_DRAG_HIT_INTERVAL_S = 0.04
CLIP_DRAG_HIT_MIN_PX = 28.0
CLIP_DRAG_RIPPLE_LITE_COUNT = 2
CLIP_DRAG_RIPPLE_LITE_SEGMENTS = 36
CLIP_DROP_LIFT = 0.002
CLIP_DROP_LINE_PX = 1.35
CLIP_DROP_RIPPLE_COUNT = 6
CLIP_DROP_RIPPLE_MAX_R = 0.78
CLIP_DROP_RIPPLE_SPEED = 0.36
CLIP_DROP_RIPPLE_SEGMENTS = 72
CLIP_DROP_RIPPLE_ALPHA_PEAK = 0.42
CLIP_DROP_BRACKET_HALF_U = 0.4
CLIP_DROP_BRACKET_HALF_V = 0.3
CLIP_DROP_BRACKET_ARM = 0.22
CLIP_DROP_STAKE_HEIGHT = 1.65
CLIP_DROP_GRID_STEP = 1.0
_DROP_WHITE = (1.0, 1.0, 1.0, 0.94)

_WM_CLIP_DROP_KEY = "gr2lab_clip_drop_pending"

_HANDLE = None
_VIEW_DRAG_HANDLE = None
_KEYMAPS: List[Tuple[object, object]] = []
_ALIVE = False
_TIMER_ON = False

# Whole character-animation trees. _Cinematic is one folder inside these.
# Version 1 indexes were cinematic-only and must be rebuilt.
_INDEX_VERSION = 2
_TREES = (
    Path("Models/Public/SharedDev/Assets/Characters/_Anims"),
    Path("Models/Public/Shared/Assets/Characters/_Anims"),
)
_COMPANIONS = (
    "Karlach",
    "Shadowheart",
    "Gale",
    "Laezel",
    "Wyll",
    "Astarion",
    "Halsin",
    "Minthara",
    "Jaheira",
    "Minsc",
)
_TAG_WORDS = {"CAMP", "ROM", "CRD", "SD", "SEX", "DATE"}
_ACTS = ("All", "Act01", "Act02", "Act03")

_PREP_LOCK = threading.Lock()
_PREP = {
    "running": False,
    "scenes": 0,
    "phase": "",
    "error": "",
    "done": False,
    "cancel": False,
}

_STATE = {
        "act": "All",
    "camp": False,
    "rom": False,
        "cast": "",
    "kind": "",
    "who": "",
    "filter_open": False,
    "query": "",
    "search_focus": False,
    "search_modal": False,
    "search_sel": False,
    "search_anchor": 0,
    "search_caret": 0,
    "search_scroll": 0.0,
    "search_blink_phase": -1,
    "search_refilter_at": 0.0,
    "tag_pending": False,
    "scene_scroll": 0,
    "clip_scroll": 0,
    "scene_id": "",
    "whole_scene": True,
    "center_parent": True,
    "edit_copy": False,
    "filtered_key": "",
    "filtered": [],
    "pane_scene": PANE_SCENE,
    "pane_clip": PANE_CLIP,
    "show_recent": False,
    "holo_mesh": False,
    "preview_on": True,
    "preview_zoom": 1.0,
    "preview_yaw": 0.0,
    "preview_pitch": 0.0,
}
_POINTER = {"mx": 0.0, "my": 0.0, "over_strip": False}
_CLIP_ARM: Dict[str, object] = {}
_CLIP_MENU_PATH = ""
_INDEX = {"mtime": 0.0, "data": None}
_HITS: Dict[int, list] = {}
_LAYOUTS: Dict[int, dict] = {}
_DRAG = {
    "active": False,
    "filepath": "",
    "label": "",
    "region": 0,
    "sx": 0.0,
    "sy": 0.0,
    "mx": 0.0,
    "my": 0.0,
    "point": None,
    "over_strip": False,
    "shift": False,
    "grid_place": False,
    "use_dialog": False,
    "normal": None,
    "region_w": 0.0,
    "region_h": 0.0,
    "t0": 0.0,
    "wm_timer": None,
    "preload": None,
    "preload_failed": "",
}
_PREVIEW = {
    "off": None,
    "w": 0,
    "h": 0,
    "fail": False,
    "timer": False,
    "path": "",
    "actors": [],
}


_HOVER = {
    "path": "",
    "since": 0.0,
    "thread": None,
    "gen": 0,
    "result": None,
    "shown": "",
    "poses": None,
    "pose_i": 0,
    "pose_tick": 0.0,
    "status": "",
    "mem": {},
    "cache_files": {},
    "stick_pending_gen": -1,
}


_PREFETCH = {"gen": 0, "queue": [], "thread": None}


def cache_dir() -> Path:
    local = os.environ.get("LOCALAPPDATA") or str(Path.home())
    path = Path(local) / "gr2lab"
    path.mkdir(parents=True, exist_ok=True)
    return path


def index_path() -> Path:
    return cache_dir() / "anim_index.json"


def pose_dir() -> Path:
    path = cache_dir() / "preview_poses"
    path.mkdir(parents=True, exist_ok=True)
    return path


RECENT_CLIP_MAX = 12
RECENT_CLIP_UI_ROWS = 5
_RECENT = {"loaded": False, "items": []}


def _recent_store_path() -> Path:
    return cache_dir() / "anim_recent.json"


def _ensure_recent_loaded() -> None:
    if _RECENT["loaded"]:
        return
    _RECENT["loaded"] = True
    path = _recent_store_path()
    try:
        if path.is_file():
            with path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            if isinstance(raw, list):
                _RECENT["items"] = [row for row in raw if isinstance(row, dict)]
                return
    except (OSError, ValueError, TypeError):
        pass
    _RECENT["items"] = []


def _save_recent_clips() -> None:
    path = _recent_store_path()
    try:
        with path.open("w", encoding="utf-8") as handle:
            json.dump(_RECENT["items"], handle, indent=0)
    except OSError:
        pass


def _record_recent_clip(filepath: str) -> None:
    path = str(filepath or "").strip()
    try:
        from .codec.paths import readable_file
    except ImportError:
        from paths import readable_file  # type: ignore
    if not path or readable_file(path) is None:
        return
    _ensure_recent_loaded()
    name = Path(path).name
    scene_label = ""
    data = _load_index()
    if data:
        scene, _clip = _indexed_clip(data, path)
        if scene is not None:
            scene_label = str(scene.get("name") or "")
    key = _path_key(path)
    items = [
        row
        for row in _RECENT["items"]
        if _path_key(str(row.get("path") or "")) != key
    ]
    items.insert(
        0,
        {
            "path": path,
            "name": name,
            "scene": scene_label,
            "t": time.time(),
        },
    )
    _RECENT["items"] = items[:RECENT_CLIP_MAX]
    _save_recent_clips()
    _tag()


def _recent_clips_for_ui() -> List[dict]:
    if not _STATE.get("show_recent", False):
        return []
    _ensure_recent_loaded()
    try:
        from .codec.paths import readable_file
    except ImportError:
        from paths import readable_file  # type: ignore
    out: List[dict] = []
    for row in _RECENT["items"]:
        p = str(row.get("path") or "")
        if p and readable_file(p) is not None:
            out.append(row)
        if len(out) >= RECENT_CLIP_UI_ROWS:
            break
    return out


def _shader():
    return gpu.shader.from_builtin("UNIFORM_COLOR")


def _stroke_rect(x, y, w, h, color, thickness: float = 1.5) -> None:
    t = float(thickness)
    if w <= 0 or h <= 0 or t <= 0:
        return
    _rect(x, y + h - t, w, t, color)
    _rect(x, y, w, t, color)
    _rect(x, y, t, h, color)
    _rect(x + w - t, y, t, h, color)


def _pointer_over(x, y, w, h) -> bool:
    return _over_box(
        (x, y, w, h),
        float(_POINTER.get("mx") or -1.0),
        float(_POINTER.get("my") or -1.0),
    )


def _button_pressed(kind: str) -> bool:
    if not kind or kind != _STATE.get("chip_press"):
        return False
    return time.time() < float(_STATE.get("chip_press_until") or 0.0)


def _paint_button(x, y, w, h, kind: str, bg, *, on: bool = False):
    """Fill a chip. Hover gets a stroke; a fresh click lights the whole button."""
    hot = _pointer_over(x, y, w, h) or (bool(kind) and kind == _POINTER.get("hover_kind"))
    pressed = _button_pressed(kind)
    if pressed:
        bg = (0.38, 0.64, 0.94, 1.0)
    elif hot and on:
        bg = (0.32, 0.52, 0.74, 1.0)
    elif hot:
        bg = (0.22, 0.28, 0.34, 1.0)
    _rect(x, y, w, h, bg)
    if pressed:
        _stroke_rect(x, y, w, h, (0.92, 0.96, 1.0, 1.0), 2.0)
    elif hot:
        _stroke_rect(x, y, w, h, (0.62, 0.82, 1.0, 1.0), 1.5)


def _flash_chip(kind: str) -> None:
    _STATE["chip_press"] = str(kind or "")
    _STATE["chip_press_until"] = time.time() + 0.28
    _tag()
    if bpy is not None and not bpy.app.timers.is_registered(_chip_press_clear):
        bpy.app.timers.register(_chip_press_clear, first_interval=0.28)


def _chip_press_clear():
    if time.time() < float(_STATE.get("chip_press_until") or 0.0):
        return 0.05
    _STATE["chip_press"] = ""
    _tag()
    return None


def _explorer_open_timer():
    """Open Explorer after the chip has painted, so the click is visible first."""
    try:
        _set_notice(_open_explorer())
    except Exception:
        traceback.print_exc()
        _set_notice("Explorer failed")
    return None


def _rect(x, y, w, h, color) -> None:
    if w <= 0 or h <= 0:
        return
    shader = _shader()
    batch = batch_for_shader(
        shader,
        "TRI_FAN",
        {"pos": ((x, y), (x + w, y), (x + w, y + h), (x, y + h))},
    )
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set("NONE")


def _lines(pairs, color) -> None:
    if len(pairs) < 2:
        return
    shader = _shader()
    batch = batch_for_shader(shader, "LINES", {"pos": pairs})
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set("NONE")


def _polyline_2d(
    points: Tuple[Tuple[float, float], ...],
    color: Tuple[float, float, float, float],
    width_px: float,
) -> None:
    if len(points) < 2:
        return
    viewport = _gpu_viewport_size()
    shader = gpu.shader.from_builtin("POLYLINE_UNIFORM_COLOR")
    batch = batch_for_shader(shader, "LINE_STRIP", {"pos": points})
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_float("viewportSize", viewport)
    shader.uniform_float("lineWidth", float(width_px))
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.blend_set("NONE")


def _font(size: int) -> int:
    font_id = 0
    try:
        blf.size(font_id, size)
    except TypeError:
        blf.size(font_id, size, 72)
    return font_id


def _text_width(font_id: int, text: str) -> float:
    try:
        return float(blf.dimensions(font_id, text)[0])
    except Exception:
        return float(len(text) * 7)


def _clip_text(font_id: int, text: str, width: float) -> str:
    if _text_width(font_id, text) <= width:
        return text
    ell = "…"
    lo, hi = 0, len(text)
    best = ell
    while lo <= hi:
        mid = (lo + hi) // 2
        trial = text[:mid] + ell
        if _text_width(font_id, trial) <= width:
            best = trial
            lo = mid + 1
        else:
            hi = mid - 1
    return best


def _tag(min_interval: float = 0.0) -> None:
    if min_interval > 0.0:
        now = time.perf_counter()
        wait = float(_STATE.get("tag_wait_until") or 0.0)
        if now < wait:
            _STATE["tag_pending"] = True
            return
        _STATE["tag_wait_until"] = now + min_interval
    _STATE["tag_pending"] = False
    try:
        wm = bpy.context.window_manager
    except Exception:
        return
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _blender_window_active() -> bool:
    """This Blender process owns the foreground window. Background playback stays put."""
    now = time.perf_counter()
    if now - float(_STATE.get("focus_check") or 0.0) < 0.2:
        return bool(_STATE.get("focused"))
    active = True
    try:
        import ctypes

        hwnd = int(ctypes.windll.user32.GetForegroundWindow() or 0)
        if not hwnd:
            active = False
        else:
            pid = ctypes.c_ulong()
            ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            active = int(pid.value) == os.getpid()
    except Exception:
        active = True
    _STATE["focus_check"] = now
    _STATE["focused"] = active
    return active


def _gallery_hold_if_inactive() -> bool:
    """Pause hologram time while Blender is not the app in front."""
    active = _blender_window_active()
    was = _GALLERY.get("app_active")
    now = time.perf_counter()
    if was is None:
        _GALLERY["app_active"] = active
        return not active
    if active and not was:
        away = now - float(_GALLERY.get("blur_at") or now)
        _GALLERY["t0"] = float(_GALLERY.get("t0") or now) + max(0.0, away)
        _GALLERY["app_active"] = True
        return False
    if not active:
        if was:
            _GALLERY["blur_at"] = now
        _GALLERY["app_active"] = False
        return True
    return False


def _flush_tag_pending() -> None:
    if _STATE.get("tag_pending"):
        _STATE["tag_wait_until"] = 0.0
        _tag()


def _prefs_unpacked_raw(context) -> str:
    try:
        addon = context.preferences.addons.get("gr2lab_blender")
        prefs = addon.preferences if addon is not None else None
        return (getattr(prefs, "bg3_unpacked_dir", "") or "").strip() if prefs else ""
    except Exception:
        return ""


def _set_prefs_unpacked_dir(context, directory: str) -> None:
    path = str(directory or "").strip()
    if not path:
        return
    try:
        addon = context.preferences.addons.get("gr2lab_blender")
        prefs = addon.preferences if addon is not None else None
        if prefs is not None and hasattr(prefs, "bg3_unpacked_dir"):
            prefs.bg3_unpacked_dir = path
    except Exception:
        pass


def unpacked_root(context) -> Optional[Path]:
    """Addon prefs first, then env / Glasses MCP / default UnpackedData roots."""
    extra = []
    raw = _prefs_unpacked_raw(context)
    if raw:
        extra.append(raw)
    try:
        from . import bg3_unpacked_resolve as unpacked

        roots = unpacked.unpacked_roots(extra or None)
    except Exception:
        roots = []
    if roots:
        return roots[0]
    if raw:
        path = Path(raw)
        return path if path.is_dir() else None
    return None


def _search_roots(root: Path) -> List[Path]:
    found = [root]
    if root.name.lower() == "gustav" and root.parent.is_dir():
        found.append(root.parent)
    return found


def _act_of(path: Path) -> str:
    for part in path.parts:
        low = part.lower()
        if low.startswith("act") and len(part) >= 4 and part[3:].isdigit():
            return "Act" + part[3:]
    return ""


def _tags_of(path: Path) -> List[str]:
    tags = set()
    blob = path.name
    for token in blob.replace("-", "_").split("_"):
        word = token.strip()
        if word.upper() in _TAG_WORDS:
            tags.add(word.upper())
        for companion in _COMPANIONS:
            if word.lower() == companion.lower():
                tags.add(companion)
    for part in path.parts:
        if part.upper() == "CAMP":
            tags.add("CAMP")
    return sorted(tags)


# Last tokens that are a phase or a same-body export, not the other person.
# AST / Daisy / Volo stay off this list so they pair with the PLYR file.
_BODY_TAIL_SKIP = {
    "LOOP", "IN", "OUT", "START", "END", "ANTIC", "ATTACK", "RECOVER",
    "PREPARE", "CAST", "DASH", "CANCEL", "TRANSIT", "ENDLFOOT", "ENDRFOOT",
    "LONGSNOUT", "PLAYERLOOP", "PLAYERSHORTLOOP", "IDLE", "GREET", "BOW",
    "HOLD", "INTRO", "CHARGE", "LAND", "LANDING", "TALLEST", "BARB",
    "SHORT", "FAIL", "SUCCESS", "FISTCLOSEUPPLYR", "MIN", "MAX", "HIGH", "LOW",
    "A", "B", "C", "D", "E", "X", "Y", "Z",
}


def _stem_parts(filename: str) -> List[str]:
    parts = [part for part in Path(filename).stem.split("_") if part]
    if parts and parts[-1].upper() == "LONGSNOUT":
        parts.pop()
    return parts


def _body_tail(filename: str) -> str:
    """Role token at the end of a clip: PLYR, Astarion, AST, Daisy, Volo."""
    parts = _stem_parts(filename)
    if not parts:
        return ""
    raw = parts[-1]
    token = raw.upper()
    if token.isdigit() or token in _BODY_TAIL_SKIP:
        return ""
    # KarlachApproach / DoesntTakeHand is the action, shared with the PLYR file.
    # AST, Daisy and Volo are the other person.
    letters = [ch for ch in raw if ch.isalpha()]
    caps = sum(ch.isupper() for ch in letters)
    if letters and caps >= 2 and caps != len(letters):
        return ""
    return token


def _role(name: str) -> str:
    tail = _body_tail(name)
    if tail in {"PLYR", "PLAYER"}:
        return "player"
    if tail:
        return "partner"
    upper = name.upper()
    for companion in _COMPANIONS:
        if companion.upper() in upper:
            return "partner"
    return "other"


_CAST_ALIAS = {
    "PLYR": "player",
    "PLAYER": "player",
    "AST": "astarion",
    "WTHRS": "withers",
    "WITHERS": "withers",
    "LAE": "laezel",
}
_CAST_TAKE = {"IN", "OUT", "LOOP", "START", "END"}
_CAST_ACTION = {"GREET", "IDLE", "BOW", "HOLD", "INTRO", "CHARGE", "LAND", "LANDING"}
_CAST_FAMILY_SKIP = {"M", "F", "FS", "MF", "MS", "HEAD", "A", "B", "C", "D", "TAIL"}


def _cast_alias(token: str) -> str:
    text = str(token or "").upper()
    if not text:
        return ""
    found = _CAST_ALIAS.get(text)
    if found:
        return found
    for companion in _COMPANIONS:
        if text == companion.upper():
            return companion.lower()
    return ""


def _cast_is_prop(name: str) -> bool:
    upper = name.upper()
    return upper.startswith("WPN_") or upper.startswith("CINE_") or "GENERIC_" in upper


def _cast_is_take(token: str) -> bool:
    text = token.upper()
    if text.isdigit() or text in _CAST_TAKE:
        return True
    return len(text) >= 2 and text[0] == "A" and text[1:].isdigit()


def _cast_is_action(token: str) -> bool:
    if token.upper() in _CAST_ACTION:
        return True
    return any(ch.isupper() for ch in token[1:])


def _cast_family(parts: List[str]) -> str:
    upper = [part.upper() for part in parts]
    cut = upper.index("RIG") if "RIG" in upper else len(parts)
    family = [part for part in parts[:cut] if part.upper() not in _CAST_FAMILY_SKIP]
    if family:
        return family[0].upper()
    return parts[0].upper() if parts else "BODY"


def _cast_person(tail: str, prev: str) -> str:
    alias = _cast_alias(tail)
    if alias:
        return alias
    token = tail.upper()
    if any(ch.isdigit() for ch in token) and token.isalnum():
        return "npc:" + token.lower()
    prev_alias = _cast_alias(prev)
    if prev_alias:
        return prev_alias
    if _cast_is_action(tail) or len(token) < 3:
        return ""
    return "npc:" + token.lower()


def _clip_cast_parts(filename: str) -> Tuple[str, str, bool]:
    """(person id, rig family, True when this file names that person)."""
    name = Path(str(filename or "")).name
    if not name or _cast_is_prop(name):
        return "", "", False
    parts = Path(name).stem.split("_")
    if parts and parts[-1].upper() == "LONGSNOUT":
        parts.pop()
    while parts and _cast_is_take(parts[-1]):
        parts.pop()
    if not parts:
        return "", "", False
    family = _cast_family(parts)
    if "SCENE" not in {part.upper() for part in parts}:
        return "body:" + family, family, True
    prev = parts[-2] if len(parts) > 1 else ""
    who = _cast_person(parts[-1], prev)
    if who:
        return who, family, True
    return "", family, False


def _scene_cast_ids(clips: List[str]) -> set:
    """People in one scene. Race variants of the player or a companion count once."""
    people = set()
    bare = set()
    resolved = set()
    for name in clips or []:
        ident, family, named = _clip_cast_parts(name)
        if named and ident:
            people.add(ident)
            if family:
                resolved.add(family)
        elif family:
            bare.add(family)
    for family in bare:
        if family not in resolved:
            people.add("body:" + family)
    return people


def _scene_cast_count(scene: dict) -> int:
    cached = scene.get("_cast_n") if isinstance(scene, dict) else None
    if isinstance(cached, int):
        return cached
    count = len(_scene_cast_ids(list((scene or {}).get("clips") or [])))
    if isinstance(scene, dict):
        scene["_cast_n"] = count
    return count


def _cast_modes() -> set:
    return {ch for ch in str(_STATE.get("cast") or "") if ch in {"1", "2", "3"}}


def _cast_bucket(count: int) -> str:
    if count <= 1:
        return "1"
    if count == 2:
        return "2"
    return "3"


def _cast_allows(count: int) -> bool:
    modes = _cast_modes()
    if not modes:
        return True
    return _cast_bucket(count) in modes


_FILTER_KINDS = (
    ("camp", "Camp"),
    ("rom", "Romance"),
    ("date", "Date"),
    ("sex", "Sex"),
)


def _token_modes(key: str) -> set:
    return {part for part in str(_STATE.get(key) or "").split(",") if part}


def _kind_modes() -> set:
    return {part for part in _token_modes("kind") if part in {item[0] for item in _FILTER_KINDS}}


def _who_modes() -> set:
    allowed = set(_COMPANIONS)
    return {part for part in _token_modes("who") if part in allowed}


def _filter_active() -> bool:
    return bool(_cast_modes() or _kind_modes() or _who_modes())


def _filter_button_label() -> str:
    count = len(_cast_modes()) + len(_kind_modes()) + len(_who_modes())
    if count:
        return f"Filter {count}"
    return "Filter"


def _filter_notice() -> str:
    parts = []
    cast = _cast_modes()
    cast_labels = []
    if "1" in cast:
        cast_labels.append("solo")
    if "2" in cast:
        cast_labels.append("pairs")
    if "3" in cast:
        cast_labels.append("groups")
    if cast_labels:
        parts.append(", ".join(cast_labels))
    kind = _kind_modes()
    if kind:
        parts.append(", ".join(label for key, label in _FILTER_KINDS if key in kind))
    who = _who_modes()
    if who:
        parts.append(", ".join(name for name in _COMPANIONS if name in who))
    if not parts:
        return "Every scene"
    return "Showing " + " · ".join(parts)


def _touch_filter() -> None:
    _STATE["filtered_key"] = ""
    _STATE["clip_hits_key"] = ""
    _STATE["scene_scroll"] = 0
    _STATE["clip_scroll"] = 0
    _set_notice(_filter_notice())


def _toggle_cast(bucket: str) -> None:
    modes = _cast_modes()
    if bucket in modes:
        modes.discard(bucket)
    else:
        modes.add(bucket)
    _STATE["cast"] = "".join(sorted(modes))
    _touch_filter()


def _toggle_token(key: str, token: str, allowed: set) -> None:
    modes = {part for part in _token_modes(key) if part in allowed}
    if token in modes:
        modes.discard(token)
    else:
        modes.add(token)
    _STATE[key] = ",".join(sorted(modes))
    _touch_filter()


def _clear_filters() -> None:
    _STATE["cast"] = ""
    _STATE["kind"] = ""
    _STATE["who"] = ""
    _touch_filter()


def _scene_filter_flags(scene: dict) -> set:
    cached = scene.get("_filter_flags") if isinstance(scene, dict) else None
    if isinstance(cached, set):
        return cached
    tags = {str(tag).upper() for tag in ((scene or {}).get("tags") or [])}
    flags = set()
    if "CAMP" in tags:
        flags.add("camp")
    if "ROM" in tags:
        flags.add("rom")
    if "DATE" in tags or "CRD" in tags:
        flags.add("date")
    sex = "SEX" in tags
    if not sex:
        for clip in (scene or {}).get("clips") or []:
            upper = str(clip).upper()
            if "NONSEX" in upper:
                continue
            if "_SEX" in upper or "SEX_" in upper:
                sex = True
                break
    if sex:
        flags.add("sex")
    if isinstance(scene, dict):
        scene["_filter_flags"] = flags
    return flags


def _scene_who_ids(scene: dict) -> set:
    cached = scene.get("_who_ids") if isinstance(scene, dict) else None
    if isinstance(cached, set):
        return cached
    found = set()
    tags = set((scene or {}).get("tags") or [])
    for companion in _COMPANIONS:
        if companion in tags:
            found.add(companion)
    for ident in _scene_cast_ids(list((scene or {}).get("clips") or [])):
        for companion in _COMPANIONS:
            if ident == companion.lower():
                found.add(companion)
    if isinstance(scene, dict):
        scene["_who_ids"] = found
    return found


def _kind_allows(scene: dict) -> bool:
    modes = _kind_modes()
    if not modes:
        return True
    return bool(modes & _scene_filter_flags(scene))


def _who_allows(scene: dict) -> bool:
    modes = _who_modes()
    if not modes:
        return True
    return bool(modes & _scene_who_ids(scene))


def _filters_allow(scene: dict) -> bool:
    return _cast_allows(_scene_cast_count(scene)) and _kind_allows(scene) and _who_allows(scene)


def _scene_dual_char(clips: List[str]) -> bool:
    has_player = False
    has_partner = False
    for name in clips or []:
        role = _role(name)
        if role == "player":
            has_player = True
        elif role == "partner":
            has_partner = True
        if has_player and has_partner:
            return True
    return False


def _role_clip_colors(name: str, dual: bool) -> Tuple[str, Tuple[float, float, float]]:
    role = _role(name)
    if not dual:
        return role, (0.94, 0.95, 0.96)
    if role == "player":
        return "you", (0.45, 0.82, 1.0)
    if role == "partner":
        return "npc", (0.98, 0.72, 0.42)
    return role, (0.78, 0.80, 0.84)


_CHAR_DUP = {"t": 0.0, "c": ""}
_SEARCH_DRAG = {"active": False, "anchor": 0}
_SEARCH_HISTORY = {"undo": [], "redo": [], "max": 80}


def _search_snapshot() -> dict:
    return {
        "query": _STATE.get("query") or "",
        "caret": _search_caret_index(),
        "anchor": int(_STATE.get("search_anchor") or 0),
        "sel": bool(_STATE.get("search_sel")),
    }


def _search_history_begin() -> None:
    _SEARCH_HISTORY["undo"] = []
    _SEARCH_HISTORY["redo"] = []


def _search_active() -> bool:
    return bool(_STATE.get("search_focus") or _STATE.get("search_modal"))


def _blur_gpu_search() -> None:
    """Leave the strip search field so Blender tools and UI work normally."""
    _SEARCH_DRAG["active"] = False
    _STATE["search_modal"] = False
    _STATE["search_focus"] = False
    _STATE["search_sel"] = False
    _tag()


def _search_push_undo() -> None:
    snap = _search_snapshot()
    stack = _SEARCH_HISTORY["undo"]
    stack.append(snap)
    if len(stack) > int(_SEARCH_HISTORY["max"]):
        stack.pop(0)
    _SEARCH_HISTORY["redo"] = []


def _restore_search_snapshot(snap: dict) -> None:
    _STATE["search_sel"] = bool(snap.get("sel"))
    text = snap.get("query") or ""
    caret = int(snap.get("caret") or 0)
    anchor = int(snap.get("anchor") if snap.get("anchor") is not None else caret)
    _STATE["query"] = text
    _STATE["filtered_key"] = ""
    _STATE["search_refilter_at"] = time.perf_counter() + 0.02
    _set_search_caret(caret)
    _STATE["search_anchor"] = max(0, min(len(text), anchor))
    _STATE["tag_wait_until"] = 0.0
    _tag()


def _undo_search() -> None:
    stack = _SEARCH_HISTORY["undo"]
    if not stack:
        return
    _SEARCH_HISTORY["redo"].append(_search_snapshot())
    snap = stack.pop()
    _restore_search_snapshot(snap)


def _redo_search() -> None:
    stack = _SEARCH_HISTORY["redo"]
    if not stack:
        return
    _SEARCH_HISTORY["undo"].append(_search_snapshot())
    snap = stack.pop()
    _restore_search_snapshot(snap)


def _apply_search_edit(text: str, *, refilter: bool = True, record_undo: bool = True) -> None:
    prev = _STATE.get("query") or ""
    if text == prev:
        return
    if record_undo:
        _search_push_undo()
    _STATE["query"] = text
    if refilter:
        _STATE["search_refilter_at"] = time.perf_counter() + 0.05
    _STATE["tag_wait_until"] = 0.0
    _tag()


def _search_caret_index() -> int:
    query = _STATE.get("query") or ""
    return max(0, min(len(query), int(_STATE.get("search_caret") or 0)))


def _set_search_caret(index: int) -> None:
    query = _STATE.get("query") or ""
    _STATE["search_caret"] = max(0, min(len(query), int(index)))


def _search_span() -> Tuple[int, int]:
    """Selected range, or a caret with no width when nothing is selected."""
    query = _STATE.get("query") or ""
    caret = _search_caret_index()
    if not _STATE.get("search_sel"):
        return caret, caret
    anchor = max(0, min(len(query), int(_STATE.get("search_anchor") or 0)))
    return min(anchor, caret), max(anchor, caret)


def _clear_search_range() -> None:
    _STATE["search_sel"] = False
    _STATE["search_anchor"] = _search_caret_index()


def _set_search_range(anchor: int, caret: int) -> None:
    query = _STATE.get("query") or ""
    anchor = max(0, min(len(query), int(anchor)))
    _STATE["search_anchor"] = anchor
    _set_search_caret(caret)
    _STATE["search_sel"] = anchor != _search_caret_index()


def _insert_search(text: str) -> None:
    if not text:
        return
    query = _STATE.get("query") or ""
    lo, hi = _search_span()
    _apply_search_edit(query[:lo] + text + query[hi:])
    _clear_search_range()
    _set_search_caret(lo + len(text))
    _STATE["search_anchor"] = _search_caret_index()


def _search_index_at(region, mx: float) -> int:
    query = _STATE.get("query") or ""
    layout = _LAYOUTS.get(region.as_pointer() if region else 0) or {}
    box = layout.get("search_box")
    font_id = _font(12)
    scroll = float(_STATE.get("search_scroll") or 0.0)
    origin = (float(box[0]) + 8.0) if box else 0.0
    local = float(mx) - origin + scroll
    if not query or local <= 0.0:
        return 0
    best = len(query)
    prev_w = 0.0
    for index in range(1, len(query) + 1):
        width = _text_width(font_id, query[:index])
        if local <= width:
            return index - 1 if (local - prev_w) < (width - local) else index
        prev_w = width
    return best


def _place_search_caret(region, mx: float) -> None:
    _set_search_range(_search_index_at(region, mx), _search_index_at(region, mx))
    _tag()


def _arm_search_drag(
    region, mx: float, *, extend: bool = False, window_x: Optional[float] = None
) -> None:
    index = _search_index_at(region, mx)
    anchor = int(_STATE.get("search_anchor") or 0) if extend else index
    _set_search_range(anchor, index)
    _SEARCH_DRAG["active"] = True
    _SEARCH_DRAG["anchor"] = int(_STATE.get("search_anchor") or index)
    _SEARCH_DRAG["region"] = int(region.as_pointer()) if region is not None else 0
    _SEARCH_DRAG["press_local"] = float(mx)
    _SEARCH_DRAG["press_wx"] = float(window_x if window_x is not None else mx)
    _tag()


def _search_drag_region(context):
    want = int(_SEARCH_DRAG.get("region") or 0)
    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window is not None else None
    if screen is None:
        screen = getattr(context, "screen", None)
    if screen is not None and want:
        for area in screen.areas:
            for reg in area.regions:
                if int(reg.as_pointer()) == want:
                    return reg
    region = getattr(context, "region", None)
    if region is not None and getattr(region, "type", "") == "WINDOW":
        return region
    return None


def _search_drag_x(context, event) -> Tuple[Optional[object], float]:
    """Follow the pointer from the press, including moves while the button is held."""
    region = _search_drag_region(context)
    if region is None:
        return None, 0.0
    press_local = float(_SEARCH_DRAG.get("press_local") or 0.0)
    press_wx = float(_SEARCH_DRAG.get("press_wx") or press_local)
    wx = float(getattr(event, "mouse_x", press_wx))
    from_window = press_local + (wx - press_wx)
    rx = float(getattr(event, "mouse_region_x", from_window))
    # Region X often stays on the press until mouse-up. Use whichever reading moved.
    if abs(from_window - press_local) >= abs(rx - press_local):
        return region, from_window
    return region, rx


def _track_search_drag(context, event) -> bool:
    """Click-drag inside the search field. True when this event belongs to it."""
    if not _SEARCH_DRAG.get("active"):
        return False
    moving = event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}
    releasing = event.type == "LEFTMOUSE" and event.value in {"RELEASE", "CLICK"}
    if not moving and not releasing:
        return False
    region, mx = _search_drag_x(context, event)
    if region is not None:
        _set_search_range(int(_SEARCH_DRAG.get("anchor") or 0), _search_index_at(region, mx))
    if releasing:
        _SEARCH_DRAG["active"] = False
    _tag()
    return True


_SEARCH_KEY_CHARS = {
    "SPACE": " ",
    "MINUS": "-",
    "NUMPAD_MINUS": "-",
    "PERIOD": ".",
    "NUMPAD_PERIOD": ".",
    "COMMA": ",",
    "EQUAL": "=",
    "NUMPAD_EQUAL": "=",
    "SLASH": "/",
    "BACK_SLASH": "\\",
    "SEMI_COLON": ";",
    "QUOTE": "'",
    "ACCENT_GRAVE": "`",
    "LEFT_BRACKET": "[",
    "RIGHT_BRACKET": "]",
}


def _search_event_char(event) -> str:
    if event.type == "TEXTINPUT":
        return (getattr(event, "unicode", "") or "").replace("\r", "").replace("\n", "")
    if event.value not in {"PRESS", "REPEAT"}:
        return ""
    if event.ctrl or event.alt or event.oskey:
        return ""
    if len(event.type) == 1:
        return event.type.lower() if not event.shift else event.type
    mapped = _SEARCH_KEY_CHARS.get(event.type)
    if mapped is not None:
        return mapped
    ascii = getattr(event, "ascii", "") or ""
    if len(ascii) == 1 and ascii.isprintable():
        return ascii
    return ""


def _search_key_glyph(event) -> str:
    """Character for a key press. TEXTINPUT is not reliable once the press is swallowed."""
    if event.ctrl or event.alt or event.oskey:
        return ""
    if event.value not in {"PRESS", "REPEAT"}:
        return ""
    ascii = getattr(event, "ascii", "") or ""
    if len(ascii) == 1 and ascii.isprintable() and ascii not in "\t\r\n":
        return ascii
    kind = str(event.type or "")
    if len(kind) == 1 and kind.isalpha():
        return kind if event.shift else kind.lower()
    mapped = _SEARCH_KEY_CHARS.get(kind)
    if mapped:
        return mapped
    digits = {
        "ZERO": "0",
        "ONE": "1",
        "TWO": "2",
        "THREE": "3",
        "FOUR": "4",
        "FIVE": "5",
        "SIX": "6",
        "SEVEN": "7",
        "EIGHT": "8",
        "NINE": "9",
    }
    if kind in digits:
        return digits[kind]
    if kind.startswith("NUMPAD_") and kind[-1:].isdigit():
        return kind[-1]
    return ""


def _search_swallow_key(event_type: str) -> bool:
    """Keys the 3D View keymap must eat while search is focused (G/R/S, …)."""
    if len(event_type) == 1 and event_type.isalpha():
        return True
    if event_type in _SEARCH_KEY_CHARS:
        return True
    if event_type.startswith("NUMPAD_") and event_type[-1:].isdigit():
        return True
    return event_type in {
        "ZERO",
        "ONE",
        "TWO",
        "THREE",
        "FOUR",
        "FIVE",
        "SIX",
        "SEVEN",
        "EIGHT",
        "NINE",
    }


def _push_search_char(char: str) -> None:
    now = time.perf_counter()
    if now < float(_CHAR_DUP.get("skip_until") or 0.0):
        return
    if char == _CHAR_DUP["c"] and (now - float(_CHAR_DUP["t"])) < 0.04:
        return
    _CHAR_DUP["t"] = now
    _CHAR_DUP["c"] = char
    _insert_search(char)


def _clipboard_text() -> str:
    try:
        raw = bpy.context.window_manager.clipboard or ""
    except Exception:
        return ""
    return " ".join(str(raw).replace("\r", " ").replace("\n", " ").split())


def _paste_search() -> None:
    text = _clipboard_text()
    _CHAR_DUP["skip_until"] = time.perf_counter() + 0.08
    if not text:
        _tag()
        return
    _insert_search(text)


def _copy_search() -> None:
    query = _STATE.get("query") or ""
    if not query:
        return
    lo, hi = _search_span()
    if lo == hi:
        _select_all_search()
        lo, hi = _search_span()
    try:
        bpy.context.window_manager.clipboard = query[lo:hi]
    except Exception:
        pass


def _cut_search() -> None:
    query = _STATE.get("query") or ""
    if not query:
        return
    lo, hi = _search_span()
    if lo == hi:
        _select_all_search()
        query = _STATE.get("query") or ""
        lo, hi = _search_span()
    try:
        bpy.context.window_manager.clipboard = query[lo:hi]
    except Exception:
        pass
    _apply_search_edit(query[:lo] + query[hi:])
    _clear_search_range()
    _set_search_caret(lo)
    _STATE["search_anchor"] = lo


def _search_shortcut(event) -> bool:
    if event.alt:
        return False
    if not (event.ctrl or event.oskey):
        return False
    if event.value not in {"PRESS", "CLICK"}:
        return False
    key = str(event.type or "")
    if len(key) == 1:
        key = key.upper()
    if key == "A":
        _select_all_search()
        return True
    if key == "C":
        _copy_search()
        return True
    if key == "X":
        _cut_search()
        return True
    if key == "V":
        _paste_search()
        return True
    if key == "INSERT":
        _paste_search()
        return True
    if key in {"DELETE", "DEL"}:
        _cut_search()
        return True
    if key == "Z":
        if event.shift:
            _redo_search()
        else:
            _undo_search()
        return True
    if key == "Y":
        _redo_search()
        return True
    return False


def _select_all_search() -> None:
    query = _STATE.get("query") or ""
    if query:
        _set_search_range(0, len(query))
    _CHAR_DUP["skip_until"] = time.perf_counter() + 0.08
    _tag()


def _backspace_search() -> None:
    query = _STATE.get("query") or ""
    lo, hi = _search_span()
    if lo != hi:
        _apply_search_edit(query[:lo] + query[hi:])
        _clear_search_range()
        _set_search_caret(lo)
        _STATE["search_anchor"] = lo
        return
    index = _search_caret_index()
    if index <= 0:
        return
    _apply_search_edit(query[: index - 1] + query[index:])
    _set_search_caret(index - 1)
    _STATE["search_anchor"] = _search_caret_index()


def _delete_search() -> None:
    query = _STATE.get("query") or ""
    lo, hi = _search_span()
    if lo != hi:
        _apply_search_edit(query[:lo] + query[hi:])
        _clear_search_range()
        _set_search_caret(lo)
        _STATE["search_anchor"] = lo
        return
    index = _search_caret_index()
    if index >= len(query):
        return
    _apply_search_edit(query[:index] + query[index + 1 :])
    _STATE["search_anchor"] = _search_caret_index()


def _move_search_caret(delta: int) -> None:
    _clear_search_range()
    _set_search_caret(_search_caret_index() + delta)
    _STATE["search_anchor"] = _search_caret_index()
    _tag(0.028)


def _begin_gpu_search(
    region=None,
    mx: Optional[float] = None,
    *,
    extend: bool = False,
    window_x: Optional[float] = None,
) -> set:
    """Arm the strip search field. Typing is handled by whichever modal is on top.

    Starting ``anim_browser_type`` here fails after a viewport drop: the import
    modal is already running, the operator poll/invoke errors, and the click is
    eaten so the field looks dead.
    """
    if region is not None and mx is not None:
        _arm_search_drag(region, mx, extend=extend, window_x=window_x)
    else:
        _set_search_caret(len(_STATE.get("query") or ""))
        _STATE["search_anchor"] = _search_caret_index()
    _STATE["search_focus"] = True
    _STATE["search_modal"] = True
    _tag()
    if region is not None and mx is not None:
        try:
            bpy.ops.gr2lab.anim_search_drag("INVOKE_DEFAULT")
        except Exception:
            traceback.print_exc()
    return {"FINISHED"}


def _search_capture_event(context, event) -> Optional[set]:
    """Eat typing while the search field is armed. None = not a search key."""
    if not _search_active():
        return None
    if event.type in {
        "MOUSEMOVE",
        "INBETWEEN_MOUSEMOVE",
        "TIMER",
        "LEFTMOUSE",
        "RIGHTMOUSE",
        "MIDDLEMOUSE",
        "WHEELUPMOUSE",
        "WHEELDOWNMOUSE",
        "TRACKPADPAN",
        "TRACKPADZOOM",
    }:
        return None
    if event.type == "TEXTINPUT":
        char = _search_event_char(event)
        if char and char.isprintable() and char not in "\t":
            _push_search_char(char)
        return {"RUNNING_MODAL"}
    if event.type == "INSERT" and event.value == "PRESS" and getattr(event, "shift", False):
        _paste_search()
        return {"RUNNING_MODAL"}
    if getattr(event, "alt", False):
        return None
    if _search_shortcut(event):
        return {"RUNNING_MODAL"}
    if event.type in {"LEFT_ARROW", "RIGHT_ARROW"} and event.value in {"PRESS", "REPEAT"}:
        _move_search_caret(-1 if event.type == "LEFT_ARROW" else 1)
        return {"RUNNING_MODAL"}
    if event.type == "HOME" and event.value == "PRESS":
        _STATE["search_sel"] = False
        _set_search_caret(0)
        _tag()
        return {"RUNNING_MODAL"}
    if event.type == "END" and event.value == "PRESS":
        _STATE["search_sel"] = False
        _set_search_caret(len(_STATE.get("query") or ""))
        _tag()
        return {"RUNNING_MODAL"}
    if event.type in {"BACK_SPACE", "BACKSPACE"} and event.value in {"PRESS", "REPEAT", "CLICK"}:
        _backspace_search()
        return {"RUNNING_MODAL"}
    if event.type in {"DELETE", "DEL"} and event.value in {"PRESS", "REPEAT", "CLICK"}:
        _delete_search()
        return {"RUNNING_MODAL"}
    if event.type == "ESC" and event.value == "PRESS":
        _apply_search_edit("")
        _set_search_caret(0)
        _blur_gpu_search()
        return {"RUNNING_MODAL"}
    if event.type in {"RET", "NUMPAD_ENTER"} and event.value == "PRESS":
        _blur_gpu_search()
        return {"RUNNING_MODAL"}
    if event.ctrl or event.oskey:
        return None
    if event.value in {"PRESS", "REPEAT"} and _search_swallow_key(event.type):
        glyph = _search_key_glyph(event)
        if glyph and glyph.isprintable() and glyph not in "\t":
            _push_search_char(glyph)
        return {"RUNNING_MODAL"}
    return None


def service_strip_during_modal(context, event) -> Optional[set]:
    """Keep the strip and its search field working under the import modal."""
    if event.type == "TIMER":
        return None
    if _track_search_drag(context, event):
        return {"RUNNING_MODAL"}
    captured = _search_capture_event(context, event)
    if captured is not None:
        return captured
    if event.type == "LEFTMOUSE" and event.value == "PRESS" and _search_active():
        found = view3d_under_pointer(context, event)
        if found is None or not pointer_over_strip(found[1], found[2], found[3]):
            _blur_gpu_search()
    if modal_strip_event(context, event):
        return {"RUNNING_MODAL"}
    return None


def build_index(root: Path, cancel) -> Optional[dict]:
    """Walk character animation folders. Does not open GR2 files."""
    scenes = []
    seen = set()
    for base in _search_roots(root):
        for rel in _TREES:
            tree = base / rel
            if not tree.is_dir():
                continue
            tree_key = str(tree.resolve()).lower()
            if tree_key in seen:
                continue
            seen.add(tree_key)
            with _PREP_LOCK:
                _PREP["phase"] = tree.name
            for dirpath, _dirnames, filenames in os.walk(tree):
                if cancel():
                    return None
                clips = sorted(name for name in filenames if name.lower().endswith(".gr2"))
                if not clips:
                    continue
                folder = Path(dirpath)
                act = _act_of(folder)
                scenes.append(
                    {
                        "id": str(folder).lower(),
                        "name": folder.name,
                        "act": act,
                        "tags": _tags_of(folder),
                        "dir": str(folder),
                        "clips": clips,
                    }
                )
                if len(scenes) % 200 == 0:
                    with _PREP_LOCK:
                        _PREP["scenes"] = len(scenes)
    scenes.sort(key=lambda row: (row.get("act") or "ZZZ", row.get("name") or ""))
    return {
        "version": _INDEX_VERSION,
        "unpacked": str(root),
        "built": time.strftime("%Y-%m-%d %H:%M:%S"),
        "scenes": scenes,
    }


def _load_index() -> Optional[dict]:
    path = index_path()
    try:
        mtime = path.stat().st_mtime
    except OSError:
        _INDEX["data"] = None
        _INDEX["mtime"] = 0.0
        return None
    if _INDEX["data"] is not None and _INDEX["mtime"] == mtime:
        return _INDEX["data"]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    _ensure_search_blobs(data)
    _INDEX["data"] = data
    _INDEX["mtime"] = mtime
    return data


def _index_matches(context, data: Optional[dict]) -> bool:
    if not data:
        return False
    if int(data.get("version") or 0) != _INDEX_VERSION:
        return False
    root = unpacked_root(context)
    if root is None:
        return False
    stored = str(data.get("unpacked") or "")
    try:
        return Path(stored).resolve() == root.resolve()
    except OSError:
        return stored.lower() == str(root).lower()


def _search_tokens(query: str) -> List[str]:
    """Split on whitespace and on _, ., etc. so pasted GR2 filenames still match."""
    raw = (query or "").strip()
    if not raw:
        return []
    try:
        if Path(raw).suffix.lower() == ".gr2" or "\\" in raw or "/" in raw:
            raw = Path(raw).name
    except (TypeError, ValueError):
        pass
    norm = _normalize_search_blob(raw)
    return [part for part in norm.split() if part]


def _normalize_search_blob(text: str) -> str:
    """Fold separators so CAMP_Karlach_CRD_Date matches 'karlach date'."""
    chars: List[str] = []
    pending_space = False
    for ch in (text or "").casefold():
        if ch.isalnum():
            if pending_space and chars:
                chars.append(" ")
            chars.append(ch)
            pending_space = False
        else:
            pending_space = True
    return "".join(chars)


def _ensure_search_blobs(data: dict) -> None:
    """Normalize every folder and clip name once. Typing must not redo that."""
    if data.get("_search_ready") == _INDEX_VERSION:
        return
    for scene in data.get("scenes") or []:
        name_blob = _normalize_search_blob(str(scene.get("name") or ""))
        blobs = tuple(
            _normalize_search_blob(str(name)) for name in (scene.get("clips") or [])
        )
        scene["_name_blob"] = name_blob
        scene["_clip_blobs"] = blobs
        scene["_blob"] = (name_blob + " " + " ".join(blobs)).strip()
    data["_search_ready"] = _INDEX_VERSION


def _text_has_tokens(text: str, tokens: List[str]) -> bool:
    if not tokens:
        return True
    blob = _normalize_search_blob(text)
    return all(token in blob for token in tokens)


def _scene_has_tokens(scene: dict, tokens: List[str]) -> bool:
    if not tokens:
        return True
    blob = scene.get("_blob")
    if not isinstance(blob, str):
        parts = [scene.get("name") or ""]
        parts.extend(scene.get("clips") or [])
        blob = _normalize_search_blob(" ".join(parts))
    return all(token in blob for token in tokens)


def _filtered(data: dict) -> List[dict]:
    key = "|".join(
        (
            str(_INDEX["mtime"]),
            _STATE["act"],
            str(_STATE.get("cast") or ""),
            str(_STATE.get("kind") or ""),
            str(_STATE.get("who") or ""),
            _STATE["query"].casefold(),
        )
    )
    if key == _STATE["filtered_key"]:
        return _STATE["filtered"]
    query = _STATE["query"].strip()
    tokens = _search_tokens(query)
    if tokens:
        _ensure_search_blobs(data)
    act = _STATE["act"]
    rows = []
    for scene in data.get("scenes") or []:
        if act != "All" and (scene.get("act") or "") != act:
            continue
        if not _filters_allow(scene):
            continue
        if tokens and not _scene_has_tokens(scene, tokens):
            continue
        rows.append(scene)
    _STATE["filtered_key"] = key
    _STATE["filtered"] = rows
    _STATE["clip_scroll"] = 0
    _STATE["clip_hits_key"] = ""
    if _STATE["scene_id"] not in {row["id"] for row in rows}:
        if _search_tokens(_STATE.get("query") or ""):
            _STATE["scene_id"] = ""
        else:
            _STATE["scene_id"] = rows[0]["id"] if rows else ""
    return rows


def _selected(rows: List[dict]) -> Optional[dict]:
    want = _STATE["scene_id"]
    for row in rows:
        if row["id"] == want:
            return row
    if _search_tokens(_STATE.get("query") or ""):
        return None
    return rows[0] if rows else None


def _browser_clip_entries(rows: Optional[List[dict]] = None) -> List[dict]:
    """Clips in the right-hand list.

    A search lists every matching animation, from every folder. With no search
    the list is the selected folder.
    """
    if rows is None:
        data = _INDEX.get("data") or _load_index() or {}
        rows = _filtered(data)
    tokens = _search_tokens(_STATE.get("query") or "")
    scene_key = "" if tokens else str(_STATE.get("scene_id") or "")
    key = f"{_STATE.get('filtered_key')}|{scene_key}|{1 if tokens else 0}"
    if key == _STATE.get("clip_hits_key"):
        return _STATE.get("clip_hits") or []
    sources = list(rows or [])
    if not tokens:
        scene = _selected(rows or [])
        sources = [scene] if scene else []
    elif data_for_blobs := (_INDEX.get("data") or {}):
        _ensure_search_blobs(data_for_blobs)
    entries = []
    for scene in sources:
        if not scene:
            continue
        folder = str(scene.get("dir") or "")
        sep = "\\" if "\\" in folder else "/"
        scene_name = str(scene.get("name") or "")
        name_blob = str(scene.get("_name_blob") or "")
        names = list(scene.get("clips") or [])
        blobs = scene.get("_clip_blobs") or ()
        if not tokens:
            names = sorted(names, key=lambda name: (_role(name), name.lower()))
        for index, name in enumerate(names):
            blob = blobs[index] if index < len(blobs) else ""
            if tokens:
                if not blob:
                    blob = _normalize_search_blob(name)
                if not all(token in blob or token in name_blob for token in tokens):
                    continue
            entries.append(
                {
                    "name": name,
                    "path": f"{folder}{sep}{name}" if folder else name,
                    "scene": scene_name,
                    "scene_id": str(scene.get("id") or ""),
                    "dir": folder,
                    "sort": blob or name.casefold(),
                }
            )
    if tokens:
        entries.sort(key=lambda entry: (entry["sort"], entry["scene"]))
    _STATE["clip_hits_key"] = key
    _STATE["clip_hits"] = entries
    return entries


def _pose_file(path: Path) -> Path:
    st = path.stat()
    key = hashlib.sha1(f"{path.resolve()}|{st.st_mtime_ns}|{st.st_size}".encode()).hexdigest()[:24]
    return pose_dir() / f"{key}.json"


def _remember_pose(path: str, data: dict) -> None:
    mem = _HOVER["mem"]
    mem[path] = data
    if len(mem) > 32:
        mem.pop(next(iter(mem)))
    if data.get("kind") != "scene":
        return
    try:
        _pose_file(Path(path)).write_text(json.dumps(data), encoding="utf-8")
    except OSError:
        pass


def _cached_pose(path: str) -> Optional[dict]:
    mem = _HOVER["mem"].get(path)
    if mem:
        return mem
    try:
        file_path = _pose_file(Path(path))
        if not file_path.is_file():
            return None
        data = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    shots = data.get("shots") or []
    if data.get("kind") != "scene" or not data.get("duration_sec") or len(shots) < 8:
        return None
    if not all(Path(shot).is_file() for shot in shots):
        return None
    _HOVER["mem"][path] = data
    return data


def _stick_attach_timing(data: dict) -> dict:
    poses = data.get("poses") or []
    data["_pose_times"] = _stick_pose_times(data, poses)
    return data


def _show_pose(path: str, data: dict, status: str) -> None:
    if data.get("kind") == "sticks":
        data = _stick_attach_timing(data)
    _HOVER["shown"] = path
    _HOVER["poses"] = data
    _HOVER["pose_i"] = 0
    _HOVER["pose_tick"] = time.perf_counter()
    _HOVER["textures"] = {}
    _HOVER["status"] = status
    _tag()


def _shot_dir(path: Path) -> Path:
    st = path.stat()
    key = hashlib.sha1(
        f"{path.resolve()}|{st.st_mtime_ns}|{st.st_size}|pv{PREVIEW_REV}".encode()
    ).hexdigest()[:24]
    folder = cache_dir() / "preview_shots" / key
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _stick_cache_file_budget(
    gr2_path: str, ver: int, fps: float, frames: int
) -> Path:
    """One stick-cache path. Older budgets stay readable after a sample-rate bump."""
    src = Path(_stick_preview_gr2_path(gr2_path))
    try:
        st = src.stat()
        stamp = f"{st.st_mtime_ns}|{st.st_size}"
    except OSError:
        stamp = "0|0"
    key = hashlib.sha1(
        f"{src}|{stamp}|sc{int(ver)}|h{float(fps)}|f{int(frames)}".encode()
    ).hexdigest()[:24]
    return cache_dir() / "preview_sticks" / f"{key}.stk"


def _stick_cache_file(gr2_path: str) -> Path:
    """Disk cache for quick hover sticks. Do not scan for a partner here.

    Partner lookup walks the scene and can stall the UI for half a second.
    Quick hover sticks are the one character only, so the key is that GR2.
    """
    src = Path(_stick_preview_gr2_path(gr2_path))
    try:
        st = src.stat()
        stamp = f"{st.st_mtime_ns}|{st.st_size}"
    except OSError:
        stamp = "0|0"
    memo_key = f"{gr2_path}|{stamp}"
    memo = _HOVER.get("cache_files")
    if isinstance(memo, dict):
        hit = memo.get(memo_key)
        if hit:
            return Path(hit)
    folder = cache_dir() / "preview_sticks"
    folder.mkdir(parents=True, exist_ok=True)
    file_path = _stick_cache_file_budget(
        gr2_path, STICK_CACHE_VER, STICK_HOVER_SAMPLE_FPS, STICK_HOVER_MAX_FRAMES
    )
    if isinstance(memo, dict):
        memo[memo_key] = str(file_path)
        if len(memo) > 128:
            memo.pop(next(iter(memo)))
    return file_path


def _stick_cache_fallbacks(gr2_path: str) -> List[Path]:
    """Current key, then the 12 Hz budget from before the 24 Hz bump."""
    current = _stick_cache_file(gr2_path)
    older = (
        (STICK_CACHE_VER, 12.0, 144),
        (STICK_CACHE_VER, 12.0, 96),
        (7, 12.0, 144),
    )
    found = [current]
    for ver, fps, frames in older:
        path = _stick_cache_file_budget(gr2_path, ver, fps, frames)
        if path != current:
            found.append(path)
    return found


def _stick_payload_ok(data: object) -> bool:
    """A stick clip is the pose samples. Older caches omitted kind and were ignored."""
    if not isinstance(data, dict) or not data.get("poses"):
        return False
    kind = data.get("kind")
    return kind in (None, "", "sticks")


def _stick_mem_get(path: str) -> Optional[dict]:
    path = str(path or "")
    if not path:
        return None
    mem = _HOVER["mem"]
    data = mem.get(path)
    if not _stick_payload_ok(data):
        stale = None
        for key in mem:
            if key != path and str(key) == path:
                stale = key
                break
        if stale is not None:
            data = mem.pop(stale)
            if _stick_payload_ok(data):
                mem[path] = data
            else:
                data = None
    if not _stick_payload_ok(data):
        return None
    data["kind"] = "sticks"
    return data


def _stick_read_one(file_path: Path) -> Optional[dict]:
    try:
        if not file_path.is_file():
            return None
        with file_path.open("rb") as handle:
            data = pickle.load(handle)
    except (OSError, ValueError, pickle.UnpicklingError):
        return None
    if not _stick_payload_ok(data):
        return None
    data["kind"] = "sticks"
    return data


def _stick_load_disk(path: str) -> Optional[dict]:
    path = str(path or "")
    if not path:
        return None
    data = None
    for file_path in _stick_cache_fallbacks(path):
        data = _stick_read_one(file_path)
        if data is not None:
            break
    if data is None:
        return None
    data = _stick_attach_timing(dict(data))
    _HOVER["mem"][path] = data
    return data


def _remember_stick_mem(path: str, data: dict) -> None:
    path = str(path or "")
    if not path:
        return
    if data.get("poses"):
        data["kind"] = "sticks"
    _HOVER["mem"][path] = data
    if len(_HOVER["mem"]) > 64:
        _HOVER["mem"].pop(next(iter(_HOVER["mem"])))


def _remember_stick_disk(path: str, data: dict) -> None:
    try:
        packed = {
            key: value
            for key, value in data.items()
            if key not in ("_pose_times", "seconds", "cached", "path")
        }
        poses = []
        for pose in packed.get("poses") or []:
            slim = {"t": pose.get("t"), "frac": pose.get("frac"), "rig": pose.get("rig")}
            if pose.get("points"):
                slim["points"] = pose.get("points")
            poses.append(slim)
        packed["poses"] = poses
        packed["kind"] = "sticks"
        with _stick_cache_file(path).open("wb") as handle:
            pickle.dump(packed, handle, protocol=4)
    except OSError:
        pass


def _remember_stick(path: str, data: dict) -> None:
    _remember_stick_mem(path, data)
    snapshot = {
        key: value
        for key, value in data.items()
        if key not in ("_pose_times",)
    }
    threading.Thread(
        target=_remember_stick_disk,
        args=(path, snapshot),
        name="gr2lab-stick-cache",
        daemon=True,
    ).start()


def _classify_rig_name(name: str) -> dict:
    try:
        from .codec.rig_catalog import classify_rig

        return classify_rig(name)
    except Exception:
        try:
            from rig_catalog import classify_rig  # type: ignore

            return classify_rig(name)
        except Exception:
            return {}


def _stick_preview_gr2_path(gr2_path: str) -> str:
    """GR2 decoded for hover sticks (head clips → matching body on same beat)."""
    try:
        from .codec.rig_catalog import import_gr2_decode_path
    except Exception:
        from rig_catalog import import_gr2_decode_path  # type: ignore

    return str(import_gr2_decode_path(gr2_path))


def _partner_gr2_fast(gr2_path: str) -> Optional[Path]:
    """Legacy folder scan for human NPC clips (import staging only)."""
    folder = Path(gr2_path).parent
    try:
        mine = Path(gr2_path).resolve()
    except OSError:
        mine = Path(gr2_path)
    info = _classify_rig_name(mine.name)
    if info.get("is_creature") or info.get("is_head"):
        return None
    for cand in sorted(folder.glob("*.GR2")) + sorted(folder.glob("*.gr2")):
        try:
            if cand.resolve() == mine:
                continue
        except OSError:
            if cand == Path(gr2_path):
                continue
        upper = cand.name.upper()
        if "PLYR" in upper:
            continue
        if any(token in upper for token in ("HUM_", "TIF_", "DGB_", "GTY_", "HFL_", "GOB_", "ELF_")):
            return cand
    return None


def _stick_partner_gr2(gr2_path: str) -> Optional[Path]:
    """Second stick figure for hover preview — scene-aware, not random HUM_ in folder."""
    primary = Path(gr2_path)
    info = _classify_rig_name(primary.name)
    if info.get("is_head"):
        return None
    if info.get("is_creature"):
        return None
    try:
        from . import scene_stage_empties as sse

        partner = sse.find_partner_gr2(str(primary))
    except Exception:
        partner = None
    if partner is not None:
        try:
            if partner.resolve() == primary.resolve():
                partner = None
        except OSError:
            if partner == primary:
                partner = None
    if partner is not None:
        pinfo = _classify_rig_name(partner.name)
        if pinfo.get("is_head"):
            try:
                from .codec.rig_catalog import matching_body_clip_for_head
            except Exception:
                from rig_catalog import matching_body_clip_for_head  # type: ignore

            body = matching_body_clip_for_head(partner)
            if body is not None:
                partner = body
        return partner
    return _partner_gr2_fast(gr2_path)


def _merge_stick_pair(player: dict, partner: dict) -> dict:
    merged = []
    p_edges = [[f"P:{a}", f"P:{b}"] for a, b in (partner.get("edges") or [])]
    p_order = [f"P:{n}" for n in (partner.get("bone_order") or [])]
    p_parents = {
        f"P:{k}": (f"P:{v}" if v else "")
        for k, v in (partner.get("parents") or {}).items()
    }
    bone_order = list(player.get("bone_order") or []) + p_order
    parents = {**(player.get("parents") or {}), **p_parents}
    for pose, other in zip(player.get("poses") or [], partner.get("poses") or []):
        rig = dict(pose.get("rig") or {})
        for name, tr in (other.get("rig") or {}).items():
            rig[f"P:{name}"] = tr
        merged.append({"t": pose.get("t"), "frac": pose.get("frac"), "rig": rig})
    return {
        **player,
        "poses": merged,
        "edges": list(player.get("edges") or []) + p_edges,
        "bones": int(player.get("bones") or 0) + int(partner.get("bones") or 0),
        "bone_order": bone_order,
        "parents": parents,
    }


def _hover_stick_proc_running() -> bool:
    proc = _HOVER.get("stick_proc")
    return proc is not None and proc.poll() is None


def _hover_stick_thread_running() -> bool:
    thread = _HOVER.get("stick_decode_thread")
    return thread is not None and thread.is_alive()


def _hover_stick_decode_busy() -> bool:
    if _hover_stick_proc_running() or _hover_stick_thread_running():
        return True
    pending = int(_HOVER.get("stick_pending_gen") or -1)
    return pending >= 0 and pending == int(_HOVER.get("gen") or 0)


def _hover_decode_busy() -> bool:
    return _hover_stick_decode_busy()


def _hover_preview_loading() -> bool:
    path = str(_HOVER.get("path") or "")
    if not path:
        return False
    if _stick_mem_get(path) is not None:
        return False
    if _HOVER.get("shown") == path and (_HOVER.get("poses") or {}).get("poses"):
        return False
    if _hover_stick_proc_running():
        return True
    return str(_HOVER.get("status") or "").startswith("sticks")


def _stick_read_disk_raw(path: str) -> Optional[dict]:
    if not path:
        return None
    for file_path in _stick_cache_fallbacks(path):
        data = _stick_read_one(file_path)
        if data is not None:
            return _stick_attach_timing(dict(data))
    return None


def _stick_beat(filename: str) -> str:
    """Scene beat shared by the two bodies in one clip, without the role tail."""
    marker = "_Rig_"
    folded = filename.lower()
    at = folded.find(marker.lower())
    if at < 0:
        return ""
    stem = Path(filename[at + len(marker) :]).stem
    parts = stem.split("_")
    if parts and parts[-1].upper() == "LONGSNOUT":
        parts.pop()
    if parts and _body_tail(filename):
        parts.pop()
    return "_".join(parts).upper()


def _stick_partner_from_list(gr2_path: str) -> Optional[Path]:
    """Other body on this beat, from the clips already listed. No scene scan."""
    paths = list(_STATE.get("clip_paths") or [])
    if not paths:
        return None
    mine = Path(gr2_path)
    beat = _stick_beat(mine.name)
    if not beat:
        return None
    my_role = _role(mine.name)
    found: List[Path] = []
    for full in paths:
        other = Path(full)
        if other.name.lower() == mine.name.lower():
            continue
        if _stick_beat(other.name) != beat:
            continue
        role = _role(other.name)
        if my_role == "player" and role != "partner":
            continue
        if my_role == "partner" and role != "player":
            continue
        if my_role not in {"player", "partner"} and role == my_role:
            continue
        found.append(other)
    if not found:
        return None

    def _rank(path: Path) -> Tuple[int, str]:
        upper = path.name.upper()
        if upper.startswith("HUM_") and "LONGSNOUT" not in upper:
            return (0, upper)
        if "LONGSNOUT" not in upper:
            return (1, upper)
        return (2, upper)

    found.sort(key=_rank)
    return found[0]


def _compose_stick_pair(
    path: str,
    solo: dict,
    *,
    decode: bool,
    should_cancel: Optional[Callable[[], bool]] = None,
    quiet: bool = True,
) -> dict:
    """Add the other body on this beat when that clip is in the open list."""
    partner = _stick_partner_from_list(path)
    if partner is None:
        out = dict(solo)
        out["partner_name"] = ""
        return out
    other = _stick_mem_get(str(partner)) or _stick_read_disk_raw(str(partner))
    if other is None and decode:
        from .local_pipeline import preview_stick_poses, stick_sample_fractions

        duration = float(solo.get("duration") or solo.get("duration_sec") or 0.0)
        fractions = stick_sample_fractions(
            duration, fps=STICK_HOVER_SAMPLE_FPS, max_frames=STICK_HOVER_MAX_FRAMES
        )
        other = preview_stick_poses(
            _stick_preview_gr2_path(str(partner)),
            fractions=fractions,
            sample_fps=STICK_HOVER_SAMPLE_FPS,
            max_frames=STICK_HOVER_MAX_FRAMES,
            should_cancel=should_cancel,
            quiet=True,
        )
        other["kind"] = "sticks"
        other = _stick_attach_timing(other)
        other["path"] = str(partner)
        _remember_stick(str(partner), other)
        if not quiet:
            _hover_log(
                f"stick partner {partner.name} decode={other.get('seconds', 0)}s"
            )
    if not other:
        out = dict(solo)
        out["partner_name"] = ""
        out["partner_pending"] = partner.name
        return out
    merged = _merge_stick_pair(solo, other)
    merged["kind"] = "sticks"
    merged["path"] = str(path)
    merged["partner_name"] = partner.name
    merged["cached"] = bool(solo.get("cached"))
    return merged


def build_stick_preview_data(
    path: str,
    *,
    quick: bool = True,
    should_cancel: Optional[Callable[[], bool]] = None,
    quiet: bool = False,
    with_partner: bool = True,
) -> Tuple[Optional[dict], str]:
    """Decode sticks (for background Blender job). Does not touch hover UI state."""
    from .local_pipeline import StickPreviewCancelled, preview_stick_poses, stick_sample_fractions

    cached = _stick_mem_get(path) or _stick_read_disk_raw(path)
    fresh = cached is None
    if cached is not None:
        cached["seconds"] = 0.0
        cached["cached"] = True

    sample_fps = STICK_HOVER_SAMPLE_FPS if quick else STICK_SAMPLE_FPS
    max_frames = STICK_HOVER_MAX_FRAMES if quick else STICK_MAX_FRAMES

    try:
        if fresh:
            source = _stick_preview_gr2_path(path)
            player = preview_stick_poses(
                source,
                sample_fps=sample_fps,
                max_frames=max_frames,
                should_cancel=should_cancel,
                quiet=quiet,
            )
            duration = float(player.get("duration") or 0.0)
            player["kind"] = "sticks"
            player["duration_sec"] = duration
            player["play_fps"] = (
                len(player.get("poses") or []) / duration if duration > 0 else sample_fps
            )
            player = _stick_attach_timing(player)
            player["path"] = str(path)
        else:
            player = cached
        solo = player
        if with_partner:
            player = _compose_stick_pair(
                path,
                solo,
                decode=True,
                should_cancel=should_cancel,
                quiet=quiet,
            )
        if fresh and with_partner:
            player["cache_solo"] = solo
        return player, ""
    except StickPreviewCancelled:
        return None, ""
    except Exception as exc:
        traceback.print_exc()
        return None, str(exc)


def _kill_stick_preview_proc() -> None:
    proc = _HOVER.get("stick_proc")
    if proc is not None and proc.poll() is None:
        try:
            proc.kill()
        except OSError:
            pass
    log_handle = _HOVER.get("stick_proc_log")
    if log_handle is not None:
        try:
            log_handle.close()
        except OSError:
            pass
    out = str(_HOVER.get("stick_proc_out") or "")
    if out:
        try:
            Path(out).unlink(missing_ok=True)
        except OSError:
            pass
    _HOVER["stick_proc"] = None
    _HOVER["stick_proc_log"] = None
    _HOVER["stick_proc_out"] = ""
    _HOVER["stick_proc_path"] = ""
    _HOVER["stick_proc_gen"] = -1


_GR2LAB_VERBOSE = False
_GALLERY_GPU_PROFILER = False


def _hover_log(msg: str) -> None:
    if not _GR2LAB_VERBOSE:
        return
    print(f"[GR2 LAB] {msg}", flush=True)


def _apply_stick_decode_result(path: str, data: Optional[dict], err: str, job_gen: int) -> bool:
    """Publish a finished stick decode. True when hover state changed."""
    if int(_HOVER.get("gen") or 0) != job_gen or str(_HOVER.get("path") or "") != path:
        return True
    if data and not err:
        _remember_stick(path, data)
        label = "sticks cached" if data.get("cached") else f"sticks {data.get('seconds', 0)}s"
        _show_pose(path, data, label)
    else:
        _HOVER["shown"] = path
        _HOVER["poses"] = None
        _HOVER["status"] = err or "stick preview failed"
    return True


def _spawn_stick_preview(path: str, gen: int) -> None:
    """Decode stick poses in a worker thread (no second Blender process)."""
    _kill_stick_preview_proc()
    _HOVER["stick_proc_path"] = path
    _HOVER["stick_proc_gen"] = int(gen)
    _HOVER["stick_pending_gen"] = int(gen)
    _PREFETCH["gen"] = int(_PREFETCH.get("gen") or 0) + 1
    holder: Dict[str, threading.Thread] = {}

    def worker(job_path: str = path, job_gen: int = int(gen)) -> None:
        name = Path(job_path).name
        t0 = time.perf_counter()
        queued = t0 - float(_HOVER.get("miss_t") or t0)
        _hover_log(f"hover start {name} queue={queued * 1000:.0f}ms")

        def stale() -> bool:
            return int(_HOVER.get("gen") or 0) != int(job_gen)

        try:
            if stale():
                data, err = None, ""
            else:
                data, err = build_stick_preview_data(
                    job_path,
                    quick=True,
                    should_cancel=stale,
                    with_partner=False,
                )
        except Exception as exc:
            traceback.print_exc()
            data, err = None, str(exc)
        wall = time.perf_counter() - t0
        if data and not err:
            solo = data.pop("cache_solo", None)
            if solo is not None:
                _remember_stick(job_path, solo)
            elif not any(
                str(name).startswith("P:") for name in (data.get("bone_order") or [])
            ):
                _remember_stick(job_path, data)

        def finish() -> None:
            if _HOVER.get("stick_decode_thread") is holder.get("thread"):
                _HOVER["stick_decode_thread"] = None
            if int(_HOVER.get("stick_pending_gen") or -1) == job_gen:
                _HOVER["stick_pending_gen"] = -1
            show_ms = (time.perf_counter() - float(_HOVER.get("miss_t") or time.perf_counter())) * 1000.0
            if not data and not err:
                _hover_log(f"hover cancel {name} after {wall:.3f}s")
                _tag()
                _queue_stick_prefetch(str(_HOVER.get("path") or ""))
                return None
            if stale():
                if data and not err:
                    _hover_log(
                        f"hover keep {name} wall={wall:.3f}s "
                        f"decode={data.get('seconds', 0)}s (pointer moved)"
                    )
                else:
                    _hover_log(f"hover cancel {name} after {wall:.3f}s")
                _tag()
                return None
            if data and not err:
                poses_n = len(data.get("poses") or [])
                dur = float(data.get("duration_sec") or data.get("duration") or 0.0)
                step = dur / max(1, poses_n - 1)
                _hover_log(
                    f"hover ready {name} decode={data.get('seconds', 0)}s "
                    f"wall={wall:.3f}s show={show_ms:.0f}ms "
                    f"poses={poses_n} dur={dur:.2f}s step={step:.3f}s "
                    f"bones={data.get('bones')} partner={data.get('partner_name') or '-'} "
                    f"cached={bool(data.get('cached'))}"
                )
            else:
                _hover_log(f"hover fail {name} wall={wall:.3f}s {err}")
            _apply_stick_decode_result(job_path, data, err or "", job_gen)
            _queue_stick_prefetch(job_path)
            _tag()
            return None

        try:
            bpy.app.timers.register(finish, first_interval=0.0)
        except Exception:
            if not stale():
                _apply_stick_decode_result(job_path, data, err or "", job_gen)

    thread = threading.Thread(
        target=worker, name="gr2lab-stick-decode", daemon=True
    )
    holder["thread"] = thread
    _HOVER["stick_decode_thread"] = thread
    thread.start()


def _hover_user_job_active() -> bool:
    pending = int(_HOVER.get("stick_pending_gen") or -1)
    return pending >= 0 and pending == int(_HOVER.get("gen") or 0)


def _queue_stick_prefetch(anchor: str) -> None:
    """Clip hover preview removed — gallery decode uses its own path."""


def _note_visible_clips(folder: str, names: List[str], scroll: int, visible: int, paths=None) -> None:
    if paths is None:
        paths = [str(Path(folder) / name) for name in names] if folder else []
    _STATE["clip_paths"] = paths
    _STATE["clip_visible"] = int(visible)
    token = f"{folder}|{scroll}|{visible}|{len(paths)}|{paths[0] if paths else ''}"
    if token == _STATE.get("prefetch_token"):
        return
    _STATE["prefetch_token"] = token


def _ensure_stick_prefetch() -> None:
    thread = _PREFETCH.get("thread")
    if thread is not None and thread.is_alive():
        return
    worker = threading.Thread(target=_stick_prefetch_worker, name="gr2lab-stick-prefetch", daemon=True)
    _PREFETCH["thread"] = worker
    worker.start()


def _stick_prefetch_worker() -> None:
    while True:
        queue = list(_PREFETCH.get("queue") or [])
        _PREFETCH["queue"] = []
        if not queue:
            return
        gen = int(_PREFETCH.get("gen") or 0)
        for path in queue:
            if int(_PREFETCH.get("gen") or 0) != gen:
                return
            while (
                _hover_user_job_active()
                and not _GALLERY.get("bulk_decode")
                and int(_PREFETCH.get("gen") or 0) == gen
            ):
                time.sleep(0.02)
            if int(_PREFETCH.get("gen") or 0) != gen:
                return
            if _stick_mem_get(path) is not None:
                continue
            name = Path(path).name

            def stale(job_gen: int = gen) -> bool:
                if int(_PREFETCH.get("gen") or 0) != job_gen:
                    return True
                return _hover_user_job_active() and not _GALLERY.get("bulk_decode")

            t0 = time.perf_counter()
            try:
                data, err = build_stick_preview_data(
                    path, quick=True, should_cancel=stale, quiet=True, with_partner=False
                )
            except Exception:
                traceback.print_exc()
                continue
            if stale() or not data or err:
                continue
            _remember_stick(path, data)
            _hover_log(
                f"prefetch {name} decode={data.get('seconds', 0)}s "
                f"wall={time.perf_counter() - t0:.3f}s "
                f"cached={bool(data.get('cached'))}"
            )


def _poll_stick_preview_proc() -> bool:
    """Finish a background stick job. True when hover state changed."""
    proc = _HOVER.get("stick_proc")
    if proc is None:
        return False
    if proc.poll() is None:
        want_gen = int(_HOVER.get("gen") or 0)
        if int(_HOVER.get("stick_proc_gen") or -1) != want_gen:
            _kill_stick_preview_proc()
            return True
        return False
    log_handle = _HOVER.get("stick_proc_log")
    if log_handle is not None:
        try:
            log_handle.close()
        except OSError:
            pass
        _HOVER["stick_proc_log"] = None
    out_path = Path(str(_HOVER.get("stick_proc_out") or ""))
    job_path = str(_HOVER.get("stick_proc_path") or "")
    job_gen = int(_HOVER.get("stick_proc_gen") or -1)
    _HOVER["stick_proc"] = None
    _HOVER["stick_proc_out"] = ""
    _HOVER["stick_proc_path"] = ""
    _HOVER["stick_proc_gen"] = -1
    data = None
    err = ""
    if out_path.is_file():
        try:
            payload = pickle.loads(out_path.read_bytes())
            if isinstance(payload, dict):
                data = payload.get("data")
                err = str(payload.get("err") or "")
        except (OSError, ValueError, pickle.UnpicklingError) as exc:
            err = str(exc)
        try:
            out_path.unlink(missing_ok=True)
        except OSError:
            pass
    else:
        err = err or "stick preview failed"
    return _apply_stick_decode_result(job_path, data, err or "preview failed", job_gen)


def _preview_source(path: str) -> str:
    """Character clip for a whole-scene preview. Props borrow the player rig."""
    file_path = Path(path)
    upper = file_path.name.upper()
    if any(token in upper for token in ("HUM_", "TIF_", "DGB_", "GTY_", "HFL_", "GOB_", "ELF_")):
        return str(file_path)
    try:
        clips = sorted(file_path.parent.glob("*.GR2")) + sorted(file_path.parent.glob("*.gr2"))
    except OSError:
        return str(file_path)
    for cand in clips:
        name = cand.name.upper()
        if "PLYR" in name and any(token in name for token in ("HUM_", "TIF_", "DGB_")):
            return str(cand)
    return str(file_path)


def _snapshot_ids() -> dict:
    return {
        "objects": {obj.name for obj in bpy.data.objects},
        "meshes": {mesh.name for mesh in bpy.data.meshes},
        "armatures": {arm.name for arm in bpy.data.armatures},
        "cameras": {cam.name for cam in bpy.data.cameras},
        "actions": {action.name for action in bpy.data.actions},
        "collections": {col.name for col in bpy.data.collections},
        "worlds": {world.name for world in bpy.data.worlds},
        "scenes": {scene.name for scene in bpy.data.scenes},
        "materials": {mat.name for mat in bpy.data.materials},
        "images": {image.name for image in bpy.data.images},
        "node_groups": {group.name for group in bpy.data.node_groups},
    }


def _drop_new_ids(before: dict) -> None:
    for obj in list(bpy.data.objects):
        if obj.name not in before["objects"]:
            bpy.data.objects.remove(obj, do_unlink=True)
    window = getattr(bpy.context, "window", None)
    window_scene = window.scene if window is not None else bpy.context.scene
    for scene in list(bpy.data.scenes):
        if scene.name not in before["scenes"] and scene != window_scene:
            bpy.data.scenes.remove(scene)
    banks = (
        ("collections", bpy.data.collections),
        ("meshes", bpy.data.meshes),
        ("armatures", bpy.data.armatures),
        ("cameras", bpy.data.cameras),
        ("materials", bpy.data.materials),
        ("images", bpy.data.images),
        ("actions", bpy.data.actions),
        ("worlds", bpy.data.worlds),
        ("node_groups", bpy.data.node_groups),
    )
    for _pass in range(4):
        for key, datablocks in banks:
            known = before.get(key) or set()
            for block in list(datablocks):
                if block.name in known:
                    continue
                if getattr(block, "use_fake_user", False):
                    try:
                        block.use_fake_user = False
                    except Exception:
                        pass
                if block.users == 0:
                    datablocks.remove(block)


def _glasses_sidecar() -> Path:
    local = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(local) / "GlassesMcp" / "gr2lab_preview.json"


def _lookat_camera(scene, camera):
    from mathutils import Vector

    points = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.hide_render:
            continue
        for corner in obj.bound_box:
            points.append(obj.matrix_world @ Vector(corner))
    if not points:
        camera.location = (4.0, -4.0, 1.6)
        return
    center = sum(points, Vector()) / len(points)
    size = max(
        max(point.x for point in points) - min(point.x for point in points),
        max(point.y for point in points) - min(point.y for point in points),
        max(point.z for point in points) - min(point.z for point in points),
        1.0,
    )
    distance = size * 2.1 * (95.0 / 36.0)
    camera.location = center + Vector((distance * 0.45, -distance, size * 0.2))
    direction = center - camera.location
    camera.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    camera.data.lens = 95.0
    camera.data.clip_start = 0.01
    camera.data.clip_end = max(distance * 40.0, 1000.0)


def _play_frames(start: int, end: int, scene_fps: float) -> Tuple[List[int], float, float]:
    """Sparse stills that play back in real time (cap count for build speed)."""
    count = max(1, end - start + 1)
    fps = float(scene_fps or 30.0)
    duration = count / fps
    step = max(1, int(math.ceil(count / PREVIEW_MAX_STILLS)))
    step = max(step, max(1, int(round(fps / PREVIEW_PLAY_FPS))))
    frames = list(range(start, end + 1, step))
    if frames[-1] != end:
        frames.append(end)
    play_fps = len(frames) / duration if duration > 0 else PREVIEW_PLAY_FPS
    return frames, duration, play_fps


def _fit_aspect_rect(rect) -> Tuple[float, float, float, float]:
    """16:9 draw rect inside the preview tile (no stretch)."""
    x, y, w, h = rect
    if w <= 1.0 or h <= 1.0:
        return rect
    if w / h > PREVIEW_ASPECT:
        fit_w = h * PREVIEW_ASPECT
        fit_h = h
    else:
        fit_w = w
        fit_h = w / PREVIEW_ASPECT
    return (x + (w - fit_w) * 0.5, y + (h - fit_h) * 0.5, fit_w, fit_h)


def _read_play_manifest(folder: Path, source: str) -> Optional[dict]:
    path = folder / "manifest.json"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    count = int(data.get("count") or 0)
    if int(data.get("preview_rev") or 0) != PREVIEW_REV:
        return None
    if count < 8 or not data.get("duration_sec"):
        return None
    shots = [folder / f"{index}.png" for index in range(count)]
    if not all(shot.is_file() and shot.stat().st_size > 0 for shot in shots):
        return None
    data = dict(data)
    data["shots"] = [str(shot) for shot in shots]
    data["seconds"] = 0.0
    data["cached"] = True
    data["source"] = source
    data["kind"] = "scene"
    return data


def build_scene_preview(context, gr2_path: str, *, inplace: bool = False, fast: bool = True) -> dict:
    """Render the clip as a playback sequence, then delete that preview."""
    from . import scene_stage_empties
    from .bridge_blender import (
        _apply_layout_from_prefs,
        _resolve_body_base_for_import,
        import_gr2lab_from_doc,
    )
    from .local_pipeline import import_gr2_pipeline_local

    source = _preview_source(gr2_path)
    folder = _shot_dir(Path(source))
    cached = _read_play_manifest(folder, source)
    if cached is not None:
        return cached

    windows = list(getattr(context.window_manager, "windows", []) or [])
    window = getattr(context, "window", None) or (windows[0] if windows else None)
    user_scene = window.scene if window is not None else context.scene
    frame = user_scene.frame_current
    user_render = (
        user_scene.render.filepath,
        user_scene.render.resolution_x,
        user_scene.render.resolution_y,
        user_scene.render.resolution_percentage,
        user_scene.render.engine,
    )
    view_layer = window.view_layer if window is not None else user_scene.view_layers[0]
    user_range = (user_scene.frame_start, user_scene.frame_end)
    user_props = {
        key: user_scene[key]
        for key in ("gr2lab_glasses_preview", "gr2lab_glasses_time_sec")
        if key in user_scene.keys()
    }
    previous_active = view_layer.objects.active
    previous_mode = getattr(previous_active, "mode", "OBJECT") if previous_active else "OBJECT"
    area = next((item for item in window.screen.areas if item.type == "VIEW_3D"), None) if window is not None else None
    region = None
    if area is not None:
        region = next((item for item in area.regions if item.type == "WINDOW"), None)
    before = _snapshot_ids()
    sidecar = _glasses_sidecar()
    sidecar_bytes = sidecar.read_bytes() if sidecar.is_file() else None
    t0 = time.perf_counter()
    if inplace:
        preview = user_scene
        for name in ("Cube", "Light", "Camera"):
            obj = preview.objects.get(name)
            if obj is not None:
                bpy.data.objects.remove(obj, do_unlink=True)
        previous_active = None
        previous_mode = "OBJECT"
    else:
        preview = bpy.data.scenes.new("GR2LAB_Preview")
    preview.render.resolution_x = PREVIEW_RENDER_W
    preview.render.resolution_y = PREVIEW_RENDER_H
    preview.render.resolution_percentage = 100
    preview.render.image_settings.file_format = "PNG"
    preview.render.film_transparent = False
    try:
        preview.render.engine = "BLENDER_WORKBENCH"
    except TypeError:
        pass
    blocked = [
        name
        for name in ("Initiator_1", "Additional_1", "Additional_2", "Additional_3", "GR2LAB_Scene_Camera")
        if bpy.data.objects.get(name) is not None
    ]
    built = {}
    try:
        override = {"scene": preview, "view_layer": preview.view_layers[0]}
        if window is not None:
            override["window"] = window
        if area is not None and region is not None:
            override["area"] = area
            override["region"] = region
        runner = context.temp_override(**override) if not inplace else contextlib.nullcontext()
        with runner:
            print("STAGE layout", flush=True)
            _apply_layout_from_prefs(bpy.context)
            base = _resolve_body_base_for_import(
                choice="AUTO", bb_hint="", prefs_base="", source_gr2=source
            )
            print("STAGE decode", base, flush=True)
            _dec, doc = import_gr2_pipeline_local(source, body_base=base)
            print("STAGE primary", flush=True)
            import_gr2lab_from_doc(
                bpy.context,
                doc,
                fps=30,
                y_up_display=True,
                template_path=source,
                rig_display=False,
                rig_parts={"shapes": False, "ik_hands": False, "ik_legs": False, "ik_head": False},
                anim_apply="NEW_RIG",
                import_meshes="BODY_CLOTH",
                import_tail=not fast,
                mesh_base=base,
            )
            partner = None
            if fast:
                partner = _partner_gr2_fast(source)
                print("STAGE fast partner", partner, flush=True)
                if partner is not None:
                    pbase = _resolve_body_base_for_import(
                        choice="AUTO", bb_hint="", prefs_base="", source_gr2=str(partner)
                    )
                    _pdec, pdoc = import_gr2_pipeline_local(str(partner), body_base=pbase)
                    import_gr2lab_from_doc(
                        bpy.context,
                        pdoc,
                        fps=30,
                        y_up_display=True,
                        template_path=str(partner),
                        rig_display=False,
                        rig_parts={"shapes": False, "ik_hands": False, "ik_legs": False, "ik_head": False},
                        anim_apply="NEW_RIG",
                        import_meshes="BODY_CLOTH",
                        import_tail=False,
                        mesh_base=pbase,
                    )
            elif not blocked:
                print("STAGE plan", flush=True)
                plan = scene_stage_empties.plan_scene_empties(source)
                if plan is not None:
                    print("STAGE place", flush=True)
                    scene_stage_empties.place_for_import(
                        bpy.context,
                        source,
                        y_up_display=True,
                        parent_rig=True,
                        plan=plan,
                        defer_cinematic=True,
                        skip_cleanup=True,
                    )
                    partner = scene_stage_empties.find_partner_gr2(source, primary_plan=plan)
                    print("STAGE partner", partner, flush=True)
                    if partner is not None:
                        pbase = _resolve_body_base_for_import(
                            choice="AUTO", bb_hint="", prefs_base="", source_gr2=str(partner)
                        )
                        _pdec, pdoc = import_gr2_pipeline_local(str(partner), body_base=pbase)
                        import_gr2lab_from_doc(
                            bpy.context,
                            pdoc,
                            fps=30,
                            y_up_display=True,
                            template_path=str(partner),
                            rig_display=False,
                            rig_parts={"shapes": False, "ik_hands": False, "ik_legs": False, "ik_head": False},
                            anim_apply="NEW_RIG",
                            import_meshes="BODY_CLOTH",
                            import_tail=True,
                            mesh_base=pbase,
                        )
                    print("STAGE sync", flush=True)
                    col = scene_stage_empties.find_scene_collection(source, plan)
                    if col is not None:
                        note = scene_stage_empties.apply_cinematic_timeline_sync(
                            bpy.context,
                            col,
                            source,
                            plan,
                            y_up_display=True,
                        )
                        print(
                            "SYNC",
                            note,
                            "phase",
                            plan.phase_index,
                            "cam",
                            bpy.data.objects.get("GR2LAB_Scene_Camera") is not None,
                            flush=True,
                        )
            camera = bpy.data.objects.get("GR2LAB_Scene_Camera")
            if camera is None or camera.name in before["objects"] or camera.type != "CAMERA":
                camera = bpy.data.objects.new("GR2LAB_Preview_Camera", bpy.data.cameras.new("GR2LAB_Preview_Camera"))
                preview.collection.objects.link(camera)
                _lookat_camera(preview, camera)
            preview.camera = camera
            for obj in preview.objects:
                if obj.type in {"EMPTY", "ARMATURE"}:
                    obj.hide_render = True
            start = int(preview.frame_start)
            end = max(start, int(preview.frame_end))
            scene_fps = float(preview.render.fps or 30)
            play_frames, duration_sec, play_fps = _play_frames(start, end, scene_fps)
            shots = [folder / f"{index}.png" for index in range(len(play_frames))]
            play_fps = round(play_fps, 3)
            built["mesh_render"] = sum(
                1 for obj in preview.objects if obj.type == "MESH" and not obj.hide_render
            )
            built["camera"] = camera.name
            built["span"] = (start, end)
            built["partner"] = Path(str(partner)).name if partner else ""
            built["play_fps"] = play_fps
            built["duration_sec"] = duration_sec
            built["play_frames"] = play_frames
            built["shots"] = shots
            fallback = camera.name == "GR2LAB_Preview_Camera"
            if fallback:
                preview.frame_set(play_frames[len(play_frames) // 2])
                preview.view_layers[0].update()
                _lookat_camera(preview, camera)
            print(
                "STAGE camera",
                camera.name,
                "meshes",
                built.get("mesh_render"),
                "frames",
                len(play_frames),
                "fps",
                play_fps,
                flush=True,
            )
            for index, frame_num in enumerate(play_frames):
                preview.frame_set(frame_num)
                preview.render.filepath = str(shots[index])
                preview.render.use_file_extension = True
                if index == 0 or index == len(play_frames) - 1 or index % 30 == 0:
                    print("STAGE render", index, frame_num, flush=True)
                bpy.ops.render.render(write_still=True)
    finally:
        if window is not None:
            window.scene = user_scene
        try:
            user_scene.frame_set(frame)
            user_scene.render.filepath = user_render[0]
            user_scene.render.resolution_x = user_render[1]
            user_scene.render.resolution_y = user_render[2]
            user_scene.render.resolution_percentage = user_render[3]
            user_scene.render.engine = user_render[4]
            user_scene.frame_start = user_range[0]
            user_scene.frame_end = user_range[1]
            for key in ("gr2lab_glasses_preview", "gr2lab_glasses_time_sec"):
                if key in user_props:
                    user_scene[key] = user_props[key]
                elif key in user_scene.keys():
                    del user_scene[key]
        except Exception:
            pass
        if previous_active is not None and previous_active.name in bpy.data.objects:
            try:
                view_layer.objects.active = previous_active
                if previous_mode and previous_mode != "OBJECT" and previous_active.mode != previous_mode:
                    with context.temp_override(window=window, area=area, region=region):
                        bpy.ops.object.mode_set(mode=previous_mode)
            except Exception:
                pass
        _drop_new_ids(before)
        if sidecar_bytes is None:
            if sidecar.is_file():
                try:
                    sidecar.unlink()
                except OSError:
                    pass
        else:
            try:
                sidecar.write_bytes(sidecar_bytes)
            except OSError:
                pass
    shots = list(built.get("shots") or [])
    missing = [shot.name for shot in shots if not shot.is_file()]
    if len(shots) < 8 or missing:
        raise RuntimeError("scene preview did not write " + ", ".join(missing[:8] or ["frames"]))
    play_fps = float(built.get("play_fps") or 0.0)
    duration_sec = float(built.get("duration_sec") or 0.0)
    result = {
        "kind": "scene",
        "preview_rev": PREVIEW_REV,
        "shots": [str(shot) for shot in shots],
        "count": len(shots),
        "play_fps": play_fps,
        "duration_sec": duration_sec,
        "seconds": round(time.perf_counter() - t0, 3),
        "cached": False,
        "source": source,
        "blocked_scene": bool(blocked),
        "mesh_render": built.get("mesh_render", 0),
        "camera": built.get("camera", ""),
        "span": list(built.get("span") or []),
        "partner": built.get("partner", ""),
    }
    try:
        (folder / "manifest.json").write_text(
            json.dumps({key: value for key, value in result.items() if key != "shots"}),
            encoding="utf-8",
        )
    except OSError:
        pass
    return result


def _spawn_preview(path: str) -> None:
    """Render outside this Blender. The open file is not imported into."""
    old = _HOVER.get("proc")
    if old is not None and old.poll() is None:
        try:
            old.kill()
        except OSError:
            pass
    log_handle = _HOVER.get("proc_log")
    if log_handle is not None:
        try:
            log_handle.close()
        except OSError:
            pass
    source = _preview_source(path)
    out = _shot_dir(Path(source)) / "result.json"
    try:
        if out.is_file():
            out.unlink()
    except OSError:
        pass
    script = Path(__file__).with_name("scene_preview_job.py")
    prefs = bpy.context.preferences.addons[__package__].preferences
    unpacked = str(getattr(prefs, "bg3_unpacked_dir", "") or "")
    log_path = out.with_suffix(".log")
    log_handle = open(log_path, "w", encoding="utf-8")
    proc = subprocess.Popen(
        [
            bpy.app.binary_path,
            "--background",
            "--factory-startup",
            "--python",
            str(script),
            "--",
            path,
            str(out),
            unpacked,
        ],
        stdout=log_handle,
        stderr=subprocess.STDOUT,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    _HOVER["proc"] = proc
    _HOVER["proc_log"] = log_handle
    _HOVER["proc_out"] = str(out)
    _HOVER["proc_path"] = path


def _show_sticks_if_cached(path: str) -> bool:
    """Strip / hover preview: cached sticks only (no background Blender jobs)."""
    if not path:
        return False
    cached = _stick_mem_get(path)
    if cached is None:
        cached = _stick_load_disk(path)
    if cached is None:
        return False
    shown = _compose_stick_pair(path, cached, decode=False)
    _show_pose(path, shown, "sticks cached")
    if shown.get("partner_pending"):
        _spawn_partner_fill(path, int(_HOVER.get("gen") or 0))
    return True


def _spawn_partner_fill(path: str, gen: int) -> None:
    """Decode the other body after the cached one is already on screen."""
    if str(_HOVER.get("partner_fill") or "") == path:
        return
    _HOVER["partner_fill"] = path

    def worker(job_path: str = path, job_gen: int = int(gen)) -> None:
        solo = _stick_mem_get(job_path)
        if not solo:
            shown = None
        else:
            shown = _compose_stick_pair(
                job_path,
                solo,
                decode=True,
                should_cancel=lambda: int(_HOVER.get("gen") or 0) != job_gen,
                quiet=False,
            )

        def finish() -> None:
            if str(_HOVER.get("partner_fill") or "") == job_path:
                _HOVER["partner_fill"] = ""
            _DRAG["pair"] = None
            if (
                shown
                and int(_HOVER.get("gen") or 0) == job_gen
                and str(_HOVER.get("path") or "") == job_path
                and shown.get("partner_name")
            ):
                _show_pose(job_path, shown, "sticks pair")
                _hover_log(
                    f"hover pair {Path(job_path).name} + {shown.get('partner_name')}"
                )
            return None

        try:
            bpy.app.timers.register(finish, first_interval=0.0)
        except Exception:
            finish()

    threading.Thread(target=worker, name="gr2lab-stick-partner", daemon=True).start()


def _start_preview(path: str, *, force: bool = False) -> None:
    return
    if not path or not force:
        return
    if _show_sticks_if_cached(path):
        _tag()
        return
    if _hover_stick_decode_busy():
        if _HOVER.get("stick_proc_path") == path:
            return
        _kill_stick_preview_proc()
    _HOVER["status"] = "sticks…"
    _HOVER["result"] = None
    _spawn_stick_preview(path, int(_HOVER["gen"]))
    _tag(STICK_LOAD_TAG_INTERVAL)


def _path_key(path: str) -> str:
    """Compare clip paths without touching the disk. Resolve() in the list draw was the hitch."""
    raw = str(path or "").replace("/", "\\").casefold()
    if raw.startswith("\\\\?\\"):
        raw = raw[4:]
    return raw


def _armature_of(obj):
    if obj is None:
        return None
    if getattr(obj, "type", None) == "ARMATURE":
        return obj
    parent = getattr(obj, "parent", None)
    if parent is not None and getattr(parent, "type", None) == "ARMATURE":
        return parent
    for mod in getattr(obj, "modifiers", ()) or ():
        if getattr(mod, "type", "") == "ARMATURE" and getattr(mod, "object", None) is not None:
            return mod.object
    return None


def _direct_rig_source(arm) -> str:
    src = str(arm.get("gr2lab_full_source_gr2") or arm.get("gr2lab_source_gr2") or "").strip()
    if src:
        return src
    anim = getattr(arm, "animation_data", None)
    action = getattr(anim, "action", None) if anim is not None else None
    if action is None:
        return ""
    return str(action.get("gr2lab_source_gr2") or "").strip()


def _rig_source_path(arm) -> str:
    src = _direct_rig_source(arm)
    if src:
        return src
    parent = getattr(arm, "parent", None)
    if parent is None:
        return ""
    for child in getattr(parent, "children", ()) or ():
        if child is arm or getattr(child, "type", None) != "ARMATURE":
            continue
        src = _direct_rig_source(child)
        if src:
            return src
    return ""


_CLIP_LOOKUP = {"mtime": -1.0, "by_path": {}, "by_name": {}}


def _norm_clip_path(path: str) -> str:
    return str(path).replace("/", "\\").casefold()


def _ensure_clip_lookup(data: dict) -> None:
    """Map clip path → scene once. Selecting a rig must not walk the library."""
    mtime = float(_INDEX.get("mtime") or 0.0)
    if _CLIP_LOOKUP["mtime"] == mtime and _CLIP_LOOKUP["by_path"]:
        return
    by_path: Dict[str, tuple] = {}
    by_name: Dict[str, list] = {}
    for row in data.get("scenes") or []:
        folder = str(row.get("dir") or "")
        prefix = _norm_clip_path(folder)
        if prefix and not prefix.endswith("\\"):
            prefix += "\\"
        for clip in row.get("clips") or []:
            full = prefix + _norm_clip_path(clip)
            by_path[full] = (row, clip)
            by_name.setdefault(str(clip).casefold(), []).append((row, clip))
    _CLIP_LOOKUP["mtime"] = mtime
    _CLIP_LOOKUP["by_path"] = by_path
    _CLIP_LOOKUP["by_name"] = by_name


def _try_focus_search_clip(data: dict) -> bool:
    """Jump the strip to a library clip when the search box holds a path or GR2 name."""
    raw = (_STATE.get("query") or "").strip()
    if not raw or not data:
        return False
    tries: List[str] = [raw]
    try:
        path = Path(raw)
        tries.append(path.name)
        if path.suffix.lower() != ".gr2":
            tries.append(f"{path.name}.GR2")
        try:
            tries.append(str(path.resolve()))
        except OSError:
            pass
    except (TypeError, ValueError):
        pass
    seen: set = set()
    for cand in tries:
        key = cand.casefold()
        if not cand or key in seen:
            continue
        seen.add(key)
        scene, clip = _indexed_clip(data, cand)
        if scene is not None and clip:
            _show_indexed_clip(scene, clip)
            return True
    return False


def _indexed_clip(data: dict, source: str):
    _ensure_clip_lookup(data)
    want = _norm_clip_path(source)
    hit = _CLIP_LOOKUP["by_path"].get(want)
    if hit is not None:
        return hit
    try:
        resolved = _norm_clip_path(str(Path(source).resolve()))
    except OSError:
        resolved = ""
    if resolved and resolved != want:
        hit = _CLIP_LOOKUP["by_path"].get(resolved)
        if hit is not None:
            return hit
    hits = _CLIP_LOOKUP["by_name"].get(Path(source).name.casefold()) or []
    if len(hits) == 1:
        return hits[0]
    return None, None


def _show_indexed_clip(scene: dict, clip: str, *, scroll: bool = True) -> None:
    tags = set(scene.get("tags") or [])
    act = str(scene.get("act") or "")
    if time.time() >= float(_STATE.get("act_hold_until") or 0.0):
        if _STATE.get("act") not in ("All", act):
            _STATE["act"] = act or "All"
            _STATE["filtered_key"] = ""
    if _STATE.get("camp") and "CAMP" not in tags:
        _STATE["camp"] = False
        _STATE["filtered_key"] = ""
    if _STATE.get("rom") and "ROM" not in tags:
        _STATE["rom"] = False
        _STATE["filtered_key"] = ""
    tokens = _search_tokens(_STATE.get("query") or "")
    scene_name = scene.get("name") or ""
    if tokens and (
        not _scene_has_tokens(scene, tokens)
        or not _text_has_tokens(f"{scene_name} {clip}", tokens)
    ):
        _STATE["query"] = ""
        _STATE["search_caret"] = 0
        _STATE["search_sel"] = False
        _STATE["filtered_key"] = ""
    data = _INDEX.get("data") or {}
    rows = _filtered(data)
    ids = [row.get("id") for row in rows]
    try:
        scene_index = ids.index(scene.get("id"))
    except ValueError:
        scene_index = 0
    _STATE["scene_id"] = scene.get("id") or ""
    if not _filters_allow(scene):
        _STATE["cast"] = ""
        _STATE["kind"] = ""
        _STATE["who"] = ""
        _STATE["filtered_key"] = ""
        _STATE["clip_hits_key"] = ""
    if scroll:
        _STATE["scene_scroll"] = max(0, scene_index - 3)
    full = str(Path(scene.get("dir") or "") / clip)
    clip_index = 0
    want_key = _path_key(full)
    for i, entry in enumerate(_browser_clip_entries()):
        if _path_key(str(entry.get("path") or "")) == want_key:
            clip_index = i
            clip = str(entry.get("name") or clip)
            full = str(entry.get("path") or full)
            break
    if scroll:
        _STATE["clip_scroll"] = max(0, clip_index - 2)
    _STATE["clip_path"] = full
    _gallery_follow_browser(full)
    _preview_follow(full)
    _tag()


def _clip_is_selected(filepath: str) -> bool:
    path = str(filepath or "").strip()
    if not path:
        return False
    return _path_key(path) == _path_key(str(_STATE.get("clip_path") or ""))


def _select_strip_clip(context, filepath: str) -> None:
    """Highlight a clip in the strip (no import, no scroll/filter side effects)."""
    path = str(filepath or "").strip()
    if not path:
        return
    data = _load_index()
    if data:
        scene, clip_name = _indexed_clip(data, path)
        if scene is not None and clip_name:
            full = str(Path(scene.get("dir") or "") / clip_name)
            scene_id = scene.get("id") or ""
            if _STATE.get("scene_id") != scene_id:
                _STATE["scene_id"] = scene_id
            path = full
    _STATE["clip_path"] = path
    if _GALLERY.get("items"):
        _GALLERY["hover_path"] = ""
        _GALLERY["generate_over"] = ""
        _GALLERY["generate_mode"] = ""
    _gallery_follow_browser(path)
    held = str(_GALLERY.get("picked_path") or path)
    if held:
        _GALLERY["last_hover"] = held
    _preview_follow(path)
    _tag()


def _sync_browser_to_rig() -> None:
    if _DRAG.get("active") or _STATE.get("search_focus"):
        return
    try:
        ctx = bpy.context
        if not _browser_on(ctx):
            return
        arm = _armature_of(getattr(ctx.view_layer.objects, "active", None))
    except Exception:
        return
    if arm is None:
        _STATE["rig_sync"] = ""
        return
    src = _rig_source_path(arm)
    token = f"{arm.as_pointer()}|{src}"
    if token == _STATE.get("rig_sync"):
        return
    _STATE["rig_sync"] = token
    if not src:
        return
    data = _load_index()
    if not data:
        return
    scene, clip = _indexed_clip(data, src)
    if scene is None or not clip:
        _STATE["clip_path"] = ""
        _tag()
        return
    _show_indexed_clip(scene, clip, scroll=True)


def _tick() -> Optional[float]:
    if not _ALIVE:
        return None
    if not _blender_window_active():
        return 0.5
    _sync_browser_to_rig()
    changed = False
    refilter_at = float(_STATE.get("search_refilter_at") or 0.0)
    if refilter_at and time.perf_counter() >= refilter_at:
        _STATE["search_refilter_at"] = 0.0
        _STATE["filtered_key"] = ""
        _STATE["scene_scroll"] = 0
        _STATE["clip_scroll"] = 0
        data = _load_index()
        if data:
            q = (_STATE.get("query") or "").strip()
            if q and (
                q.casefold().endswith(".gr2")
                or "\\" in q
                or "/" in q
                or ("_" in q and len(q) > 24)
            ):
                if _try_focus_search_clip(data):
                    changed = True
        changed = True
    if _STATE.get("search_focus"):
        phase = int(time.time() * 2) % 2
        if phase != int(_STATE.get("search_blink_phase", -1)):
            _STATE["search_blink_phase"] = phase
            changed = True
    if changed or _PREP["running"]:
        _tag()
    _flush_tag_pending()
    if _STATE.get("search_focus"):
        return 0.08
    return 0.1


def _ensure_timer() -> None:
    global _TIMER_ON
    if _TIMER_ON:
        return
    _TIMER_ON = True
    bpy.app.timers.register(_tick, first_interval=0.1, persistent=True)


def addon_keyconfig(wm) -> Optional[object]:
    """Addon keymaps only — never write into user/active (breaks F2/F3, save, etc.)."""
    if wm is None:
        return None
    return wm.keyconfigs.addon


def view3d_keyconfig(wm) -> Optional[object]:
    return addon_keyconfig(wm)


def _keymap_find(kc, name: str, space_type: str):
    try:
        return kc.keymaps.find(name=name, space_type=space_type)
    except TypeError:
        return kc.keymaps.find(name, space_type=space_type)


def _ensure_keymap(kc, name: str, space_type: str):
    km = _keymap_find(kc, name, space_type)
    if km is not None:
        return km
    return kc.keymaps.new(name=name, space_type=space_type)


def _browser_on(context) -> bool:
    try:
        addon = context.preferences.addons.get("gr2lab_blender")
        prefs = addon.preferences if addon is not None else None
        return bool(getattr(prefs, "anim_browser", True))
    except Exception:
        return False


def stop_clip_hover_preview() -> None:
    """Cancel decode jobs and clear the preview tile (browser stays usable)."""
    _kill_stick_preview_proc()
    proc = _HOVER.get("proc")
    if proc is not None and proc.poll() is None:
        try:
            proc.kill()
        except OSError:
            pass
    log_handle = _HOVER.get("proc_log")
    if log_handle is not None:
        with contextlib.suppress(OSError):
            log_handle.close()
    _HOVER["proc"] = None
    _HOVER["proc_log"] = None
    _HOVER["proc_out"] = ""
    _HOVER["proc_path"] = ""
    _HOVER["partner_fill"] = ""
    _HOVER["gen"] = int(_HOVER.get("gen") or 0) + 1
    _HOVER["shown"] = ""
    _HOVER["poses"] = None
    _HOVER["result"] = None
    _HOVER["status"] = ""
    _PREFETCH["gen"] = int(_PREFETCH.get("gen") or 0) + 1
    _PREFETCH["queue"] = []
    _tag()


def _browser_whole_scene(context=None) -> bool:
    """Whole scene in the strip: partner rig, stage empties, timeline camera (import dialog)."""
    return bool(_STATE.get("whole_scene", True))


def _browser_center_parent(context=None) -> bool:
    """Centralize scene (top parent at origin) — same as import dialog toggle."""
    return bool(_STATE.get("center_parent"))


def edit_copy_enabled() -> bool:
    return bool(_STATE.get("edit_copy"))


def _sync_browser_center_parent(context, value: bool) -> None:
    _STATE["center_parent"] = bool(value)
    if context is None:
        return
    try:
        prefs = context.preferences.addons[__package__].preferences
        prefs.center_parent = bool(value)
    except Exception:
        pass


def _active_browser_clip_path() -> str:
    path = str(_STATE.get("clip_path") or "").strip()
    if path:
        return path
    hover = str(_HOVER.get("path") or "").strip()
    if hover:
        return hover
    return ""


def _strip_clip_path_at(region, mx: float, my: float) -> str:
    if region is None:
        return ""
    found = _hit(region, float(mx), float(my))
    if found is None or found[0] not in {"clip", "recent"}:
        return ""
    return str(found[1] or "")


def copy_gr2_clip_name(filepath: str) -> bool:
    """Copy the GR2 file name (e.g. HUM_….GR2) to the system clipboard."""
    path = str(filepath or "").strip()
    if not path:
        return False
    name = Path(path).name
    if not name:
        return False
    try:
        bpy.context.window_manager.clipboard = name
    except Exception:
        return False
    _HOVER["status"] = f"copied {name}"
    _tag()
    return True


def _invoke_clip_context_menu(context, filepath: str) -> bool:
    global _CLIP_MENU_PATH
    path = str(filepath or "").strip()
    if not path:
        return False
    _CLIP_MENU_PATH = path
    try:
        bpy.ops.wm.call_menu(name=GR2LAB_MT_anim_clip_menu.bl_idname)
        return True
    except Exception:
        traceback.print_exc()
        return False


def _cursor_drop_point(context):
    return Vector(context.scene.cursor.location)


def _gr2lab_armatures():
    if bpy is None:
        return []
    return [
        obj
        for obj in bpy.data.objects
        if getattr(obj, "type", "") == "ARMATURE" and obj.get("gr2lab_run_id")
    ]


def finish_deferred_edit_copy(context, import_state) -> None:
    """Run edit duplicate after import modal ends (ops do not run inside import modal)."""
    if bpy is None or context is None or not import_state:
        return
    if not import_state.pop("defer_edit_copy", False):
        return
    arm = import_state.get("arm")
    if arm is None:
        name = str(import_state.get("arm_name") or "").strip()
        if name:
            arm = bpy.data.objects.get(name)
    if arm is None or getattr(arm, "type", "") != "ARMATURE":
        print("[GR2 LAB] edit copy: no armature after import", flush=True)
        return
    try:
        from .import_progress_ui import update as overlay_update

        overlay_update(0.99, "Edit copy…", detail="duplicate rig + NLA")
    except Exception:
        pass
    duplicate_edit_rig_now(context, arm)


def duplicate_edit_rig_now(context, arm):
    """Copy rig + meshes aside with one full NLA strip + copied Action."""
    if bpy is None or context is None or arm is None:
        return None
    from . import scene_stage_empties

    dup = scene_stage_empties.duplicate_gr2lab_edit_rig(
        context,
        arm,
        offset=(0.0, 3.0, 0.0),
        scene_start=1,
        duplicate_action=False,
    )
    if dup is not None:
        try:
            bpy.ops.object.select_all(action="DESELECT")
            dup.select_set(True)
            context.view_layer.objects.active = dup
        except Exception:
            pass
        print(f"[GR2 LAB] duplicate for edit: {dup.name}", flush=True)
    return dup


def _place_strip_clip_at_cursor(context, filepath: str) -> None:
    """Drop the selected strip clip at the 3D cursor (second click / click without drag)."""
    path = str(filepath or "").strip()
    if not path:
        return
    point = _cursor_drop_point(context)
    _import_clip_at(
        context,
        path,
        point,
        place=True,
        whole_scene=_browser_whole_scene(context),
        replace_stack=True,
    )


def _strip_import_kwargs(context, filepath: str) -> dict:
    """Browser drag / preload uses the same NEW_RIG + Whole scene flags as a quick drop."""
    from .bridge_blender import gr2_import_exec_kwargs

    path = str(filepath or "").strip()
    whole = _browser_whole_scene(context)
    kwargs = gr2_import_exec_kwargs(context, path)
    kwargs["import_apply"] = "NEW_RIG"
    kwargs["target_armature"] = ""
    kwargs["add_rig"] = True
    center = _browser_center_parent(context)
    kwargs["second_character"] = whole
    kwargs["scene_empties"] = bool(whole or center)
    kwargs["center_parent"] = bool(center)
    return kwargs


def _importing() -> bool:
    try:
        from .import_progress_ui import _STATE as import_state

        return bool(import_state.get("active"))
    except Exception:
        return False


def _step_scene(delta: int) -> None:
    rows = _STATE["filtered"]
    if not rows:
        return
    ids = [row["id"] for row in rows]
    current = _STATE["scene_id"]
    try:
        index = ids.index(current)
    except ValueError:
        index = 0
    index = (index + delta) % len(ids)
    _STATE["scene_id"] = ids[index]
    _STATE["clip_scroll"] = 0
    visible = 7
    if index < _STATE["scene_scroll"]:
        _STATE["scene_scroll"] = index
    elif index >= _STATE["scene_scroll"] + visible:
        _STATE["scene_scroll"] = index - visible + 1


def _paeth(left: int, up: int, up_left: int) -> int:
    estimate = left + up - up_left
    dist_left = abs(estimate - left)
    dist_up = abs(estimate - up)
    dist_up_left = abs(estimate - up_left)
    if dist_left <= dist_up and dist_left <= dist_up_left:
        return left
    if dist_up <= dist_up_left:
        return up
    return up_left


def _decode_png(path: str) -> Tuple[int, int, bytes]:
    data = Path(path).read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("png")
    pos = 8
    width = height = color = 0
    idat = []
    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos : pos + 4])[0]
        kind = data[pos + 4 : pos + 8]
        chunk = data[pos + 8 : pos + 8 + length]
        pos += 12 + length
        if kind == b"IHDR":
            width, height, bit, color, _comp, _filt, inter = struct.unpack(">IIBBBBB", chunk)
            if bit != 8 or inter != 0 or color not in (2, 6):
                raise ValueError("png format")
        elif kind == b"IDAT":
            idat.append(chunk)
        elif kind == b"IEND":
            break
    raw = zlib.decompress(b"".join(idat))
    channels = 4 if color == 6 else 3
    stride = width * channels
    rows = []
    cursor = 0
    previous = bytearray(stride)
    for _y in range(height):
        filter_type = raw[cursor]
        cursor += 1
        row = bytearray(raw[cursor : cursor + stride])
        cursor += stride
        if filter_type == 1:
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                row[x] = (row[x] + left) & 255
        elif filter_type == 2:
            for x in range(stride):
                row[x] = (row[x] + previous[x]) & 255
        elif filter_type == 3:
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                row[x] = (row[x] + ((left + previous[x]) // 2)) & 255
        elif filter_type == 4:
            for x in range(stride):
                left = row[x - channels] if x >= channels else 0
                up = previous[x]
                up_left = previous[x - channels] if x >= channels else 0
                row[x] = (row[x] + _paeth(left, up, up_left)) & 255
        elif filter_type != 0:
            raise ValueError("png filter")
        previous = row
        if channels == 3:
            rgba = bytearray(width * 4)
            for x in range(width):
                rgba[x * 4 : x * 4 + 3] = row[x * 3 : x * 3 + 3]
                rgba[x * 4 + 3] = 255
            row = rgba
        rows.append(bytes(row))
    rows.reverse()
    return width, height, b"".join(rows)


def _texture_from_png(path: str):
    width, height, pixels = _decode_png(path)
    import numpy as np

    values = np.frombuffer(pixels, dtype=np.uint8).astype(np.float32) * (1.0 / 255.0)
    buffer = gpu.types.Buffer("FLOAT", values.size, values)
    return gpu.types.GPUTexture((width, height), format="RGBA8", data=buffer)


def _shot_texture(path: str):
    cache = _HOVER.setdefault("textures", {})
    tex = cache.get(path)
    if tex is not None:
        return tex
    tex = _texture_from_png(path)
    cache[path] = tex
    return tex


def _preload_play(data: dict, index: int) -> None:
    shots = data.get("shots") or []
    if not shots:
        return
    cache = _HOVER.setdefault("textures", {})
    loaded = 0
    count = len(shots)
    for offset in range(10):
        path = shots[(int(index) + offset) % count]
        if path in cache:
            continue
        try:
            cache[path] = _texture_from_png(path)
        except Exception:
            cache[path] = None
        loaded += 1
        if loaded >= 2:
            break


def _stick_clock(data: dict) -> float:
    duration = float(data.get("duration_sec") or data.get("duration") or 0.0)
    if duration <= 0:
        return 0.0
    elapsed = time.perf_counter() - float(_HOVER["pose_tick"])
    return elapsed % duration


def _stick_pose_times(data: dict, poses: list) -> List[float]:
    duration = float(data.get("duration_sec") or data.get("duration") or 0.0)
    times: List[float] = []
    for pose in poses:
        if pose.get("t") is not None:
            times.append(float(pose["t"]))
        else:
            times.append(float(pose.get("frac", 0.0)) * duration)
    return times


def _blender_world_to_stick(world: Vector) -> Vector:
    """Bone points are already Blender (x, y, z). Stage marks use that same space."""
    return Vector((float(world.x), float(world.y), float(world.z)))


def _planned_empty_stick(pos: Tuple[float, float, float]) -> Vector:
    """Glasses slot location in the same space as stick FK."""
    from .scene_stage_empties import larian_timeline_slot_location

    loc = larian_timeline_slot_location(pos, True, True)
    return _blender_world_to_stick(loc)


def _collection_for_gr2_plan(gr2_path: str, plan) -> Optional[object]:
    if bpy is None or plan is None:
        return None
    want_stem = Path(gr2_path).stem.casefold()
    want_scene = ""
    try:
        want_scene = Path(plan.scene_path).resolve().as_posix().casefold()
    except OSError:
        want_scene = str(plan.scene_path or "").replace("\\", "/").casefold()
    exact = None
    scene_hit = None
    for col in bpy.data.collections:
        if not col.get("gr2lab_scene_empties"):
            continue
        anim = str(col.get("gr2lab_scene_anim") or "").casefold()
        scene_file = str(col.get("gr2lab_scene_file") or "").replace("\\", "/").casefold()
        if anim == want_stem:
            exact = col
            break
        if want_scene and scene_file == want_scene:
            scene_hit = col
    return exact or scene_hit


def _object_stick_translation(name: str) -> Optional[Vector]:
    if not name:
        return None
    obj = bpy.data.objects.get(name)
    if obj is None:
        return None
    return _blender_world_to_stick(obj.matrix_world.translation.copy())


def _stick_offsets_from_live_scene(gr2_path: str) -> Tuple[Optional[Vector], Optional[Vector]]:
    """Read placed stage empties from the open file (no scene planning)."""
    if bpy is None:
        return None, None
    want_stem = Path(gr2_path).stem.casefold()
    want_beat = _stick_beat(Path(gr2_path).name).casefold()
    col = None
    beat_col = None
    for candidate in bpy.data.collections:
        if not candidate.get("gr2lab_scene_empties"):
            continue
        anim = str(candidate.get("gr2lab_scene_anim") or "")
        if anim.casefold() == want_stem:
            col = candidate
            break
        if want_beat and _stick_beat(anim).casefold() == want_beat:
            beat_col = candidate
    if col is None:
        col = beat_col
    if col is None:
        return None, None
    by_name: Dict[str, Vector] = {}
    player_from_flag: Optional[Vector] = None
    try:
        objects = col.all_objects
    except AttributeError:
        objects = col.objects
    for obj in objects:
        if obj.type != "EMPTY" or "gr2lab_is_player" not in obj:
            continue
        if obj.hide_viewport:
            continue
        off = _object_stick_translation(obj.name)
        if off is None:
            continue
        by_name[obj.name] = off
        if bool(obj.get("gr2lab_is_player")):
            player_from_flag = off
    player_name = ""
    partner_name = ""
    try:
        from . import scene_stage_empties as sse

        plan = sse._PLAN_CACHE.get(sse._gr2_resolve_key(gr2_path))
        if plan is not None and plan.empties:
            binding = plan.clip_binding
            if binding is not None:
                pe = sse._empty_by_actor(
                    plan.empties, binding.actor_type, binding.actor_index
                )
                if pe is not None:
                    player_name = pe.name
                pa = sse._empty_by_actor(
                    plan.empties,
                    binding.partner_actor_type,
                    binding.partner_actor_index,
                )
                if pa is not None:
                    partner_name = pa.name
                if not partner_name:
                    partner_name = str(
                        sse._partner_empty_name(plan.empties, binding) or ""
                    )
            if not player_name and plan.rig_empty_name:
                player_name = str(plan.rig_empty_name)
    except Exception:
        pass
    player_off = by_name.get(player_name) if player_name else None
    if player_off is None:
        player_off = player_from_flag
    partner_off = by_name.get(partner_name) if partner_name else None
    if partner_off is None and player_off is not None:
        extras = []
        for name, off in by_name.items():
            if name == player_name:
                continue
            slot = bpy.data.objects.get(name)
            if slot is not None and bool(slot.get("gr2lab_is_player")):
                continue
            extras.append((name, off))
        if extras:
            partner_off = min(
                extras, key=lambda item: (item[1] - player_off).length_squared
            )[1]
    if player_off is None and partner_off is None:
        return None, None
    return player_off, partner_off


def _stick_seated_arm_mirror(points: Dict[str, List[float]]) -> Dict[str, List[float]]:
    """Glasses slot seating uses scale -1 on X for each rig."""
    out: Dict[str, List[float]] = {}
    for name, pt in points.items():
        out[name] = [-float(pt[0]), float(pt[1]), float(pt[2])]
    return out


def _stick_offsets_from_plan(gr2_path: str) -> Tuple[Optional[Vector], Optional[Vector]]:
    """Planned empty slots from LSX (may run off the main thread)."""
    path = str(gr2_path or "").strip()
    if not path:
        return None, None
    player_off: Optional[Vector] = None
    partner_off: Optional[Vector] = None
    try:
        from . import scene_stage_empties as sse

        plan = sse.plan_scene_empties(
            path, use_cache=True, allow_timeline_convert=True
        )
    except Exception:
        plan = None
    if plan is not None and plan.empties:
        binding = plan.clip_binding
        player_empty = None
        partner_empty = None
        if binding is not None:
            player_empty = sse._empty_by_actor(
                plan.empties, binding.actor_type, binding.actor_index
            )
            partner_empty = sse._empty_by_actor(
                plan.empties,
                binding.partner_actor_type,
                binding.partner_actor_index,
            )
            if partner_empty is None:
                pname = sse._partner_empty_name(plan.empties, binding)
                if pname:
                    partner_empty = next(
                        (e for e in plan.empties if e.name == pname), None
                    )
        if player_empty is None and plan.rig_empty_name:
            player_empty = next(
                (e for e in plan.empties if e.name == plan.rig_empty_name),
                None,
            )
        if player_empty is None:
            player_empty = next((e for e in plan.empties if e.is_player), None)
        if partner_empty is None and player_empty is not None:
            for item in plan.empties:
                if item is player_empty:
                    continue
                if item.actor_type in {2, 8}:
                    partner_empty = item
                    break
        if player_empty is not None:
            player_off = _planned_empty_stick(player_empty.position)
        if partner_empty is not None:
            partner_off = _planned_empty_stick(partner_empty.position)
    return player_off, partner_off


def _stick_scene_offsets(gr2_path: str) -> Tuple[Optional[Vector], Optional[Vector]]:
    """Cached stage spacing for stick preview. Never blocks on scene planning."""
    path = str(gr2_path or "").strip()
    if not path:
        return None, None
    cached = _STICK_STAGE_OFFSETS.get(path)
    if cached is not None:
        return cached
    live = _stick_offsets_from_live_scene(path)
    if live[0] is not None or live[1] is not None:
        _STICK_STAGE_OFFSETS[path] = live
        return live
    _queue_stick_offsets(path)
    return None, None


_STICK_OFFSET_PENDING: set = set()


def _publish_stick_offsets(path: str, result: Tuple[Optional[Vector], Optional[Vector]]) -> None:
    if path not in _STICK_STAGE_OFFSETS:
        _STICK_STAGE_OFFSETS[path] = result
    _tag()


def _stick_offsets_plan_thread(path: str) -> None:
    try:
        result = _stick_offsets_from_plan(path)
    except Exception:
        traceback.print_exc()
        result = (None, None)

    def publish() -> None:
        _publish_stick_offsets(path, result)
        return None

    try:
        bpy.app.timers.register(publish, first_interval=0.0)
    except Exception:
        _publish_stick_offsets(path, result)


def _queue_stick_offsets(path: str) -> None:
    """Resolve planned empty spacing without blocking hover, draw, or drag."""
    path = str(path or "").strip()
    if not path or path in _STICK_STAGE_OFFSETS or path in _STICK_OFFSET_PENDING:
        return
    _STICK_OFFSET_PENDING.add(path)

    def kick() -> None:
        _STICK_OFFSET_PENDING.discard(path)
        if path in _STICK_STAGE_OFFSETS:
            return None
        live = _stick_offsets_from_live_scene(path)
        if live[0] is not None or live[1] is not None:
            _publish_stick_offsets(path, live)
            return None
        threading.Thread(
            target=_stick_offsets_plan_thread, args=(path,), daemon=True, name="gr2lab-stick-offsets"
        ).start()
        return None

    try:
        bpy.app.timers.register(kick, first_interval=0.0)
    except Exception:
        _STICK_OFFSET_PENDING.discard(path)


def _stick_stage_offsets_for_data(data: dict) -> Tuple[Optional[Vector], Optional[Vector]]:
    path = str(
        data.get("path")
        or _DRAG.get("filepath")
        or _HOVER.get("path")
        or ""
    ).strip()
    if not path:
        return None, None
    cached = _STICK_STAGE_OFFSETS.get(path)
    if cached is not None:
        return cached
    live = _stick_offsets_from_live_scene(path)
    if live[0] is not None or live[1] is not None:
        _STICK_STAGE_OFFSETS[path] = live
        return live
    return None, None


def _stick_apply_stage_offsets(
    points: Dict[str, List[float]],
    player_off: Optional[Vector],
    partner_off: Optional[Vector],
) -> Dict[str, List[float]]:
    points = _stick_seated_arm_mirror(points)
    po = player_off if player_off is not None else Vector((0.0, 0.0, 0.0))
    has_partner = any(str(name).startswith("P:") for name in points)
    if partner_off is not None:
        pao = partner_off
    elif has_partner:
        pao = po + Vector((float(STICK_PARTNER_SHIFT), 0.0, 0.0))
    else:
        pao = po
    out: Dict[str, List[float]] = {}
    for name, pt in points.items():
        base = Vector((float(pt[0]), float(pt[1]), float(pt[2])))
        if str(name).startswith("P:"):
            shifted = base + pao
        else:
            shifted = base + po
        out[name] = [float(shifted.x), float(shifted.y), float(shifted.z)]
    return out


def _stick_points_for_pose(data: dict, pose: dict) -> Dict[str, List[float]]:
    """Granny stick joints, not stage placement. The 3D drop applies the slot."""
    bone_order = data.get("bone_order") or []
    parents = data.get("parents") or {}
    if pose.get("rig") and bone_order:
        from .local_pipeline import stick_blend_poses

        fk = stick_blend_poses(bone_order, parents, pose, pose, 0.0)
        if fk:
            return fk
    return {name: [float(p[0]), float(p[1]), float(p[2])] for name, p in (pose.get("points") or {}).items()}


def _stick_interp_points(data: dict, clock: float) -> Dict[str, List[float]]:
    poses = data.get("poses") or []
    if not poses:
        return {}
    if len(poses) == 1:
        return _stick_points_for_pose(data, poses[0])
    times = data.get("_pose_times")
    if not times or len(times) != len(poses):
        times = _stick_pose_times(data, poses)
    duration = float(data.get("duration_sec") or times[-1] or 0.0)
    if clock <= times[0]:
        return _stick_points_for_pose(data, poses[0])
    if clock >= times[-1] or duration <= 0:
        return _stick_points_for_pose(data, poses[-1])
    index = 0
    lo, hi = 0, len(times) - 2
    while lo <= hi:
        mid = (lo + hi) // 2
        if clock < times[mid]:
            hi = mid - 1
        elif clock > times[mid + 1]:
            lo = mid + 1
        else:
            index = mid
            break
    else:
        index = max(0, min(len(times) - 2, lo))
    start = times[index]
    end = times[index + 1]
    span = end - start
    alpha = 0.0 if span <= 1e-8 else (clock - start) / span
    left_pose = poses[index]
    right_pose = poses[index + 1]
    bone_order = data.get("bone_order") or []
    parents = data.get("parents") or {}
    if bone_order and left_pose.get("rig") and right_pose.get("rig"):
        from .local_pipeline import stick_blend_poses

        fk = stick_blend_poses(bone_order, parents, left_pose, right_pose, alpha)
        if fk:
            return fk
    left = left_pose.get("points") or {}
    right = right_pose.get("points") or {}
    blended: Dict[str, List[float]] = {}
    for name in set(left) | set(right):
        a = left.get(name)
        b = right.get(name)
        if a is None and b is None:
            continue
        if a is None:
            blended[name] = [float(b[0]), float(b[1]), float(b[2])]
        elif b is None:
            blended[name] = [float(a[0]), float(a[1]), float(a[2])]
        else:
            blended[name] = [
                float(a[0]) + (float(b[0]) - float(a[0])) * alpha,
                float(a[1]) + (float(b[1]) - float(a[1])) * alpha,
                float(a[2]) + (float(b[2]) - float(a[2])) * alpha,
            ]
    return blended


def _draw_shot(rect, path: str) -> None:
    if not rect or not path:
        return
    cache = _HOVER.setdefault("textures", {})
    tex = cache.get(path)
    if path not in cache:
        try:
            tex = _texture_from_png(path)
        except Exception:
            tex = None
        cache[path] = tex
    if tex is None:
        return
    x, y, w, h = _fit_aspect_rect(rect)
    shader = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(
        shader,
        "TRI_FAN",
        {
            "pos": ((x, y), (x + w, y), (x + w, y + h), (x, y + h)),
            "texCoord": ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),
        },
    )
    gpu.state.blend_set("ALPHA")
    shader.bind()
    shader.uniform_sampler("image", tex)
    batch.draw(shader)
    gpu.state.blend_set("NONE")


def _stick_world_points(data: dict, points: Dict[str, List[float]]) -> Dict[str, Vector]:
    """Seat hover joints on the stage so a camera can see both bodies."""
    path = str(data.get("path") or "")
    primary = None
    partner = None
    if path:
        try:
            primary, partner = _stick_pair_slot_matrices(path)
        except Exception:
            traceback.print_exc()
    worlds: Dict[str, Vector] = {}
    for name, pt in points.items():
        mat = partner if str(name).startswith("P:") else primary
        if mat is not None:
            worlds[name] = _stick_through_slot(mat, pt)
        else:
            worlds[name] = Vector((float(pt[0]), float(pt[1]), float(pt[2])))
    return worlds


def _look_through(eye: Vector, center: Vector, worlds: Dict[str, Vector]) -> Dict[str, Tuple[float, float]]:
    """Orthographic view from eye toward center. +Y in the view is world up."""
    forward = center - eye
    if forward.length_squared < 1e-8:
        forward = Vector((0.0, -1.0, 0.2))
    forward.normalize()
    up = Vector((0.0, 0.0, 1.0))
    right = forward.cross(up)
    if right.length_squared < 1e-8:
        right = Vector((1.0, 0.0, 0.0))
    right.normalize()
    up = right.cross(forward).normalized()
    view: Dict[str, Tuple[float, float]] = {}
    for name, world in worlds.items():
        rel = world - eye
        if float(rel.dot(forward)) < 0.08:
            continue
        view[name] = (float(rel.dot(right)), float(rel.dot(up)))
    return view


def _project_camera_xy(
    worlds: Dict[str, Vector], cam
) -> Optional[Dict[str, Tuple[float, float]]]:
    """The shot camera when it frames the pair, otherwise that camera aimed at them."""
    if not worlds:
        return None
    try:
        inv = cam.matrix_world.inverted()
    except Exception:
        inv = None
    proj: Dict[str, Tuple[float, float]] = {}
    if inv is not None:
        for name, world in worlds.items():
            loc = inv @ world
            depth = -float(loc.z)
            if depth < 0.08:
                continue
            # Camera-space X/Y, not X/depth. Dividing by depth was a wide lens
            # and stretched the body closer to the camera.
            proj[name] = (float(loc.x), float(loc.y))
    if len(proj) >= max(4, len(worlds) // 3):
        return proj
    center = Vector((0.0, 0.0, 0.0))
    for world in worlds.values():
        center += world
    center /= float(len(worlds))
    eye = cam.matrix_world.translation.copy()
    if (center - eye).length < 0.4:
        eye = center + Vector((0.6, -2.4, 1.1))
    aimed = _look_through(eye, center, worlds)
    if len(aimed) >= max(4, len(worlds) // 3):
        return aimed
    return None


def _project_quarter_xy(worlds: Dict[str, Vector]) -> Dict[str, Tuple[float, float]]:
    """Three-quarter view when the shot camera does not see the pair."""
    forward = Vector((0.55, -1.0, 0.35)).normalized()
    up = Vector((0.0, 0.0, 1.0))
    right = forward.cross(up)
    if right.length_squared < 1e-8:
        right = Vector((1.0, 0.0, 0.0))
    right.normalize()
    up = right.cross(forward).normalized()
    return {
        name: (float(world.dot(right)), float(world.dot(up)))
        for name, world in worlds.items()
    }


def _draw_stick(rect, data, pose_i: int = 0, *, clock: Optional[float] = None) -> None:
    if not rect or not data:
        return
    x, y, w, h = rect
    poses = data.get("poses") or []
    if not poses:
        return
    if clock is not None:
        points = _stick_interp_points(data, clock)
    else:
        pose = poses[int(pose_i) % len(poses)]
        points = _stick_points_for_pose(data, pose)
    if not points:
        return
    worlds = _stick_world_points(data, points)
    cam = bpy.data.objects.get("GR2LAB_Scene_Camera")
    view = None
    if cam is not None and getattr(cam, "type", "") == "CAMERA":
        view = _project_camera_xy(worlds, cam)
    if not view:
        view = _project_quarter_xy(worlds)
    if not view:
        return
    xs = [p[0] for p in view.values()]
    ys = [p[1] for p in view.values()]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    span_x = max(max_x - min_x, 0.05)
    span_y = max(max_y - min_y, 0.05)
    pad = 10.0
    scale = min((w - pad * 2) / span_x, (h - pad * 2) / span_y)
    cx = (min_x + max_x) * 0.5
    cy = (min_y + max_y) * 0.5

    def project(name: str):
        vx, vy = view[name]
        px = x + w * 0.5 + (vx - cx) * scale
        py = y + h * 0.45 + (vy - cy) * scale
        return (px, py)

    player_pairs = []
    partner_pairs = []
    for a, b in data.get("edges") or []:
        if a not in view or b not in view:
            continue
        seg = (project(a), project(b))
        if str(a).startswith("P:") or str(b).startswith("P:"):
            partner_pairs.extend(seg)
        else:
            player_pairs.extend(seg)
    if partner_pairs:
        _lines(player_pairs, (0.45, 0.82, 1.0, 1.0))
        _lines(partner_pairs, (0.98, 0.72, 0.42, 1.0))
    else:
        _lines(player_pairs, (0.93, 0.78, 0.42, 1.0))


def _icon_loop(cx, cy, radius, color, width=1.35, segs=12) -> None:
    pts = []
    for i in range(segs + 1):
        ang = (2.0 * math.pi * i) / segs
        pts.append((cx + math.cos(ang) * radius, cy + math.sin(ang) * radius))
    _polyline_2d(tuple(pts), color, width)


def _draw_chip_icon(name: str, x: float, y: float, w: float, h: float) -> None:
    """Small white glyph centered in a toolbar chip."""
    cx = x + w * 0.5
    cy = y + h * 0.5
    c = (0.94, 0.96, 0.98, 1.0)
    if name == "whole":
        _stroke_rect(cx - 6, cy - 4.5, 12, 9, c, 1.2)
        _polyline_2d(((cx - 2, cy - 1.5), (cx + 3, cy), (cx - 2, cy + 1.5)), c, 1.3)
    elif name == "center":
        _icon_loop(cx, cy, 4.5, c)
        _rect(cx - 0.8, cy - 0.8, 1.6, 1.6, c)
        _rect(cx - 0.6, cy + 4.6, 1.2, 2.4, c)
        _rect(cx - 0.6, cy - 7.0, 1.2, 2.4, c)
        _rect(cx + 4.6, cy - 0.6, 2.4, 1.2, c)
        _rect(cx - 7.0, cy - 0.6, 2.4, 1.2, c)
    elif name == "edit":
        _polyline_2d(((cx - 5, cy - 3.5), (cx + 2.5, cy + 4)), c, 1.6)
        _polyline_2d(((cx + 1.5, cy + 2.2), (cx + 5, cy + 5), (cx + 3.2, cy + 1.2)), c, 1.4)
    elif name == "recent":
        _icon_loop(cx, cy, 5.2, c)
        _polyline_2d(((cx, cy + 0.4), (cx, cy + 3.4)), c, 1.4)
        _polyline_2d(((cx, cy + 0.4), (cx + 2.8, cy - 0.6)), c, 1.4)
    elif name == "camp":
        _polyline_2d(((cx - 6, cy - 4), (cx, cy + 5), (cx + 6, cy - 4)), c, 1.45)
        _rect(cx - 6.5, cy - 5.2, 13, 1.3, c)
    elif name == "rom":
        _polyline_2d(
            (
                (cx, cy - 4.2),
                (cx - 5, cy + 0.6),
                (cx - 3.1, cy + 4.4),
                (cx, cy + 1.3),
                (cx + 3.1, cy + 4.4),
                (cx + 5, cy + 0.6),
                (cx, cy - 4.2),
            ),
            c,
            1.35,
        )
    elif name == "glasses":
        _icon_loop(cx - 3.5, cy, 3.0, c, segs=10)
        _icon_loop(cx + 3.5, cy, 3.0, c, segs=10)
        _rect(cx - 1.0, cy + 0.3, 2.0, 1.3, c)
    elif name == "explorer":
        _stroke_rect(cx - 6, cy - 5, 12, 8, c, 1.25)
        _rect(cx - 6, cy + 1.6, 5.2, 2.2, c)
    elif name == "person":
        _icon_loop(cx, cy + 3.6, 2.15, c, width=1.3, segs=10)
        _polyline_2d(((cx, cy + 1.5), (cx, cy - 1.1)), c, 1.5)
        _polyline_2d(((cx - 4.0, cy + 0.3), (cx + 4.0, cy + 0.3)), c, 1.4)
        _polyline_2d(((cx, cy - 1.1), (cx - 2.5, cy - 5.2)), c, 1.4)
        _polyline_2d(((cx, cy - 1.1), (cx + 2.5, cy - 5.2)), c, 1.4)


def _draw_eye_icon(cx: float, cy: float, color, *, closed: bool) -> None:
    """Open eye, or the same eye with a slash when the preview is hidden."""
    half_w = 6.0
    half_h = 3.3
    upper = []
    lower = []
    steps = 8
    for i in range(steps + 1):
        x = -half_w + (2.0 * half_w * i) / steps
        span = math.sqrt(max(0.0, 1.0 - (x / half_w) ** 2))
        upper.append((cx + x, cy + half_h * span))
        lower.append((cx + x, cy - half_h * span))
    _polyline_2d(tuple(upper), color, 1.35)
    _polyline_2d(tuple(lower), color, 1.35)
    if closed:
        _polyline_2d(
            ((cx - half_w - 0.6, cy - half_h - 0.4), (cx + half_w + 0.6, cy + half_h + 0.4)),
            color,
            1.35,
        )
        return
    _icon_loop(cx, cy, 1.55, color, width=1.2, segs=8)


def _draw_preview_eye(hits, x: float, y: float) -> None:
    size = 22.0
    on = _preview_enabled()
    hot = _pointer_over(x, y, size, size) or _button_pressed("preview_eye")
    if hot:
        bg = (0.22, 0.36, 0.52, 0.96)
    elif on:
        bg = (0.10, 0.14, 0.20, 0.94)
    else:
        bg = (0.12, 0.13, 0.16, 0.94)
    _rect(x, y, size, size, bg)
    _stroke_rect(
        x,
        y,
        size,
        size,
        (0.55, 0.72, 0.92, 1.0) if on or hot else (0.38, 0.42, 0.48, 1.0),
        1.0,
    )
    color = (0.86, 0.92, 1.0, 1.0) if on else (0.62, 0.66, 0.72, 1.0)
    _draw_eye_icon(x + size * 0.5, y + size * 0.5, color, closed=not on)
    hits.append(("preview_eye", x, y, size, size, ""))


_CHIP_TIPS = {
    "center": "Center the holograms on the origin",
    "recent": "Recent clips you opened",
    "explorer": "Open this folder in Explorer",
    "rig": "Rig options for drag and drop",
    "rig_shapes": "Bone widgets. Boxes, hoops, and the IK targets show on the rig.",
    "rig_limbs": "Wrist and ankle IK. The hands and feet follow their targets.",
    "rig_head": "Head look-at IK and the face controls.",
    "rig_tail": "Tail rig for tieflings and dragonborn.",
    "rig_akelka": "Dragonborn use the AkELkA body instead of the stock body.",
    "gallery_load": "Load every GR2 in this list",
    "gallery_add": "Add every GR2 in this list as a playing hologram",
    "act": "Every act, including shared clips. Click to cycle Act 1, Act 2, Act 3.",
    "preview_eye": "Show or hide the clip preview",
}


def _set_notice(text: str) -> None:
    _STATE["notice"] = str(text or "")
    _STATE["notice_until"] = time.time() + 5.0
    _tag()


def _queue_hover_preview(path: str) -> None:
    """Play a cached hologram, or decode sticks in this process. No scene import."""
    path = str(path or "")
    if not path:
        return
    cached = _stick_mem_get(path) or _stick_load_disk(path)
    if cached:
        _HOVER["poses"] = cached
        _HOVER["shown"] = path
        _HOVER["status"] = ""
    else:
        _HOVER["status"] = "…"
        _HOVER["miss_t"] = time.perf_counter()
        if _HOVER.get("stick_proc_path") != path or not _hover_stick_decode_busy():
            _spawn_stick_preview(path, int(_HOVER.get("gen") or 0))
    _ensure_preview_timer()


def _preview_follow(path: str) -> None:
    """Play this clip in the mini viewport. Same clip keeps running."""
    path = str(path or "").strip()
    if not path:
        return
    if path == str(_HOVER.get("path") or ""):
        if _preview_enabled():
            _ensure_preview_timer()
        return
    _HOVER["path"] = path
    _HOVER["since"] = time.time()
    _HOVER["gen"] = int(_HOVER.get("gen") or 0) + 1
    _kill_stick_preview_proc()
    _HOVER["status"] = ""
    _HOVER["shown"] = ""
    _HOVER["poses"] = None
    _PREVIEW["path"] = ""
    _PREVIEW["actors"] = []
    _PREVIEW["slot_path"] = ""
    _queue_hover_preview(path)
    _tag()


def _preview_enabled() -> bool:
    return bool(_STATE.get("preview_on", True))


def _preview_zoom() -> float:
    return max(0.68, min(1.55, float(_STATE.get("preview_zoom") or 1.0)))


def _preview_angles() -> Tuple[float, float]:
    yaw = _PREVIEW_YAW0 + max(-0.85, min(0.85, float(_STATE.get("preview_yaw") or 0.0)))
    pitch = _PREVIEW_PITCH0 + max(-0.40, min(0.45, float(_STATE.get("preview_pitch") or 0.0)))
    return yaw, pitch


def _preview_eye_vector(center: Vector, arm: float) -> Vector:
    yaw, pitch = _preview_angles()
    flat = math.cos(pitch)
    return center + Vector((
        math.sin(yaw) * flat * arm,
        math.cos(yaw) * flat * arm,
        math.sin(pitch) * arm,
    ))


def _toggle_preview() -> None:
    _STATE["preview_on"] = not _preview_enabled()
    if _STATE["preview_on"] and str(_HOVER.get("path") or ""):
        _ensure_preview_timer()
    _tag()


def _preview_orbit_begin(event) -> None:
    _PREVIEW["orbit"] = {
        "wx": float(getattr(event, "mouse_x", 0.0)),
        "wy": float(getattr(event, "mouse_y", 0.0)),
        "yaw": float(_STATE.get("preview_yaw") or 0.0),
        "pitch": float(_STATE.get("preview_pitch") or 0.0),
    }


def _preview_orbit_drag(event) -> None:
    drag = _PREVIEW.get("orbit")
    if not drag:
        return
    dx = float(getattr(event, "mouse_x", 0.0)) - float(drag.get("wx") or 0.0)
    dy = float(getattr(event, "mouse_y", 0.0)) - float(drag.get("wy") or 0.0)
    _STATE["preview_yaw"] = max(-0.85, min(0.85, float(drag.get("yaw") or 0.0) - dx * 0.007))
    _STATE["preview_pitch"] = max(-0.40, min(0.45, float(drag.get("pitch") or 0.0) + dy * 0.007))
    _tag()


def _preview_orbit_event(event) -> bool:
    """Keep a preview-camera drag alive after the pointer leaves the strip."""
    if not _PREVIEW.get("orbit"):
        return False
    if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
        _preview_orbit_drag(event)
        return True
    if event.type == "LEFTMOUSE" and event.value in {"RELEASE", "CLICK"}:
        _PREVIEW["orbit"] = None
        _tag()
        return True
    if event.type == "ESC" and event.value == "PRESS":
        _PREVIEW["orbit"] = None
        _tag()
        return True
    return False


def _gpu_release_to_window(prev_fb, prev_vp) -> None:
    """Hand the window framebuffer back. Binding the preview from a draw
    callback left every other editor painting into that tiny target."""
    if prev_fb is not None:
        try:
            prev_fb.bind()
        except Exception:
            pass
    if prev_vp is not None:
        try:
            x, y, w, h = (int(v) for v in prev_vp)
            if w > 0 and h > 0:
                gpu.state.viewport_set(x, y, w, h)
        except Exception:
            pass
    try:
        gpu.state.scissor_test_set(False)
    except Exception:
        pass
    try:
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(True)
        gpu.state.blend_set("NONE")
        gpu.state.face_culling_set("NONE")
    except Exception:
        pass


def _redraw_every_editor() -> None:
    try:
        windows = list(bpy.context.window_manager.windows)
    except Exception:
        return
    for window in windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            area.tag_redraw()


def _preview_timer() -> Optional[float]:
    if not _ALIVE or not _preview_enabled() or not str(_HOVER.get("path") or ""):
        _PREVIEW["timer"] = False
        return None
    if not _PREVIEW.get("fail"):
        _preview_render_offscreen()
    _redraw_every_editor()
    return 1.0 / 24.0


def _ensure_preview_timer() -> None:
    if _PREVIEW.get("timer"):
        return
    try:
        bpy.app.timers.register(_preview_timer, first_interval=0.04)
    except Exception:
        return
    _PREVIEW["timer"] = True


def _preview_look(eye: Vector, target: Vector) -> Matrix:
    world = Matrix.LocRotScale(
        eye,
        (target - eye).to_track_quat("-Z", "Y"),
        Vector((1.0, 1.0, 1.0)),
    )
    return world.inverted()


def _preview_persp(fovy: float, aspect: float, near: float, far: float) -> Matrix:
    s = 1.0 / math.tan(fovy * 0.5)
    mat = Matrix()
    mat.zero()
    mat[0][0] = s / max(aspect, 0.05)
    mat[1][1] = s
    mat[2][2] = (far + near) / (near - far)
    mat[2][3] = (2.0 * far * near) / (near - far)
    mat[3][2] = -1.0
    return mat


def _preview_offscreen(width: int, height: int):
    width = max(8, int(width))
    height = max(8, int(height))
    off = _PREVIEW.get("off")
    if off is not None and int(_PREVIEW.get("w") or 0) == width and int(_PREVIEW.get("h") or 0) == height:
        return off
    if off is not None:
        try:
            off.free()
        except Exception:
            pass
        _PREVIEW["off"] = None
    off = gpu.types.GPUOffScreen(width, height)
    _PREVIEW["off"] = off
    _PREVIEW["w"] = width
    _PREVIEW["h"] = height
    _PREVIEW["fail"] = False
    return off


def _preview_actor(path: str, shift: float) -> Optional[dict]:
    shell = _gallery_shell(path)
    if not shell or not shell.get("meshes"):
        return None
    bind = _gallery_bind_gpu(shell)
    if not bind:
        return None
    return {
        "path": path,
        "shell": shell,
        "bind": bind,
        "shift": float(shift),
        "ubo": {},
        "bones_tex": None,
        "bones_tex_cols": 0,
    }


_PREVIEW_PLAN_PENDING: set = set()
_PARTNER_STICK_BUSY: set = set()
_PARTNER_STICK_FAIL: set = set()


def _ensure_partner_stick(path: str) -> None:
    """Decode the other body of this beat. The hover worker only reads the hovered file."""
    path = str(path or "")
    if not path or path in _PARTNER_STICK_BUSY or path in _PARTNER_STICK_FAIL:
        return
    if _stick_mem_get(path) or _stick_load_disk(path):
        return
    _PARTNER_STICK_BUSY.add(path)

    def worker(job_path: str = path) -> None:
        try:
            data, err = build_stick_preview_data(
                job_path, quick=True, quiet=True, with_partner=False
            )
        except Exception:
            traceback.print_exc()
            data, err = None, "fail"

        def done() -> None:
            _PARTNER_STICK_BUSY.discard(job_path)
            if data and not err and isinstance(data, dict):
                solo = data.pop("cache_solo", None)
                payload = solo if isinstance(solo, dict) else data
                if payload.get("poses"):
                    _remember_stick(job_path, payload)
            else:
                _PARTNER_STICK_FAIL.add(job_path)
            _tag()
            return None

        try:
            bpy.app.timers.register(done, first_interval=0.0)
        except Exception:
            _PARTNER_STICK_BUSY.discard(job_path)

    threading.Thread(target=worker, daemon=True, name="gr2lab-partner-stick").start()


def _preview_add_partner(path: str, actors: List[dict]) -> List[dict]:
    partner = _stick_partner_from_list(path)
    if not partner:
        return actors
    partner_s = str(partner)
    _ensure_partner_stick(partner_s)
    if any(str(actor.get("path") or "") == partner_s for actor in actors):
        return actors
    other = _preview_actor(partner_s, 0.0)
    if other is None:
        return actors
    actors.append(other)
    _PREVIEW["actors"] = actors
    return actors


def _preview_plan_hit(path: str):
    hit = _stick_plan_cached(path)
    if hit is None or (hit[0] is None and hit[1] is None):
        return None
    return hit


def _queue_preview_plan(path: str) -> None:
    """Stage marks for the hover view. Cinematic plans stay off the draw timer."""
    path = str(path or "").strip()
    if not path:
        return
    folded = path.replace("/", "\\").casefold()
    if "\\_cinematic\\" not in folded:
        _planned_stick_pair(path)
        return
    if path in _PREVIEW_PLAN_PENDING or _preview_plan_hit(path) is not None:
        return
    _PREVIEW_PLAN_PENDING.add(path)

    def work() -> None:
        try:
            _planned_stick_pair(path)
        except Exception:
            traceback.print_exc()

        def done() -> None:
            _PREVIEW_PLAN_PENDING.discard(path)
            if _PREVIEW.get("slot_path") == path:
                _PREVIEW["slot_path"] = ""
            _tag()
            return None

        try:
            bpy.app.timers.register(done, first_interval=0.0)
        except Exception:
            _PREVIEW_PLAN_PENDING.discard(path)

    threading.Thread(target=work, daemon=True, name="gr2lab-preview-slots").start()


def _preview_live_slots(path: str):
    if _PREVIEW.get("slot_path") == path and _PREVIEW.get("slot_live") is not None:
        return _PREVIEW["slot_live"]
    partner_path = _stick_partner_from_list(path)
    primary = _matrix_for_clip(path)
    partner = _matrix_for_clip(str(partner_path)) if partner_path else None
    if partner is None and primary is not None:
        col = _stage_collection_for_clip(path)
        if col is not None:
            for empty in _visible_stage_empties(col):
                mat = _seated_slot_matrix(empty)
                if (mat.translation - primary.translation).length_squared > 1e-4:
                    partner = mat
                    break
    live = (primary, partner)
    _PREVIEW["slot_path"] = path
    _PREVIEW["slot_live"] = live
    return live


def _preview_slot_pair(path: str):
    """(hovered body, other body) on the stage. Same choice as the hologram."""
    path = str(path or "").strip()
    if not path:
        return None, None
    if _browser_center_parent():
        planned = _preview_plan_hit(path)
        if planned is not None:
            return planned
        _queue_preview_plan(path)
        # Empties already in the file can be the bed. The hologram does not use them.
        return None, None
    live = _preview_live_slots(path)
    if live[0] is not None or live[1] is not None:
        return live
    planned = _preview_plan_hit(path)
    if planned is not None:
        return planned
    _queue_preview_plan(path)
    return None, None


def _preview_refresh_models(path: str, actors: List[dict]) -> None:
    primary, other = _preview_slot_pair(path)
    if len(actors) >= 2 and (primary is None or other is None):
        primary, other = None, None
    hovered = str(path)
    for actor in actors:
        partner = str(actor.get("path") or "") != hovered
        mat = other if partner else primary
        if mat is None:
            mat = _hologram_loose_matrix(partner, STICK_PARTNER_SHIFT)
        actor["model"] = mat


def _preview_actors(path: str) -> List[dict]:
    path = str(path or "")
    if not path:
        return []
    actors: Optional[List[dict]] = None
    if _PREVIEW.get("path") == path and _PREVIEW.get("actors"):
        actors = list(_PREVIEW.get("actors") or [])
        if len(actors) < 2:
            actors = _preview_add_partner(path, actors)
    if actors is None:
        actors = []
        primary = _preview_actor(path, 0.0)
        if primary is not None:
            actors.append(primary)
        actors = _preview_add_partner(path, actors)
        _PREVIEW["path"] = path
        _PREVIEW["actors"] = actors
    _preview_refresh_models(path, actors)
    return actors


def _preview_model(shift: float) -> Matrix:
    return Matrix.Translation((float(shift), 0.0, 0.0)) @ _DRAG_RXP


def _preview_world_aabb(actors: List[dict]) -> Tuple[Vector, Vector]:
    lo = Vector((1.0e9, 1.0e9, 1.0e9))
    hi = Vector((-1.0e9, -1.0e9, -1.0e9))
    any_pt = False
    for actor in actors:
        bind = actor.get("bind") or {}
        mn = bind.get("mn")
        mx = bind.get("mx")
        if mn is None or mx is None:
            continue
        model = actor.get("model") or _preview_model(float(actor.get("shift") or 0.0))
        for ix in (0, 1):
            for iy in (0, 1):
                for iz in (0, 1):
                    point = model @ Vector((
                        float(mx[0] if ix else mn[0]),
                        float(mx[1] if iy else mn[1]),
                        float(mx[2] if iz else mn[2]),
                    ))
                    lo.x = min(lo.x, point.x)
                    lo.y = min(lo.y, point.y)
                    lo.z = min(lo.z, point.z)
                    hi.x = max(hi.x, point.x)
                    hi.y = max(hi.y, point.y)
                    hi.z = max(hi.z, point.z)
                    any_pt = True
    if not any_pt:
        return Vector((-0.4, -0.4, 0.0)), Vector((0.4, 0.4, 1.8))
    return lo, hi


def _preview_pose_actor(actor: dict, clock: float) -> None:
    shell = actor.get("shell")
    if not shell:
        return
    path = str(actor.get("path") or "")
    stick = _stick_mem_get(path) or _stick_load_disk(path)
    worlds = _stick_fk_worlds(stick, clock, "") if stick else {}
    mats = _shell_delta_mats(shell, worlds)
    _gallery_item_bone_tex(actor, mats)


_PREVIEW_SKY_TOP = (0.14, 0.16, 0.22, 1.0)
_PREVIEW_SKY_BOTTOM = (0.20, 0.23, 0.30, 1.0)
_PREVIEW_YAW0 = math.atan2(0.38, 1.0)
_PREVIEW_PITCH0 = math.atan2(0.32, math.hypot(0.38, 1.0))
_PREVIEW_ARM = math.sqrt(0.38 * 0.38 + 1.0 + 0.32 * 0.32)


def _preview_theme():
    """Blue preview space. The grid stays in the same family."""
    return (
        _PREVIEW_SKY_TOP,
        _PREVIEW_SKY_BOTTOM,
        (0.40, 0.46, 0.54),
        (0.92, 0.28, 0.30),
        (0.32, 0.78, 0.36),
    )


def _draw_preview_sky() -> None:
    """Fill the offscreen in clip space. The bound buffer is not the region."""
    _top, bottom, _grid, _axis_x, _axis_y = _preview_theme()
    top = _top
    shader = gpu.shader.from_builtin("SMOOTH_COLOR")
    batch = batch_for_shader(
        shader,
        "TRI_FAN",
        {
            "pos": ((-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)),
            "color": (bottom, bottom, top, top),
        },
    )
    saved_p = gpu.matrix.get_projection_matrix()
    saved_v = gpu.matrix.get_model_view_matrix()
    try:
        ident = Matrix.Identity(4)
        gpu.matrix.load_projection_matrix(ident)
        gpu.matrix.load_matrix(ident)
        gpu.state.depth_test_set("NONE")
        gpu.state.blend_set("NONE")
        shader.bind()
        batch.draw(shader)
    finally:
        gpu.matrix.load_projection_matrix(saved_p)
        gpu.matrix.load_matrix(saved_v)


def _draw_preview_pane_bg(x: float, y: float, w: float, h: float) -> None:
    if w <= 0 or h <= 0:
        return
    top, bottom, _grid, _axis_x, _axis_y = _preview_theme()
    shader = gpu.shader.from_builtin("SMOOTH_COLOR")
    batch = batch_for_shader(
        shader,
        "TRI_FAN",
        {
            "pos": ((x, y), (x + w, y), (x + w, y + h), (x, y + h)),
            "color": (bottom, bottom, top, top),
        },
    )
    gpu.state.blend_set("NONE")
    shader.bind()
    batch.draw(shader)


def _preview_grid_fade(dx: float, dy: float, reach: float) -> float:
    dist = math.sqrt(dx * dx + dy * dy) / max(reach, 0.001)
    if dist >= 1.0:
        return 0.0
    fade = 1.0 - dist
    return fade * fade


def _draw_preview_floor(view: Matrix, proj: Matrix, lo: Vector, hi: Vector) -> None:
    """Ground grid that fades out, with the X and Y axes colored like the 3D view."""
    z = float(lo.z)
    cx = (float(lo.x) + float(hi.x)) * 0.5
    cy = (float(lo.y) + float(hi.y)) * 0.5
    body = max(float(hi.x - lo.x), float(hi.y - lo.y), float(hi.z - lo.z), 1.6)
    step = 0.5
    if body > 6.0:
        step = 1.0
    if body > 14.0:
        step = 2.0
    cells = 14
    reach = step * float(cells)
    coords: List[Vector] = []
    colors: List[Tuple[float, float, float, float]] = []
    _top, _bottom, grid, axis_x, axis_y = _preview_theme()
    minor = grid
    major = grid

    def segment(ax: float, ay: float, bx: float, by: float, rgb, strength: float) -> None:
        fa = _preview_grid_fade(ax - cx, ay - cy, reach) * strength
        fb = _preview_grid_fade(bx - cx, by - cy, reach) * strength
        if fa <= 0.02 and fb <= 0.02:
            return
        coords.append(Vector((ax, ay, z)))
        coords.append(Vector((bx, by, z)))
        colors.append((rgb[0], rgb[1], rgb[2], fa))
        colors.append((rgb[0], rgb[1], rgb[2], fb))

    for i in range(-cells, cells + 1):
        if i == 0:
            continue
        x = cx + i * step
        rgb = major if i % 4 == 0 else minor
        strength = 0.72 if i % 4 == 0 else 0.32
        y = cy - reach
        for _j in range(cells * 2):
            y2 = y + step
            segment(x, y, x, y2, rgb, strength)
            y = y2
    for j in range(-cells, cells + 1):
        if j == 0:
            continue
        y = cy + j * step
        rgb = major if j % 4 == 0 else minor
        strength = 0.72 if j % 4 == 0 else 0.32
        x = cx - reach
        for _i in range(cells * 2):
            x2 = x + step
            segment(x, y, x2, y, rgb, strength)
            x = x2
    x = cx - reach
    for _i in range(cells * 2):
        x2 = x + step
        segment(x, cy, x2, cy, axis_x, 0.95)
        x = x2
    y = cy - reach
    for _j in range(cells * 2):
        y2 = y + step
        segment(cx, y, cx, y2, axis_y, 0.95)
        y = y2
    if len(coords) < 2:
        return
    saved_p = gpu.matrix.get_projection_matrix()
    saved_v = gpu.matrix.get_model_view_matrix()
    try:
        gpu.matrix.load_projection_matrix(proj)
        gpu.matrix.load_matrix(view)
        gpu.state.depth_test_set("NONE")
        gpu.state.blend_set("ALPHA")
        shader = gpu.shader.from_builtin("SMOOTH_COLOR")
        shader.bind()
        batch = batch_for_shader(shader, "LINES", {"pos": coords, "color": colors})
        batch.draw(shader)
    finally:
        gpu.matrix.load_projection_matrix(saved_p)
        gpu.matrix.load_matrix(saved_v)


def _blit_preview(off, rect) -> None:
    x, y, w, h = rect
    tex = getattr(off, "texture_color", None)
    if tex is None:
        return
    shader = gpu.shader.from_builtin("IMAGE")
    batch = batch_for_shader(
        shader,
        "TRI_FAN",
        {
            "pos": ((x, y), (x + w, y), (x + w, y + h), (x, y + h)),
            "texCoord": ((0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)),
        },
    )
    gpu.state.blend_set("NONE")
    shader.bind()
    shader.uniform_sampler("image", tex)
    batch.draw(shader)


def _blit_ready_preview(rect, path: str) -> bool:
    """Paste the picture the timer already drew. Never bind an offscreen here."""
    off = _PREVIEW.get("off")
    if off is None or _PREVIEW.get("ready_path") != path:
        return False
    _x, _y, w, h = rect
    if int(_PREVIEW.get("w") or 0) != int(w) or int(_PREVIEW.get("h") or 0) != int(h):
        return False
    try:
        _blit_preview(off, rect)
    except Exception:
        traceback.print_exc()
        return False
    return True


def _preview_render_offscreen() -> None:
    """Draw the hologram between frames, then give the window its framebuffer back."""
    if _PREVIEW.get("fail"):
        return
    path = str(_PREVIEW.get("want_path") or "")
    width = max(0, min(512, int(_PREVIEW.get("want_w") or 0)))
    height = max(0, min(512, int(_PREVIEW.get("want_h") or 0)))
    if not path or width < 8 or height < 8:
        return
    actors = _preview_actors(path)
    if not actors:
        return
    try:
        off = _preview_offscreen(width, height)
    except Exception:
        traceback.print_exc()
        _PREVIEW["fail"] = True
        return
    lo, hi = _preview_world_aabb(actors)
    center = (lo + hi) * 0.5
    span = hi - lo
    radius = max(float(span.x), float(span.y), float(span.z), 0.6) * 0.55
    fovy = math.radians(32.0)
    arm = radius / math.tan(fovy * 0.5) * 0.86 / _preview_zoom() * _PREVIEW_ARM
    # After Rx+90 the face points +Y. Yaw and pitch remember the last drag.
    eye = _preview_eye_vector(center, arm)
    view = _preview_look(eye, center)
    proj = _preview_persp(fovy, width / float(height), max(0.05, arm * 0.06), arm + radius * 8.0)
    now = time.perf_counter()
    saved_p = gpu.matrix.get_projection_matrix()
    saved_v = gpu.matrix.get_model_view_matrix()
    prev_fb = None
    prev_vp = None
    try:
        prev_fb = gpu.state.active_framebuffer_get()
    except Exception:
        prev_fb = None
    try:
        vp = gpu.state.viewport_get()
        prev_vp = (int(vp[0]), int(vp[1]), int(vp[2]), int(vp[3]))
    except Exception:
        prev_vp = None
    try:
        shader = _gallery_skin_shader()
        with off.bind():
            fb = gpu.state.active_framebuffer_get()
            try:
                _top, bottom, _grid, _axis_x, _axis_y = _preview_theme()
                fb.clear(color=bottom, depth=1.0)
            except TypeError:
                fb.clear(color=bottom)
            _draw_preview_sky()
            _draw_preview_floor(view, proj, lo, hi)
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            solid = bool(_STATE.get("holo_mesh"))
            gpu.state.blend_set("NONE" if solid else "ALPHA")
            gpu.state.depth_mask_set(solid)
            gpu.state.face_culling_set("NONE" if solid else "BACK")
            shader.bind()
            for actor in actors:
                stick = _stick_mem_get(str(actor.get("path") or ""))
                duration = float((stick or {}).get("duration_sec") or (stick or {}).get("duration") or 0.0)
                clock = 0.0 if duration <= 0.0 else round((now % duration) * 24.0) / 24.0
                _preview_pose_actor(actor, clock)
                tex = actor.get("bones_tex")
                bind = actor.get("bind")
                if tex is None or not bind:
                    continue
                model = actor.get("model") or _preview_model(float(actor.get("shift") or 0.0))
                mv = view @ model
                tint = (0.98, 0.72, 0.42) if float(actor.get("shift") or 0.0) else (0.45, 0.78, 1.0)
                shader.uniform_float("ModelViewMatrix", mv)
                shader.uniform_float("ModelViewProjectionMatrix", proj @ mv)
                shader.uniform_sampler("bones", tex)
                shader.uniform_block(
                    "gp",
                    _gallery_ubo(
                        actor.setdefault("ubo", {}),
                        1.0,
                        float(bind.get("bones") or 0),
                        0.0,
                        0.0,
                        tint,
                    ),
                )
                bind["batch"].draw(shader)
        _PREVIEW["ready_path"] = path
    except Exception:
        traceback.print_exc()
        _PREVIEW["fail"] = True
    finally:
        _gpu_release_to_window(prev_fb, prev_vp)
        try:
            gpu.matrix.load_projection_matrix(saved_p)
            gpu.matrix.load_matrix(saved_v)
        except Exception:
            pass


def _viewport_corners(x: float, y: float, w: float, h: float) -> None:
    color = (0.45, 0.68, 0.90, 0.95)
    arm = 9.0
    _polyline_2d(((x, y + arm), (x, y), (x + arm, y)), color, 1.25)
    _polyline_2d(((x + w, y + arm), (x + w, y), (x + w - arm, y)), color, 1.25)
    _polyline_2d(((x, y + h - arm), (x, y + h), (x + arm, y + h)), color, 1.25)
    _polyline_2d(((x + w, y + h - arm), (x + w, y + h), (x + w - arm, y + h)), color, 1.25)


def _draw_hover_viewport(font_id: int, rect) -> None:
    x, y, w, h = rect
    path = str(_HOVER.get("path") or "")
    _draw_preview_pane_bg(x, y, w, h)
    view = (x + 1.0, y + 1.0, max(8.0, w - 2.0), max(8.0, h - 2.0))
    vx, vy, vw, vh = view
    _PREVIEW["want_w"] = max(8, int(vw))
    _PREVIEW["want_h"] = max(8, int(vh))
    _PREVIEW["want_path"] = path
    drew = False
    if path and not _PREVIEW.get("fail"):
        drew = _blit_ready_preview(view, path)
    if not drew and path and str(_HOVER.get("status") or "") == "…":
        blf.color(font_id, 0.55, 0.62, 0.70, 1.0)
        blf.position(font_id, vx + 8.0, vy + vh * 0.5, 0.0)
        blf.draw(font_id, "…")
    _viewport_corners(vx, vy, vw, vh)
    _stroke_rect(x + 0.5, y + 0.5, w - 1.0, h - 1.0, (0.34, 0.38, 0.44, 1.0), 1.15)


def _draw() -> None:
    try:
        gpu.state.scissor_test_set(False)
    except Exception:
        pass
    context = bpy.context
    region = getattr(context, "region", None)
    if region is None or getattr(region, "type", "") != "WINDOW":
        return
    area = getattr(context, "area", None)
    if area is None or getattr(area, "type", "") != "VIEW_3D":
        return
    try:
        _draw_gallery_hud()
    except Exception:
        traceback.print_exc()
    if not _browser_on(context):
        _HITS[region.as_pointer()] = []
        _LAYOUTS.pop(region.as_pointer(), None)
        return
    font_id = _font(12)
    width = float(region.width)
    x0 = STRIP_MARGIN_X
    y0 = STRIP_MARGIN_Y
    strip_w = max(240.0, width - STRIP_MARGIN_X * 2.0)
    strip_h = STRIP_HEIGHT
    hits = []
    root = unpacked_root(context)
    data = _load_index()
    ready = root is not None and _index_matches(context, data)
    _LAYOUTS[region.as_pointer()] = {
        "strip": (x0, y0, strip_w, strip_h),
        "scene_box": None,
        "clip_box": None,
        "preview": None,
    }
    _rect(x0, y0, strip_w, strip_h, (0.05, 0.06, 0.07, 0.92))
    _rect(x0, y0 + strip_h - 2.0, strip_w, 2.0, (0.45, 0.72, 0.95, 1.0))
    if not ready:
        message = "Set unpacked data and Prepare library."
        if root is None:
            message = "Set BG3 unpacked data, then Prepare library."
        elif _PREP["running"]:
            message = f"Preparing library… {_PREP['scenes']} scenes"
        elif _PREP["error"]:
            message = _PREP["error"]
        blf.color(font_id, 0.92, 0.94, 0.96, 1.0)
        blf.position(font_id, x0 + 10.0, y0 + 78.0, 0.0)
        blf.draw(font_id, message)
        bx, by, bw, bh = x0 + 10.0, y0 + 36.0, 160.0, 24.0
        _paint_button(bx, by, bw, bh, "prepare", (0.20, 0.36, 0.55, 1.0), on=True)
        blf.position(font_id, bx + 8.0, by + 6.0, 0.0)
        blf.draw(font_id, "Prepare library")
        hits.append(("prepare", bx, by, bw, bh, ""))
        _HITS[region.as_pointer()] = hits
        return

    rows = _filtered(data)
    scene = _selected(rows)
    row_h = 20.0
    top = y0 + strip_h - 28.0
    chip_y = top + 4.0
    cursor_x = x0 + 8.0

    def chip(text, kind, payload, on=False, action=False, icon=""):
        nonlocal cursor_x
        icon = str(icon or "")
        tw = 22.0 if icon else _text_width(font_id, text) + 16.0
        if action:
            bg = (0.16, 0.28, 0.20, 1.0)
        elif on:
            bg = (0.24, 0.42, 0.62, 1.0)
        else:
            bg = (0.14, 0.16, 0.18, 1.0)
        _paint_button(cursor_x, chip_y, tw, 20.0, kind, bg, on=bool(on or action))
        if icon:
            _draw_chip_icon(icon, cursor_x, chip_y, tw, 20.0)
        else:
            blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
            blf.position(font_id, cursor_x + 8.0, chip_y + 4.0, 0.0)
            blf.draw(font_id, text)
        hits.append((kind, cursor_x, chip_y, tw, 20.0, payload))
        cursor_x += tw + 4.0

    chip(_STATE["act"], "act", _STATE["act"], True)
    cursor_x += 8.0
    filter_label = _filter_button_label()
    filter_box = (cursor_x, chip_y, _text_width(font_id, filter_label) + 16.0, 20.0)
    chip(filter_label, "filter", "", bool(_STATE.get("filter_open")) or _filter_active())
    cursor_x += 6.0
    chip("Scene", "whole", "", bool(_STATE.get("whole_scene")))
    chip("", "center", "", bool(_STATE.get("center_parent")), icon="center")
    chip("Edit", "edit", "", bool(_STATE.get("edit_copy")))
    chip("", "recent", "", bool(_STATE.get("show_recent", False)), icon="recent")
    glasses_on = False
    try:
        from .scene_stage_empties import glasses_frame_sync_is_active

        glasses_on = glasses_frame_sync_is_active(bpy.context)
    except Exception:
        glasses_on = False
    chip("Glasses", "glasses", "", glasses_on)
    chip("", "explorer", "", False, icon="explorer")
    search_x = cursor_x
    search_h = 20.0
    clip_entries = _browser_clip_entries(rows)
    searching = bool(_search_tokens(_STATE.get("query") or ""))
    count_label = f"{len(clip_entries)} clips" if searching else f"{len(rows)} scenes"
    count_w = _text_width(font_id, count_label) + 10.0
    mesh_on = bool(_STATE.get("holo_mesh"))
    style_label = "Mesh" if mesh_on else "Holo"
    style_w = _text_width(font_id, style_label) + 16.0
    right_edge = x0 + strip_w - 8.0
    count_x = right_edge - count_w
    style_x = count_x - style_w - 6.0
    rig = _browser_rig_flags(bpy.context)
    mesh_label = {"BODY_CLOTH": "Cloth", "BODY": "Body", "NONE": "None"}[rig["meshes"]]
    rig_open = bool(_STATE.get("rig_open"))
    person_w = 22.0
    if rig_open:
        rig_items, options_w = _rig_bar_items(font_id, rig, mesh_label)
        rig_w = options_w + 4.0 + person_w
    else:
        rig_items, options_w = [], 0.0
        rig_w = person_w
    rig_x = style_x - 10.0 - rig_w
    search_w = max(0.0, rig_x - search_x - 6.0)
    search_focus = bool(_STATE.get("search_focus"))
    query = _STATE.get("query") or ""
    caret = _search_caret_index()
    inner_w = max(40.0, search_w - 16.0)
    caret_px = _text_width(font_id, query[:caret]) if query else 0.0
    scroll = float(_STATE.get("search_scroll") or 0.0)
    if caret_px - scroll > inner_w - 6.0:
        scroll = max(0.0, caret_px - (inner_w - 6.0))
    if caret_px < scroll:
        scroll = caret_px
    if query and _text_width(font_id, query) <= inner_w:
        scroll = 0.0
    _STATE["search_scroll"] = scroll
    placeholder = "Search"
    show_text = query if query else placeholder
    text_color = (0.94, 0.96, 0.98, 1.0) if query else (0.55, 0.58, 0.62, 1.0)
    search_bg = (0.12, 0.14, 0.18, 1.0)
    if search_focus:
        search_bg = (0.16, 0.20, 0.28, 1.0)
    elif _POINTER.get("over_strip"):
        search_bg = (0.14, 0.16, 0.20, 1.0)
    if search_w >= 28.0:
        _rect(search_x, chip_y, search_w, search_h, search_bg)
        if search_focus or query:
            _rect(search_x, chip_y, search_w, 1.5, (0.45, 0.72, 0.95, 1.0))
        elif _pointer_over(search_x, chip_y, search_w, search_h):
            _stroke_rect(search_x, chip_y, search_w, search_h, (0.62, 0.82, 1.0, 1.0), 1.5)
        text_x = search_x + 8.0 - scroll
        visible = show_text
        draw_x = text_x
        if query:
            start = 0
            if scroll > 0.0:
                for index in range(len(query) + 1):
                    if _text_width(font_id, query[:index]) >= scroll:
                        start = max(0, index - 1)
                        break
            rest = query[start:]
            fit = 0
            for count in range(len(rest) + 1):
                if _text_width(font_id, rest[:count]) > inner_w:
                    break
                fit = count
            visible = rest[:fit]
            draw_x = search_x + 8.0 + _text_width(font_id, query[:start]) - scroll
        if search_focus and query and _STATE.get("search_sel"):
            lo, hi = _search_span()
            if hi > lo:
                sel_l = search_x + 8.0 + _text_width(font_id, query[:lo]) - scroll
                sel_r = search_x + 8.0 + _text_width(font_id, query[:hi]) - scroll
                clip_l = search_x + 4.0
                clip_r = search_x + search_w - 4.0
                sel_l = max(sel_l, clip_l)
                sel_r = min(sel_r, clip_r)
                if sel_r > sel_l:
                    _rect(
                        sel_l,
                        chip_y + 2.0,
                        sel_r - sel_l,
                        16.0,
                        (0.22, 0.48, 0.86, 0.85),
                    )
        blf.color(font_id, *text_color[:3], text_color[3])
        blf.position(font_id, draw_x, chip_y + 4.0, 0.0)
        blf.draw(font_id, visible)
        if search_focus and int(time.time() * 2) % 2 == 0:
            caret_x = search_x + 8.0 + caret_px - scroll
            caret_x = max(search_x + 6.0, min(caret_x, search_x + search_w - 4.0))
            _rect(caret_x, chip_y + 4.0, 1.0, 12.0, (0.92, 0.94, 0.96, 1.0))
        hits.append(("search", search_x, chip_y, search_w, search_h, ""))
        _LAYOUTS[region.as_pointer()]["search_box"] = (
            search_x,
            chip_y,
            search_w,
            search_h,
        )
    if style_w >= 28.0 and style_x >= x0:
        style_bg = (0.22, 0.36, 0.28, 1.0) if mesh_on else (0.16, 0.28, 0.42, 1.0)
        _paint_button(style_x, chip_y, style_w, 20.0, "holo_mesh", style_bg, on=True)
        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
        blf.position(font_id, style_x + 8.0, chip_y + 4.0, 0.0)
        blf.draw(font_id, style_label)
        hits.append(("holo_mesh", style_x, chip_y, style_w, 20.0, ""))
    if rig_x >= x0:
        if rig_open:
            _draw_rig_bar(font_id, hits, rig_x, chip_y, rig_items)
        _draw_person_chip(hits, rig_x + (options_w + 4.0 if rig_open else 0.0), chip_y, rig_open)
    blf.color(font_id, 0.70, 0.74, 0.78, 1.0)
    blf.position(font_id, count_x, chip_y + 4.0, 0.0)
    blf.draw(font_id, count_label)

    body_y = y0 + 6.0
    body_h = top - body_y - 4.0
    body_span = strip_w - 12.0
    preview_w = _preview_pane_w(body_span)
    lists_span = _lists_span(strip_w)
    scene_w, clip_w = _pane_pixel_sizes(lists_span)
    scene_x = x0 + 6.0
    clip_x = scene_x + scene_w + 4.0
    preview_x = clip_x + clip_w + (4.0 if preview_w > 1.0 else 0.0)
    _rect(scene_x, body_y, scene_w, body_h, (0.08, 0.09, 0.10, 1.0))
    _rect(clip_x, body_y, clip_w, body_h, (0.08, 0.09, 0.10, 1.0))
    split_scene = (clip_x - 6.0, body_y, 8.0, body_h)
    _LAYOUTS[region.as_pointer()]["scene_box"] = (scene_x, body_y, scene_w, body_h)
    _LAYOUTS[region.as_pointer()]["clip_box"] = (clip_x, body_y, clip_w, body_h)
    _LAYOUTS[region.as_pointer()]["split_scene"] = split_scene
    _LAYOUTS[region.as_pointer()].pop("split_clip", None)
    if preview_w > 1.0:
        _LAYOUTS[region.as_pointer()]["preview"] = (preview_x, body_y, preview_w, body_h)
    else:
        _LAYOUTS[region.as_pointer()]["preview"] = None
    mx = float(_POINTER.get("mx") or -1.0)
    my = float(_POINTER.get("my") or -1.0)
    _split_grip(split_scene, hot=_over_box(split_scene, mx, my))

    visible = max(1, int((body_h - 16.0) // row_h))
    scroll = max(0, min(_STATE["scene_scroll"], max(0, len(rows) - visible)))
    _STATE["scene_scroll"] = scroll
    scene_rows_y = body_y + 16.0
    scene_rows_h = body_h - 16.0
    scene_row_w = scene_w - 12.0
    for i in range(visible):
        index = scroll + i
        if index >= len(rows):
            break
        row = rows[index]
        iy = scene_rows_y + scene_rows_h - row_h * (i + 1)
        selected = scene is not None and row["id"] == scene["id"]
        if selected:
            _rect(scene_x, iy, scene_row_w, row_h, (0.16, 0.28, 0.40, 1.0))
        label = f"{row.get('act') or '—'}  {row.get('name') or ''}"
        blf.color(font_id, 0.95, 0.96, 0.97, 1.0)
        blf.position(font_id, scene_x + 6.0, iy + 4.0, 0.0)
        blf.draw(font_id, _clip_text(font_id, label, scene_row_w - 10.0))
        hits.append(("scene", scene_x, iy, scene_row_w, row_h, row["id"]))
    _paint_vscroll(
        hits,
        region,
        "scene",
        scene_x + scene_w - 9.0,
        scene_rows_y,
        8.0,
        scene_rows_h,
        len(rows),
        visible,
        scroll,
    )
    scene_lo = (scroll + 1) if rows else 0
    scene_hi = min(len(rows), scroll + visible)
    blf.color(font_id, 0.62, 0.68, 0.74, 1.0)
    blf.position(font_id, scene_x + 6.0, body_y + 2.0, 0.0)
    blf.draw(font_id, f"{scene_lo}–{scene_hi} / {len(rows)}")

    clips = clip_entries
    dual_char = False
    if scene is not None and not searching:
        if "_dual" not in scene:
            scene["_dual"] = _scene_dual_char(scene.get("clips") or [])
        dual_char = bool(scene["_dual"])
    recent_items = _recent_clips_for_ui()
    recent_header_h = 14.0 if recent_items else 0.0
    recent_block_h = recent_header_h + row_h * len(recent_items)
    # Own band under the rows. The old 16px strip was shorter than the buttons,
    # so the last row and the scrollbar ate the top of Load all / Add all.
    clip_footer_h = 28.0
    clips_body_h = max(row_h, body_h - recent_block_h - clip_footer_h)
    visible_clips = max(1, int(clips_body_h // row_h))
    clip_scroll = max(0, min(_STATE["clip_scroll"], max(0, len(clips) - visible_clips)))
    _STATE["clip_scroll"] = clip_scroll
    folder = scene.get("dir") if scene else ""
    paths_key = str(_STATE.get("clip_hits_key") or "")
    if paths_key != _STATE.get("clip_paths_key"):
        _STATE["clip_paths"] = [str(entry.get("path") or "") for entry in clips]
        _STATE["clip_paths_key"] = paths_key
    _note_visible_clips(
        str(folder or ""),
        [],
        clip_scroll,
        visible_clips,
        paths=_STATE.get("clip_paths") or [],
    )
    if recent_items:
        top_y = body_y + body_h
        blf.color(font_id, 0.55, 0.60, 0.66, 1.0)
        blf.position(font_id, clip_x + 6.0, top_y - recent_header_h + 2.0, 0.0)
        blf.draw(font_id, "Last used")
        _rect(
            clip_x + 4.0,
            top_y - recent_block_h,
            clip_w - 8.0,
            1.0,
            (0.22, 0.24, 0.28, 1.0),
        )
        for ri, item in enumerate(recent_items):
            full = str(item.get("path") or "")
            if not full:
                continue
            iy = top_y - recent_header_h - row_h * (ri + 1)
            picked = _path_key(full) == _path_key(str(_STATE.get("clip_path") or ""))
            if picked:
                _rect(clip_x, iy, clip_w, row_h, (0.12, 0.34, 0.55, 1.0))
                _rect(clip_x, iy, 3.0, row_h, (0.45, 0.86, 1.0, 1.0))
            elif full == _HOVER["path"]:
                _rect(clip_x, iy, clip_w, row_h, (0.28, 0.24, 0.12, 1.0))
            scene_short = str(item.get("scene") or "")
            label = str(item.get("name") or Path(full).name)
            if scene_short:
                label = f"{_clip_text(font_id, scene_short, clip_w * 0.42)} · {label}"
            blf.color(font_id, 0.82, 0.86, 0.90, 1.0)
            blf.position(font_id, clip_x + 6.0, iy + 4.0, 0.0)
            blf.draw(font_id, _clip_text(font_id, label, clip_w - 12.0))
            hits.append(("recent", clip_x, iy, clip_w, row_h, full))
    clip_base_y = body_y + body_h - recent_block_h
    for i in range(visible_clips):
        index = clip_scroll + i
        if index >= len(clips):
            break
        entry = clips[index]
        name = str(entry.get("name") or "")
        iy = clip_base_y - row_h * (i + 1)
        full = str(entry.get("path") or "")
        picked = bool(full) and _path_key(full) == _path_key(str(_STATE.get("clip_path") or ""))
        if picked:
            _rect(clip_x, iy, clip_w - 12.0, row_h, (0.12, 0.34, 0.55, 1.0))
            _rect(clip_x, iy, 3.0, row_h, (0.45, 0.86, 1.0, 1.0))
        elif full and full == _HOVER["path"]:
            _rect(clip_x, iy, clip_w - 12.0, row_h, (0.28, 0.24, 0.12, 1.0))
        if searching:
            role_label = str(entry.get("scene") or "")
            role_rgb = (0.62, 0.78, 0.95)
        else:
            role_label, role_rgb = _role_clip_colors(name, dual_char)
        tx = clip_x + 6.0
        prefix = f"{role_label}  "
        prefix_w = min(_text_width(font_id, prefix), clip_w * 0.36)
        shown_prefix = _clip_text(font_id, prefix, prefix_w)
        blf.color(font_id, role_rgb[0], role_rgb[1], role_rgb[2], 1.0)
        blf.position(font_id, tx, iy + 4.0, 0.0)
        blf.draw(font_id, shown_prefix)
        tx += _text_width(font_id, shown_prefix)
        blf.color(font_id, 0.94, 0.95, 0.96, 1.0)
        blf.position(font_id, tx, iy + 4.0, 0.0)
        blf.draw(font_id, _clip_text(font_id, name, clip_w - 22.0 - (tx - clip_x - 6.0)))
        hits.append(("clip", clip_x, iy, clip_w - 12.0, row_h, full))
    _paint_vscroll(
        hits,
        region,
        "clip",
        clip_x + clip_w - 9.0,
        body_y + clip_footer_h,
        8.0,
        clips_body_h,
        len(clips),
        visible_clips,
        clip_scroll,
    )
    _rect(clip_x, body_y + clip_footer_h, clip_w, 1.0, (0.18, 0.20, 0.24, 1.0))
    clip_lo = (clip_scroll + 1) if clips else 0
    clip_hi = min(len(clips), clip_scroll + visible_clips)
    count_label = f"{clip_lo}–{clip_hi} / {len(clips)} GR2"
    count_w = clip_w - 16.0
    if clips:
        btn_h = 20.0
        btn_y = body_y + (clip_footer_h - btn_h) * 0.5
        right = clip_x + clip_w - 16.0
        add_label = "Add all"
        load_label = "Load all"
        add_w = max(68.0, _text_width(font_id, add_label) + 16.0)
        load_w = max(72.0, _text_width(font_id, load_label) + 16.0)
        add_x = right - add_w
        load_x = add_x - 4.0 - load_w
        if load_x < clip_x + 4.0:
            room = max(40.0, right - (clip_x + 4.0) - 4.0)
            load_w = min(load_w, room * 0.5)
            add_w = min(add_w, room - load_w)
            add_x = right - add_w
            load_x = add_x - 4.0 - load_w
        for kind, label, bx, bw in (
            ("gallery_load", load_label, load_x, load_w),
            ("gallery_add", add_label, add_x, add_w),
        ):
            _paint_button(bx, btn_y, bw, btn_h, kind, (0.16, 0.20, 0.26, 1.0))
            blf.color(font_id, 0.95, 0.96, 0.98, 1.0)
            blf.position(
                font_id,
                bx + max(4.0, (bw - _text_width(font_id, label)) * 0.5),
                btn_y + 4.0,
                0.0,
            )
            blf.draw(font_id, _clip_text(font_id, label, bw - 8.0))
            hits.append((kind, bx, btn_y, bw, btn_h, ""))
        count_w = max(24.0, load_x - clip_x - 12.0)
    blf.color(font_id, 0.62, 0.68, 0.74, 1.0)
    blf.position(font_id, clip_x + 6.0, body_y + (clip_footer_h - 12.0) * 0.5, 0.0)
    blf.draw(font_id, _clip_text(font_id, count_label, count_w))

    notice = str(_STATE.get("notice") or "")
    hover = str(_POINTER.get("hover_kind") or "")
    tip = _rig_hover_text(hover, rig) if hover else ""
    if hover == "rig" or hover.startswith("rig_"):
        tip = ""
    status = ""
    if notice and time.time() < float(_STATE.get("notice_until") or 0.0):
        status = notice
    elif tip:
        status = tip
    if status:
        blf.color(font_id, 0.75, 0.78, 0.82, 1.0)
        blf.position(font_id, clip_x + 6.0, body_y + body_h - 14.0, 0.0)
        blf.draw(font_id, _clip_text(font_id, status, clip_w - 12.0))
    footer_kinds = {"gallery_add", "gallery_load"}
    chip_hits = [row for row in hits if row[0] in _TOOLBAR_CHIP_KINDS]
    footer_hits = [row for row in hits if row[0] in footer_kinds]
    other_hits = [
        row for row in hits if row[0] not in _TOOLBAR_CHIP_KINDS and row[0] not in footer_kinds
    ]
    hits = other_hits + footer_hits + chip_hits
    preview_box = _LAYOUTS[region.as_pointer()].get("preview")
    eye = 22.0
    if preview_box:
        try:
            _draw_hover_viewport(font_id, preview_box)
        except Exception:
            traceback.print_exc()
        px, py, pw, ph = preview_box
        hits.append(("preview_view", px + 1.0, py + 1.0, max(8.0, pw - 2.0), max(8.0, ph - 2.0), ""))
        eye_x = px + pw - eye - 6.0
        eye_y = py + 6.0
    else:
        eye_x = x0 + strip_w - eye - 8.0
        eye_y = body_y + 4.0
    _draw_preview_eye(hits, eye_x, eye_y)
    _LAYOUTS[region.as_pointer()]["preview_eye"] = (eye_x, eye_y, eye, eye)
    _draw_hover_tip(font_id, hits, region, rig)
    if _STATE.get("filter_open"):
        _draw_filter_menu(font_id, filter_box, hits, y0)
    _HITS[region.as_pointer()] = hits


def _draw_filter_menu(font_id: int, anchor, hits: list, floor_y: float) -> None:
    """Dropdown over the lists. Checks combine: cast, kind, and companion."""
    ax, ay, _aw, _ah = anchor
    row_h = 16.0
    step = 18.0
    width = 268.0
    height = 8.0 + 14.0 + 3 * step + 10.0 + 14.0 + 4 * step + 8.0 + step + 8.0
    x = float(ax)
    top = float(ay) - 4.0
    y = max(float(floor_y) + 2.0, top - height)
    top = y + height
    _rect(x, y, width, height, (0.07, 0.08, 0.10, 0.98))
    _stroke_rect(x, y, width, height, (0.34, 0.50, 0.68, 1.0), 1.2)
    _LAYOUTS[bpy.context.region.as_pointer()]["filter_menu"] = (x, y, width, height)
    left = x + 8.0
    col_w = 118.0
    right = left + col_w + 12.0

    def header(text: str, hx: float, hy: float) -> None:
        blf.color(font_id, 0.55, 0.62, 0.70, 1.0)
        blf.position(font_id, hx, hy + 2.0, 0.0)
        blf.draw(font_id, text)

    def row(text: str, on: bool, hx: float, hy: float, kind: str, payload: str) -> None:
        if on:
            _rect(hx, hy, col_w, row_h, (0.18, 0.32, 0.48, 1.0))
        elif _pointer_over(hx, hy, col_w, row_h):
            _rect(hx, hy, col_w, row_h, (0.14, 0.18, 0.24, 1.0))
        _stroke_rect(hx + 3.0, hy + 3.0, 10.0, 10.0, (0.78, 0.86, 0.94, 1.0), 1.0)
        if on:
            _rect(hx + 5.0, hy + 5.0, 6.0, 6.0, (0.62, 0.84, 1.0, 1.0))
        blf.color(font_id, 0.94, 0.96, 0.98, 1.0)
        blf.position(font_id, hx + 17.0, hy + 2.0, 0.0)
        blf.draw(font_id, text)
        hits.append((kind, hx, hy, col_w, row_h, payload))

    cast = _cast_modes()
    kind_on = _kind_modes()
    who = _who_modes()
    cy = top - 8.0 - 14.0
    header("Cast", left, cy)
    cy -= step
    for bucket, label in (("1", "Solo"), ("2", "Pair"), ("3", "3 or more")):
        row(label, bucket in cast, left, cy, "filter_cast", bucket)
        cy -= step
    cy -= 6.0
    header("Kind", left, cy)
    cy -= step
    for key, label in _FILTER_KINDS:
        row(label, key in kind_on, left, cy, "filter_kind", key)
        cy -= step
    cy -= 4.0
    clear_on = _pointer_over(left, cy, col_w, row_h)
    _rect(left, cy, col_w, row_h, (0.22, 0.16, 0.16, 1.0) if clear_on else (0.16, 0.12, 0.12, 1.0))
    blf.color(font_id, 0.95, 0.86, 0.84, 1.0)
    blf.position(font_id, left + 8.0, cy + 2.0, 0.0)
    blf.draw(font_id, "Clear")
    hits.append(("filter_clear", left, cy, col_w, row_h, ""))

    cy = top - 8.0 - 14.0
    header("With", right, cy)
    cy -= step
    for companion in _COMPANIONS:
        row(companion, companion in who, right, cy, "filter_who", companion)
        cy -= step


def _preview_pane_w(body_span: float) -> float:
    """Fixed mini viewport. Lists keep the rest of the strip."""
    if not _preview_enabled():
        return 0.0
    room = float(body_span) - 420.0
    if room < 148.0:
        return max(0.0, min(148.0, float(body_span) * 0.28))
    return min(PREVIEW_PANE_W, room)


def _lists_span(strip_w: float) -> float:
    body = float(strip_w) - 12.0
    if not _preview_enabled():
        return max(120.0, body - 36.0)
    preview = _preview_pane_w(body)
    if preview <= 1.0:
        return body
    return body - preview - 4.0


def _pane_floors(usable: float) -> Tuple[float, float]:
    """Scene and clip lists cannot collapse. Narrow strips scale the floors."""
    scene, clip = 180.0, 220.0
    need = scene + clip
    if usable >= need:
        return scene, clip
    scale = usable / need
    return scene * scale, clip * scale


def _pane_pixel_sizes(inner: float) -> Tuple[float, float]:
    """Scene list and clip list widths inside the strip body."""
    gaps = 4.0
    usable = max(320.0, float(inner) - gaps)
    min_scene, min_clip = _pane_floors(usable)
    scene = usable * float(_STATE.get("pane_scene") or PANE_SCENE)
    scene = max(min_scene, min(scene, usable - min_clip))
    clip = max(min_clip, usable - scene)
    scene = usable - clip
    return scene, clip


def _vscroll_geom(total: int, visible: int, scroll: int, track_y: float, track_h: float):
    """Thumb box for a bottom-up track. A full thumb means the whole list is on screen."""
    total_n = max(0, int(total))
    visible_n = max(1, int(visible))
    max_scroll = max(0, total_n - visible_n)
    thumb_h = track_h if max_scroll <= 0 else max(16.0, track_h * (visible_n / max(total_n, 1)))
    thumb_h = min(track_h, thumb_h)
    travel = max(0.0, track_h - thumb_h)
    if max_scroll <= 0 or travel <= 0.0:
        thumb_y = track_y
    else:
        used = max(0, min(int(scroll), max_scroll)) / max_scroll
        thumb_y = track_y + travel * (1.0 - used)
    return thumb_y, thumb_h, max_scroll


def _paint_vscroll(hits, region, which: str, x, y, w, h, total: int, visible: int, scroll: int) -> None:
    """Track and thumb. The hit covers the track so a click can jump."""
    _rect(x, y, w, h, (0.07, 0.08, 0.09, 1.0))
    thumb_y, thumb_h, _max_scroll = _vscroll_geom(total, visible, scroll, y, h)
    hot = _pointer_over(x, y, w, h) or _STATE.get("vscroll_drag") == which
    thumb_bg = (0.55, 0.74, 0.95, 1.0) if hot else (0.38, 0.48, 0.60, 1.0)
    _rect(x + 1.0, thumb_y + 1.0, max(2.0, w - 2.0), max(4.0, thumb_h - 2.0), thumb_bg)
    hits.append(("vscroll", x, y, w, h, which))
    layout = _LAYOUTS.get(region.as_pointer()) if region is not None else None
    if layout is not None:
        bars = layout.setdefault("vscroll", {})
        bars[which] = {
            "track": (float(x), float(y), float(w), float(h)),
            "thumb": (float(x), float(thumb_y), float(w), float(thumb_h)),
            "total": int(total),
            "visible": int(visible),
        }


def _vscroll_apply(which: str, my: float, grab: float) -> None:
    """`grab` is the pointer's offset above the bottom of the thumb."""
    info = None
    for layout in _LAYOUTS.values():
        info = (layout.get("vscroll") or {}).get(which)
        if info:
            break
    if not info:
        return
    _x, y, _w, h = info["track"]
    thumb_h = float(info["thumb"][3])
    total = int(info["total"])
    visible = int(info["visible"])
    max_scroll = max(0, total - visible)
    travel = max(1.0, h - thumb_h)
    thumb_y = min(y + travel, max(y, float(my) - float(grab)))
    rel = (y + travel) - thumb_y
    scroll = 0 if max_scroll <= 0 else int(round((rel / travel) * max_scroll))
    key = "scene_scroll" if which == "scene" else "clip_scroll"
    _STATE[key] = max(0, min(max_scroll, scroll))


def _split_grip(box, *, hot: bool) -> None:
    if not box:
        return
    x, y, w, h = box
    gx = x + (w - 2.0) * 0.5
    color = (0.55, 0.74, 0.95, 0.95) if hot else (0.32, 0.36, 0.40, 0.9)
    _rect(gx, y + 4.0, 2.0, max(8.0, h - 8.0), color)


def _split_at(layout, mx, my) -> str:
    if _over_box(layout.get("split_scene"), mx, my):
        return "scene"
    return ""


def _set_pane_from_mouse(which: str, mx: float, region_width: float) -> None:
    strip_w = max(240.0, float(region_width) - STRIP_MARGIN_X * 2.0)
    inner = _lists_span(strip_w)
    gaps = 4.0
    usable = max(320.0, inner - gaps)
    scene_x = STRIP_MARGIN_X + 6.0
    scene_w, clip_w = _pane_pixel_sizes(inner)
    if which == "scene":
        scene_w = float(mx) - scene_x
    min_scene, min_clip = _pane_floors(usable)
    scene_w = max(min_scene, min(scene_w, usable - min_clip))
    clip_w = usable - scene_w
    clip_w = max(min_clip, clip_w)
    scene_w = usable - clip_w
    _STATE["pane_scene"] = scene_w / usable
    _STATE["pane_clip"] = clip_w / usable


def _hit(region, mx, my):
    if region is None:
        return None
    # Exact button pixels. A pad overlaps the next chip, so the outline and the
    # click were landing on different buttons.
    for kind, x, y, w, h, payload in reversed(_HITS.get(region.as_pointer()) or []):
        if x <= mx <= x + w and y <= my <= y + h:
            return kind, payload
    return None


def _track_button_hover(region, mx, my) -> None:
    """Remember the button under the pointer and redraw when it changes.

    Stick preview can be busy. The outline still has to follow every move.
    """
    _POINTER["mx"] = float(mx)
    _POINTER["my"] = float(my)
    _POINTER["over_strip"] = True
    found = _hit(region, mx, my)
    hover_kind = ""
    if found and found[0] in _TOOLBAR_CHIP_KINDS | {"prepare", "search", "gallery_add", "gallery_load", "preview_eye"}:
        if not (found[0] == "recent" and found[1]):
            hover_kind = found[0]
    if hover_kind != (_POINTER.get("hover_kind") or ""):
        _POINTER["hover_kind"] = hover_kind
        _tag()


def _over_box(box, mx, my) -> bool:
    if not box:
        return False
    x, y, w, h = box
    return x <= mx <= x + w and y <= my <= y + h


def strip_box_for_region(region) -> Tuple[float, float, float, float]:
    width = float(getattr(region, "width", 0) or 0)
    strip_w = max(240.0, width - STRIP_MARGIN_X * 2.0)
    return (STRIP_MARGIN_X, STRIP_MARGIN_Y, strip_w, STRIP_HEIGHT)


def refresh_strip_pick_data(context) -> None:
    """Rebuild hit boxes for the active 3D view (same pass as GPU draw)."""
    if not _browser_on(context):
        return
    area = getattr(context, "area", None)
    region = getattr(context, "region", None)
    if area is None or getattr(area, "type", "") != "VIEW_3D":
        return
    if region is None or getattr(region, "type", "") != "WINDOW":
        return
    try:
        _draw()
    except Exception:
        traceback.print_exc()


def pointer_over_strip(region, mx, my) -> bool:
    if region is None or not _browser_on(bpy.context):
        return False
    box = (_LAYOUTS.get(region.as_pointer()) or {}).get("strip")
    if not box:
        return False
    return _over_box(box, float(mx), float(my))


_FORCE_XY: Optional[Tuple[float, float]] = None
_CLICK_STAMP = {"t": 0.0, "xy": (0, 0, "")}


def _event_xy(event) -> Tuple[float, float]:
    if _FORCE_XY is not None:
        return _FORCE_XY
    return float(event.mouse_region_x), float(event.mouse_region_y)


def _region_contains(region, wx: float, wy: float) -> bool:
    w = float(getattr(region, "width", 0) or 0)
    h = float(getattr(region, "height", 0) or 0)
    if w <= 1.0 or h <= 1.0:
        return False
    x = float(region.x)
    y = float(region.y)
    return x <= wx < x + w and y <= wy < y + h


def view3d_under_pointer(context, event):
    """3D View window under the cursor, using window coordinates (not context.region).

    Blender's WINDOW region rectangle also covers the N-panel, the toolbar,
    and the headers. Those regions are drawn on top. A click there belongs
    to that panel, not to the animation strip.
    """
    window = getattr(context, "window", None)
    screen = getattr(window, "screen", None) if window is not None else None
    if screen is None:
        screen = getattr(context, "screen", None)
    if screen is None:
        return None
    wx = float(getattr(event, "mouse_x", 0.0))
    wy = float(getattr(event, "mouse_y", 0.0))
    for area in screen.areas:
        if area.type != "VIEW_3D":
            continue
        window_region = None
        covered = False
        for region in area.regions:
            if not _region_contains(region, wx, wy):
                continue
            if region.type == "WINDOW":
                window_region = region
            else:
                covered = True
        if covered or window_region is None:
            continue
        x = float(window_region.x)
        y = float(window_region.y)
        return area, window_region, wx - x, wy - y
    return None


def _fresh_click(event) -> bool:
    now = time.perf_counter()
    xy = (
        int(getattr(event, "mouse_x", 0)),
        int(getattr(event, "mouse_y", 0)),
        str(getattr(event, "value", "")),
    )
    if now - float(_CLICK_STAMP["t"]) < 0.08 and xy == _CLICK_STAMP["xy"]:
        return False
    _CLICK_STAMP["t"] = now
    _CLICK_STAMP["xy"] = xy
    return True


def modal_strip_event(context, event) -> bool:
    """Handle hover / wheel / click on the strip. True when the event was used."""
    global _FORCE_XY
    if not _browser_on(context):
        return False
    found = view3d_under_pointer(context, event)
    if found is None:
        return False
    area, region, mx, my = found
    if clip_drag_active() and event.type in {"MOUSEMOVE", "LEFTMOUSE"}:
        return False
    over = pointer_over_strip(region, mx, my)
    try:
        from .race_picker import pointer_over_ui

        if pointer_over_ui(region, mx, my):
            return False
    except Exception:
        pass
    if event.type == "MOUSEMOVE":
        if not over:
            if _POINTER.get("hover_kind") or _POINTER.get("mx", -1) >= 0:
                _POINTER["hover_kind"] = ""
                _POINTER["mx"] = -1.0
                _POINTER["my"] = -1.0
                _tag()
            if _preview_enabled() and str(_HOVER.get("path") or ""):
                _ensure_preview_timer()
            return False
        _track_button_hover(region, mx, my)
        if _hover_decode_busy():
            now = time.perf_counter()
            if (now - float(_POINTER.get("strip_mv_t") or 0.0)) < STICK_BUSY_MOVE_INTERVAL:
                return True
            _POINTER["strip_mv_t"] = now
        window = getattr(context, "window", None)
        try:
            with context.temp_override(window=window, area=area, region=region):
                _FORCE_XY = (mx, my)
                _on_move(bpy.context, event)
        except Exception:
            traceback.print_exc()
        finally:
            _FORCE_XY = None
        return True
    if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"} and over:
        window = getattr(context, "window", None)
        try:
            with context.temp_override(window=window, area=area, region=region):
                _FORCE_XY = (mx, my)
                handled = _on_wheel(bpy.context, event) == {"FINISHED"}
        except Exception:
            traceback.print_exc()
            handled = False
        finally:
            _FORCE_XY = None
        return handled
    if event.type == "RIGHTMOUSE" and event.value == "PRESS" and over:
        window = getattr(context, "window", None)
        try:
            with context.temp_override(window=window, area=area, region=region):
                _FORCE_XY = (mx, my)
                refresh_strip_pick_data(bpy.context)
                hit = _hit(region, mx, my)
                if hit is not None and hit[0] == "search":
                    return False
                path = _strip_clip_path_at(region, mx, my) or _active_browser_clip_path()
                if path and _invoke_clip_context_menu(bpy.context, path):
                    return True
        except Exception:
            traceback.print_exc()
        finally:
            _FORCE_XY = None
        return False
    if event.type == "LEFTMOUSE" and event.value == "PRESS" and over:
        if not _fresh_click(event):
            return True
        window = getattr(context, "window", None)
        try:
            with context.temp_override(window=window, area=area, region=region):
                _FORCE_XY = (mx, my)
                refresh_strip_pick_data(bpy.context)
                handle_strip_click(bpy.context, event, mx, my)
        except Exception:
            traceback.print_exc()
        finally:
            _FORCE_XY = None
        return True
    return False


def clip_drag_active() -> bool:
    return bool(_DRAG.get("active"))


def _drop_plane_basis(normal: Vector) -> Tuple[Vector, Vector, Vector]:
    n = normal.normalized() if normal.length_squared > 1e-12 else Vector((0.0, 0.0, 1.0))
    ref = Vector((0.0, 1.0, 0.0))
    if abs(n.dot(ref)) > 0.95:
        ref = Vector((0.0, 0.0, 1.0))
    u = ref.cross(n)
    if u.length_squared < 1e-12:
        u = Vector((1.0, 0.0, 0.0))
    else:
        u.normalize()
    v = n.cross(u).normalized()
    return u, v, n


def _drop_view_ray(context, mx: float, my: float):
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return None, None
    coord = (float(mx), float(my))
    try:
        origin = region_2d_to_origin_3d(region, rv3d, coord)
        direction = region_2d_to_vector_3d(region, rv3d, coord)
    except Exception:
        return None, None
    if direction.length_squared < 1e-12:
        return None, None
    direction.normalize()
    return origin, direction


def _drop_on_plane(origin, direction, plane_co: Vector, plane_no: Vector) -> Optional[Vector]:
    if origin is None or direction is None:
        return None
    hit = intersect_line_plane(origin, origin + direction, plane_co, plane_no)
    if hit is None:
        return None
    return Vector(hit)


def _drop_grid_step(context) -> float:
    step = float(CLIP_DROP_GRID_STEP)
    try:
        ts = context.scene.tool_settings
        if bool(getattr(ts, "use_snap", False)):
            inc = float(getattr(ts, "snap_increment", step) or step)
            if inc > 1e-9:
                step = inc
    except Exception:
        pass
    return step


def _snap_drop_grid(context, point: Vector) -> Vector:
    step = _drop_grid_step(context)
    if step <= 1e-9:
        return point.copy()
    out = point.copy()
    for axis in range(3):
        out[axis] = round(float(out[axis]) / step) * step
    return out


def _drop_plane_hit(
    context,
    mx: float,
    my: float,
    *,
    surface_snap: bool = True,
) -> Tuple[Optional[Vector], Vector]:
    """World point under the cursor (mesh raycast, else ground plane Z=0)."""
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return None, Vector((0.0, 0.0, 1.0))
    coord = (float(mx), float(my))
    try:
        ray_origin = region_2d_to_origin_3d(region, rv3d, coord)
        ray_dir = region_2d_to_vector_3d(region, rv3d, coord)
    except Exception:
        return None, Vector((0.0, 0.0, 1.0))
    if ray_dir.length_squared < 1e-12:
        return None, Vector((0.0, 0.0, 1.0))
    ray_dir.normalize()
    if surface_snap:
        try:
            depsgraph = context.evaluated_depsgraph_get()
            hit, location, normal, _index, _obj, _matrix = context.scene.ray_cast(
                depsgraph, ray_origin, ray_dir, distance=1.0e6
            )
        except Exception:
            hit = False
            location = None
            normal = Vector((0.0, 0.0, 1.0))
        if hit and location is not None:
            if normal.length_squared < 1e-12:
                normal = Vector((0.0, 0.0, 1.0))
            return location.copy(), normal
    plane_loc = intersect_line_plane(
        ray_origin,
        ray_origin + ray_dir,
        Vector((0.0, 0.0, 0.0)),
        Vector((0.0, 0.0, 1.0)),
    )
    if plane_loc is not None:
        return Vector(plane_loc), Vector((0.0, 0.0, 1.0))
    return None, Vector((0.0, 0.0, 1.0))


def _resolve_drop_hit(
    context, mx: float, my: float, *, grid_place: bool
) -> Tuple[Optional[Vector], Vector]:
    if grid_place:
        point, normal = _drop_plane_hit(context, mx, my, surface_snap=False)
        if point is not None:
            point = _snap_drop_grid(context, point)
        return point, Vector((0.0, 0.0, 1.0))
    return _drop_plane_hit(context, mx, my, surface_snap=True)


def _gpu_viewport_size() -> Tuple[float, float]:
    region = getattr(bpy.context, "region", None)
    if region is not None:
        return (float(region.width), float(region.height))
    return (
        float(_DRAG.get("region_w") or 1920.0),
        float(_DRAG.get("region_h") or 1080.0),
    )


def _drop_path_key(filepath: str) -> str:
    try:
        return Path(filepath).resolve().as_posix().casefold()
    except OSError:
        return str(filepath or "").casefold()


def _pending_clip_drop_raw(context=None) -> Optional[dict]:
    """Read pending drop from WM (Blender stores this as IDPropertyGroup, not dict)."""
    ctx = context or bpy.context
    try:
        wm = ctx.window_manager
        raw = wm.get(_WM_CLIP_DROP_KEY)
    except Exception:
        return None
    if raw is None:
        return None
    try:
        path = raw.get("path")
        point = raw.get("point")
    except AttributeError:
        return None
    if not path or point is None:
        return None
    return {
        "path": str(path),
        "point": point,
        "whole": bool(raw.get("whole")),
    }


def _pending_clip_drop_point(raw: dict) -> Optional[Vector]:
    pt = raw.get("point")
    if pt is None:
        return None
    if isinstance(pt, Vector):
        return pt.copy()
    try:
        return Vector((float(pt[0]), float(pt[1]), float(pt[2])))
    except (TypeError, ValueError, IndexError):
        return None


def register_pending_clip_drop(
    filepath: str, point: Vector, context=None, *, whole_scene: bool = False
) -> None:
    payload = {
        "path": _drop_path_key(filepath),
        "point": (float(point.x), float(point.y), float(point.z)),
        "whole": bool(whole_scene),
    }
    try:
        (context or bpy.context).window_manager[_WM_CLIP_DROP_KEY] = payload
    except Exception:
        pass


def clear_pending_clip_drop(context=None) -> None:
    try:
        wm = (context or bpy.context).window_manager
        if _WM_CLIP_DROP_KEY in wm:
            del wm[_WM_CLIP_DROP_KEY]
    except Exception:
        pass


def pending_clip_drop_blocks_scene_place(filepath: str, context=None) -> bool:
    # Center draws the ghost on the stage, so the drop has to place that stage.
    if _browser_center_parent(context):
        return False
    pending = _pending_clip_drop_raw(context)
    if not pending or pending.get("whole"):
        return False
    return pending.get("path") == _drop_path_key(filepath)


def apply_pending_clip_drop(
    context, filepath: str, arm, *, consume: bool = True
) -> bool:
    pending = _pending_clip_drop_raw(context)
    if pending is None or arm is None:
        return False
    if pending.get("path") != _drop_path_key(filepath):
        return False
    point = _pending_clip_drop_point(pending)
    if point is None:
        if consume:
            clear_pending_clip_drop(context)
        return False
    # Whole scene stays on the timeline marks. Center slides that stage to
    # the origin, so a cursor snap would pull the body back off the sticks.
    if not pending.get("whole") and not _browser_center_parent(context):
        _snap_armature_to_drop(arm, point)
    _select_armature(context, arm)
    if consume:
        clear_pending_clip_drop(context)
        anchor = _armature_anchor_world(arm)
        print(
            f"[GR2 LAB] strip drop placed {arm.name} anchor "
            f"({anchor.x:.3f}, {anchor.y:.3f}, {anchor.z:.3f})",
            flush=True,
        )
    return True


def _circle_on_plane(
    center: Vector, u: Vector, v: Vector, radius: float, segments: int
) -> List[Vector]:
    pts: List[Vector] = []
    for i in range(segments + 1):
        t = (i / float(segments)) * (2.0 * math.pi)
        pts.append(center + u * (math.cos(t) * radius) + v * (math.sin(t) * radius))
    return pts


def _drop_plane_point(
    center: Vector, u: Vector, v: Vector, n: Vector, u_off: float, v_off: float
) -> Vector:
    return center + n * CLIP_DROP_LIFT + u * u_off + v * v_off


def _drop_ripple_strips(
    center: Vector,
    u: Vector,
    v: Vector,
    n: Vector,
    now: float,
    *,
    ring_count: Optional[int] = None,
    segments: Optional[int] = None,
) -> List[Tuple[List[Vector], float, float]]:
    """Expanding circular line rings."""
    base = center + n * CLIP_DROP_LIFT
    out: List[Tuple[List[Vector], float, float]] = []
    rings = int(ring_count if ring_count is not None else CLIP_DROP_RIPPLE_COUNT)
    segs = int(segments if segments is not None else CLIP_DROP_RIPPLE_SEGMENTS)
    for i in range(rings):
        phase = (now * CLIP_DROP_RIPPLE_SPEED + i / float(max(1, rings))) % 1.0
        radius = 0.12 + phase * CLIP_DROP_RIPPLE_MAX_R
        alpha = (1.0 - phase) ** 2.1 * CLIP_DROP_RIPPLE_ALPHA_PEAK
        if alpha < 0.02:
            continue
        ring = _circle_on_plane(base, u, v, radius, segs)
        width = CLIP_DROP_LINE_PX * (1.05 - phase * 0.25)
        out.append((ring, alpha, width))
    return out


def _drop_bracket_strips(
    center: Vector, u: Vector, v: Vector, n: Vector
) -> List[List[Vector]]:
    hu = CLIP_DROP_BRACKET_HALF_U
    hv = CLIP_DROP_BRACKET_HALF_V
    arm = CLIP_DROP_BRACKET_ARM
    corners = (
        (-hu, -hv, 1, 1),
        (hu, -hv, -1, 1),
        (hu, hv, -1, -1),
        (-hu, hv, 1, -1),
    )
    strips: List[List[Vector]] = []
    for u0, v0, du, dv in corners:
        p = _drop_plane_point(center, u, v, n, u0, v0)
        strips.append([p, p + u * (du * arm)])
        strips.append([p, p + v * (dv * arm)])
    return strips


def _drop_stake_strip(
    center: Vector, u: Vector, v: Vector, n: Vector
) -> List[Vector]:
    foot = _drop_plane_point(center, u, v, n, 0.0, 0.0)
    return [foot, foot + n * CLIP_DROP_STAKE_HEIGHT]


def _draw_polyline_strips_3d(
    strips: List[List[Vector]],
    color: Tuple[float, float, float, float],
    width_px: float,
    *,
    in_front: bool = False,
) -> None:
    if not strips:
        return
    viewport = _gpu_viewport_size()
    shader = gpu.shader.from_builtin("POLYLINE_UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    try:
        gpu.state.depth_test_set("NONE" if in_front else "LESS_EQUAL")
        gpu.state.depth_mask_set(False)
    except Exception:
        pass
    shader.bind()
    shader.uniform_float("viewportSize", viewport)
    shader.uniform_float("lineWidth", float(width_px))
    shader.uniform_float("color", color)
    for strip in strips:
        if len(strip) < 2:
            continue
        batch = batch_for_shader(
            shader,
            "LINE_STRIP",
            {"pos": [tuple(p) for p in strip]},
        )
        batch.draw(shader)
    try:
        gpu.state.depth_mask_set(True)
        gpu.state.depth_test_set("NONE")
    except Exception:
        pass
    gpu.state.blend_set("NONE")


def _stick_drop_anchor(points: Dict[str, List[float]], prefix: str = "") -> Tuple[float, float, float]:
    for name in ("Dummy_Root", "Root_M", "Root"):
        key = f"{prefix}{name}"
        if key in points:
            pt = points[key]
            return float(pt[0]), float(pt[1]), float(pt[2])
    scoped = {
        name: pt
        for name, pt in points.items()
        if (str(name).startswith(prefix) if prefix else not str(name).startswith("P:"))
    }
    if not scoped:
        return 0.0, 0.0, 0.0
    xs = [float(p[0]) for p in scoped.values()]
    ys = [float(p[1]) for p in scoped.values()]
    zs = [float(p[2]) for p in scoped.values()]
    return (min(xs) + max(xs)) * 0.5, (min(ys) + max(ys)) * 0.5, min(zs)


def _stick_point_on_drop_plane(
    center: Vector,
    u: Vector,
    v: Vector,
    n: Vector,
    local: List[float],
    anchor: Tuple[float, float, float],
) -> Vector:
    lx = float(local[0]) - anchor[0]
    ly = float(local[1]) - anchor[1]
    lz = float(local[2]) - anchor[2]
    return center + u * lx + v * ly + n * (CLIP_DROP_LIFT + lz)


def _drag_preload_arm():
    pre = _DRAG.get("preload")
    if not pre or not pre.get("ready"):
        return None
    return (pre.get("state") or {}).get("arm")


def _drag_follows_real_rig(context) -> bool:
    """True when strip preload has finished and the mesh rig should be visible."""
    pre = _DRAG.get("preload")
    if not pre or not pre.get("ready"):
        return False
    arm = _drag_preload_arm()
    if arm is None:
        return False
    try:
        if arm.hide_viewport:
            return False
    except Exception:
        pass
    point = _DRAG.get("point")
    path = str(pre.get("path") or _DRAG.get("filepath") or "")
    if point is not None and path:
        register_pending_clip_drop(
            path, point, context, whole_scene=_browser_whole_scene(context)
        )
        apply_pending_clip_drop(context, path, arm, consume=False)
    return True


def _drag_stick_data() -> Optional[dict]:
    path = str(_DRAG.get("filepath") or "")
    if not path:
        return None
    held = _DRAG.get("pair")
    if (
        isinstance(held, tuple)
        and len(held) == 2
        and held[0] == path
        and not (held[1] or {}).get("partner_pending")
    ):
        return held[1]
    solo = _stick_mem_get(path) or _stick_load_disk(path)
    if solo is None and _HOVER.get("shown") == path:
        poses = _HOVER.get("poses") or {}
        if poses.get("kind") == "sticks" and poses.get("poses"):
            solo = poses.get("cache_solo") or poses
    if solo is None:
        return None
    if any(str(name).startswith("P:") for name in (solo.get("bone_order") or [])):
        _DRAG["pair"] = (path, solo)
        return solo
    shown = _compose_stick_pair(path, solo, decode=False)
    if shown.get("partner_pending"):
        if not _DRAG.get("partner_fill"):
            _DRAG["partner_fill"] = path
            _spawn_partner_fill(path, int(_HOVER.get("gen") or 0))
    else:
        _DRAG["pair"] = (path, shown)
    return shown


def _drag_stick_clock(data: dict) -> float:
    duration = float(data.get("duration_sec") or data.get("duration") or 0.0)
    if duration <= 0:
        return 0.0
    t0 = float(_DRAG.get("t0") or 0.0)
    if t0 <= 0.0:
        return 0.0
    return (time.perf_counter() - t0) % duration


def _publish_drag_stick(path: str, data: dict) -> None:
    """Hand poses to the drag without writing a short cache over the full one."""
    data = _stick_attach_timing(data)
    data["kind"] = "sticks"
    data["path"] = str(path)
    _remember_stick_mem(path, data)
    _DRAG["pair"] = None


def _spawn_drag_stick(path: str, gen: int) -> None:
    """Unpack the clip once, show the opening poses, then fill the rest.

    The partner body is not decoded here. That used to hold the hologram
    until a second full GR2 finished.
    """
    _kill_stick_preview_proc()
    _HOVER["stick_proc_path"] = path
    _HOVER["stick_proc_gen"] = int(gen)
    _HOVER["stick_pending_gen"] = int(gen)
    holder: Dict[str, threading.Thread] = {}

    def worker(job_path: str = path, job_gen: int = int(gen)) -> None:
        from .local_pipeline import (
            StickPreviewCancelled,
            _stick_from_doc,
            preview_stick_document,
            stick_sample_fractions,
        )

        name = Path(job_path).name
        t0 = time.perf_counter()

        def stale() -> bool:
            return int(_HOVER.get("gen") or 0) != int(job_gen)

        try:
            source = _stick_preview_gr2_path(job_path)
            doc = preview_stick_document(source, should_cancel=stale, quiet=True)
            duration = max(0.0, float(doc.get("duration") or 0.0))
            head_n = 36
            if duration <= 1e-6:
                head_fracs = (0.0,)
                head_end = 0.0
            else:
                step = 1.0 / STICK_HOVER_SAMPLE_FPS
                times = []
                cursor = 0.0
                while len(times) < head_n and cursor <= duration + 1e-6:
                    times.append(cursor)
                    cursor += step
                if len(times) < 2:
                    times = [0.0, min(step, duration)]
                head_end = times[-1]
                head_fracs = tuple(t / duration for t in times)
            head = _stick_from_doc(doc, fractions=head_fracs, should_cancel=stale)
            head["duration"] = head_end
            head["duration_sec"] = head_end
            head["seconds"] = round(time.perf_counter() - t0, 3)
            if not stale():
                _publish_drag_stick(job_path, head)
                print(
                    f"[GR2 LAB drop] hologram playing {name}  "
                    f"first {head_end:.2f}s in {head['seconds']:.2f}s",
                    flush=True,
                )
            full_fracs = stick_sample_fractions(
                duration,
                fps=STICK_HOVER_SAMPLE_FPS,
                max_frames=STICK_HOVER_MAX_FRAMES,
            )
            full = _stick_from_doc(doc, fractions=full_fracs, should_cancel=stale)
            full["duration"] = duration
            full["duration_sec"] = duration
            full["seconds"] = round(time.perf_counter() - t0, 3)
            full["play_fps"] = (
                len(full.get("poses") or []) / duration if duration > 0 else STICK_HOVER_SAMPLE_FPS
            )
            err = ""
        except StickPreviewCancelled:
            full, err = None, ""
        except Exception as exc:
            traceback.print_exc()
            full, err = None, str(exc)

        def finish() -> None:
            if _HOVER.get("stick_decode_thread") is holder.get("thread"):
                _HOVER["stick_decode_thread"] = None
            if int(_HOVER.get("stick_pending_gen") or -1) == job_gen:
                _HOVER["stick_pending_gen"] = -1
            if full and not err and not stale():
                _DRAG["pair"] = None
                _remember_stick(job_path, full)
                _show_pose(job_path, full, f"sticks {full.get('seconds', 0)}s")
                print(
                    f"[GR2 LAB drop] hologram full {name}  "
                    f"{len(full.get('poses') or [])} poses in {full.get('seconds', 0)}s",
                    flush=True,
                )
            _tag()
            return None

        try:
            bpy.app.timers.register(finish, first_interval=0.0)
        except Exception:
            if full and not err and not stale():
                _DRAG["pair"] = None
                _remember_stick(job_path, full)

    thread = threading.Thread(target=worker, name="gr2lab-drag-stick", daemon=True)
    holder["thread"] = thread
    _HOVER["stick_decode_thread"] = thread
    thread.start()


def _ensure_drag_stick_preview(path: str) -> None:
    """Load the clip's bone samples so the drag hologram can play.

    A cache hit returns immediately. A miss decodes in the background and
    puts the opening of the clip on screen before the rest of the samples.
    """
    path = str(path or "")
    if not path:
        return
    if _stick_mem_get(path) or _stick_load_disk(path):
        return
    gen = int(_HOVER.get("gen") or 0)
    if (
        _hover_stick_thread_running()
        and str(_HOVER.get("stick_proc_path") or "") == path
        and int(_HOVER.get("stick_proc_gen") or -1) == gen
    ):
        return
    _HOVER["path"] = path
    _HOVER["since"] = time.time()
    _HOVER["miss_t"] = time.perf_counter()
    print(f"[GR2 LAB drop] decoding stick {Path(path).name}", flush=True)
    _spawn_drag_stick(path, gen)


def _stick_plane_offset(center: Vector, u: Vector, v: Vector, n: Vector, delta: Vector) -> Vector:
    if delta.length_squared < 1e-12:
        return center
    return center + u * delta.dot(u) + v * delta.dot(v) + n * delta.dot(n)


def _stage_collection_for_clip(gr2_path: str, *, allow_beat_match: bool = False):
    """Stage-empty collection for this clip.

    Drag preview only trusts an exact GR2 stem match so a prior drop on the
    same dialog beat (e.g. Short Kiss vs Tall Kiss) cannot steer the sticks.
    """
    if bpy is None:
        return None
    want_stem = Path(gr2_path).stem.casefold()
    want_beat = _stick_beat(Path(gr2_path).name).casefold()
    exact = None
    beat_col = None
    for candidate in bpy.data.collections:
        if not candidate.get("gr2lab_scene_empties"):
            continue
        anim = str(candidate.get("gr2lab_scene_anim") or "")
        if anim.casefold() == want_stem:
            exact = candidate
            break
        if allow_beat_match and want_beat and _stick_beat(anim).casefold() == want_beat:
            beat_col = candidate
    if exact is not None and not _stage_collection_plays(exact, gr2_path):
        exact = None
    if beat_col is not None and not _stage_collection_plays(beat_col, gr2_path):
        beat_col = None
    return exact or (beat_col if allow_beat_match else None)


def _stage_collection_plays(col, gr2_path: str) -> bool:
    """A drop onto the wrong dialog must not steer the next preview."""
    scene_file = str(col.get("gr2lab_scene_file") or "")
    if not scene_file:
        return True
    try:
        from .scene_stage_empties import _scene_supports_gr2

        return bool(_scene_supports_gr2(gr2_path, Path(scene_file)))
    except Exception:
        return True


def _visible_stage_empties(col) -> list:
    try:
        objects = col.all_objects
    except AttributeError:
        objects = col.objects
    found = []
    for obj in objects:
        if obj.type != "EMPTY" or "gr2lab_is_player" not in obj:
            continue
        if obj.hide_viewport:
            continue
        found.append(obj)
    return found


def _seated_slot_matrix(empty) -> Matrix:
    """World matrix of a rig parented by ``_seat_arm``: empty, then scale -1 on X."""
    rig_name = str(empty.get("gr2lab_imported_rig") or "")
    arm = bpy.data.objects.get(rig_name) if rig_name else None
    if arm is not None and arm.type == "ARMATURE" and arm.parent == empty:
        return arm.matrix_world.copy()
    return empty.matrix_world @ Matrix.Diagonal((-1.0, 1.0, 1.0, 1.0))


def _matrix_for_clip(gr2_path: str) -> Optional[Matrix]:
    """Same transform the imported armature uses for this body's slot."""
    if bpy is None or not gr2_path:
        return None
    stem = Path(gr2_path).stem.casefold()
    for arm in bpy.data.objects:
        if arm.type != "ARMATURE" or arm.get("gr2lab_tail_of"):
            continue
        src = str(arm.get("gr2lab_full_source_gr2") or arm.get("gr2lab_source_gr2") or "")
        if not src or Path(src).stem.casefold() != stem:
            continue
        if arm.parent is not None:
            return arm.matrix_world.copy()
    col = _stage_collection_for_clip(gr2_path)
    if col is None:
        return None
    empties = _visible_stage_empties(col)
    role = _role(Path(gr2_path).name)
    if role == "player":
        hit = next((obj for obj in empties if bool(obj.get("gr2lab_is_player"))), None)
        return _seated_slot_matrix(hit) if hit is not None else None
    if role == "partner":
        hit = next((obj for obj in empties if not bool(obj.get("gr2lab_is_player"))), None)
        return _seated_slot_matrix(hit) if hit is not None else None
    return None


_STICK_PLAN_MATS: Dict[str, Tuple[Optional[Matrix], Optional[Matrix]]] = {}


def _planned_stick_pair(gr2_path: str) -> Tuple[Optional[Matrix], Optional[Matrix]]:
    """Stage matrices from the scene plan. No rig has to be in the file."""
    path = str(gr2_path or "").strip()
    if not path:
        return None, None
    center = _browser_center_parent()
    key = f"{path}|{int(center)}"
    cached = _STICK_PLAN_MATS.get(key)
    if cached is not None:
        return cached
    beat = _stick_beat(Path(path).name)
    role = _role(Path(path).name)
    beat_key = f"beat|{beat}|{role}|{int(center)}" if beat else ""
    if beat_key:
        shared = _STICK_PLAN_MATS.get(beat_key)
        if shared is not None:
            _STICK_PLAN_MATS[key] = shared
            return shared
    folded = path.replace("/", "\\").casefold()
    # Gameplay clips are not dialog scenes. Searching for a timeline here
    # blocks the UI for about a tenth of a second per file.
    if "\\_anims\\" in folded and "\\_cinematic\\" not in folded:
        pair = (None, None)
        _STICK_PLAN_MATS[key] = pair
        return pair
    try:
        from .scene_stage_empties import planned_stick_matrices

        pair = planned_stick_matrices(path, center=center)
    except Exception:
        traceback.print_exc()
        pair = (None, None)
    _STICK_PLAN_MATS[key] = pair
    if beat_key and (pair[0] is not None or pair[1] is not None):
        _STICK_PLAN_MATS[beat_key] = pair
    return pair


def _stick_plan_cached(gr2_path: str):
    """Stage pair only when it is already known. Does not build a new plan."""
    path = str(gr2_path or "").strip()
    if not path:
        return None
    center = int(_browser_center_parent())
    key = f"{path}|{center}"
    hit = _STICK_PLAN_MATS.get(key)
    if hit is not None:
        return hit
    beat = _stick_beat(Path(path).name)
    role = _role(Path(path).name)
    beat_key = f"beat|{beat}|{role}|{center}" if beat else ""
    if beat_key and beat_key in _STICK_PLAN_MATS:
        shared = _STICK_PLAN_MATS[beat_key]
        _STICK_PLAN_MATS[key] = shared
        return shared
    return None


def _stick_pair_slot_matrices(gr2_path: str) -> Tuple[Optional[Matrix], Optional[Matrix]]:
    """(dragged body, partner body) on the stage, even before this clip is dropped."""
    path = str(gr2_path or "").strip()
    if not path:
        return None, None
    # Center shows the placement the next drop will use, not the rigs already
    # sitting in the file from an uncentered drop.
    if _browser_center_parent():
        planned = _planned_stick_pair(path)
        if planned[0] is not None or planned[1] is not None:
            return planned
    primary = _matrix_for_clip(path)
    partner_path = _stick_partner_from_list(path)
    partner = _matrix_for_clip(str(partner_path)) if partner_path else None
    if partner is None and primary is not None:
        col = _stage_collection_for_clip(path)
        if col is not None:
            for empty in _visible_stage_empties(col):
                mat = _seated_slot_matrix(empty)
                if (mat.translation - primary.translation).length_squared > 1e-4:
                    partner = mat
                    break
    if primary is not None:
        return primary, partner
    return _planned_stick_pair(path)


def _stick_through_slot(matrix: Matrix, pt: List[float]) -> Vector:
    """Granny stick (x, -z, y) through the seated armature matrix."""
    local = Vector((float(pt[0]), float(pt[2]), -float(pt[1])))
    return matrix @ local


def _stick_drop_edge_strips(
    center: Vector,
    u: Vector,
    v: Vector,
    n: Vector,
    data: dict,
    clock: float,
) -> Tuple[List[List[Vector]], List[List[Vector]]]:
    points = _stick_interp_points(data, clock)
    if not points:
        return [], []
    path = str(data.get("path") or _DRAG.get("filepath") or "").strip()
    primary, partner_mat = _stick_pair_slot_matrices(path)
    on_stage = primary is not None or partner_mat is not None
    player_anchor = (0.0, 0.0, 0.0)
    partner_anchor = (0.0, 0.0, 0.0)
    if not on_stage:
        origin = _stick_interp_points(data, 0.0) or points
        player_anchor = _stick_drop_anchor(origin, "")
        partner_anchor = _stick_drop_anchor(origin, "P:")
    player: List[List[Vector]] = []
    partner: List[List[Vector]] = []
    for a, b in data.get("edges") or []:
        if a not in points or b not in points:
            continue
        is_partner = str(a).startswith("P:") or str(b).startswith("P:")
        if on_stage:
            mat = partner_mat if is_partner else primary
            if mat is None:
                continue
            p0 = _stick_through_slot(mat, points[a])
            p1 = _stick_through_slot(mat, points[b])
        else:
            anchor = partner_anchor if is_partner else player_anchor
            p0 = _stick_point_on_drop_plane(center, u, v, n, points[a], anchor)
            p1 = _stick_point_on_drop_plane(center, u, v, n, points[b], anchor)
        strip = [p0, p1]
        if is_partner:
            partner.append(strip)
        else:
            player.append(strip)
    return player, partner


def _holo_point(center, u, v, n, x: float, y: float, z: float) -> Vector:
    return center + n * (CLIP_DROP_LIFT + z) + u * x + v * y


def _holo_ring(center, u, v, n, z: float, radius: float, segments: int) -> List[Vector]:
    pts: List[Vector] = []
    for i in range(segments + 1):
        t = (i / float(segments)) * (2.0 * math.pi)
        pts.append(
            _holo_point(
                center, u, v, n, math.cos(t) * radius, math.sin(t) * radius, z
            )
        )
    return pts


def _holo_circle_vertical(center, u, v, n, z: float, radius: float, segments: int, axis: int) -> List[Vector]:
    pts: List[Vector] = []
    for i in range(segments + 1):
        t = (i / float(segments)) * (2.0 * math.pi)
        c = math.cos(t) * radius
        s = math.sin(t) * radius
        if axis == 0:
            pts.append(_holo_point(center, u, v, n, c, 0.0, z + s))
        else:
            pts.append(_holo_point(center, u, v, n, 0.0, c, z + s))
    return pts


def _hologram_layers(center, u, v, n, now: float):
    """Wire figure, floor rings, and a scan band. No scene objects."""
    body: List[List[Vector]] = []
    scan: List[List[Vector]] = []
    flicker = 0.72 + 0.28 * math.sin(now * 17.0)
    joints = (
        ((0.0, 0.0, 1.46), (0.0, 0.0, 0.92)),
        ((-0.24, 0.0, 1.38), (0.24, 0.0, 1.38)),
        ((-0.24, 0.0, 1.38), (-0.34, 0.0, 1.05)),
        ((-0.34, 0.0, 1.05), (-0.28, 0.05, 0.76)),
        ((0.24, 0.0, 1.38), (0.34, 0.0, 1.05)),
        ((0.34, 0.0, 1.05), (0.28, 0.05, 0.76)),
        ((-0.13, 0.0, 0.92), (0.13, 0.0, 0.92)),
        ((-0.13, 0.0, 0.92), (-0.15, 0.0, 0.46)),
        ((-0.15, 0.0, 0.46), (-0.13, 0.03, 0.02)),
        ((0.13, 0.0, 0.92), (0.15, 0.0, 0.46)),
        ((0.15, 0.0, 0.46), (0.13, 0.03, 0.02)),
        ((0.0, 0.0, 0.02), (0.0, 0.0, 1.72)),
    )
    for a, b in joints:
        body.append([
            _holo_point(center, u, v, n, *a),
            _holo_point(center, u, v, n, *b),
        ])
    body.append(_holo_circle_vertical(center, u, v, n, 1.58, 0.12, 18, 0))
    body.append(_holo_circle_vertical(center, u, v, n, 1.58, 0.12, 18, 1))
    body.append(_holo_ring(center, u, v, n, 1.22, 0.16, 16))
    body.append(_holo_ring(center, u, v, n, 0.92, 0.13, 14))
    phase = (now * 0.42) % 1.0
    scan_z = 0.04 + phase * 1.68
    scan.append(_holo_ring(center, u, v, n, scan_z, 0.22 + 0.06 * math.sin(phase * math.pi), 28))
    echo = scan_z - 0.08
    if echo > 0.02:
        scan.append(_holo_ring(center, u, v, n, echo, 0.16, 20))
    near: List[List[Vector]] = []
    far: List[List[Vector]] = []
    for i, radius in enumerate((0.28, 0.55)):
        spin = now * (0.35 + i * 0.12)
        segs = 28
        bucket = near if i == 0 else far
        shift = int(spin * segs)
        for s in range(segs):
            if (s + shift) % 9 < 2:
                continue
            t0a = (s / float(segs)) * (2.0 * math.pi)
            t1a = ((s + 1) / float(segs)) * (2.0 * math.pi)
            bucket.append([
                _holo_point(center, u, v, n, math.cos(t0a) * radius, math.sin(t0a) * radius, 0.0),
                _holo_point(center, u, v, n, math.cos(t1a) * radius, math.sin(t1a) * radius, 0.0),
            ])
    floor = ((near, 0.35), (far, 0.18))
    return body, scan, floor, flicker


# Donor mesh verts are moved into armature space with the mesh local matrix
# (GR2LAB bodies are Rx -90). Skinning then uses the bone matrices directly.
# The free-drop plane still speaks stick Z-up, so that path applies Rx +90.
_DRAG_RXP = Matrix.Rotation(math.radians(90.0), 4, "X")
_DRAG_SHELLS: Dict[str, dict] = {}
_DRAG_MESH_SHADER = None


def _clip_base(gr2_path: str) -> Tuple[str, bool]:
    """Body-base family the importer would use, plus whether that base is AkELkA."""
    name = Path(gr2_path or "").name
    if not name:
        return "", False
    detail: Dict[str, object] = {}
    try:
        from rig_catalog import match_body_base_detail  # type: ignore

        raw = match_body_base_detail(name) or {}
        if isinstance(raw, dict):
            detail = raw
    except Exception:
        detail = {}
    matched = str(detail.get("matched") or "")
    family = str(detail.get("rig_family") or "")
    if not family and matched:
        family = Path(matched).stem
        if family.lower().endswith("_base"):
            family = family[: -len("_base")]
    return family.upper(), "AKELKA" in matched.upper()


_MESH_SKIP = {"CLT", "HAIR", "BEARD", "BOOT", "GLOVE", "HOOD", "HAT", "ARMOR", "TAIL"}
_PREVIEW_TRI_BUDGET = 4200
_DRAG_GPU: Dict[str, dict] = {}


def _mesh_for_base(obj_name: str, family: str, akelka: bool) -> bool:
    """True for this body base's own meshes. Clothes and a swapped race stay out."""
    stem = str(obj_name or "").split(".", 1)[0].upper()
    if not family or not (stem == family or stem.startswith(family + "_")):
        return False
    if "AKELKA" in stem and not akelka:
        return False
    if set(stem.split("_")) & _MESH_SKIP:
        return False
    return True


def _preview_ratios(counts: List[int], budget: int = _PREVIEW_TRI_BUDGET) -> List[float]:
    """Share a small triangle budget across the body pieces."""
    total = sum(counts) or 1
    ratios = []
    for count in counts:
        if count < 400:
            ratios.append(1.0)
            continue
        share = max(160, int(budget * count / total))
        ratios.append(min(1.0, share / float(count)))
    return ratios


def _read_preview_arrays(obj, bone_index: Dict[str, int], ratio: float, xform, *, duplicate: bool):
    """Bind-pose surface, collapsed so the ghost is a few thousand triangles."""
    import numpy as np

    source = obj
    temp = None
    evaluated = None
    mesh = obj.data
    reduce = ratio < 0.98 and len(getattr(obj.data, "polygons", [])) >= 400
    try:
        if reduce:
            if duplicate:
                temp = bpy.data.objects.new("_gr2lab_drag_preview", obj.data.copy())
                for group in obj.vertex_groups:
                    temp.vertex_groups.new(name=group.name)
                source = temp
            bpy.context.scene.collection.objects.link(source)
            source.hide_set(True)
            modifier = source.modifiers.new("gr2lab_preview_dec", "DECIMATE")
            modifier.decimate_type = "COLLAPSE"
            modifier.ratio = max(0.05, float(ratio))
            # Cloth kits hide the chest with an invert Mask. The ghost is naked,
            # so that mask must not delete the torso before the decimate.
            for other in source.modifiers:
                if other != modifier:
                    other.show_viewport = False
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated = source.evaluated_get(depsgraph)
            mesh = evaluated.to_mesh()
        mesh.calc_loop_triangles()
        count = len(mesh.vertices)
        tris_n = len(mesh.loop_triangles)
        if count == 0 or tris_n == 0:
            return None
        flat = np.empty(count * 3, dtype=np.float64)
        mesh.vertices.foreach_get("co", flat)
        coords = flat.reshape(-1, 3)
        if xform is not None:
            coords = coords @ xform[:3, :3].T + xform[:3, 3]
        groups = {group.index: group.name for group in source.vertex_groups}
        ids = np.full((count, 4), -1, dtype=np.int16)
        weights = np.zeros((count, 4), dtype=np.float64)
        for vi, vert in enumerate(mesh.vertices):
            ranked = sorted(
                (
                    (groups.get(g.group, ""), float(g.weight))
                    for g in vert.groups
                    if g.weight > 0.0
                ),
                key=lambda item: -item[1],
            )[:4]
            for slot, (name, weight) in enumerate(ranked):
                ids[vi, slot] = bone_index.get(name, -1)
                weights[vi, slot] = weight
        raw = np.empty(tris_n * 3, dtype=np.int32)
        mesh.loop_triangles.foreach_get("vertices", raw)
        return {"co": coords, "ids": ids, "wts": weights, "tris": raw.reshape(-1, 3)}
    finally:
        if evaluated is not None:
            try:
                evaluated.to_mesh_clear()
            except Exception:
                pass
        if temp is not None:
            data = temp.data
            try:
                bpy.data.objects.remove(temp, do_unlink=True)
            except Exception:
                pass
            if data is not None and getattr(data, "users", 1) == 0:
                try:
                    bpy.data.meshes.remove(data)
                except Exception:
                    pass
        elif reduce:
            modifier = source.modifiers.get("gr2lab_preview_dec")
            if modifier is not None:
                try:
                    source.modifiers.remove(modifier)
                except Exception:
                    pass
            try:
                bpy.context.scene.collection.objects.unlink(source)
            except Exception:
                pass


def _finish_preview_shell(names, index, rest, parents, order, meshes) -> dict:
    import numpy as np

    return {
        "names": names,
        "index": index,
        "rest": rest,
        "rest_inv": [np.linalg.inv(mat) for mat in rest],
        "parents": parents,
        "order": order,
        "meshes": meshes,
    }


def _warm_slot_plans() -> Optional[float]:
    """Plan one clip's stage slot per tick so the first drag is not the one that waits."""
    if not _ALIVE or bpy is None:
        return None
    if (
        _GALLERY.get("bulk_decode")
        or _gallery_building()
        or len(_GALLERY.get("items") or []) > 0
    ):
        return 0.35
    if _DRAG.get("active"):
        return 0.2
    paths = list(_STATE.get("clip_paths") or [])
    scroll = max(0, int(_STATE.get("clip_scroll") or 0))
    visible = max(1, int(_STATE.get("clip_visible") or 12))
    paths = paths[scroll : scroll + visible + 4]
    center = int(_browser_center_parent())
    for path in paths:
        beat = _stick_beat(Path(path).name)
        role = _role(Path(path).name)
        beat_key = f"beat|{beat}|{role}|{center}" if beat else ""
        path_key = f"{path}|{center}"
        if path_key in _STICK_PLAN_MATS or (beat_key and beat_key in _STICK_PLAN_MATS):
            continue
        mark = time.perf_counter()
        _planned_stick_pair(path)
        if _GR2LAB_VERBOSE:
            print(
                f"[GR2 LAB drop] slot warm {Path(path).name} "
                f"{(time.perf_counter() - mark) * 1000.0:.0f}ms",
                flush=True,
            )
        return 0.05
    return None


def _warm_preview_caches() -> None:
    """Read every saved body into memory before the first drag."""
    if not _ALIVE or bpy is None:
        return None
    t0 = time.perf_counter()
    try:
        from .rig_display.mesh_kits import load_catalog

        bases = list((load_catalog().get("bases") or {}).keys())
    except Exception:
        traceback.print_exc()
        return None
    ready = 0
    for key in bases:
        text = str(key)
        family = text[: -len("_Base")] if text.endswith("_Base") else text
        if _shell_from_kit(family, quiet=True):
            ready += 1
    print(
        f"[GR2 LAB drop] previews in memory {ready} bodies {time.perf_counter() - t0:.2f}s",
        flush=True,
    )
    return None


def _donor_arm(gr2_path: str):
    """Scene rig whose meshes are this clip's body base. A different race is not a stand-in."""
    if bpy is None or not gr2_path:
        return None
    family, akelka = _clip_base(gr2_path)
    if not family:
        return None

    def body_meshes(arm) -> int:
        count = 0
        for obj in getattr(arm, "children_recursive", []):
            if getattr(obj, "type", "") != "MESH":
                continue
            if len(getattr(obj.data, "polygons", [])) <= 0:
                continue
            if _mesh_for_base(obj.name, family, akelka):
                count += 1
        return count

    best = None
    best_n = 0
    for obj in bpy.data.objects:
        if getattr(obj, "type", "") != "ARMATURE" or obj.get("gr2lab_tail"):
            continue
        try:
            if not obj.visible_get():
                continue
        except Exception:
            pass
        count = body_meshes(obj)
        if count > best_n:
            best = obj
            best_n = count
    return best


def _capture_drag_shell(arm, family: str = "", akelka: bool = False) -> Optional[dict]:
    """Bind-pose verts and weights for this body base. The clip pose is applied later."""
    if arm is None:
        return None
    cache_key = f"{arm.name}|{family}|{int(akelka)}"
    cached = _DRAG_SHELLS.get(cache_key)
    if cached is not None:
        return cached or None
    try:
        import numpy as np
    except Exception:
        _DRAG_SHELLS[cache_key] = {}
        return None
    bones = list(arm.data.bones)
    if not bones:
        _DRAG_SHELLS[cache_key] = {}
        return None
    names = [bone.name for bone in bones]
    index = {name: i for i, name in enumerate(names)}
    rest = [np.array(bone.matrix_local, dtype=np.float64) for bone in bones]
    parents = {bone.name: (bone.parent.name if bone.parent else "") for bone in bones}
    order: List[str] = []
    pending = set(names)
    while pending:
        grew = False
        for name in list(pending):
            parent = parents.get(name) or ""
            if not parent or parent not in pending:
                order.append(name)
                pending.remove(name)
                grew = True
        if not grew:
            order.extend(sorted(pending))
            break
    meshes = []
    picked = []
    for obj in getattr(arm, "children_recursive", []):
        if getattr(obj, "type", "") != "MESH" or getattr(obj, "hide_viewport", False):
            continue
        if family and not _mesh_for_base(obj.name, family, akelka):
            continue
        if len(getattr(obj.data, "polygons", [])) == 0 or len(obj.data.vertices) == 0:
            continue
        picked.append(obj)
    ratios = _preview_ratios([len(obj.data.polygons) for obj in picked])
    for obj, ratio in zip(picked, ratios):
        local = np.array(obj.matrix_local, dtype=np.float64)
        xform = None if np.allclose(local, np.eye(4), atol=1e-5) else local
        surface = _read_preview_arrays(obj, index, ratio, xform, duplicate=True)
        if surface is not None:
            meshes.append(surface)
    if not meshes:
        _DRAG_SHELLS[cache_key] = {}
        return None
    shell = _finish_preview_shell(names, index, rest, parents, order, meshes)
    _DRAG_SHELLS[cache_key] = shell
    return shell


_DRAG_REVEAL_SEC = 0.36


def _drag_mesh_shader():
    global _DRAG_MESH_SHADER
    if _DRAG_MESH_SHADER is not None:
        return _DRAG_MESH_SHADER
    from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo

    iface = GPUStageInterfaceInfo("gr2lab_drag_rim_815")
    iface.smooth("VEC3", "viewPos")
    iface.smooth("VEC3", "localPos")
    info = GPUShaderCreateInfo()
    info.vertex_in(0, "VEC3", "pos")
    info.vertex_in(1, "VEC3", "nrm")
    info.vertex_out(iface)
    info.push_constant("MAT4", "ModelViewProjectionMatrix")
    info.push_constant("MAT4", "ModelViewMatrix")
    info.typedef_source(
        "struct DragParams { float Reveal; float BoneCount; float Hover; float Pulse; };"
    )
    info.uniform_buf(0, "DragParams", "gp")
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(
        "void main() {\n"
        "    vec4 vp = ModelViewMatrix * vec4(pos, 1.0);\n"
        "    viewPos = vp.xyz;\n"
        "    localPos = pos + nrm * 0.0;\n"
        "    gl_Position = ModelViewProjectionMatrix * vec4(pos, 1.0);\n"
        "}\n"
    )
    info.fragment_source(
        "void main() {\n"
        "    vec3 N = normalize(cross(dFdx(viewPos), dFdy(viewPos)));\n"
        "    vec3 V = normalize(-viewPos);\n"
        "    float open = clamp(gp.Reveal, 0.0, 1.0);\n"
        "    if (gp.Pulse > 0.5) {\n"
        "        if (dot(N, V) < 0.0) N = -N;\n"
        "        float lambert = clamp(dot(N, V), 0.0, 1.0);\n"
        "        float lit = 0.42 + 0.58 * lambert;\n"
        "        fragColor = vec4(vec3(0.62, 0.66, 0.72) * lit, 1.0);\n"
        "        return;\n"
        "    }\n"
        "    float ndv = clamp(abs(dot(N, V)), 0.0, 1.0);\n"
        "    float rim = pow(1.0 - ndv, mix(2.2, 1.05, open));\n"
        "    float sweep = smoothstep(0.0, 0.16, open * 2.25 - localPos.y + 0.2);\n"
        "    float edge = smoothstep(0.0, 0.04, sweep) * (1.0 - smoothstep(0.04, 0.22, sweep));\n"
        "    vec3 col = mix(vec3(0.16, 0.38, 0.58), vec3(0.78, 0.94, 1.0), rim);\n"
        "    col = mix(col, vec3(0.92, 0.98, 1.0), clamp(edge * 0.85, 0.0, 1.0));\n"
        "    float alpha = rim * mix(0.35, 0.86, open) * max(sweep, 0.42);\n"
        "    alpha = max(alpha, edge * 0.7);\n"
        "    fragColor = vec4(col, alpha);\n"
        "}\n"
    )
    _DRAG_MESH_SHADER = gpu.shader.create_from_info(info)
    return _DRAG_MESH_SHADER


def _gallery_ubo(store: dict, reveal: float, bone: float, hover: float, pulse: float, tint):
    """Eight floats. The last four are the action-group color."""
    import gpu

    rgb = tint or (0.35, 0.62, 0.95)
    solid = 1.0 if _STATE.get("holo_mesh") else 0.0
    values = (
        float(reveal),
        float(bone),
        float(hover),
        float(pulse),
        float(rgb[0]),
        float(rgb[1]),
        float(rgb[2]),
        solid,
    )
    buf = store.get("buf")
    ubo = store.get("ubo")
    if ubo is None or buf is None or len(buf) != 8:
        buf = gpu.types.Buffer("FLOAT", 8, values)
        ubo = gpu.types.GPUUniformBuf(buf)
        store["buf"] = buf
        store["ubo"] = ubo
        return ubo
    for i, value in enumerate(values):
        buf[i] = value
    ubo.update(buf)
    return ubo


def _ubo_float4(store: dict, reveal: float, bone: float, hover: float, pulse: float):
    """Four floats in a uniform buffer. Push constants stop at the two matrices."""
    import gpu

    values = (float(reveal), float(bone), float(hover), float(pulse))
    buf = store.get("buf")
    ubo = store.get("ubo")
    if ubo is None or buf is None:
        buf = gpu.types.Buffer("FLOAT", 4, values)
        ubo = gpu.types.GPUUniformBuf(buf)
        store["buf"] = buf
        store["ubo"] = ubo
        return ubo
    buf[0] = values[0]
    buf[1] = values[1]
    buf[2] = values[2]
    buf[3] = values[3]
    ubo.update(buf)
    return ubo


_DRAG_UBO: Dict[str, object] = {}
_GALLERY_SHADER = None


def _gallery_skin_shader():
    """Same fresnel as the drag hologram. Bones are applied in the vertex shader."""
    global _GALLERY_SHADER
    if _GALLERY_SHADER is not None:
        return _GALLERY_SHADER
    from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo

    iface = GPUStageInterfaceInfo("gr2lab_gallery_skin_804")
    iface.smooth("VEC3", "viewPos")
    iface.smooth("VEC3", "localPos")
    info = GPUShaderCreateInfo()
    info.vertex_in(0, "VEC3", "pos")
    info.vertex_in(1, "VEC4", "bids")
    info.vertex_in(2, "VEC4", "bwgt")
    info.vertex_out(iface)
    info.push_constant("MAT4", "ModelViewProjectionMatrix")
    info.push_constant("MAT4", "ModelViewMatrix")
    info.typedef_source(
        "struct GalleryParams { float Reveal; float BoneCount; float Hover; float Pulse; float TintR; float TintG; float TintB; float Pad; };"
    )
    info.uniform_buf(0, "GalleryParams", "gp")
    info.sampler(0, "FLOAT_2D", "bones")
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(
        "vec3 galleryBone(int id, vec3 rest) {\n"
        "    int base = id * 4;\n"
        "    mat4 m = mat4(\n"
        "        texelFetch(bones, ivec2(base, 0), 0),\n"
        "        texelFetch(bones, ivec2(base + 1, 0), 0),\n"
        "        texelFetch(bones, ivec2(base + 2, 0), 0),\n"
        "        texelFetch(bones, ivec2(base + 3, 0), 0));\n"
        "    return (m * vec4(rest, 1.0)).xyz;\n"
        "}\n"
        "void main() {\n"
        "    vec3 acc = vec3(0.0);\n"
        "    float sum = 0.0;\n"
        "    int id0 = int(bids.x);\n"
        "    if (id0 >= 0 && bwgt.x > 0.0 && float(id0) < gp.BoneCount) {\n"
        "        acc += galleryBone(id0, pos) * bwgt.x;\n"
        "        sum += bwgt.x;\n"
        "    }\n"
        "    int id1 = int(bids.y);\n"
        "    if (id1 >= 0 && bwgt.y > 0.0 && float(id1) < gp.BoneCount) {\n"
        "        acc += galleryBone(id1, pos) * bwgt.y;\n"
        "        sum += bwgt.y;\n"
        "    }\n"
        "    int id2 = int(bids.z);\n"
        "    if (id2 >= 0 && bwgt.z > 0.0 && float(id2) < gp.BoneCount) {\n"
        "        acc += galleryBone(id2, pos) * bwgt.z;\n"
        "        sum += bwgt.z;\n"
        "    }\n"
        "    int id3 = int(bids.w);\n"
        "    if (id3 >= 0 && bwgt.w > 0.0 && float(id3) < gp.BoneCount) {\n"
        "        acc += galleryBone(id3, pos) * bwgt.w;\n"
        "        sum += bwgt.w;\n"
        "    }\n"
        "    vec3 p = sum < 1e-6 ? pos : acc;\n"
        "    vec4 vp = ModelViewMatrix * vec4(p, 1.0);\n"
        "    viewPos = vp.xyz;\n"
        "    localPos = p;\n"
        "    gl_Position = ModelViewProjectionMatrix * vec4(p, 1.0);\n"
        "}\n"
    )
    info.fragment_source(
        "void main() {\n"
        "    vec3 N = normalize(cross(dFdx(viewPos), dFdy(viewPos)));\n"
        "    vec3 V = normalize(-viewPos);\n"
        "    if (gp.Pad > 0.5) {\n"
        "        if (dot(N, V) < 0.0) N = -N;\n"
        "        float lambert = clamp(dot(N, V), 0.0, 1.0);\n"
        "        float lit = 0.42 + 0.58 * lambert;\n"
        "        vec3 base = max(vec3(gp.TintR, gp.TintG, gp.TintB), vec3(0.55, 0.58, 0.62));\n"
        "        float hot = clamp(gp.Hover, 0.0, 1.0);\n"
        "        vec3 col = base * lit;\n"
        "        col = mix(col, vec3(1.0, 0.82, 0.45), hot * 0.45);\n"
        "        fragColor = vec4(col, 1.0);\n"
        "        return;\n"
        "    }\n"
        "    float ndv = clamp(abs(dot(N, V)), 0.0, 1.0);\n"
        "    float open = clamp(gp.Reveal, 0.0, 1.0);\n"
        "    float rim = pow(1.0 - ndv, mix(2.2, 1.05, open));\n"
        "    float sweep = smoothstep(0.0, 0.16, open * 2.25 - localPos.y + 0.2);\n"
        "    float edge = smoothstep(0.0, 0.04, sweep) * (1.0 - smoothstep(0.04, 0.22, sweep));\n"
        "    float hot = clamp(gp.Hover, 0.0, 1.0);\n"
        "    float pulse = clamp(gp.Pulse, 0.0, 1.0);\n"
        "    float warm = hot * mix(0.92, 1.0, pulse);\n"
        "    vec3 tint = max(vec3(gp.TintR, gp.TintG, gp.TintB), vec3(0.0));\n"
        "    vec3 coolLo = mix(vec3(0.12, 0.22, 0.34), tint, 0.72);\n"
        "    vec3 coolHi = mix(vec3(0.78, 0.94, 1.0), tint, 0.55);\n"
        "    vec3 warmLo = vec3(0.42, 0.24, 0.10);\n"
        "    vec3 warmHi = vec3(0.98, 0.72, 0.42);\n"
        "    vec3 col = mix(mix(coolLo, warmLo, warm), mix(coolHi, warmHi, warm), rim);\n"
        "    vec3 sweepTint = mix(vec3(0.92, 0.98, 1.0), vec3(1.0, 0.88, 0.62), warm);\n"
        "    col = mix(col, sweepTint, clamp(edge * 0.85, 0.0, 1.0));\n"
        "    float alpha = rim * mix(0.35, 0.86, open) * max(sweep, 0.42);\n"
        "    alpha = max(alpha, edge * 0.7);\n"
        "    float grazing = 1.0 - ndv;\n"
        "    float stroke = smoothstep(0.82, 0.96, grazing) * max(warm, 0.35);\n"
        "    col = mix(col, mix(tint, vec3(0.92, 0.96, 1.0), 0.35), stroke * mix(0.40, 0.55, warm));\n"
        "    alpha = max(alpha, stroke * sweep);\n"
        "    fragColor = vec4(col, alpha);\n"
        "}\n"
    )
    _GALLERY_SHADER = gpu.shader.create_from_info(info)
    return _GALLERY_SHADER


def _stick_pose_pair(data: dict, clock: float):
    poses = data.get("poses") or []
    if not poses:
        return None, None, 0.0
    if len(poses) == 1:
        return poses[0], poses[0], 0.0
    times = data.get("_pose_times")
    if not times or len(times) != len(poses):
        times = _stick_pose_times(data, poses)
    if clock <= times[0]:
        return poses[0], poses[0], 0.0
    if clock >= times[-1]:
        return poses[-1], poses[-1], 0.0
    index = 0
    lo, hi = 0, len(times) - 2
    while lo <= hi:
        mid = (lo + hi) // 2
        if clock < times[mid]:
            hi = mid - 1
        elif clock > times[mid + 1]:
            lo = mid + 1
        else:
            index = mid
            break
    else:
        index = max(0, min(len(times) - 2, lo))
    start = times[index]
    end = times[index + 1]
    span = end - start
    alpha = 0.0 if span <= 1e-8 else (clock - start) / span
    return poses[index], poses[index + 1], alpha


def _stick_fk_worlds(data: dict, clock: float, prefix: str) -> Dict[str, object]:
    """Granny bone worlds for this clip pose. Prefix 'P:' is the partner."""
    import numpy as np
    from mathutils import Quaternion

    left, right, alpha = _stick_pose_pair(data, clock)
    if left is None:
        return {}
    rig_a = left.get("rig") or {}
    rig_b = right.get("rig") or {}
    if not rig_a or not rig_b:
        return {}
    order = []
    for name in data.get("bone_order") or []:
        text = str(name)
        if prefix:
            if text.startswith(prefix):
                order.append(text)
        elif not text.startswith("P:"):
            order.append(text)
    parents = data.get("parents") or {}
    u = max(0.0, min(1.0, float(alpha)))
    worlds: Dict[str, Matrix] = {}
    out: Dict[str, object] = {}
    for name in order:
        ra = rig_a.get(name)
        rb = rig_b.get(name)
        if not ra or not rb:
            continue
        p0, p1 = ra["p"], rb["p"]
        pos = Vector((
            float(p0[0]) + (float(p1[0]) - float(p0[0])) * u,
            float(p0[1]) + (float(p1[1]) - float(p0[1])) * u,
            float(p0[2]) + (float(p1[2]) - float(p0[2])) * u,
        ))
        q0, q1 = ra["q"], rb["q"]
        qa = Quaternion((float(q0[3]), float(q0[0]), float(q0[1]), float(q0[2])))
        qb = Quaternion((float(q1[3]), float(q1[0]), float(q1[1]), float(q1[2])))
        local = Matrix.LocRotScale(pos, qa.slerp(qb, u), Vector((1.0, 1.0, 1.0)))
        parent = str(parents.get(name) or "")
        world = (worlds[parent] @ local) if parent and parent in worlds else local
        worlds[name] = world
        bare = name[len(prefix):] if prefix and name.startswith(prefix) else name
        out[bare] = np.array(world, dtype=np.float64)
    return out


def _shell_delta_mats(shell: dict, worlds: Dict[str, object]):
    """Bone deltas, posed @ inverse(rest). The same matrices the CPU skin uses."""
    import numpy as np

    rest = shell["rest"]
    rest_inv = shell.get("rest_inv")
    if not rest_inv:
        rest_inv = [np.linalg.inv(mat) for mat in rest]
        shell["rest_inv"] = rest_inv
    parents = shell["parents"]
    index = shell["index"]
    anim: Dict[str, object] = {}
    for name in shell["order"]:
        if name in worlds:
            anim[name] = worlds[name]
            continue
        parent = parents.get(name) or ""
        bone_rest = rest[index[name]]
        if parent and parent in anim and parent in index:
            local = rest_inv[index[parent]] @ bone_rest
            anim[name] = anim[parent] @ local
        else:
            anim[name] = bone_rest
    count = len(rest)
    packed = np.zeros((count, 4, 4), dtype=np.float64)
    for name, posed in anim.items():
        slot = index.get(name)
        if slot is None:
            continue
        packed[slot] = np.asarray(posed @ rest_inv[slot], dtype=np.float64)
    return packed


def _shell_posed(shell: dict, worlds: Dict[str, object]):
    import numpy as np

    packed = _shell_delta_mats(shell, worlds)
    rots = packed[:, :3, :3]
    locs = packed[:, :3, 3]
    parts = []
    for mesh in shell["meshes"]:
        co = mesh["co"]
        ids = mesh["ids"]
        weights = mesh["wts"]
        acc = np.zeros_like(co)
        wsum = np.zeros((len(co), 1), dtype=np.float64)
        for slot in range(4):
            bi = ids[:, slot]
            valid = bi >= 0
            if not np.any(valid):
                continue
            chosen = np.where(valid, bi, 0)
            weight = weights[:, slot:slot + 1]
            mask = valid[:, None]
            skinned = np.einsum("nij,nj->ni", rots[chosen], co) + locs[chosen]
            acc += skinned * weight * mask
            wsum += weight * mask
        missing = wsum[:, 0] < 1e-8
        acc[missing] = co[missing]
        tris = mesh["tris"]
        corners = acc[tris]
        edge_a = corners[:, 1] - corners[:, 0]
        edge_b = corners[:, 2] - corners[:, 0]
        normal = np.cross(edge_a, edge_b)
        length = np.linalg.norm(normal, axis=1, keepdims=True)
        length[length < 1e-12] = 1.0
        normal = normal / length
        parts.append((
            np.ascontiguousarray(corners.reshape(-1, 3), dtype=np.float32),
            np.ascontiguousarray(np.repeat(normal, 3, axis=0), dtype=np.float32),
        ))
    return parts


def _fill_preview_batch(role: str, pos, nrm):
    """Reuse one GPU buffer and upload the new pose into it."""
    import numpy as np
    from gpu.types import GPUBatch, GPUVertBuf, GPUVertFormat

    pos = np.ascontiguousarray(pos, dtype=np.float32)
    nrm = np.ascontiguousarray(nrm, dtype=np.float32)
    count = len(pos)
    slot = _DRAG_GPU.get(role)
    if slot is None or slot.get("count") != count:
        fmt = GPUVertFormat()
        fmt.attr_add(id="pos", comp_type="F32", len=3, fetch_mode="FLOAT")
        fmt.attr_add(id="nrm", comp_type="F32", len=3, fetch_mode="FLOAT")
        vbo = GPUVertBuf(len=count, format=fmt)
        slot = {"vbo": vbo, "batch": GPUBatch(type="TRIS", buf=vbo), "count": count}
        _DRAG_GPU[role] = slot
    slot["vbo"].attr_fill("pos", pos)
    slot["vbo"].attr_fill("nrm", nrm)
    return slot["batch"]


def _shell_batch(role: str, shell: dict, worlds: Dict[str, object]):
    batch, _times = _timed_shell_batch(role, shell, worlds)
    return batch


def _timed_shell_batch(role: str, shell: dict, worlds: Dict[str, object]):
    """Skin and upload one pose. Returns the batch and millisecond costs."""
    import numpy as np

    times: Dict[str, float] = {}
    mark = time.perf_counter()
    parts = _shell_posed(shell, worlds)
    times["skin"] = (time.perf_counter() - mark) * 1000.0
    if not parts:
        return None, times
    mark = time.perf_counter()
    pos = np.concatenate([item[0] for item in parts])
    nrm = np.concatenate([item[1] for item in parts])
    times["pack"] = (time.perf_counter() - mark) * 1000.0
    fresh = role not in _DRAG_GPU or _DRAG_GPU[role].get("count") != len(pos)
    mark = time.perf_counter()
    try:
        batch = _fill_preview_batch(role, pos, nrm)
    except Exception:
        shader = _drag_mesh_shader()
        batch = batch_for_shader(shader, "TRIS", {"pos": pos, "nrm": nrm})
        fresh = True
    times["gpu"] = (time.perf_counter() - mark) * 1000.0
    times["gpu_new"] = 1.0 if fresh else 0.0
    return batch, times


def _fmt_drag_ms(times: Dict[str, float]) -> str:
    order = (
        "stick",
        "base",
        "donor",
        "shell",
        "fk",
        "skin",
        "pack",
        "gpu",
        "partner_base",
        "partner_donor",
        "partner_shell",
        "partner_fk",
        "partner_skin",
        "partner_pack",
        "partner_gpu",
        "partner_find",
        "slot",
        "shader",
        "draw",
        "pointer",
    )
    bits = []
    for key in order:
        if key not in times:
            continue
        note = ""
        if key == "shell":
            note = "/" + str(times.get("shell_kind") or "")
        elif key == "partner_shell":
            note = "/" + str(times.get("partner_shell_kind") or "")
        elif key == "gpu" and times.get("gpu_new"):
            note = " new"
        elif key == "partner_gpu" and times.get("partner_gpu_new"):
            note = " new"
        bits.append(f"{key} {times[key]:.2f}ms{note}")
    return "  ".join(bits)


def _drag_plane_matrix(center: Vector, u: Vector, v: Vector, n: Vector, stick: dict, prefix: str) -> Matrix:
    origin_pose = _stick_interp_points(stick, 0.0) if stick else {}
    ax, ay, az = _stick_drop_anchor(origin_pose, prefix)
    origin = center - u * ax - v * ay + n * (CLIP_DROP_LIFT - az)
    return Matrix((
        (float(u.x), float(v.x), float(n.x), float(origin.x)),
        (float(u.y), float(v.y), float(n.y), float(origin.y)),
        (float(u.z), float(v.z), float(n.z), float(origin.z)),
        (0.0, 0.0, 0.0, 1.0),
    ))


def _bind_rest_matrices(base_id: str):
    """Granny rest worlds from the body-base bind pose. Same space as a GR2LAB armature."""
    import numpy as np
    from mathutils import Quaternion

    from bind_pose import bind_pose_sidecar_path, load_bind_pose  # type: ignore

    doc = load_bind_pose(bind_pose_sidecar_path(base_id))
    bones = [b for b in (doc.get("bones") or []) if b.get("name")]
    parents = {b["name"]: (b.get("parent_name") or "") for b in bones}
    pending = set(parents)
    order: List[str] = []
    while pending:
        grew = False
        for name in list(pending):
            parent = parents.get(name) or ""
            if not parent or parent not in pending:
                order.append(name)
                pending.remove(name)
                grew = True
        if not grew:
            order.extend(sorted(pending))
            break
    worlds: Dict[str, Matrix] = {}
    for name in order:
        bone = next(b for b in bones if b["name"] == name)
        pos = bone.get("bind_translation") or [0.0, 0.0, 0.0]
        quat = bone.get("bind_rotation") or [0.0, 0.0, 0.0, 1.0]
        scale = bone.get("bind_scale") or [1.0, 1.0, 1.0]
        local = Matrix.LocRotScale(
            Vector((float(pos[0]), float(pos[1]), float(pos[2]))),
            Quaternion((float(quat[3]), float(quat[0]), float(quat[1]), float(quat[2]))),
            Vector((float(scale[0]), float(scale[1]), float(scale[2]))),
        )
        parent = parents.get(name) or ""
        worlds[name] = (worlds[parent] @ local) if parent and parent in worlds else local
    names = list(order)
    index = {name: i for i, name in enumerate(names)}
    rest = [np.array(worlds[name], dtype=np.float64) for name in names]
    return names, index, rest, parents, order


_PREVIEW_CACHE_VER = 1


def _preview_cache_file(kit_id: str):
    from .rig_display.mesh_kits import mesh_kits_dir

    return mesh_kits_dir() / "preview" / f"{kit_id}.npz"


def _load_preview_cache(kit_id: str):
    """Decimated body that was saved last time, so a drag does not open the kit blend."""
    import numpy as np

    path = _preview_cache_file(kit_id)
    if not path.is_file():
        return None
    try:
        with np.load(path, allow_pickle=False) as data:
            if int(data["ver"]) != _PREVIEW_CACHE_VER or int(data["budget"]) != _PREVIEW_TRI_BUDGET:
                return None
            names = [str(item) for item in data["names"].tolist()]
            parent_names = [str(item) for item in data["parent_names"].tolist()]
            parent_vals = [str(item) for item in data["parent_vals"].tolist()]
            parents = dict(zip(parent_names, parent_vals))
            rest = [np.array(data["rest"][i], dtype=np.float64) for i in range(len(names))]
            meshes = []
            for i in range(int(data["mesh_count"])):
                meshes.append({
                    "co": np.array(data[f"co{i}"]),
                    "ids": np.array(data[f"ids{i}"]),
                    "wts": np.array(data[f"wts{i}"]),
                    "tris": np.array(data[f"tris{i}"]),
                })
    except Exception:
        traceback.print_exc()
        return None
    if not names or not meshes:
        return None
    index = {name: i for i, name in enumerate(names)}
    return _finish_preview_shell(names, index, rest, parents, names, meshes)


def _save_preview_cache(kit_id: str, shell: dict) -> None:
    import numpy as np

    path = _preview_cache_file(kit_id)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "ver": np.int32(_PREVIEW_CACHE_VER),
            "budget": np.int32(_PREVIEW_TRI_BUDGET),
            "names": np.array(shell["names"]),
            "parent_names": np.array(list(shell["parents"].keys())),
            "parent_vals": np.array([shell["parents"][key] for key in shell["parents"]]),
            "rest": np.stack([np.asarray(mat, dtype=np.float64) for mat in shell["rest"]]),
            "mesh_count": np.int32(len(shell["meshes"])),
        }
        for i, mesh in enumerate(shell["meshes"]):
            payload[f"co{i}"] = np.asarray(mesh["co"])
            payload[f"ids{i}"] = np.asarray(mesh["ids"])
            payload[f"wts{i}"] = np.asarray(mesh["wts"])
            payload[f"tris{i}"] = np.asarray(mesh["tris"])
        np.savez_compressed(path, **payload)
    except Exception:
        traceback.print_exc()


def _shell_from_kit(
    family: str,
    akelka: bool = False,
    *,
    quiet: bool = False,
    tri_budget: Optional[int] = None,
) -> Optional[dict]:
    """Body-base meshes from the kit library. An empty file has no scene rig to borrow."""
    family = str(family or "").upper()
    if not family or bpy is None:
        return None
    budget = int(tri_budget or _PREVIEW_TRI_BUDGET)
    cache_key = f"kit|{family}|{int(akelka)}|b{budget}"
    cached = _DRAG_SHELLS.get(cache_key)
    if cached is not None:
        return cached or None
    try:
        import numpy as np
        from .rig_display.mesh_kits import (
            _append_collections,
            _catalog_base_for_kit,
            library_path,
            load_catalog,
        )
    except Exception:
        traceback.print_exc()
        _DRAG_SHELLS[cache_key] = {}
        return None
    cat = load_catalog()
    kit_id, _fallback = _catalog_base_for_kit(f"{family}_Base", cat, template_path=f"{family}_Base")
    t_cache = time.perf_counter()
    cached_shell = _load_preview_cache(kit_id) if budget == _PREVIEW_TRI_BUDGET else None
    if cached_shell is not None:
        _DRAG_SHELLS[cache_key] = cached_shell
        tris = sum(len(mesh["tris"]) for mesh in cached_shell["meshes"])
        if not quiet:
            print(
                f"[GR2 LAB drop] preview {kit_id} cache {time.perf_counter() - t_cache:.2f}s"
                f"  ({len(cached_shell['meshes'])} meshes, {tris} tris)",
                flush=True,
            )
        return cached_shell
    t0 = time.perf_counter()
    entry = (cat.get("bases") or {}).get(kit_id) or {}
    body_collection = str(entry.get("body_collection") or "")
    lib = library_path()
    if not body_collection or lib is None:
        _DRAG_SHELLS[cache_key] = {}
        return None
    try:
        names, index, rest, parents, order = _bind_rest_matrices(kit_id)
    except Exception:
        traceback.print_exc()
        _DRAG_SHELLS[cache_key] = {}
        return None
    t_bind = time.perf_counter()
    loaded = _append_collections(lib, [body_collection])
    t_append = time.perf_counter()
    rx = np.array(Matrix.Rotation(math.radians(-90.0), 4, "X"), dtype=np.float64)
    meshes = []
    try:
        objects = []
        for coll in loaded:
            objects.extend(obj for obj in coll.objects if getattr(obj, "type", "") == "MESH")
        picked = []
        for obj in objects:
            stem = obj.name.split(".", 1)[0].upper()
            if "LOD" in stem or set(stem.split("_")) & _MESH_SKIP:
                continue
            if len(getattr(obj.data, "polygons", [])) == 0 or len(obj.data.vertices) == 0:
                continue
            picked.append(obj)
        # Kit meshes are Z-up. Bone rest is Y-up, same Rx-90 the importer puts on the mesh.
        ratios = _preview_ratios([len(obj.data.polygons) for obj in picked], budget=budget)
        for obj, ratio in zip(picked, ratios):
            surface = _read_preview_arrays(obj, index, ratio, rx, duplicate=False)
            if surface is not None:
                meshes.append(surface)
    finally:
        # The preview read must not leave an empty collection under the kit
        # name. Load all would reuse that shell and attach 0 meshes.
        try:
            from .rig_display.mesh_kits import _LIB_DEPOT
        except Exception:
            _LIB_DEPOT = {}
        for coll in list(loaded):
            name = ""
            try:
                name = str(coll.name or "")
            except Exception:
                name = ""
            if name:
                _LIB_DEPOT.pop(name, None)
            for obj in list(getattr(coll, "objects", []) or []):
                data = obj.data
                try:
                    bpy.data.objects.remove(obj, do_unlink=True)
                except Exception:
                    pass
                if data is not None and getattr(data, "users", 1) == 0:
                    try:
                        bpy.data.meshes.remove(data)
                    except Exception:
                        pass
            try:
                bpy.data.collections.remove(coll)
            except Exception:
                if name:
                    try:
                        coll.name = ("_gr2lab_spent_" + name)[:63]
                    except Exception:
                        pass
    if not meshes:
        _DRAG_SHELLS[cache_key] = {}
        return None
    shell = _finish_preview_shell(names, index, rest, parents, order, meshes)
    _DRAG_SHELLS[cache_key] = shell
    if budget == _PREVIEW_TRI_BUDGET:
        _save_preview_cache(kit_id, shell)
    tris = sum(len(mesh["tris"]) for mesh in meshes)
    now = time.perf_counter()
    if not quiet:
        print(
            f"[GR2 LAB drop] preview {kit_id} {now - t0:.2f}s"
            f"  bind {t_bind - t0:.2f}s  append {t_append - t_bind:.2f}s"
            f"  decimate {now - t_append:.2f}s"
            f"  ({len(meshes)} meshes, {tris} tris)",
            flush=True,
        )
    return shell


def _drag_show_rest_pose(path: str) -> None:
    """Body from the mesh kit, before the clip's bones have been read.

    The kit is already in memory. Waiting for a full GR2 decode left the drag blank.
    """
    if not path or _DRAG.get("mesh_fail"):
        return
    bucket = f"rest|{path}"
    if _DRAG.get("mesh_bucket") == bucket and _DRAG.get("mesh_draw"):
        return
    family, akelka = _clip_base(path)
    shell = _shell_from_kit(family, akelka)
    if not shell:
        return
    batch, _times = _timed_shell_batch("player", shell, {})
    if batch is None:
        return
    _DRAG["mesh_draw"] = [("player", batch)]
    _DRAG["mesh_bucket"] = bucket
    _DRAG["mesh_clock"] = 0.0
    if _DRAG.get("rest_logged") != path:
        _DRAG["rest_logged"] = path
        print(f"[GR2 LAB drop] hologram {family} on screen (rest, clip still loading)", flush=True)


def _refresh_drag_mesh() -> None:
    """Pose the donor body with the clip's bones and keep a fresnel batch for the cursor."""
    if not _DRAG.get("active") or _DRAG.get("mesh_fail"):
        return
    pre = _DRAG.get("preload") or {}
    if pre.get("ready") or pre.get("commit"):
        _DRAG["mesh_draw"] = None
        return
    path = str(_DRAG.get("filepath") or "")
    stick = _drag_stick_data()
    poses = (stick or {}).get("poses") or []
    if not path or not poses or not (poses[0].get("rig")):
        _drag_show_rest_pose(path)
        return
    clock = _drag_stick_clock(stick)
    # Blend through the sampled poses. Holding a whole 12 Hz step reads as a snap.
    prev_clock = _DRAG.get("mesh_clock")
    if (
        _DRAG.get("mesh_bucket") == path
        and prev_clock is not None
        and abs(float(prev_clock) - clock) < (1.0 / 180.0)
        and _DRAG.get("mesh_draw")
    ):
        return
    try:
        t_hologram = time.perf_counter()
        times: Dict[str, float] = {}
        mark = time.perf_counter()
        family, akelka = _clip_base(path)
        times["base"] = (time.perf_counter() - mark) * 1000.0
        mark = time.perf_counter()
        player = _donor_arm(path)
        times["donor"] = (time.perf_counter() - mark) * 1000.0
        shell_key = f"{player.name}|{family}|{int(akelka)}" if player is not None else ""
        kit_key = f"kit|{family}|{int(akelka)}"
        if player is not None and shell_key in _DRAG_SHELLS:
            times["shell_kind"] = "scene"
        elif kit_key in _DRAG_SHELLS:
            times["shell_kind"] = "memory"
        else:
            times["shell_kind"] = "load"
        mark = time.perf_counter()
        shell = _capture_drag_shell(player, family, akelka) if player is not None else None
        if shell is None:
            shell = _shell_from_kit(family, akelka)
        times["shell"] = (time.perf_counter() - mark) * 1000.0
        draws = []
        pose_times: Dict[str, float] = {}
        if shell is not None:
            mark = time.perf_counter()
            worlds = _stick_fk_worlds(stick, clock, "")
            times["fk"] = (time.perf_counter() - mark) * 1000.0
            batch, pose_times = _timed_shell_batch("player", shell, worlds)
            times.update(pose_times)
            if batch is not None:
                draws.append(("player", batch))
        partner_arm = None
        p_family = ""
        if any(str(name).startswith("P:") for name in (stick.get("bone_order") or [])):
            mark = time.perf_counter()
            partner_path = _stick_partner_from_list(path)
            times["partner_find"] = (time.perf_counter() - mark) * 1000.0
            if partner_path:
                mark = time.perf_counter()
                p_family, p_ak = _clip_base(str(partner_path))
                times["partner_base"] = (time.perf_counter() - mark) * 1000.0
                mark = time.perf_counter()
                partner_arm = _donor_arm(str(partner_path))
                times["partner_donor"] = (time.perf_counter() - mark) * 1000.0
                p_key = f"kit|{p_family}|{int(p_ak)}"
                times["partner_shell_kind"] = "memory" if p_key in _DRAG_SHELLS else "load"
                mark = time.perf_counter()
                partner_shell = (
                    _capture_drag_shell(partner_arm, p_family, p_ak) if partner_arm is not None else None
                )
                if partner_shell is None:
                    partner_shell = _shell_from_kit(p_family, p_ak)
                times["partner_shell"] = (time.perf_counter() - mark) * 1000.0
                if partner_shell is not None:
                    mark = time.perf_counter()
                    p_worlds = _stick_fk_worlds(stick, clock, "P:")
                    times["partner_fk"] = (time.perf_counter() - mark) * 1000.0
                    p_batch, p_times = _timed_shell_batch("partner", partner_shell, p_worlds)
                    times["partner_skin"] = p_times.get("skin", 0.0)
                    times["partner_pack"] = p_times.get("pack", 0.0)
                    times["partner_gpu"] = p_times.get("gpu", 0.0)
                    times["partner_gpu_new"] = p_times.get("gpu_new", 0.0)
                    if p_batch is not None:
                        draws.append(("partner", p_batch))
        draws = [(role, batch) for role, batch in draws if batch is not None]
        if not draws:
            _DRAG["mesh_fail"] = True
            return
        if _DRAG.get("mesh_logged") != path:
            bits = []
            if shell is not None:
                tris = sum(len(mesh["tris"]) for mesh in shell.get("meshes") or [])
                if player is not None:
                    bits.append(f"{family} from {player.name} ({tris} tris)")
                else:
                    bits.append(f"{family} mesh kit ({tris} tris)")
            if partner_arm is not None and p_family:
                bits.append(f"{p_family} from {partner_arm.name}")
            held = (time.perf_counter() - float(_DRAG.get("t0") or time.perf_counter())) * 1000.0
            built = (time.perf_counter() - t_hologram) * 1000.0
            print(
                "[GR2 LAB drop] hologram "
                + ", ".join(bits)
                + f"  build {built:.2f}ms  drag {held:.2f}ms",
                flush=True,
            )
            print("[GR2 LAB drop] parts  " + _fmt_drag_ms(times), flush=True)
            _DRAG["mesh_logged"] = path
            _DRAG["pose_samples"] = []
            _DRAG["pose_logged"] = False
        elif not _DRAG.get("pose_logged"):
            samples = _DRAG.setdefault("pose_samples", [])
            samples.append(
                times.get("fk", 0.0)
                + times.get("skin", 0.0)
                + times.get("pack", 0.0)
                + times.get("gpu", 0.0)
                + times.get("partner_fk", 0.0)
                + times.get("partner_skin", 0.0)
                + times.get("partner_gpu", 0.0)
            )
            if len(samples) >= 8:
                mean = sum(samples) / len(samples)
                print(
                    "[GR2 LAB drop] playing "
                    f"{len(samples)} poses  mean {mean:.2f}ms  "
                    f"max {max(samples):.2f}ms  "
                    f"last fk {times.get('fk', 0.0):.2f}  "
                    f"skin {times.get('skin', 0.0):.2f}  "
                    f"pack {times.get('pack', 0.0):.2f}  "
                    f"gpu {times.get('gpu', 0.0):.2f}",
                    flush=True,
                )
                _DRAG["pose_logged"] = True
        _DRAG["mesh_draw"] = draws
        _DRAG["mesh_bucket"] = path
        _DRAG["mesh_clock"] = clock
    except Exception:
        traceback.print_exc()
        _DRAG["mesh_fail"] = True


def _hologram_loose_matrix(partner: bool, partner_shift: float) -> Matrix:
    """No stage mark for this clip.

    Center stands the body on the origin. Otherwise it follows the 3D cursor,
    which is where an uncentered drop will land.
    """
    if _browser_center_parent():
        base = (0.0, 0.0, 0.0)
    else:
        cursor = bpy.context.scene.cursor.location
        base = (float(cursor.x), float(cursor.y), float(cursor.z))
    mat = Matrix.Translation(base) @ _DRAG_RXP
    if partner:
        mat = mat @ Matrix.Translation((float(partner_shift), 0.0, 0.0))
    return mat


def _drag_place_matrix(path: str, partner: bool) -> Matrix:
    """Where this drop will land.

    Center off keeps the clip's stage coordinates. Center on slides that
    same stage so the top parent sits at the origin.
    """
    primary, partner_mat = _stick_pair_slot_matrices(path)
    mat = partner_mat if partner else primary
    if mat is not None:
        return mat
    return _hologram_loose_matrix(partner, STICK_PARTNER_SHIFT)


def _draw_drag_mesh(point: Vector, u: Vector, v: Vector, n: Vector) -> bool:
    draws = _DRAG.get("mesh_draw")
    if not draws:
        return False
    mark = time.perf_counter()
    stick = _drag_stick_data() or {}
    path = str(_DRAG.get("filepath") or stick.get("path") or "")
    slot_ms = 0.0
    mark = time.perf_counter()
    try:
        shader = _drag_mesh_shader()
    except Exception:
        return False
    shader_ms = (time.perf_counter() - mark) * 1000.0
    solid = bool(_STATE.get("holo_mesh"))
    gpu.state.blend_set("NONE" if solid else "ALPHA")
    try:
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.depth_mask_set(solid)
        gpu.state.face_culling_set("NONE" if solid else "BACK")
    except Exception:
        pass
    drawn = False
    draw_mark = time.perf_counter()
    try:
        for role, batch in draws:
            mat = _drag_place_matrix(path, role == "partner")
            if mat is None:
                continue
            age = time.perf_counter() - float(_DRAG.get("t0") or time.perf_counter())
            reveal = max(0.0, min(1.0, age / _DRAG_REVEAL_SEC))
            gpu.matrix.push()
            try:
                gpu.matrix.multiply_matrix(mat)
                shader.bind()
                mv = gpu.matrix.get_model_view_matrix()
                proj = gpu.matrix.get_projection_matrix()
                shader.uniform_float("ModelViewMatrix", mv)
                shader.uniform_float("ModelViewProjectionMatrix", proj @ mv)
                shader.uniform_block(
                    "gp",
                    _ubo_float4(_DRAG_UBO, reveal, 0.0, 0.0, 1.0 if solid else 0.0),
                )
                batch.draw(shader)
                drawn = True
            finally:
                gpu.matrix.pop()
    finally:
        try:
            gpu.state.face_culling_set("BACK")
            gpu.state.depth_mask_set(True)
            gpu.state.depth_test_set("NONE")
        except Exception:
            pass
        gpu.state.blend_set("NONE")
    if drawn and not _DRAG.get("draw_logged"):
        _DRAG["draw_logged"] = True
        print(
            "[GR2 LAB drop] first draw  "
            f"slot {slot_ms:.2f}ms  shader {shader_ms:.2f}ms  "
            f"draw {(time.perf_counter() - draw_mark) * 1000.0:.2f}ms  "
            f"at ({point.x:.1f}, {point.y:.1f}, {point.z:.1f})  "
            f"since drag {(time.perf_counter() - float(_DRAG.get('t0') or time.perf_counter())) * 1000.0:.2f}ms",
            flush=True,
        )
    if drawn:
        age = time.perf_counter() - float(_DRAG.get("t0") or time.perf_counter())
        if age < _DRAG_REVEAL_SEC:
            _tag()
    return drawn


def _draw_view_drop() -> None:
    try:
        _draw_gallery()
    except Exception:
        traceback.print_exc()
    if not _DRAG.get("active"):
        return
    point = _DRAG.get("point")
    if point is None or _DRAG.get("over_strip"):
        return
    normal = _DRAG.get("normal") or Vector((0.0, 0.0, 1.0))
    u, v, n = _drop_plane_basis(normal)
    try:
        _draw_drag_mesh(point, u, v, n)
    except Exception:
        traceback.print_exc()
    # Held drag shows the skinned hologram only. The wire figure does not
    # play the clip, so it is not a stand-in while the body is still loading.


def _armature_anchor_world(arm) -> Vector:
    for name in ("Dummy_Root", "Root_M"):
        bone = arm.data.bones.get(name) if arm is not None else None
        if bone is not None:
            return (arm.matrix_world @ bone.head_local).copy()
    return arm.matrix_world.translation.copy()


def _stage_group(arm) -> set:
    """Stage empties, both rigs, and anything parented to them."""
    found = set()
    if arm is None:
        return found
    parent = getattr(arm, "parent", None)
    for col in bpy.data.collections:
        if not col.get("gr2lab_scene_empties"):
            continue
        names = {obj.name for obj in col.objects}
        if (parent is not None and parent.name in names) or arm.name in names:
            found.update(col.objects)
    if parent is not None:
        found.add(parent)
    found.add(arm)
    changed = True
    while changed:
        changed = False
        for obj in bpy.data.objects:
            if obj in found or obj.parent not in found:
                continue
            found.add(obj)
            changed = True
    return found


def _move_stage_to_drop(context, arm, point: Vector) -> bool:
    """Slide the whole stage so this rig's anchor lands on the drop point."""
    if arm is None or point is None:
        return False
    try:
        context.view_layer.update()
    except Exception:
        pass
    group = _stage_group(arm)
    if len(group) < 2 and getattr(arm, "parent", None) is None:
        return False
    delta = point - _armature_anchor_world(arm)
    roots = [obj for obj in group if obj.parent not in group]
    from .scene_stage_empties import _offset_location_keys

    for obj in roots:
        if obj.parent is None:
            _offset_location_keys(obj, delta)
        world = obj.matrix_world.copy()
        world.translation += delta
        obj.matrix_world = world
    try:
        context.view_layer.update()
    except Exception:
        pass
    return True


def _snap_armature_to_drop(arm, point: Vector) -> None:
    if arm is None or point is None:
        return
    mat = arm.matrix_world.copy()
    mat.translation += point - _armature_anchor_world(arm)
    arm.matrix_world = mat


def _armature_for_imported_clip(filepath: str, before: set) -> Optional[bpy.types.Object]:
    from .bridge_blender import PROP_SOURCE_GR2

    new_ones = [
        obj
        for obj in bpy.data.objects
        if getattr(obj, "type", None) == "ARMATURE" and obj.name not in before
    ]
    if not new_ones:
        return None
    want_key = Path(filepath).resolve().as_posix().casefold()
    matched = []
    for obj in new_ones:
        src = str(obj.get(PROP_SOURCE_GR2) or "").strip()
        if not src:
            continue
        try:
            if Path(src).resolve().as_posix().casefold() == want_key:
                matched.append(obj)
        except OSError:
            continue
    if matched:
        return matched[-1]
    return new_ones[-1]


def _select_armature(context, arm) -> None:
    if arm is None or getattr(arm, "type", None) != "ARMATURE":
        return
    try:
        for obj in context.view_layer.objects:
            obj.select_set(obj == arm)
        context.view_layer.objects.active = arm
    except Exception:
        pass


class _StripImportHost:
    """Stand-in for the GR2 import operator while a strip drag preloads."""

    def __init__(self, fields: dict) -> None:
        self.fps = 30
        self.body_base = "AUTO"
        self.bb_hint = ""
        self.body_choice = ""
        self.import_apply = "NEW_RIG"
        self.add_rig = True
        self.second_character = False
        self.scene_empties = False
        self.center_parent = True
        self.import_meshes = "BODY_CLOTH"
        self.import_akelka = True
        self.import_clear_meshes = True
        self.import_tail = True
        self.rig_shapes = True
        self.rig_ik_limbs = True
        self.rig_ik_head = True
        self.partner_body_base = "AUTO"
        for key, value in fields.items():
            setattr(self, key, value)

    def report(self, _level, message) -> None:
        print(f"[GR2 LAB] {message}", flush=True)


def _end_preload_ui(pre: Optional[dict]) -> None:
    if not pre:
        return
    progress = pre.get("progress")
    if progress is not None:
        try:
            progress.end()
        except Exception:
            pass
        pre["progress"] = None
    try:
        from .import_progress_ui import end as overlay_end

        overlay_end()
    except Exception:
        pass


_DROP_HOLD_COLLECTION = "GR2LAB_preload_hold"


def _find_layer_collection(layer, name: str):
    if layer.name == name:
        return layer
    for child in layer.children:
        found = _find_layer_collection(child, name)
        if found is not None:
            return found
    return None


def _hold_collection(context, pre: dict):
    name = str(pre.get("hold_col") or _DROP_HOLD_COLLECTION)
    col = bpy.data.collections.get(name)
    if col is None:
        col = bpy.data.collections.new(name)
    root = context.scene.collection
    if col.name not in root.children:
        root.children.link(col)
    pre["hold_col"] = col.name
    return col


def _set_hold_excluded(context, name: str, excluded: bool) -> None:
    layer = _find_layer_collection(context.view_layer.layer_collection, name)
    if layer is None or bool(layer.exclude) == bool(excluded):
        return
    try:
        layer.exclude = bool(excluded)
    except Exception:
        pass


_DROP_BUILD_LAYER = "GR2LAB_preload_build"


def _ensure_drop_build_layer(context, pre: dict) -> None:
    """User view hides the hold collection. A second view layer can still edit it."""
    col = _hold_collection(context, pre)
    _set_hold_excluded(context, col.name, True)
    scene = context.scene
    vl = scene.view_layers.get(_DROP_BUILD_LAYER)
    if vl is None:
        vl = scene.view_layers.new(_DROP_BUILD_LAYER)
    layer = _find_layer_collection(vl.layer_collection, col.name)
    if layer is not None and layer.exclude:
        try:
            layer.exclude = False
        except Exception:
            pass
    pre["build_vl"] = vl.name
    pre["state"]["strip_hold_collection"] = col.name


def _drop_build_view_layer(context, pre: dict) -> None:
    name = str(pre.get("build_vl") or "")
    pre["build_vl"] = ""
    if not name or context is None:
        return
    scene = getattr(context, "scene", None)
    if scene is None:
        return
    vl = scene.view_layers.get(name)
    if vl is None or vl == getattr(context, "view_layer", None):
        return
    active = getattr(vl.objects, "active", None)
    if active is not None and getattr(active, "mode", "OBJECT") != "OBJECT":
        try:
            with context.temp_override(
                scene=scene, view_layer=vl, active_object=active, object=active
            ):
                bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass
    try:
        scene.view_layers.remove(vl)
    except Exception:
        pass


def _stash_preload_collection(context, pre: dict) -> None:
    """Move the in-progress rig into a view-layer-excluded collection."""
    before = pre.get("before") or set()
    col = _hold_collection(context, pre)
    for obj in bpy.data.objects:
        if obj.name in before:
            continue
        try:
            if obj.name not in col.objects:
                col.objects.link(obj)
        except Exception:
            pass
        for user in list(obj.users_collection):
            if user == col:
                continue
            try:
                user.objects.unlink(obj)
            except Exception:
                pass
    _set_hold_excluded(context, col.name, True)


def _show_preload_collection(context, pre: dict) -> None:
    name = str(pre.get("hold_col") or "")
    if name:
        _set_hold_excluded(context, name, False)


def _release_preload_collection(context, pre: dict) -> None:
    """Put the finished rig back in the scene collection and drop the hold."""
    _drop_build_view_layer(context, pre)
    name = str(pre.get("hold_col") or "")
    if not name:
        return
    _set_hold_excluded(context, name, False)
    col = bpy.data.collections.get(name)
    root = context.scene.collection
    if col is not None:
        for obj in list(col.objects):
            try:
                if obj.name not in root.objects:
                    root.objects.link(obj)
            except Exception:
                pass
            try:
                col.objects.unlink(obj)
            except Exception:
                pass
        try:
            if col.name in root.children:
                root.children.unlink(col)
        except Exception:
            pass
        try:
            if col.users == 0:
                bpy.data.collections.remove(col)
        except Exception:
            pass
    pre["hold_col"] = ""


def _hide_preload_objects(pre: dict) -> None:
    before = pre.get("before") or set()
    hidden = pre.setdefault("hidden", set())
    for obj in bpy.data.objects:
        if obj.name in before:
            continue
        try:
            if not obj.hide_viewport:
                obj.hide_viewport = True
            hidden.add(obj.name)
        except Exception:
            pass


def _reveal_preload_objects(pre: dict) -> None:
    for name in list(pre.get("hidden") or ()):
        obj = bpy.data.objects.get(name)
        if obj is None:
            continue
        try:
            obj.hide_viewport = False
        except Exception:
            pass


def _place_ready_drop(context, pre: dict, point: Optional[Vector]) -> None:
    arm = (pre.get("state") or {}).get("arm")
    if point is None or arm is None:
        _reveal_preload_objects(pre)
        return
    register_pending_clip_drop(
        pre["path"], point, context, whole_scene=_browser_whole_scene(context)
    )
    _release_preload_collection(context, pre)
    apply_pending_clip_drop(context, pre["path"], arm, consume=False)
    try:
        arm.hide_viewport = False
    except Exception:
        pass
    _reveal_preload_objects(pre)
    _select_armature(context, arm)
    _record_recent_clip(str(pre.get("path") or ""))


def _discard_datablock(data) -> None:
    if data is None or getattr(data, "users", 1) != 0:
        return
    ident = str(getattr(getattr(data, "bl_rna", None), "identifier", "") or "")
    coll_name = ident[:1].lower() + ident[1:] + "s" if ident else ""
    coll = getattr(bpy.data, coll_name, None) if coll_name else None
    if coll is None:
        return
    try:
        if coll.get(data.name) != data:
            return
        coll.remove(data)
    except Exception:
        pass


def _delete_preload_objects(pre: dict) -> None:
    before = pre.get("before") or set()
    actions = []
    for obj in list(bpy.data.objects):
        if obj.name in before:
            continue
        anim = getattr(obj, "animation_data", None)
        action = getattr(anim, "action", None) if anim is not None else None
        if action is not None:
            actions.append(action)
        data = obj.data
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            continue
        _discard_datablock(data)
    for action in actions:
        _discard_datablock(action)
    cols = pre.get("cols") or set()
    for col in list(bpy.data.collections):
        if col.name in cols or len(col.objects) != 0:
            continue
        try:
            bpy.data.collections.remove(col)
        except Exception:
            pass


def _abort_clip_preload() -> None:
    pre = _DRAG.get("preload")
    if not pre or pre.get("aborted"):
        _DRAG["preload"] = None
        return
    pre["aborted"] = True
    _DRAG["preload"] = None
    if not pre.get("done"):
        _drop_build_view_layer(bpy.context, pre)
        _delete_preload_objects(pre)
        _release_preload_collection(bpy.context, pre)
        _print_drop_report(pre, "cancelled")
        print("[GR2 LAB] strip preload cancelled", flush=True)
    _end_preload_ui(pre)
    clear_pending_clip_drop()


def _show_preload_bar(context, pre: dict) -> None:
    if pre.get("bar") or pre.get("ready"):
        return
    from .import_modal import stage_count
    from .import_progress_ui import begin as overlay_begin

    overlay_begin(
        stage_total=stage_count(pre["host"]),
        context=context,
        area_ptr=int(pre.get("area_ptr") or 0),
    )
    pre["bar"] = True


def _drop_step_label(key) -> str:
    names = {
        0: "body base",
        1: "decode clip",
        2: "build rig and meshes",
        3: "stamp metadata",
        4: "scene place and center",
        5: "second character decode",
        6: "second character build",
        7: "finish",
    }
    finish = {
        0: "finish cleanup",
        1: "timeline, center, camera",
        2: "move onto the drop",
        3: "edit copy",
        5: "finish",
    }
    if key == ("place", 0):
        return "put on the cursor"
    if not isinstance(key, tuple) or not key:
        return str(key)
    step, phase = key[0], key[1] if len(key) > 1 else 0
    if step == 7:
        return finish.get(phase, f"finish {phase}")
    return names.get(step, f"step {step}")


def _drop_clock(pre: dict) -> None:
    """Add the time since the last pump onto the step that was running."""
    now = time.perf_counter()
    state = pre.get("state") or {}
    step = int(state.get("step") or 0)
    phase = int(state.get("finish_phase") or 0)
    key = (step, phase if step == 7 else 0)
    prev = pre.get("clock_key")
    last = float(pre.get("clock_at") or now)
    if prev is None:
        start = float(pre.get("t0") or now)
        if now - start > 0.0:
            bucket = pre.setdefault("step_secs", {})
            bucket[key] = float(bucket.get(key) or 0.0) + (now - start)
        pre["clock_key"] = key
        pre["clock_at"] = now
        return
    bucket = pre.setdefault("step_secs", {})
    bucket[prev] = float(bucket.get(prev) or 0.0) + (now - last)
    pre["clock_at"] = now
    if prev != key:
        print(
            f"[GR2 LAB drop] {_drop_step_label(prev)} {bucket[prev]:.2f}s",
            flush=True,
        )
        pre["clock_key"] = key


def _print_drop_report(pre: dict, headline: str) -> None:
    """One console block for a strip drop. Paste this back to see where the time went."""
    if pre.get("timing_printed") and headline != "cancelled":
        return
    _drop_clock(pre)
    t0 = float(pre.get("t0") or time.perf_counter())
    now = time.perf_counter()
    name = Path(str(pre.get("path") or "")).name
    commit = pre.get("t_commit")
    lines = [f"[GR2 LAB drop] {headline}  {name}"]
    lines.append(f"  since drag start     {now - t0:7.2f}s")
    if commit:
        held = float(commit) - t0
        lines.append(f"  while mouse held     {held:7.2f}s")
        lines.append(f"  after mouse release  {now - float(commit):7.2f}s")
    ranked = sorted(
        (pre.get("step_secs") or {}).items(),
        key=lambda item: float(item[1]),
        reverse=True,
    )
    if ranked:
        lines.append("  where the wait sat:")
        for key, sec in ranked:
            if float(sec) < 0.05:
                continue
            lines.append(f"    {_drop_step_label(key):<28} {float(sec):7.2f}s")
    job = (pre.get("state") or {}).get("job_timer")
    if job is not None and getattr(job, "stages", None):
        lines.append(job.format_block())
    print("\n".join(lines), flush=True)
    if headline != "cancelled":
        pre["timing_printed"] = True


def _begin_clip_preload(context, filepath: str, point: Vector) -> None:
    from .bridge_blender import Gr2LabProgress

    path = str(filepath or "").strip()
    if not path or _DRAG.get("preload") is not None:
        return
    _clear_stacked_drops(context)
    host = _StripImportHost(_strip_import_kwargs(context, path))
    prefs = context.preferences.addons[__package__].preferences
    area = getattr(context, "area", None)
    area_ptr = (
        int(area.as_pointer())
        if area is not None and getattr(area, "type", "") == "VIEW_3D"
        else 0
    )
    state = {
        "step": 0,
        "path": path,
        "apply": "NEW_RIG",
        "target": None,
        "prefs": prefs,
        "preload_quiet": True,
        "defer_clip_snap": True,
        "strip_hide_build": True,
    }
    pre = {
        "path": path,
        "host": host,
        "state": state,
        "progress": None,
        "before": {obj.name for obj in bpy.data.objects},
        "cols": {col.name for col in bpy.data.collections},
        "hidden": set(),
        "done": False,
        "commit": False,
        "commit_point": None,
        "ready": False,
        "err": "",
        "aborted": False,
        "bar": False,
        "area_ptr": area_ptr,
        "t0": time.perf_counter(),
        "step_secs": {},
    }
    _DRAG["preload"] = pre
    _DRAG["preload_failed"] = ""
    try:
        progress = Gr2LabProgress(context, header=False)
        progress.begin(100)
        pre["progress"] = progress
        register_pending_clip_drop(
            path, point, context, whole_scene=_browser_whole_scene(context)
        )
    except Exception:
        _abort_clip_preload()
        raise
    try:
        _ensure_drop_build_layer(context, pre)
    except Exception:
        traceback.print_exc()
    print(f"[GR2 LAB drop] started {Path(path).name}", flush=True)


def _preload_pump_limits(committed: bool, pre: dict) -> Tuple[int, Optional[float]]:
    if pre.get("ready") and not committed:
        return 0, None
    if committed:
        return CLIP_PRELOAD_COMMIT_SLICES, None
    return 1, 0.008


def _pump_clip_preload(context) -> None:
    pre = _DRAG.get("preload")
    if not pre or pre.get("done") or pre.get("aborted"):
        return
    _drop_clock(pre)
    committed = bool(pre.get("commit"))
    point = pre.get("commit_point") if committed else _DRAG.get("point")
    if point is not None:
        register_pending_clip_drop(
            pre["path"], point, context, whole_scene=_browser_whole_scene(context)
        )
    from . import bridge_blender
    from .import_modal import advance

    state = pre["state"]
    state["preload_quiet"] = not committed
    progress = pre.get("progress") if committed else None
    max_slices, budget = _preload_pump_limits(committed, pre)
    if max_slices <= 0:
        return
    t_budget = time.perf_counter() + budget if budget else 0.0
    for _ in range(max_slices):
        if budget and time.perf_counter() >= t_budget:
            break
        step_before = int(state.get("step") or 0)
        build_vl = None
        build_name = str(pre.get("build_vl") or "")
        if build_name:
            build_vl = context.scene.view_layers.get(build_name)
        try:
            if build_vl is not None:
                with context.temp_override(view_layer=build_vl):
                    finished, err = advance(
                        pre["host"],
                        context,
                        state,
                        progress=progress,
                        bridge=bridge_blender,
                    )
            else:
                finished, err = advance(
                    pre["host"],
                    context,
                    state,
                    progress=progress,
                    bridge=bridge_blender,
                )
        except Exception as exc:
            traceback.print_exc()
            finished, err = True, str(exc)
        step_after = int(state.get("step") or 0)
        if err:
            pre["err"] = str(err)
            _DRAG["preload_failed"] = str(err)
            _abort_clip_preload()
            return
        if finished:
            _release_preload_collection(context, pre)
            if not committed:
                pre["ready"] = True
                point = _DRAG.get("point")
                t_place = time.perf_counter()
                _place_ready_drop(context, pre, point)
                pre.setdefault("step_secs", {})[("place", 0)] = (
                    float(pre.get("step_secs", {}).get(("place", 0)) or 0.0)
                    + (time.perf_counter() - t_place)
                )
                _print_drop_report(pre, "built while the mouse is held")
                print("[GR2 LAB] strip preload ready at cursor", flush=True)
                return
            pre["done"] = True
            arm = state.get("arm")
            if arm is not None:
                try:
                    arm.hide_viewport = False
                except Exception:
                    pass
            _reveal_preload_objects(pre)
            try:
                finish_deferred_edit_copy(context, state)
            except Exception:
                traceback.print_exc()
            _print_drop_report(pre, "on screen")
            _end_preload_ui(pre)
            return
        _stash_preload_collection(context, pre)
        if step_after == step_before:
            return


def _maybe_begin_clip_preload(context) -> None:
    if _DRAG.get("use_dialog") or _DRAG.get("preload") is not None:
        return
    if _DRAG.get("preload_failed") or _DRAG.get("over_strip"):
        return
    point = _DRAG.get("point")
    path = str(_DRAG.get("filepath") or "")
    if point is None or not path:
        return
    dx = float(_DRAG.get("mx") or 0.0) - float(_DRAG.get("sx") or 0.0)
    dy = float(_DRAG.get("my") or 0.0) - float(_DRAG.get("sy") or 0.0)
    if (dx * dx + dy * dy) < CLIP_DRAG_THRESHOLD * CLIP_DRAG_THRESHOLD:
        return
    try:
        _begin_clip_preload(context, path, point)
        _pump_clip_preload(context)
    except Exception:
        traceback.print_exc()
        _abort_clip_preload()


def _clear_stacked_drops(context) -> int:
    """Remove earlier centered drops sitting on the origin.

    Center puts every solo clip on the same point, so the previous body
    stays inside the new one and reads as a second character.
    """
    if bpy is None or not _browser_center_parent(context):
        return 0
    doomed = []
    for obj in list(bpy.data.objects):
        if getattr(obj, "type", "") != "ARMATURE":
            continue
        if not (obj.get("gr2lab_full_source_gr2") or obj.get("gr2lab_source_gr2")):
            continue
        if obj.matrix_world.translation.length > 0.25:
            continue
        doomed.append(obj)
    removed = 0
    for arm in doomed:
        children = list(getattr(arm, "children_recursive", ()) or ())
        for child in children:
            mesh = child.data if getattr(child, "type", "") == "MESH" else None
            try:
                bpy.data.objects.remove(child, do_unlink=True)
            except Exception:
                continue
            if mesh is not None and getattr(mesh, "users", 1) == 0:
                bpy.data.meshes.remove(mesh)
        mesh = arm.data if getattr(arm, "type", "") == "ARMATURE" else None
        try:
            bpy.data.objects.remove(arm, do_unlink=True)
            removed += 1
        except Exception:
            continue
        if mesh is not None and getattr(mesh, "users", 1) == 0:
            try:
                bpy.data.armatures.remove(mesh)
            except Exception:
                pass
    if removed:
        print(f"[GR2 LAB drop] cleared {removed} stacked character(s) at the origin", flush=True)
    return removed


def _import_clip_at(
    context,
    filepath: str,
    point: Optional[Vector],
    *,
    place: bool,
    whole_scene: bool = False,
    replace_stack: bool = False,
) -> None:
    from .bridge_blender import exec_gr2_import_quick

    if replace_stack:
        _clear_stacked_drops(context)
    if place and point is not None:
        register_pending_clip_drop(
            filepath, point, context, whole_scene=whole_scene
        )
    else:
        clear_pending_clip_drop(context)
    center = _browser_center_parent(context)
    t0 = time.perf_counter()
    print(f"[GR2 LAB drop] started {Path(filepath).name}", flush=True)
    exec_gr2_import_quick(
        context, filepath, whole_scene=whole_scene, center_parent=center
    )
    print(
        f"[GR2 LAB drop] click import finished  {Path(filepath).name}  "
        f"{time.perf_counter() - t0:.2f}s",
        flush=True,
    )
    if place:
        _record_recent_clip(filepath)


def _clear_clip_arm() -> None:
    _CLIP_ARM.clear()


def _arm_clip_press(
    context, event, region, path: str, mx: float, my: float
) -> None:
    _CLIP_ARM.clear()
    window = getattr(context, "window", None)
    area = getattr(context, "area", None)
    _CLIP_ARM.update(
        {
            "path": str(path),
            "sx": float(mx),
            "sy": float(my),
            "wx": float(getattr(event, "mouse_x", 0.0)),
            "wy": float(getattr(event, "mouse_y", 0.0)),
            "region_ptr": int(region.as_pointer()) if region is not None else 0,
            "window": window,
            "area": area,
            "region": region,
            "was_selected": _clip_is_selected(path),
            "shift": bool(getattr(event, "shift", False)),
            "drag_started": False,
        }
    )


def _finish_clip_arm(context) -> None:
    arm = _CLIP_ARM
    path = str(arm.get("path") or "")
    if not path or arm.get("drag_started"):
        _clear_clip_arm()
        return
    _select_strip_clip(context, path)
    _clear_clip_arm()


def _try_armed_clip_drag(context, event) -> bool:
    arm = _CLIP_ARM
    path = str(arm.get("path") or "")
    if not path or arm.get("drag_started") or clip_drag_active():
        return False
    wx = float(getattr(event, "mouse_x", 0.0))
    wy = float(getattr(event, "mouse_y", 0.0))
    dx = wx - float(arm.get("wx") or 0.0)
    dy = wy - float(arm.get("wy") or 0.0)
    if (dx * dx + dy * dy) < CLIP_DRAG_THRESHOLD * CLIP_DRAG_THRESHOLD:
        return False
    if not arm.get("was_selected"):
        _select_strip_clip(context, path)
    arm["drag_started"] = True
    window = arm.get("window") or getattr(context, "window", None)
    area = arm.get("area") or getattr(context, "area", None)
    region = arm.get("region")
    if window is None or area is None or region is None:
        _clear_clip_arm()
        return False

    class _PressEvent:
        mouse_region_x = float(arm.get("sx") or 0.0)
        mouse_region_y = float(arm.get("sy") or 0.0)
        shift = bool(arm.get("shift"))

    press_ev = _PressEvent()
    try:
        with context.temp_override(window=window, area=area, region=region):
            ok = _begin_clip_drag(bpy.context, press_ev, path)
    except Exception:
        traceback.print_exc()
        ok = False
    _clear_clip_arm()
    return ok


def _begin_clip_drag(context, event, filepath: str) -> bool:
    path = str(filepath or "")
    if not path:
        return False
    try:
        bpy.ops.gr2lab.anim_clip_drag(
            "INVOKE_DEFAULT",
            filepath=path,
            start_x=float(event.mouse_region_x),
            start_y=float(event.mouse_region_y),
            use_dialog=bool(getattr(event, "alt", False)),
        )
        return True
    except Exception:
        traceback.print_exc()
        return False


def _on_move(context, event) -> set:
    region = getattr(context, "region", None)
    if region is None:
        return {"PASS_THROUGH"}
    mx, my = _event_xy(event)
    found = _hit(region, mx, my)
    path = ""
    if found and found[0] in {"clip", "recent"}:
        path = found[1]
    layout = _LAYOUTS.get(region.as_pointer() if region else 0) or {}
    _POINTER["mx"] = mx
    _POINTER["my"] = my
    _POINTER["over_strip"] = _over_box(layout.get("strip"), _POINTER["mx"], _POINTER["my"])
    split = _split_at(layout, _POINTER["mx"], _POINTER["my"])
    was = bool(_POINTER.get("split_cursor"))
    if split and not was:
        try:
            context.window.cursor_set("MOVE_X")
        except Exception:
            pass
    elif was and not split:
        try:
            context.window.cursor_set("DEFAULT")
        except Exception:
            pass
    _POINTER["split_cursor"] = bool(split)
    _track_button_hover(region, mx, my)
    # Leaving the row, including into the 3D view, keeps the last clip playing.
    if path:
        _preview_follow(path)
    elif _preview_enabled() and str(_HOVER.get("path") or ""):
        _ensure_preview_timer()
    return {"PASS_THROUGH"}


def _on_wheel(context, event) -> set:
    region = getattr(context, "region", None)
    layout = _LAYOUTS.get(region.as_pointer() if region else 0) or {}
    mx, my = _event_xy(event)
    if not _over_box(layout.get("strip"), mx, my):
        return {"PASS_THROUGH"}
    if _over_box(layout.get("filter_menu"), mx, my):
        return {"FINISHED"}
    if _preview_enabled() and _over_box(layout.get("preview"), mx, my):
        step = 1.12 if event.type == "WHEELUPMOUSE" else (1.0 / 1.12)
        _STATE["preview_zoom"] = max(0.68, min(1.55, float(_STATE.get("preview_zoom") or 1.0) * step))
        _tag()
        return {"FINISHED"}
    delta = -1 if event.type == "WHEELUPMOUSE" else 1
    # A notch moves about half the rows on screen, so a few hundred clips are not a crawl.
    visible = max(4, int(_STATE.get("clip_visible") or 8))
    delta *= max(1, visible // 2)
    if _over_box(layout.get("clip_box"), mx, my):
        _STATE["clip_scroll"] = max(0, _STATE["clip_scroll"] + delta)
    else:
        _STATE["scene_scroll"] = max(0, _STATE["scene_scroll"] + delta)
    _tag()
    return {"FINISHED"}


def _path_present(raw: str) -> bool:
    """True for long BG3 paths that fail the normal 260-character check."""
    if not raw:
        return False
    from .codec.paths import _win_extended, readable_file

    if readable_file(raw) is not None:
        return True
    extended = _win_extended(raw)
    if not extended:
        return False
    return os.path.isdir(extended) or os.path.isfile(extended)


def _explorer_target() -> str:
    """Highlighted clip, then the clip under the pointer, then the open scene folder."""
    for candidate in (
        str(_STATE.get("clip_path") or ""),
        str(_HOVER.get("path") or ""),
    ):
        if candidate and _path_present(candidate):
            return str(Path(candidate))
    data = _INDEX.get("data") or _load_index()
    if not data:
        return ""
    scene = _selected(_filtered(data))
    folder = str((scene or {}).get("dir") or "")
    if folder and _path_present(folder):
        return folder
    return ""


_REVEAL_PS = r"""
$target = $env:GR2LAB_REVEAL
$unpacked = $env:GR2LAB_UNPACKED
$dry = $env:GR2LAB_REVEAL_DRY
$sep = [string][IO.Path]::DirectorySeparatorChar
function Norm([string]$p) {
  if ([string]::IsNullOrWhiteSpace($p)) { return "" }
  try { $p = [IO.Path]::GetFullPath($p) } catch { return "" }
  $p = $p.ToLowerInvariant()
  if ($p.Length -gt 3 -and $p.EndsWith($sep)) { $p = $p.TrimEnd($sep) }
  return $p
}
function IsUnder([string]$child, [string]$parent) {
  if (-not $parent -or -not $child) { return $false }
  if ($child -eq $parent) { return $true }
  $prefix = $parent
  if (-not $prefix.EndsWith($sep)) { $prefix += $sep }
  return $child.StartsWith($prefix)
}
if ([string]::IsNullOrWhiteSpace($target)) { Write-Output "NONE"; exit 1 }
$lookup = $target
if ($lookup.Length -ge 240 -and -not $lookup.StartsWith('\\?\')) { $lookup = '\\?\' + $lookup }
$item = Get-Item -LiteralPath $lookup -ErrorAction SilentlyContinue
if (-not $item) { Write-Output "NONE"; exit 1 }
if ($item.PSIsContainer) {
  $folder = $item.FullName
  $leaf = ""
} else {
  $folder = $item.DirectoryName
  $leaf = $item.Name
}
$folderN = Norm $folder
$unpackedN = Norm $unpacked
$shell = New-Object -ComObject Shell.Application
$best = $null
$bestPath = ""
$bestScore = -1
foreach ($w in @($shell.Windows())) {
  try {
    $exe = [string]$w.FullName
    if ($exe -notlike "*explorer.exe") { continue }
    $p = [string]$w.Document.Folder.Self.Path
  } catch { continue }
  $pn = Norm $p
  if (-not $pn) { continue }
  $exact = ($pn -eq $folderN)
  $windowInUnpacked = [bool]($unpackedN -and (IsUnder $pn $unpackedN))
  $targetInWindow = IsUnder $folderN $pn
  $ok = $exact -or $windowInUnpacked
  if (-not $ok) { continue }
  if ($exact) { $score = 3000000 }
  elseif ($targetInWindow) { $score = 2000000 + $pn.Length }
  else { $score = 1000000 }
  if ($score -gt $bestScore) {
    $bestScore = $score
    $best = $w
    $bestPath = $p
  }
}
if (-not $best) { Write-Output "NONE"; exit 1 }
if ($dry -eq "1") { Write-Output ("REUSED " + $bestPath); exit 0 }
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class Gr2LabWin552 {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
}
"@
try { $hwnd = New-Object IntPtr ([int64]$best.HWND) } catch { $hwnd = [IntPtr]::Zero }
if ($hwnd -ne [IntPtr]::Zero) {
  if ([Gr2LabWin552]::IsIconic($hwnd)) { [void][Gr2LabWin552]::ShowWindow($hwnd, 9) }
  [Gr2LabWin552]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero)
  [void][Gr2LabWin552]::SetForegroundWindow($hwnd)
  [Gr2LabWin552]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
}
$cur = Norm ([string]$best.Document.Folder.Self.Path)
if ($cur -ne $folderN) {
  $best.Navigate($folder)
  for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 50
    try {
      $cur = Norm ([string]$best.Document.Folder.Self.Path)
      if ($cur -eq $folderN) { break }
    } catch {}
  }
}
if ($leaf -and ((Norm ([string]$best.Document.Folder.Self.Path)) -eq $folderN)) {
  try {
    $parsed = $best.Document.Folder.ParseName($leaf)
    if ($parsed) { [void]$best.Document.SelectItem($parsed, 0x1D) }
    else { [void]$best.Document.SelectItem($leaf, 0x1D) }
  } catch {}
}
Write-Output "REUSED"
exit 0
"""


def _reveal_in_open_explorer(path: str, unpacked: str, *, dry: bool = False) -> bool:
    """Select path in an Explorer window already on the unpacked data. False if none is open."""
    if not path:
        return False
    import base64

    encoded = base64.b64encode(_REVEAL_PS.encode("utf-16le")).decode("ascii")
    env = os.environ.copy()
    env["GR2LAB_REVEAL"] = str(path)
    env["GR2LAB_UNPACKED"] = str(unpacked or "")
    env["GR2LAB_REVEAL_DRY"] = "1" if dry else "0"
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-EncodedCommand",
                encoded,
            ],
            capture_output=True,
            text=True,
            timeout=8,
            env=env,
            creationflags=flags,
        )
    except Exception:
        traceback.print_exc()
        return False
    out = proc.stdout or ""
    if "REUSED" not in out and proc.returncode not in (0, 1) and proc.stderr:
        print("gr2lab explorer:", proc.stderr.strip())
    return "REUSED" in out


def _shell_reveal(path: str) -> bool:
    """Open Explorer on ``path``. Long clip paths skip the 260-character check."""
    import ctypes

    params = f'/select,"{path}"'
    try:
        rc = int(ctypes.windll.shell32.ShellExecuteW(None, "open", "explorer.exe", params, None, 1))
    except Exception:
        traceback.print_exc()
        return False
    if rc > 32:
        return True
    print(f"[GR2 LAB] Explorer failed ({rc}): {path}", flush=True)
    return False


def _open_explorer() -> str:
    target = _explorer_target()
    if not target:
        print("[GR2 LAB] Explorer: select a clip first", flush=True)
        return "Explorer: select a clip first"
    path = str(Path(target))
    root = unpacked_root(bpy.context)
    unpacked = str(root) if root else ""
    if _reveal_in_open_explorer(path, unpacked):
        return f"Explorer: {Path(path).name}"
    if _shell_reveal(path):
        return f"Explorer: {Path(path).name}"
    if Path(path).is_file() or _path_present(path):
        folder = str(Path(path).parent) if not os.path.isdir(path) else path
        subprocess.Popen(["explorer", folder])
        return f"Explorer: {Path(folder).name}"
    subprocess.Popen(["explorer", path])
    return f"Explorer: {Path(path).name}"


_GALLERY_COLUMNS = 10
_GALLERY_REPLAY_STEP = 0.04
_GALLERY_GAP = 2.0
_GALLERY_POSE_HZ = 48.0
_GALLERY_PUMP_INTERVAL = 1.0 / 48.0
_GALLERY_TAG_INTERVAL = 1.0 / 48.0
_GALLERY_TRI_BUDGET = 3000
_GALLERY_FK_WORLD_CACHE: Dict[tuple, dict] = {}
_GALLERY_FK_ORDER: List[tuple] = []
_GALLERY_FK_MAX = 640
_GALLERY_BONE_TEX_CACHE: Dict[tuple, object] = {}
_GALLERY_BONE_TEX_ORDER: List[tuple] = []
_GALLERY_BONE_TEX_MAX = 640
_GALLERY_DECODE_MAX_THREADS = 6
_GALLERY_DECODE_QUEUE: List[str] = []
_GALLERY_DECODE_ACTIVE = 0
_GALLERY_DECODE_LOCK = threading.Lock()
_GALLERY_COLLECTION = "GR2LAB_Gallery"
_GALLERY: Dict[str, object] = {
    "batches": {},
    "binds": {},
    "build": [],
    "load": [],
    "items": [],
    "paths": [],
    "stick_queue": [],
    "hover_path": "",
    "last_hover": "",
    "picked_path": "",
    "cancel_over": False,
    "cancel_boxes": {},
    "label_boxes": {},
    "built": 0,
    "cancel": False,
    "modal": False,
    "t0": 0.0,
    "bulk_decode": False,
    "load_t0": 0.0,
    "pose_warming": False,
    "pose_warm_idx": 0,
    "await_load_report": None,
}
_GALLERY_PERF: Dict[str, float] = {}
_GALLERY_PERF_LAST = 0.0


def _gallery_perf_active() -> bool:
    return bool(_GALLERY.get("items"))


def _gallery_perf_inc(name: str, amount: float = 1.0) -> None:
    if not _gallery_perf_active():
        return
    _GALLERY_PERF[name] = float(_GALLERY_PERF.get(name) or 0.0) + float(amount)


def _gallery_perf_add_ms(name: str, ms: float) -> None:
    if not _gallery_perf_active() or ms <= 0.0:
        return
    _GALLERY_PERF[name] = float(_GALLERY_PERF.get(name) or 0.0) + float(ms)


def _gallery_perf_reset() -> None:
    global _GALLERY_PERF_LAST
    _GALLERY_PERF.clear()
    _GALLERY_PERF_LAST = 0.0


def _gallery_clear_pose_caches() -> None:
    _GALLERY_FK_WORLD_CACHE.clear()
    _GALLERY_FK_ORDER.clear()
    _GALLERY_BONE_TEX_CACHE.clear()
    _GALLERY_BONE_TEX_ORDER.clear()


def _gallery_building() -> bool:
    return bool(_GALLERY.get("build"))


def _gallery_stick_ready(path: str) -> bool:
    path = str(path or "")
    if not path:
        return True
    return _stick_mem_get(path) is not None or _stick_load_disk(path) is not None


def _gallery_load_stats() -> dict:
    return _GALLERY.setdefault("load_stats", {})


def _gallery_load_stats_reset() -> None:
    _GALLERY["load_stats"] = {
        "place_ms": 0.0,
        "slot_ms": 0.0,
        "pose_warm_ms": 0.0,
        "sticks_total": 0,
        "sticks_cached_start": 0,
        "sticks_decoded": 0,
    }
    _GALLERY["load_stick_paths"] = []


def _gallery_load_stick_paths(paths: List[str]) -> List[str]:
    seen: set = set()
    ordered: List[str] = []
    for raw in paths:
        path = str(raw or "")
        if not path:
            continue
        key = _path_key(path)
        if not key or key in seen:
            continue
        seen.add(key)
        ordered.append(path)
    return ordered


def _gallery_load_stats_add_ms(name: str, ms: float) -> None:
    if ms <= 0.0:
        return
    stats = _gallery_load_stats()
    stats[name] = float(stats.get(name) or 0.0) + float(ms)


def _gallery_load_stats_inc(name: str, amount: int = 1) -> None:
    stats = _gallery_load_stats()
    stats[name] = int(stats.get(name) or 0) + int(amount)


def _gallery_print_load_summary() -> None:
    if _GALLERY.get("load_summary_printed"):
        return
    if _GALLERY.get("head_bake"):
        _gallery_release_viewport()
        return
    _GALLERY["load_summary_printed"] = True
    _gallery_unpark()
    _gallery_release_viewport()
    stats = _gallery_load_stats()
    t0 = float(_GALLERY.get("load_wall_t0") or 0.0)
    wall = (time.perf_counter() - t0) if t0 > 0.0 else 0.0
    head_s = float(stats.get("head_bake_ms") or 0.0) / 1000.0
    print(
        "[GR2 LAB] load summary "
        f"wall={wall:.1f}s "
        f"head_bake={head_s:.1f}s "
        f"same_body={int(stats.get('same_body') or 0)} "
        f"copy_pair={int(stats.get('copy_pair') or 0)} "
        f"head_cache_hits={int(stats.get('head_bake_skip') or 0)}",
        flush=True,
    )


def _gallery_collect_prewarm_paths(items) -> List[str]:
    ordered: List[str] = []
    seen: set = set()
    for item in list(items or []):
        if not isinstance(item, dict):
            continue
        for raw in (item.get("path"), item.get("partner_path")):
            path = str(raw or "")
            key = _path_key(path)
            if path and key and key not in seen:
                seen.add(key)
                ordered.append(path)
    return ordered


def _prewarm_path_if_needed(path: str) -> None:
    """Pull one GR2's dense doc and pose pack into RAM. Disk hits used to skip this,
    so every Load all unpickled on the import itself.
    """
    from .bridge_blender import _resolve_body_base_for_import

    one = str(path or "").strip()
    if not one:
        return
    body = _resolve_body_base_for_import(
        choice="AUTO",
        bb_hint="",
        prefs_base="",
        source_gr2=one,
        explicit_choice=False,
    )
    _pipeline_touch(one, body, pack=True)
    time.sleep(0.02)


def _start_gallery_prewarm(paths: List[str]) -> None:
    unique = list(paths or [])
    if not unique:
        _GALLERY["prewarm_done"] = True
        _GALLERY["prewarm_left"] = 0
        _GALLERY["prewarm_total"] = 0
        return
    _GALLERY["prewarm_done"] = False
    _GALLERY["prewarm_total"] = len(unique)
    _GALLERY["prewarm_left"] = len(unique)

    def _run() -> None:
        try:
            for path in unique:
                if _GALLERY.get("cancel"):
                    break
                _prewarm_path_if_needed(path)
                _GALLERY["prewarm_left"] = max(
                    0, int(_GALLERY.get("prewarm_left") or 0) - 1
                )
        finally:
            _GALLERY["prewarm_done"] = True

    threading.Thread(target=_run, name="gr2lab-gallery-prewarm", daemon=True).start()


def _gallery_load_snapshot(note: str) -> None:
    """Console line while the row is still spawning, not only after it finishes."""
    stats = _gallery_load_stats()
    stick_paths = list(_GALLERY.get("load_stick_paths") or [])
    total_sticks = int(stats.get("sticks_total") or len(stick_paths))
    cached_now = sum(1 for path in stick_paths if _stick_mem_get(path) is not None)
    decoded = int(stats.get("sticks_decoded") or 0)
    bodies = len(_GALLERY.get("items") or [])
    left = len(_GALLERY.get("build") or [])
    done = int(_GALLERY.get("built") or 0)
    elapsed = time.perf_counter() - float(_GALLERY.get("load_t0") or time.perf_counter())
    place_s = float(stats.get("place_ms") or 0.0) / 1000.0
    shell_s = float(stats.get("shell_ms") or 0.0) / 1000.0
    gpu_s = float(stats.get("gpu_ms") or 0.0) / 1000.0
    slot_s = float(stats.get("slot_ms") or 0.0) / 1000.0
    print(
        f"[GR2 LAB] {note}: clips {done} placed, {left} left, {bodies} bodies, {elapsed:.1f}s  "
        f"meshes {place_s:.1f}s (shell {shell_s:.1f}s, gpu {gpu_s:.1f}s)  slots {slot_s:.1f}s  "
        f"sticks {cached_now}/{total_sticks} ready (+{decoded} decoded)",
        flush=True,
    )


def _gallery_load_print_ready(bodies: int, primaries: int, elapsed: float) -> None:
    stats = _gallery_load_stats()
    stick_paths = list(_GALLERY.get("load_stick_paths") or [])
    cached_now = sum(1 for path in stick_paths if _stick_mem_get(path) is not None)
    total_sticks = int(stats.get("sticks_total") or len(stick_paths))
    cached_start = int(stats.get("sticks_cached_start") or 0)
    decoded = int(stats.get("sticks_decoded") or 0)
    pending = max(0, total_sticks - cached_now)
    place_s = float(stats.get("place_ms") or 0.0) / 1000.0
    gpu_s = float(stats.get("gpu_ms") or 0.0) / 1000.0
    slot_s = float(stats.get("slot_ms") or 0.0) / 1000.0
    pose_s = float(stats.get("pose_warm_ms") or 0.0) / 1000.0
    accounted = place_s + slot_s + pose_s
    other_s = max(0.0, elapsed - accounted)
    print(
        f"[GR2 LAB] Gallery ready: {bodies} bodies ({primaries} clips) in {elapsed:.1f}s",
        flush=True,
    )
    print(
        f"  spawn meshes {place_s:.1f}s (gpu {gpu_s:.1f}s)  |  center slots {slot_s:.1f}s  |  "
        f"pose ramp {pose_s:.1f}s  |  other ~{other_s:.1f}s (decode wait + redraw)",
        flush=True,
    )
    print(
        f"  sticks: {cached_start}/{total_sticks} cached at start, "
        f"+{decoded} decoded on {_GALLERY_DECODE_MAX_THREADS} threads, "
        f"{pending} still loading (meshes use bind pose until ready)",
        flush=True,
    )


def _gallery_decode_redraw() -> None:
    _tag()
    return None


def _gallery_decode_worker() -> None:
    global _GALLERY_DECODE_ACTIVE, _GALLERY_DECODE_QUEUE
    touched = False
    try:
        while _ALIVE:
            with _GALLERY_DECODE_LOCK:
                path = ""
                keep: List[str] = []
                for candidate in _GALLERY_DECODE_QUEUE:
                    if _stick_mem_get(candidate) or _stick_load_disk(candidate):
                        continue
                    if not path:
                        path = candidate
                    else:
                        keep.append(candidate)
                _GALLERY_DECODE_QUEUE = keep
            if not path:
                break
            try:
                data, err = build_stick_preview_data(
                    path, quick=True, quiet=True, with_partner=False
                )
            except Exception:
                traceback.print_exc()
                continue
            if data and not err:
                _remember_stick(path, data)
                if _GALLERY.get("bulk_decode"):
                    _gallery_load_stats_inc("sticks_decoded")
                touched = True
    finally:
        with _GALLERY_DECODE_LOCK:
            _GALLERY_DECODE_ACTIVE = max(0, int(_GALLERY_DECODE_ACTIVE) - 1)
        if touched and bpy is not None:
            try:
                if not bpy.app.timers.is_registered(_gallery_decode_redraw):
                    bpy.app.timers.register(_gallery_decode_redraw, first_interval=0.0)
            except Exception:
                traceback.print_exc()


def _gallery_decode_enqueue(paths: List[str]) -> None:
    """Decode several GR2 sticks at once on background threads."""
    global _GALLERY_DECODE_ACTIVE
    pending: List[str] = []
    with _GALLERY_DECODE_LOCK:
        seen = {_path_key(item) for item in _GALLERY_DECODE_QUEUE}
        for raw in paths:
            path = str(raw or "")
            if not path or _stick_mem_get(path) or _stick_load_disk(path):
                continue
            key = _path_key(path)
            if not key or key in seen:
                continue
            seen.add(key)
            _GALLERY_DECODE_QUEUE.append(path)
            pending.append(path)
        active = int(_GALLERY_DECODE_ACTIVE)
        slots = max(0, _GALLERY_DECODE_MAX_THREADS - active)
        spawn = min(slots, len(_GALLERY_DECODE_QUEUE))
        for _ in range(spawn):
            _GALLERY_DECODE_ACTIVE += 1
            threading.Thread(
                target=_gallery_decode_worker,
                name="gr2lab-gallery-decode",
                daemon=True,
            ).start()


def _gallery_decode_reset() -> None:
    global _GALLERY_DECODE_ACTIVE
    with _GALLERY_DECODE_LOCK:
        _GALLERY_DECODE_QUEUE.clear()
        _GALLERY_DECODE_ACTIVE = 0


def _gallery_pose_hz() -> float:
    count = len(_GALLERY.get("items") or [])
    if count > 44:
        return 36.0
    if count > 30:
        return 44.0
    return _GALLERY_POSE_HZ


def _gallery_perf_maybe_report() -> None:
    """Once per second: why the gallery row is heavy (console for tuning)."""
    global _GALLERY_PERF_LAST
    if not _GALLERY_GPU_PROFILER:
        return
    if not _gallery_perf_active():
        _gallery_perf_reset()
        return
    now = time.perf_counter()
    if _GALLERY_PERF_LAST <= 0.0:
        _GALLERY_PERF_LAST = now
        return
    if now - _GALLERY_PERF_LAST < 1.0:
        return
    window = max(1.0e-3, now - _GALLERY_PERF_LAST)
    _GALLERY_PERF_LAST = now

    items = len(_GALLERY.get("items") or [])
    primaries = sum(1 for it in _GALLERY.get("items") or [] if not it.get("partner"))
    pumps = int(_GALLERY_PERF.get("pumps") or 0)
    pose_new = int(_GALLERY_PERF.get("pose_changed") or 0)
    pose_skip = int(_GALLERY_PERF.get("pose_skipped") or 0)
    tex_new = int(_GALLERY_PERF.get("bone_tex_new") or 0)
    tex_reuse = int(_GALLERY_PERF.get("bone_tex_reuse") or 0)
    fk_new = int(_GALLERY_PERF.get("fk_new") or 0)
    pump_ms = float(_GALLERY_PERF.get("pump_ms") or 0.0)
    draws = int(_GALLERY_PERF.get("draw_calls") or 0)
    tris = int(_GALLERY_PERF.get("draw_tris") or 0)
    draw_frames = max(1, int(_GALLERY_PERF.get("draw_frames") or 0))
    draw_ms = float(_GALLERY_PERF.get("draw_ms") or 0.0)
    skip_off = int(_GALLERY_PERF.get("draw_skip_offscreen") or 0)
    skip_tiny = int(_GALLERY_PERF.get("draw_skip_tiny") or 0)
    skip_bone = int(_GALLERY_PERF.get("draw_skip_nobone") or 0)
    hud_frames = max(0, int(_GALLERY_PERF.get("hud_frames") or 0))
    hud_ms = float(_GALLERY_PERF.get("hud_ms") or 0.0)
    hud_labels = int(_GALLERY_PERF.get("hud_labels") or 0)
    tags = int(_GALLERY_PERF.get("redraw_tags") or 0)
    tris_per_sec = tris / window
    draws_per_sec = draws / window

    lines = [
        f"[GR2 LAB gallery gpu] {window:.1f}s  row={items} bodies ({primaries} clips)",
        (
            f"  CPU pose pump: {pumps}x  {pump_ms / max(1, pumps):.1f}ms avg  "
            f"pose updates {pose_new / window:.0f}/s  skipped {pose_skip / window:.0f}/s  "
            f"FK builds {fk_new / window:.0f}/s"
        ),
        (
            f"  CPU bone textures: {tex_new / window:.0f} new uploads/s  "
            f"{tex_reuse / window:.0f} reused (same pose step)"
        ),
        (
            f"  GPU mesh draws: {draws_per_sec:.0f}/s  ~{tris_per_sec / 1.0e6:.2f}M tris/s  "
            f"{draw_ms / draw_frames:.2f}ms per POST_VIEW pass"
        ),
        (
            f"  GPU culled: {skip_off / draw_frames:.0f} off-screen/pass  "
            f"{skip_tiny / draw_frames:.0f} sub-5px/pass  {skip_bone / draw_frames:.0f} not ready/pass"
        ),
        (
            f"  CPU HUD (names+buttons): {hud_labels / max(1, hud_frames):.0f} labels/pass  "
            f"{hud_ms / max(1, hud_frames):.2f}ms per POST_PIXEL pass"
        ),
        f"  Viewport redraw requests: {tags / window:.0f}/s  (each retriggers draw+HUD)",
    ]
    if tris_per_sec > 2.0e6:
        lines.append(
            "  >> likely GPU bound: skinned fresnel meshes (4 bone fetches/vert + dFdx rim)"
        )
    if tex_new > pumps * primaries * 0.5 and pumps > 0:
        lines.append(
            "  >> likely CPU bound: too many new bone GPU textures (one per body per pose step)"
        )
    if hud_ms / max(1, hud_frames) > 2.0 and hud_frames > 0:
        lines.append(
            "  >> likely CPU bound: many blf name tablets per frame"
        )
    if tags > 28:
        lines.append(
            "  >> likely CPU bound: viewport tagging too often (limits idle frames)"
        )
    for line in lines:
        print(line, flush=True)
    _GALLERY_PERF.clear()


def _gallery_slot(index: int, count: Optional[int] = None, centered: Optional[bool] = None) -> Tuple[float, float, float]:
    """First line runs along Y. The next line steps on X. Ten per line, 2 m apart.

    Center puts that block around the origin. Off, it still starts at the corner.
    """
    along = int(index) % _GALLERY_COLUMNS
    row = int(index) // _GALLERY_COLUMNS
    x = row * _GALLERY_GAP
    y = along * _GALLERY_GAP
    use_center = _browser_center_parent() if centered is None else bool(centered)
    if use_center:
        n = count
        if not n:
            n = len(_GALLERY.get("paths") or [])
        if not n:
            n = int(index) + 1
        cols = min(int(n), _GALLERY_COLUMNS)
        rows = (int(n) + _GALLERY_COLUMNS - 1) // _GALLERY_COLUMNS
        x -= (rows - 1) * _GALLERY_GAP * 0.5
        y -= (cols - 1) * _GALLERY_GAP * 0.5
    return (x, y, 0.0)


def _gallery_matches_slots(centered: bool) -> bool:
    """True when each pair already sits on the centered (or corner) marks."""
    items = [item for item in list(_GALLERY.get("items") or []) if item.get("matrix") is not None]
    if not items:
        return False
    groups: Dict[int, List[dict]] = {}
    for item in items:
        groups.setdefault(int(item.get("index") or 0), []).append(item)
    count = len(_GALLERY.get("paths") or []) or len(groups)
    for index, group in groups.items():
        slot = Vector(_gallery_slot(index, count, centered=centered))
        loc = Vector((0.0, 0.0, 0.0))
        for item in group:
            loc += item["matrix"].translation
        loc /= float(len(group))
        if (Vector((loc.x, loc.y, 0.0)) - Vector((slot.x, slot.y, 0.0))).length > 0.35:
            return False
    return True


def _gallery_apply_center() -> None:
    """Rebuild the row around the origin, with each pair sharing its mark.

    The old slide only moved root points, so partners stayed a few meters
    off to one side and the block still read as a corner grid.
    """
    items = [item for item in list(_GALLERY.get("items") or []) if item.get("matrix") is not None]
    legacy = _GALLERY.pop("center_shift", None)
    if not items:
        return
    # Older builds stored one root slide. Peel it off before measuring pair gaps.
    applied = legacy if isinstance(legacy, (tuple, list)) and len(legacy) >= 2 else (0.0, 0.0, 0.0)
    applied_v = Vector((float(applied[0]), float(applied[1]), 0.0))
    if applied_v.length_squared > 1.0e-8:
        undo = Matrix.Translation(-applied_v)
        for item in items:
            item["matrix"] = undo @ item["matrix"]
    groups: Dict[int, List[dict]] = {}
    for item in items:
        groups.setdefault(int(item.get("index") or 0), []).append(item)
    count = len(_GALLERY.get("paths") or []) or len(groups)
    for index, group in groups.items():
        primary = next((it for it in group if not it.get("partner")), None)
        partner = next((it for it in group if it.get("partner")), None)
        delta = Vector((0.0, 0.0, 0.0))
        if primary is not None and partner is not None:
            delta = partner["matrix"].translation - primary["matrix"].translation
        slot = Vector(_gallery_slot(index, count))
        for item in group:
            facing = _gallery_rotation_only(item["matrix"])
            if item.get("partner"):
                offset = delta * 0.5 if _browser_center_parent() else delta
            elif partner is not None and _browser_center_parent():
                offset = delta * -0.5
            else:
                offset = Vector((0.0, 0.0, 0.0))
            item["matrix"] = Matrix.Translation(slot + offset) @ facing
            loc = item["matrix"].translation
            item["slot"] = (float(loc.x), float(loc.y), 0.0)
    _tag()


def _listed_clip_paths() -> List[str]:
    """GR2 files in the clip list, search hits included."""
    return [str(entry.get("path") or "") for entry in _browser_clip_entries() if entry.get("path")]


def _gallery_collection():
    col = bpy.data.collections.get(_GALLERY_COLLECTION)
    if col is None:
        col = bpy.data.collections.new(_GALLERY_COLLECTION)
    col.hide_render = True
    scene = bpy.context.scene
    if scene is not None and col.name not in scene.collection.children:
        scene.collection.children.link(col)
    return col


def _clear_gallery(keep_pose: bool = False) -> None:
    _GALLERY["built"] = 0
    _GALLERY["cancel"] = True
    _GALLERY["pose_warming"] = False
    if bpy is not None:
        try:
            bpy.app.timers.unregister(_pump_gallery_build)
        except Exception:
            pass
    _GALLERY["batches"] = {}
    _GALLERY["binds"] = {}
    _GALLERY["build"] = []
    _GALLERY["items"] = []
    _GALLERY["paths"] = []
    _GALLERY["stick_queue"] = []
    _GALLERY["bulk_decode"] = False
    _GALLERY["center_shift"] = (0.0, 0.0, 0.0)
    _GALLERY["facings"] = None
    _GALLERY["label_cache"] = {}
    _GALLERY["hover_path"] = ""
    _GALLERY["last_hover"] = ""
    _GALLERY["picked_path"] = ""
    _GALLERY["cancel_over"] = False
    _GALLERY["cancel_boxes"] = {}
    _GALLERY["label_boxes"] = {}
    _GALLERY["generate_over"] = ""
    _GALLERY["generate_mode"] = ""
    _GALLERY["generate_boxes"] = {}
    _GALLERY["banner_over"] = ""
    _GALLERY["banner_boxes"] = {}
    _GALLERY.pop("plaque_follow", None)
    _GALLERY.pop("plaque_hold", None)
    _GALLERY["plaque_lock"] = False
    _GALLERY["plaque_near"] = False
    _GALLERY["plaque_bridge"] = {}
    _gallery_perf_reset()
    _gallery_load_stats_reset()
    if not keep_pose:
        _gallery_clear_pose_caches()
        _GALLERY["pose_at_spawn"] = False
    _gallery_decode_reset()
    _GALLERY["binds"] = {}
    _GALLERY["rest_tex"] = {}
    _GALLERY.pop("_pose_now", None)
    if bpy is not None:
        try:
            bpy.app.timers.unregister(_pump_gallery_anim)
        except Exception:
            pass
        for obj in list(bpy.data.objects):
            if obj.get("gr2lab_gallery") or obj.name == "GR2LAB_Gallery" or obj.name.startswith("GR2LAB_Holo_"):
                mesh = obj.data if getattr(obj, "type", "") == "MESH" else None
                bpy.data.objects.remove(obj, do_unlink=True)
                if mesh is not None and getattr(mesh, "users", 1) == 0:
                    bpy.data.meshes.remove(mesh)
    col = bpy.data.collections.get(_GALLERY_COLLECTION) if bpy is not None else None
    if col is None:
        return
    for obj in list(col.objects):
        mesh = obj.data if getattr(obj, "type", "") == "MESH" else None
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh is not None and getattr(mesh, "users", 1) == 0:
            bpy.data.meshes.remove(mesh)
    try:
        bpy.data.collections.remove(col)
    except Exception:
        pass


def _gallery_material():
    mat = bpy.data.materials.get("GR2LAB_GalleryHolo")
    if mat is not None:
        return mat
    mat = bpy.data.materials.new("GR2LAB_GalleryHolo")
    try:
        mat.use_nodes = True
        try:
            mat.surface_render_method = "BLENDED"
        except Exception:
            pass
        try:
            mat.blend_method = "BLEND"
        except Exception:
            pass
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()
        out = nodes.new("ShaderNodeOutputMaterial")
        emit = nodes.new("ShaderNodeEmission")
        emit.inputs[0].default_value = (0.55, 0.82, 1.0, 1.0)
        emit.inputs[1].default_value = 2.0
        trans = nodes.new("ShaderNodeBsdfTransparent")
        facing = nodes.new("ShaderNodeLayerWeight")
        power = nodes.new("ShaderNodeMath")
        power.operation = "POWER"
        power.inputs[1].default_value = 1.4
        mix = nodes.new("ShaderNodeMixShader")
        links.new(facing.outputs[0], power.inputs[0])
        links.new(power.outputs[0], mix.inputs[0])
        links.new(trans.outputs[0], mix.inputs[1])
        links.new(emit.outputs[0], mix.inputs[2])
        links.new(mix.outputs[0], out.inputs[0])
    except Exception:
        bpy.data.materials.remove(mat)
        raise
    return mat


def _gallery_partner_path(path: str, paths: List[str]) -> str:
    """Other body on this beat, used when Scene is on."""
    beat = _stick_beat(Path(path).name)
    role = _role(Path(path).name)
    if not beat or role not in {"player", "partner"}:
        return ""
    want = "partner" if role == "player" else "player"
    for other in paths:
        if other == path:
            continue
        if _stick_beat(Path(other).name) == beat and _role(Path(other).name) == want:
            return str(other)
    return ""


def _mat_translation(mat) -> Tuple[float, float, float]:
    return (float(mat[0, 3]), float(mat[1, 3]), float(mat[2, 3]))


def _stick_bone_shell(path: str):
    """Bone sticks for a clip that has no body-kit mesh (bear, owlbear).

    Rest is the clip's first pose, in the same Y-up space later poses use,
    so the gallery skin stands it up with the usual placement matrix.
    """
    import numpy as np

    data = _stick_mem_get(path) or _stick_load_disk(path)
    if not data or not (data.get("poses") or []):
        return None
    key = f"stick|{_path_key(path)}"
    cached = _DRAG_SHELLS.get(key)
    if cached is not None:
        return cached or None
    worlds = _stick_fk_worlds(data, 0.0, "")
    order: List[str] = []
    for name in data.get("bone_order") or list(worlds.keys()):
        text = str(name)
        if text.startswith("P:") or text not in worlds:
            continue
        order.append(text)
    if len(order) < 2:
        _DRAG_SHELLS[key] = {}
        return None
    index = {name: i for i, name in enumerate(order)}
    rest = [np.array(worlds[name], dtype=np.float64) for name in order]
    raw_parents = data.get("parents") or {}
    parents: Dict[str, str] = {}
    for name in order:
        parent = str(raw_parents.get(name) or "")
        parents[name] = parent if parent in index else ""
    cos: List[Tuple[float, float, float]] = []
    ids: List[Tuple[float, float, float, float]] = []
    wts: List[Tuple[float, float, float, float]] = []
    tris: List[Tuple[int, int, int]] = []

    def _vert(co: Tuple[float, float, float], bone_i: int) -> int:
        cos.append(co)
        ids.append((float(bone_i), 0.0, 0.0, 0.0))
        wts.append((1.0, 0.0, 0.0, 0.0))
        return len(cos) - 1

    def _tube(a: Tuple[float, float, float], b: Tuple[float, float, float], bone_i: int) -> None:
        ax, ay, az = a
        bx, by, bz = b
        dx, dy, dz = bx - ax, by - ay, bz - az
        length = math.sqrt(dx * dx + dy * dy + dz * dz)
        if length < 0.004:
            return
        radius = min(0.03, max(0.008, length * 0.07))
        ux, uy, uz = dx / length, dy / length, dz / length
        helper = (1.0, 0.0, 0.0) if abs(ux) < 0.9 else (0.0, 1.0, 0.0)
        sx = uy * helper[2] - uz * helper[1]
        sy = uz * helper[0] - ux * helper[2]
        sz = ux * helper[1] - uy * helper[0]
        sl = math.sqrt(sx * sx + sy * sy + sz * sz) or 1.0
        sx, sy, sz = sx / sl * radius, sy / sl * radius, sz / sl * radius
        tx = uy * sz - uz * sy
        ty = uz * sx - ux * sz
        tz = ux * sy - uy * sx
        ring_a = []
        ring_b = []
        for cx, cy, cz in ((sx, sy, sz), (tx, ty, tz), (-sx, -sy, -sz), (-tx, -ty, -tz)):
            ring_a.append(_vert((ax + cx, ay + cy, az + cz), bone_i))
            ring_b.append(_vert((bx + cx, by + cy, bz + cz), bone_i))
        for i in range(4):
            j = (i + 1) % 4
            tris.append((ring_a[i], ring_b[i], ring_b[j]))
            tris.append((ring_a[i], ring_b[j], ring_a[j]))

    for name in order:
        parent = parents[name]
        if not parent:
            continue
        _tube(_mat_translation(worlds[parent]), _mat_translation(worlds[name]), index[parent])
    if not tris:
        _DRAG_SHELLS[key] = {}
        return None
    mesh = {
        "co": np.asarray(cos, dtype=np.float32),
        "ids": np.asarray(ids, dtype=np.float32),
        "wts": np.asarray(wts, dtype=np.float32),
        "tris": np.asarray(tris, dtype=np.int32),
    }
    shell = _finish_preview_shell(order, index, rest, parents, order, [mesh])
    shell["stick"] = True
    _DRAG_SHELLS[key] = shell
    print(f"[GR2 LAB] stick body {Path(path).name} {len(order)} bones", flush=True)
    return shell


def _gallery_shell(path: str):
    family, akelka = _clip_base(path)
    if family:
        # Same shells startup already loaded. A lower budget misses that cache and re-imports each race.
        shell = _shell_from_kit(family, akelka, quiet=True)
        if shell and shell.get("meshes"):
            return shell
    return _stick_bone_shell(path)


def _gallery_pose_arrays(shell, worlds: Dict[str, object]):
    """Bone-space triangles, the same space as the drag hologram."""
    import numpy as np

    parts = _shell_posed(shell, worlds or {})
    if not parts:
        return None
    pos = np.ascontiguousarray(np.concatenate([item[0] for item in parts]), dtype=np.float32)
    nrm = np.ascontiguousarray(np.concatenate([item[1] for item in parts]), dtype=np.float32)
    return pos, nrm


def _gallery_body_matrix(path: str, partner: bool) -> Matrix:
    """Center / Scene placement for one body, with no viewing-row shift."""
    primary = None
    partner_mat = None
    if _browser_center_parent():
        primary, partner_mat = _stick_pair_slot_matrices(path)
    mat = partner_mat if partner else primary
    if mat is None:
        mat = _hologram_loose_matrix(partner, 0.9)
    return mat


def _gallery_rotation_only(mat: Matrix) -> Matrix:
    """Pose facing for the row. Cinematic translation stays in the real drop."""
    loc, rot, scale = mat.decompose()
    return Matrix.LocRotScale(Vector((0.0, 0.0, 0.0)), rot, scale)


def _gallery_world(path: str, index: int, partner: bool) -> Matrix:
    """Grid slot plus this clip's facing. Center shares the mark between a pair."""
    slot = Vector(_gallery_slot(index))
    had = _stick_plan_cached(path) is not None
    mark = time.perf_counter()
    primary = _gallery_body_matrix(path, False)
    if not had:
        _gallery_load_stats_add_ms("slot_ms", (time.perf_counter() - mark) * 1000.0)
    paths = list(_GALLERY.get("paths") or [])
    partner_path = _gallery_partner_path(path, paths) if _browser_whole_scene() else ""
    other = _gallery_body_matrix(path, True) if partner or partner_path else None
    delta = (other.translation - primary.translation) if other is not None else Vector((0.0, 0.0, 0.0))
    if partner:
        offset = delta * 0.5 if _browser_center_parent() else delta
        src = other if other is not None else primary
        return Matrix.Translation(slot + offset) @ _gallery_rotation_only(src)
    if partner_path and _browser_center_parent():
        offset = delta * -0.5
    else:
        offset = Vector((0.0, 0.0, 0.0))
    return Matrix.Translation(slot + offset) @ _gallery_rotation_only(primary)


def _gallery_bone_tex(mats):
    """One RGBA column per matrix column. Tiny upload, the mesh stays put."""
    import gpu
    import numpy as np

    cols = np.ascontiguousarray(np.transpose(mats, (0, 2, 1)).reshape(-1, 4), dtype=np.float32)
    buf = gpu.types.Buffer("FLOAT", cols.shape, cols.reshape(-1))
    return gpu.types.GPUTexture((int(cols.shape[0]), 1), format="RGBA32F", data=buf)


def _gallery_fk_worlds_cached(fk_key: tuple, stick: dict, clock: float, prefix: str) -> Dict[str, object]:
    hit = _GALLERY_FK_WORLD_CACHE.get(fk_key)
    if hit is not None:
        return hit
    worlds = _stick_fk_worlds(stick, clock, prefix)
    _GALLERY_FK_WORLD_CACHE[fk_key] = worlds
    _GALLERY_FK_ORDER.append(fk_key)
    while len(_GALLERY_FK_ORDER) > _GALLERY_FK_MAX:
        old = _GALLERY_FK_ORDER.pop(0)
        _GALLERY_FK_WORLD_CACHE.pop(old, None)
    _gallery_perf_inc("fk_new")
    return worlds


def _gallery_bone_tex_cached(cache_key: tuple, mats) -> object:
    hit = _GALLERY_BONE_TEX_CACHE.get(cache_key)
    if hit is not None:
        _gallery_perf_inc("bone_tex_reuse")
        return hit
    tex = _gallery_bone_tex(mats)
    _GALLERY_BONE_TEX_CACHE[cache_key] = tex
    _GALLERY_BONE_TEX_ORDER.append(cache_key)
    while len(_GALLERY_BONE_TEX_ORDER) > _GALLERY_BONE_TEX_MAX:
        old = _GALLERY_BONE_TEX_ORDER.pop(0)
        _GALLERY_BONE_TEX_CACHE.pop(old, None)
    _gallery_perf_inc("bone_tex_new")
    return tex


def _gallery_item_bone_tex(item: dict, mats) -> object:
    """One GPU texture per hologram; refresh columns when the pose step changes."""
    import numpy as np

    cols = np.ascontiguousarray(np.transpose(mats, (0, 2, 1)).reshape(-1, 4), dtype=np.float32)
    ncol = int(cols.shape[0])
    tex = item.get("bones_tex")
    if tex is not None and int(item.get("bones_tex_cols") or 0) == ncol:
        buf = gpu.types.Buffer("FLOAT", cols.shape, cols.reshape(-1))
        item["bones_tex"] = gpu.types.GPUTexture((ncol, 1), format="RGBA32F", data=buf)
        _gallery_perf_inc("bone_tex_reuse")
        return item["bones_tex"]
    buf = gpu.types.Buffer("FLOAT", cols.shape, cols.reshape(-1))
    tex = gpu.types.GPUTexture((ncol, 1), format="RGBA32F", data=buf)
    item["bones_tex"] = tex
    item["bones_tex_cols"] = ncol
    _gallery_perf_inc("bone_tex_new")
    return tex


def _gallery_pose_clock(stick: dict, t0: float) -> float:
    """Quantize clip time so many holograms share the same bone upload."""
    if not stick or not stick.get("poses"):
        return 0.0
    duration = float(stick.get("duration_sec") or stick.get("duration") or 0.0)
    if duration <= 0.0:
        return 0.0
    now = float(_GALLERY.get("_pose_now") or time.perf_counter())
    clock = (now - t0) % duration
    step = 1.0 / _gallery_pose_hz()
    return round(clock / step) * step


def _gallery_pose_cache_key(item: dict, clock: float) -> Tuple[str, str, float, str, int]:
    path = str(item.get("path") or "")
    family, akelka = _clip_base(path)
    return (
        str(item.get("stick") or ""),
        str(item.get("prefix") or ""),
        float(clock),
        str(family or ""),
        int(akelka),
    )


def _gallery_item_on_screen(item, region, rv3d) -> bool:
    """Skip draw when the whole hologram is off-screen."""
    bind = item.get("bind")
    mat = item.get("matrix")
    if bind is None or mat is None or region is None or rv3d is None:
        return True
    mn = bind.get("mn")
    mx = bind.get("mx")
    if mn is None or mx is None:
        return True
    margin = 48.0
    rw = float(region.width) + margin
    rh = float(region.height) + margin
    for ix in (0, 1):
        for iy in (0, 1):
            for iz in (0, 1):
                corner = mat @ Vector((float(mx[0] if ix else mn[0]), float(mx[1] if iy else mn[1]), float(mx[2] if iz else mn[2])))
                try:
                    xy = location_3d_to_region_2d(region, rv3d, corner)
                except Exception:
                    return True
                if xy is None:
                    continue
                if -margin <= float(xy[0]) <= rw and -margin <= float(xy[1]) <= rh:
                    return True
    return False


def _gallery_item_screen_span(item, region, rv3d) -> Tuple[float, float]:
    """Rough screen width and height of one hologram in pixels."""
    bind = item.get("bind")
    mat = item.get("matrix")
    if bind is None or mat is None or region is None or rv3d is None:
        return 0.0, 0.0
    mn = bind.get("mn")
    mx = bind.get("mx")
    if mn is None or mx is None:
        return 0.0, 0.0
    xs = []
    ys = []
    for ix in (0, 1):
        for iy in (0, 1):
            for iz in (0, 1):
                corner = mat @ Vector((float(mx[0] if ix else mn[0]), float(mx[1] if iy else mn[1]), float(mx[2] if iz else mn[2])))
                try:
                    xy = location_3d_to_region_2d(region, rv3d, corner)
                except Exception:
                    continue
                if xy is None:
                    continue
                xs.append(float(xy[0]))
                ys.append(float(xy[1]))
    if not xs:
        return 0.0, 0.0
    return max(xs) - min(xs), max(ys) - min(ys)


def _gallery_outward_tris(co, tris):
    """Flip a piece whose triangles face the centroid. Bodies disagree per mesh."""
    import numpy as np

    co = np.asarray(co, dtype=np.float64)
    tris = np.asarray(tris)
    if len(co) == 0 or len(tris) == 0:
        return tris
    centroid = co.mean(axis=0)
    step = max(1, len(tris) // 64)
    sample = tris[::step]
    v0 = co[sample[:, 0]]
    v1 = co[sample[:, 1]]
    v2 = co[sample[:, 2]]
    normal = np.cross(v1 - v0, v2 - v0)
    center = (v0 + v1 + v2) / 3.0
    if float(np.sum(normal * (center - centroid))) < 0.0:
        return tris[:, [0, 2, 1]]
    return tris


def _gallery_bind_gpu(shell: dict):
    """Rest-pose triangles and weights, uploaded once per body."""
    import numpy as np
    from gpu.types import GPUBatch, GPUVertBuf, GPUVertFormat

    key = id(shell)
    binds = _GALLERY.setdefault("binds", {})
    hit = binds.get(key)
    if hit:
        return hit
    mark = time.perf_counter()
    pos_parts = []
    idx_parts = []
    wgt_parts = []
    for mesh in shell.get("meshes") or []:
        tris = _gallery_outward_tris(mesh["co"], mesh["tris"])
        pos_parts.append(np.asarray(mesh["co"], dtype=np.float32)[tris].reshape(-1, 3))
        idx_parts.append(np.asarray(mesh["ids"], dtype=np.float32)[tris].reshape(-1, 4))
        wgt_parts.append(np.asarray(mesh["wts"], dtype=np.float32)[tris].reshape(-1, 4))
    if not pos_parts:
        return None
    pos = np.ascontiguousarray(np.concatenate(pos_parts))
    bids = np.ascontiguousarray(np.concatenate(idx_parts))
    bwgt = np.ascontiguousarray(np.concatenate(wgt_parts))
    fmt = GPUVertFormat()
    fmt.attr_add(id="pos", comp_type="F32", len=3, fetch_mode="FLOAT")
    fmt.attr_add(id="bids", comp_type="F32", len=4, fetch_mode="FLOAT")
    fmt.attr_add(id="bwgt", comp_type="F32", len=4, fetch_mode="FLOAT")
    vbo = GPUVertBuf(len=len(pos), format=fmt)
    vbo.attr_fill("pos", pos)
    vbo.attr_fill("bids", bids)
    vbo.attr_fill("bwgt", bwgt)
    slot = {
        "batch": GPUBatch(type="TRIS", buf=vbo),
        "count": int(len(pos)),
        "mn": pos.min(axis=0) - 0.45,
        "mx": pos.max(axis=0) + 0.45,
        "bones": int(len(shell.get("rest") or [])),
    }
    binds[key] = slot
    _gallery_load_stats_add_ms("gpu_ms", (time.perf_counter() - mark) * 1000.0)
    return slot


def _gallery_queue_stick(path: str) -> None:
    """Decode this clip without cancelling the one already in flight."""
    path = str(path or "")
    if not path or _stick_mem_get(path) or _stick_load_disk(path):
        return
    queue = _GALLERY.setdefault("stick_queue", [])
    if path not in queue:
        queue.append(path)


def _gallery_prefetch_sticks(paths: List[str]) -> None:
    """Background stick decode for the gallery row (does not steal hover preview)."""
    merged: List[str] = []
    seen: set = set()
    for raw in list(_PREFETCH.get("queue") or []):
        key = _path_key(str(raw))
        if key and key not in seen:
            seen.add(key)
            merged.append(str(raw))
    for raw in paths:
        path = str(raw or "")
        if not path or _stick_mem_get(path) or _stick_load_disk(path):
            continue
        key = _path_key(path)
        if not key or key in seen:
            continue
        seen.add(key)
        merged.append(path)
    if not merged:
        return
    _PREFETCH["queue"] = merged
    _ensure_stick_prefetch()


def _gallery_pump_sticks() -> None:
    queue = [
        path
        for path in list(_GALLERY.get("stick_queue") or [])
        if not _stick_mem_get(path) and not _stick_load_disk(path)
    ]
    _GALLERY["stick_queue"] = queue
    if not queue or _DRAG.get("active"):
        return
    _gallery_prefetch_sticks(queue)


def _gallery_ensure_rest_bones(item: dict) -> None:
    """Bind-pose GPU texture so the mesh draws before stick decode finishes."""
    if item.get("bones_tex") is not None:
        return
    shell = item.get("shell")
    if not shell:
        return
    shared = _GALLERY.setdefault("rest_tex", {})
    key = id(shell)
    tex = shared.get(key)
    if tex is None:
        tex = _gallery_bone_tex(_shell_delta_mats(shell, {}))
        shared[key] = tex
    item["bones_tex"] = tex


def _gallery_apply_pose(item: dict) -> bool:
    """Pose one hologram. FK and bone GPU textures are shared across the row."""
    shell = item.get("shell")
    bind = item.get("bind")
    if not shell or not bind:
        return False
    stick_path = str(item.get("stick") or "")
    stick = None
    if stick_path:
        if not _gallery_stick_ready(stick_path):
            _gallery_ensure_rest_bones(item)
            if not item.get("pick_pts"):
                _gallery_refresh_pick_points(item)
            return False
        stick = _stick_mem_get(stick_path) or _stick_load_disk(stick_path)
    t0 = float(_GALLERY.get("t0") or 0.0)
    clock = _gallery_pose_clock(stick, t0)
    cache_key = _gallery_pose_cache_key(item, clock)
    if item.get("pose_key") == cache_key and item.get("bones_tex") is not None:
        _gallery_perf_inc("pose_skipped")
        _gallery_perf_inc("bone_tex_reuse")
        return False
    worlds: Dict[str, object] = {}
    if stick and stick.get("poses"):
        fk_key = (cache_key[0], cache_key[1], cache_key[2])
        if item.get("fk_key") == fk_key and item.get("fk_worlds") is not None:
            worlds = item["fk_worlds"]
        else:
            worlds = _gallery_fk_worlds_cached(fk_key, stick, clock, str(item.get("prefix") or ""))
            item["fk_key"] = fk_key
            item["fk_worlds"] = worlds
        item["clock"] = clock
    elif item.get("bones_tex") is not None:
        if not item.get("pick_pts"):
            _gallery_refresh_pick_points(item)
        _gallery_perf_inc("pose_skipped")
        return False
    item["bones_tex"] = _gallery_item_bone_tex(item, _shell_delta_mats(shell, worlds))
    item["pose_key"] = cache_key
    _gallery_refresh_pick_points(item)
    _gallery_perf_inc("pose_changed")
    return True


def _bind_gallery_hologram(name: str, path: str, index: int, partner: bool, shell, stick_path: str, prefix: str, born: float) -> None:
    bind = _gallery_bind_gpu(shell)
    if not bind:
        return
    item = {
        "name": name,
        "path": str(path),
        "stick": stick_path,
        "prefix": prefix,
        "shell": shell,
        "partner": bool(partner),
        "bind": bind,
        "index": int(index),
        "slot": _gallery_slot(index),
        "born": float(born),
        "matrix": _gallery_world(path, index, partner).copy(),
        "label": _gallery_label_lines(path),
        "tint": (_GALLERY.get("group_rgb") or {}).get(_path_key(path)) or (0.35, 0.62, 0.95),
    }
    items = _GALLERY.setdefault("items", [])
    items.append(item)
    _gallery_queue_stick(stick_path)
    if _GALLERY.get("pose_at_spawn") or not _gallery_building():
        if not _gallery_apply_pose(item):
            _gallery_ensure_rest_bones(item)
    else:
        _gallery_ensure_rest_bones(item)


def _place_gallery_hologram(path: str, index: int) -> bool:
    place_mark = time.perf_counter()
    shell_mark = place_mark
    shell = _gallery_shell(path)
    shell_ms = (time.perf_counter() - shell_mark) * 1000.0
    _gallery_load_stats_add_ms("shell_ms", shell_ms)
    if shell is None:
        print(f"[GR2 LAB] skip (no body) {Path(path).name} shell {shell_ms:.0f}ms", flush=True)
        return False
    born = time.perf_counter()
    partner_born = born
    if _GALLERY.get("pose_at_spawn"):
        step = float(_GALLERY.get("spawn_step") or _GALLERY_REPLAY_STEP)
        born = float(_GALLERY.get("spawn_t0") or born) + int(index) * step
        partner_born = born + step * 0.5
    _gallery_queue_stick(path)
    _bind_gallery_hologram(f"GR2LAB_Holo_{index:02d}", path, index, False, shell, path, "", born)
    if _browser_whole_scene():
        partner = _gallery_partner_path(path, list(_GALLERY.get("paths") or []))
        if partner:
            partner_shell = _gallery_shell(partner)
            if partner_shell is not None:
                _bind_gallery_hologram(
                    f"GR2LAB_Holo_{index:02d}_P",
                    path,
                    index,
                    True,
                    partner_shell,
                    partner,
                    "",
                    partner_born,
                )
    try:
        if not bpy.app.timers.is_registered(_pump_gallery_anim):
            bpy.app.timers.register(_pump_gallery_anim, first_interval=0.0)
    except Exception:
        traceback.print_exc()
    place_ms = (time.perf_counter() - place_mark) * 1000.0
    _gallery_load_stats_add_ms("place_ms", place_ms)
    if place_ms >= 120.0:
        print(
            f"[GR2 LAB] slow spawn {Path(path).name} {place_ms:.0f}ms (shell {shell_ms:.0f}ms)",
            flush=True,
        )
    return True


def _pump_gallery_anim():
    if not _ALIVE or bpy is None:
        return None
    try:
        _gallery_pump_sticks()
    except Exception:
        traceback.print_exc()
    items = list(_GALLERY.get("items") or [])
    if not items:
        return None
    if _gallery_hold_if_inactive():
        return 0.45
    pump_mark = time.perf_counter()
    building = _gallery_building()
    changed = False
    revealing = False
    hot = False
    if building and not _GALLERY.get("pose_at_spawn"):
        for item in items:
            try:
                if _gallery_reveal(item) < 1.0:
                    revealing = True
            except Exception:
                traceback.print_exc()
        _gallery_perf_inc("pumps")
        _gallery_perf_add_ms("pump_ms", (time.perf_counter() - pump_mark) * 1000.0)
        if revealing:
            _gallery_perf_inc("redraw_tags")
            _tag(0.1)
        return 0.1
    if _GALLERY.get("pose_warming"):
        items_list = items
        idx = int(_GALLERY.get("pose_warm_idx") or 0)
        batch = 4
        end = min(len(items_list), idx + batch)
        for i in range(idx, end):
            try:
                _gallery_apply_pose(items_list[i])
            except Exception:
                traceback.print_exc()
        _GALLERY["pose_warm_idx"] = end
        _gallery_load_stats_add_ms("pose_warm_ms", (time.perf_counter() - pump_mark) * 1000.0)
        _gallery_perf_inc("pumps")
        _gallery_perf_add_ms("pump_ms", (time.perf_counter() - pump_mark) * 1000.0)
        if end < len(items_list):
            _tag(0.08)
            return 0.04
        _GALLERY["pose_warming"] = False
        pose_s = float(_gallery_load_stats().get("pose_warm_ms") or 0.0) / 1000.0
        print(f"[GR2 LAB] pose ramp done in {pose_s:.1f}s", flush=True)
        _tag(0.05)
        return 0.08
    _GALLERY["_pose_now"] = time.perf_counter()
    for item in items:
        try:
            if _gallery_reveal(item) < 1.0:
                revealing = True
            if not item.get("partner") and _gallery_marked(str(item.get("path") or "")):
                hot = True
            if _gallery_apply_pose(item):
                changed = True
        except Exception:
            traceback.print_exc()
    _gallery_perf_inc("pumps")
    _gallery_perf_add_ms("pump_ms", (time.perf_counter() - pump_mark) * 1000.0)
    if changed or revealing or hot:
        _gallery_perf_inc("redraw_tags")
        _tag(0.0 if revealing else _GALLERY_TAG_INTERVAL)
    _gallery_perf_maybe_report()
    interval = _GALLERY_PUMP_INTERVAL
    if len(items) > 44:
        interval = 1.0 / 36.0
    elif len(items) > 30:
        interval = 1.0 / 44.0
    return interval


def _pump_gallery_build():
    if not _ALIVE or bpy is None:
        return None
    queue = list(_GALLERY.get("build") or [])
    if not queue:
        built = int(_GALLERY.get("built") or 0)
        if built:
            _GALLERY["bulk_decode"] = False
            rows = (built + _GALLERY_COLUMNS - 1) // _GALLERY_COLUMNS
            scene = "Scene on" if _browser_whole_scene() else "Scene off"
            center = "Center on" if _browser_center_parent() else "Center off"
            _set_notice(
                f"{built} playing, {scene}, {center}, "
                f"{min(built, _GALLERY_COLUMNS)} along Y, {rows} lines, 2 m"
            )
            items_list = list(_GALLERY.get("items") or [])
            bodies = len(items_list)
            primaries = sum(1 for it in items_list if not it.get("partner"))
            load_t0 = float(_GALLERY.get("load_t0") or time.perf_counter())
            _gallery_load_print_ready(bodies, primaries, time.perf_counter() - load_t0)
            _gallery_apply_center()
            try:
                _start_gallery_prewarm(_gallery_collect_prewarm_paths(items_list))
            except Exception:
                traceback.print_exc()
            if _GALLERY.get("pose_at_spawn"):
                _GALLERY["pose_at_spawn"] = False
            else:
                _GALLERY["pose_warming"] = True
                _GALLERY["pose_warm_idx"] = 0
            try:
                if not bpy.app.timers.is_registered(_pump_gallery_anim):
                    bpy.app.timers.register(_pump_gallery_anim, first_interval=0.05)
            except Exception:
                traceback.print_exc()
        _tag()
        return None
    paths = list(_GALLERY.get("paths") or [])
    replay = bool(_GALLERY.get("pose_at_spawn"))
    if replay:
        step = float(_GALLERY.get("spawn_step") or _GALLERY_REPLAY_STEP)
        due = float(_GALLERY.get("spawn_t0") or time.perf_counter()) + int(_GALLERY.get("built") or 0) * step
        wait = due - time.perf_counter()
        if wait > 0.004:
            return wait
        batch = 1
    else:
        batch = 5
    placed = 0
    while queue and placed < batch:
        path = queue.pop(0)
        index = int(_GALLERY.get("built") or 0)
        warm = [path]
        if _browser_whole_scene():
            partner = _gallery_partner_path(path, paths)
            if partner:
                warm.append(partner)
        _gallery_decode_enqueue(warm)
        try:
            if _place_gallery_hologram(path, index):
                _GALLERY["built"] = index + 1
                placed += 1
        except Exception:
            traceback.print_exc()
    _GALLERY["build"] = queue
    built = int(_GALLERY.get("built") or 0)
    total = built + len(queue)
    if queue:
        _set_notice(f"Gallery {built}/{total}")
    if not replay or built % 5 == 0 or not queue:
        _gallery_load_snapshot("loading")
    _tag()
    if replay:
        return float(_GALLERY.get("spawn_step") or _GALLERY_REPLAY_STEP)
    return 0.006


def _gallery_same_listing(paths: List[str]) -> bool:
    """The holograms already on screen are this clip list."""
    current = [str(path) for path in (_GALLERY.get("paths") or [])]
    items = list(_GALLERY.get("items") or [])
    if not current or not items or len(current) != len(paths):
        return False
    return all(_path_key(a) == _path_key(b) for a, b in zip(current, paths))


def _add_gallery(context) -> None:
    paths = _listed_clip_paths()
    if not paths:
        _set_notice("No GR2 in this list")
        return
    replay = _gallery_same_listing(paths) and not _gallery_building()
    _clear_gallery(keep_pose=replay)
    _GALLERY["cancel"] = False
    _GALLERY["pose_at_spawn"] = replay
    _GALLERY["built"] = 0
    _GALLERY["paths"] = list(paths)
    _GALLERY["build"] = list(paths)
    _gallery_build_group_colors(paths)
    _GALLERY["t0"] = time.perf_counter()
    _GALLERY["_pose_now"] = _GALLERY["t0"]
    _GALLERY["bulk_decode"] = True
    _GALLERY["load_t0"] = time.perf_counter()
    _gallery_load_stats_reset()
    _GALLERY["pose_warming"] = False
    _GALLERY["pose_warm_idx"] = 0
    scene = "Scene on" if _browser_whole_scene() else "Scene off"
    center = "Center on" if _browser_center_parent() else "Center off"
    print(f"[GR2 LAB] Gallery loading {len(paths)} clips ({scene}, {center})…", flush=True)
    _set_notice(f"Adding {len(paths)} playing holograms, {scene}, {center}")
    warm = list(paths)
    if _browser_whole_scene():
        for clip in paths:
            partner = _gallery_partner_path(clip, paths)
            if partner:
                warm.append(partner)
    stick_paths = _gallery_load_stick_paths(warm)
    total_sticks = len(stick_paths)
    cached_sticks = sum(
        1
        for path in stick_paths
        if _stick_mem_get(path) is not None or _stick_cache_file(path).is_file()
    )
    stats = _gallery_load_stats()
    stats["sticks_total"] = total_sticks
    stats["sticks_cached_start"] = cached_sticks
    _GALLERY["load_stick_paths"] = stick_paths
    _gallery_decode_enqueue(warm)
    print(
        f"[GR2 LAB] sticks {cached_sticks}/{total_sticks} already on disk or in memory, "
        f"decoding the rest on {_GALLERY_DECODE_MAX_THREADS} threads",
        flush=True,
    )
    if _browser_center_parent():
        _GALLERY["slot_warm"] = list(paths)
    else:
        _GALLERY["slot_warm"] = []
    if _GALLERY.get("pose_at_spawn"):
        _GALLERY["spawn_step"] = _GALLERY_REPLAY_STEP
        _GALLERY["spawn_t0"] = time.perf_counter()
    try:
        if not bpy.app.timers.is_registered(_pump_gallery_build):
            bpy.app.timers.register(_pump_gallery_build, first_interval=0.0)
    except Exception:
        traceback.print_exc()


def _drop_gallery_path(path: str) -> None:
    want = str(path or "")
    col = bpy.data.collections.get(_GALLERY_COLLECTION) if bpy is not None else None
    if col is None:
        return
    batches = _GALLERY.setdefault("batches", {})
    for obj in list(col.objects):
        if str(obj.get("gr2lab_gallery_gr2") or "") != want:
            continue
        batches.pop(obj.name, None)
        mesh = obj.data if obj.type == "MESH" else None
        bpy.data.objects.remove(obj, do_unlink=True)
        if mesh is not None and mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def _cancel_gallery_load() -> None:
    pending = len(_GALLERY.get("load") or [])
    _GALLERY["load"] = []
    _GALLERY["cancel"] = True
    _GALLERY["load_kick"] = False
    with _WARM_LOCK:
        _WARM_PATHS.clear()
    if pending:
        _set_notice("Load cancelled")


def gallery_load_abort() -> None:
    """Stop a Load-all queue. A normal single import has no queue, so this is a no-op."""
    had = bool(_GALLERY.get("load_job") or _GALLERY.get("load"))
    _GALLERY["load"] = []
    _GALLERY["load_job"] = None
    _GALLERY["cancel"] = True
    _GALLERY["load_kick"] = False
    _GALLERY["head_bake"] = []
    _GALLERY["prewarm_done"] = True
    with _WARM_LOCK:
        _WARM_PATHS.clear()
    _gallery_unpark()
    if had:
        _set_notice("Load cancelled")


def gallery_load_skips_scene_place() -> bool:
    """Gallery Load all already has a hologram transform, so do not rebuild the stage."""
    job = _GALLERY.get("load_job") or {}
    return job.get("target") is not None


def gallery_known_partner() -> str:
    """The other hologram in this pair. Empty when Load all did not record one."""
    job = _GALLERY.get("load_job") or {}
    return str(job.get("partner_path") or "")


def _head_bake_source_key(arm) -> str:
    if arm is None:
        return ""
    ad = getattr(arm, "animation_data", None)
    action = getattr(ad, "action", None) if ad is not None else None
    src = ""
    if action is not None:
        src = str(action.get("gr2lab_source_gr2") or "")
    if not src:
        src = str(
            arm.get("gr2lab_full_source_gr2") or arm.get("gr2lab_source_gr2") or ""
        )
    return _path_key(src) if src else ""


def _gallery_note_head_rig(name: str) -> None:
    name = str(name or "")
    if not name:
        return
    bag = set(_GALLERY.get("head_bake_rigs") or [])
    bag.add(name)
    _GALLERY["head_bake_rigs"] = bag


def _gallery_apply_head_pack_all(src_key: str, pack: dict) -> int:
    """Apply cached head IK curves to gallery rigs with this source GR2; trim the bake queue."""
    if bpy is None or not src_key or not pack:
        return 0
    from .rig_display import head_ik as _head_ik

    keys = dict(_GALLERY.get("head_bake_keys") or {})
    pending = [
        n
        for n in list(_GALLERY.get("head_bake") or [])
        if keys.get(n) != src_key
    ]
    _GALLERY["head_bake"] = pending
    names = set(_GALLERY.get("head_bake_rigs") or [])
    applied = 0
    for name in sorted(names):
        obj = bpy.data.objects.get(name)
        if obj is None or getattr(obj, "type", "") != "ARMATURE" or obj.get("gr2lab_tail"):
            continue
        if _head_bake_source_key(obj) != src_key:
            continue
        try:
            if _head_ik.apply_head_target_curve_pack(obj, pack):
                applied += 1
        except Exception:
            traceback.print_exc()
    return applied


def _collapse_head_bake_queue() -> None:
    pending = list(_GALLERY.get("head_bake") or [])
    keys = dict(_GALLERY.get("head_bake_keys") or {})
    seen: set = set()
    out: List[str] = []
    for name in pending:
        sk = str(keys.get(name) or name)
        if sk in seen:
            continue
        seen.add(sk)
        out.append(name)
    _GALLERY["head_bake"] = out


def queue_gallery_head_bake(name: str) -> None:
    """Remember a rig whose head target should be keyed after Load all."""
    name = str(name or "")
    if not name:
        return
    arm = bpy.data.objects.get(name) if bpy is not None else None
    src_key = _head_bake_source_key(arm) or name
    mem = dict(_GALLERY.get("head_curve_cache") or {})
    pack = mem.get(src_key)
    if pack and arm is not None:
        try:
            from .rig_display import head_ik as _head_ik

            _head_ik.apply_head_target_curve_pack(arm, pack)
            _gallery_load_stats_inc("head_bake_skip")
        except Exception:
            traceback.print_exc()
        return
    pending = list(_GALLERY.get("head_bake") or [])
    keys = dict(_GALLERY.get("head_bake_keys") or {})
    if src_key in {keys.get(n) for n in pending}:
        keys[name] = src_key
        _GALLERY["head_bake_keys"] = keys
        return
    if name not in pending:
        pending.append(name)
    _GALLERY["head_bake"] = pending
    keys[name] = src_key
    _GALLERY["head_bake_keys"] = keys
    _gallery_note_head_rig(name)


def _pump_head_bake_once() -> bool:
    """Bake or apply one unique head source. Returns True when more work remains."""
    if bpy is None or _GALLERY.get("cancel"):
        _GALLERY["head_bake"] = []
        return False
    pending = list(_GALLERY.get("head_bake") or [])
    if not pending:
        return False
    name = str(pending.pop(0))
    _GALLERY["head_bake"] = pending
    arm = bpy.data.objects.get(name)
    if arm is None or getattr(arm, "type", "") != "ARMATURE":
        return bool(_GALLERY.get("head_bake"))
    try:
        from .rig_display import head_ik as _head_ik

        t0 = time.perf_counter()
        keys = dict(_GALLERY.get("head_bake_keys") or {})
        src_key = str(keys.get(name) or _head_bake_source_key(arm) or name)
        mem = dict(_GALLERY.get("head_curve_cache") or {})
        pack = mem.get(src_key)
        if not pack:
            n = _head_ik.bake_ik_head_target_from_action(
                bpy.context,
                arm,
                clip_match=False,
                check_toggle_gaps=False,
                max_samples=48,
                light_depsgraph=True,
            )
            if n > 0:
                snap = _head_ik.snapshot_head_target_curves(arm)
                if snap:
                    pack = snap
                    mem[src_key] = snap
                    _GALLERY["head_curve_cache"] = mem
        if pack:
            applied = _gallery_apply_head_pack_all(src_key, pack)
            if applied > 1:
                _gallery_load_stats_inc("head_bake_skip", applied - 1)
        dt = time.perf_counter() - t0
        _gallery_load_stats_add_ms("head_bake_ms", dt * 1000.0)
        print(f"[GR2 LAB] head look {arm.name} {dt:.2f}s", flush=True)
    except Exception:
        traceback.print_exc()
    return bool(_GALLERY.get("head_bake"))


def _gallery_interleave_head_bake(budget_s: float = 0.55) -> None:
    """Use idle gaps between fast load steps so head IK does not pile up at the end."""
    if bpy is None or _GALLERY.get("load_job") or _GALLERY.get("head_bake_kick"):
        return
    if not _GALLERY.get("head_bake"):
        return
    t0 = time.perf_counter()
    while _GALLERY.get("head_bake") and (time.perf_counter() - t0) < budget_s:
        if not _pump_head_bake_once():
            break


def _maybe_start_head_bake() -> None:
    if _GALLERY.get("load") or _GALLERY.get("load_job") or _GALLERY.get("cancel"):
        return
    if not _GALLERY.get("head_bake") or _GALLERY.get("head_bake_kick"):
        return
    _collapse_head_bake_queue()
    _GALLERY["head_bake_kick"] = True
    try:
        bpy.app.timers.register(_pump_head_bake, first_interval=0.12)
    except Exception:
        _GALLERY["head_bake_kick"] = False


def _pump_head_bake():
    """Key one head target. The clip already plays; this only fills the IK slider."""
    _GALLERY["head_bake_kick"] = False
    more = _pump_head_bake_once()
    if more and not _GALLERY.get("cancel"):
        _GALLERY["head_bake_kick"] = True
        return 0.12
    if not _GALLERY.get("head_bake"):
        try:
            bpy.context.view_layer.update()
        except Exception:
            pass
        _tag()
        _gallery_print_load_summary()
    return None


def _body_token(path: str) -> str:
    """TIF_FS from TIF_FS_Rig_.... Empty when this file is not a body clip."""
    name = Path(str(path or "")).name
    at = name.lower().find("_rig_")
    if at <= 0:
        return ""
    return name[:at]


def existing_body_donor(path: str):
    """A different clip of this same body, already in the file. Tails do not count."""
    token = _body_token(path)
    if bpy is None or not token:
        return None
    prefix = (token + "_Rig_").casefold()
    want = _path_key(path)
    for obj in bpy.data.objects:
        if getattr(obj, "type", "") != "ARMATURE" or obj.get("gr2lab_tail"):
            continue
        src = _direct_rig_source(obj)
        if not src or _path_key(src) == want:
            continue
        if Path(src).name.casefold().startswith(prefix):
            return obj
    return None


def existing_rig_for_path(path: str):
    """A body armature already imported from this GR2. Tails do not count."""
    if bpy is None or not path:
        return None
    want = _path_key(path)
    for obj in bpy.data.objects:
        if getattr(obj, "type", "") != "ARMATURE" or obj.get("gr2lab_tail"):
            continue
        src = _direct_rig_source(obj)
        if src and _path_key(src) == want:
            return obj
    return None


def gallery_note_partner_copy(name: str) -> None:
    job = _GALLERY.get("load_job")
    if job is not None and name:
        job["copy_partner_from"] = str(name)


def _copy_object_local(dst, src) -> None:
    dst.parent_type = src.parent_type
    try:
        dst.parent_bone = src.parent_bone
    except Exception:
        pass
    dst.matrix_parent_inverse = src.matrix_parent_inverse.copy()
    dst.location = src.location.copy()
    dst.scale = src.scale.copy()
    dst.rotation_mode = src.rotation_mode
    if src.rotation_mode == "QUATERNION":
        dst.rotation_quaternion = src.rotation_quaternion.copy()
    elif src.rotation_mode == "AXIS_ANGLE":
        dst.rotation_axis_angle = list(src.rotation_axis_angle)
    else:
        dst.rotation_euler = src.rotation_euler.copy()
    dst.delta_location = src.delta_location.copy()
    dst.delta_scale = src.delta_scale.copy()
    dst.delta_rotation_euler = src.delta_rotation_euler.copy()


def _duplicate_rig(src):
    """Copy a finished body. Meshes are shared. Bones, pose, and IK targets are new."""
    mapping = {}

    def _walk(src_obj, parent_new):
        new = src_obj.copy()
        if getattr(src_obj, "type", "") == "ARMATURE" and src_obj.data is not None:
            new.data = src_obj.data.copy()
        mapping[src_obj] = new
        if parent_new is None:
            new.parent = None
        else:
            new.parent = parent_new
            _copy_object_local(new, src_obj)
        for coll in src_obj.users_collection:
            try:
                coll.objects.link(new)
            except RuntimeError:
                pass
        for child in list(src_obj.children):
            _walk(child, new)
        return new

    root = _walk(src, None)
    try:
        for old, new in mapping.items():
            if getattr(old, "type", "") == "ARMATURE" and not old.get("gr2lab_tail"):
                _gallery_note_head_rig(new.name)
    except Exception:
        pass
    if bpy is not None:
        for obj in list(bpy.data.objects):
            if obj in mapping:
                continue
            if str(obj.get("gr2lab_tail_of") or "") != src.name:
                continue
            _walk(obj, None)
    for old, new in mapping.items():
        for mod in getattr(new, "modifiers", ()) or ():
            target = getattr(mod, "object", None)
            if target in mapping:
                mod.object = mapping[target]
        if new.get("gr2lab_tail"):
            new["gr2lab_tail_of"] = root.name
            new.parent = root
            try:
                new.matrix_world = root.matrix_world.copy()
            except Exception:
                pass
        pose = getattr(new, "pose", None)
        if pose is None:
            continue
        for pb in pose.bones:
            for con in pb.constraints:
                tgt = getattr(con, "target", None)
                if tgt in mapping:
                    con.target = mapping[tgt]
                pole = getattr(con, "pole_target", None)
                if pole in mapping:
                    con.pole_target = mapping[pole]
    try:
        from .rig_display.mesh_kits import seat_kit_meshes

        seat_kit_meshes(root)
    except Exception:
        traceback.print_exc()
    return root


def _gallery_try_copy_pair(path, target, partner_target, extra, partner_path: str = "") -> bool:
    """Place copies when this clip and its partner were already imported."""
    if not isinstance(target, Matrix):
        return False
    primary = existing_rig_for_path(path)
    if primary is None:
        return False
    partner_path = str(partner_path or "")
    if not partner_path and _browser_whole_scene():
        try:
            from . import scene_stage_empties

            found = scene_stage_empties.find_partner_gr2(path)
            partner_path = str(found) if found else ""
        except Exception:
            traceback.print_exc()
            return False
    partner_src = existing_rig_for_path(partner_path) if partner_path else None
    if partner_path and partner_src is None:
        return False
    mat = target.copy()
    if extra is not None:
        mat = Matrix.Translation(Vector(extra)) @ mat
    copy = _duplicate_rig(primary)
    copy.matrix_world = mat
    if partner_src is not None and isinstance(partner_target, Matrix):
        other = _duplicate_rig(partner_src)
        other.matrix_world = partner_target.copy()
    _gallery_load_stats_inc("copy_pair")
    print(
        f"[GR2 LAB] load copy {Path(path).name}"
        + (f" + {Path(partner_path).name}" if partner_src is not None else ""),
        flush=True,
    )
    return True


def _delete_copied_rig(root) -> None:
    if root is None or bpy is None:
        return
    stack = [root]
    found = []
    while stack:
        obj = stack.pop()
        found.append(obj)
        stack.extend(list(getattr(obj, "children", ()) or ()))
    for obj in reversed(found):
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except Exception:
            pass


def _gallery_try_action_swap(path, target, partner_target, extra, partner_path: str = "") -> bool:
    """Same skeleton already built: duplicate it and write only this clip's curves."""
    if not isinstance(target, Matrix):
        return False
    donor = existing_body_donor(path)
    if donor is None:
        return False
    partner_path = str(partner_path or "")
    partner_src = None
    partner_donor = None
    if partner_path:
        partner_src = existing_rig_for_path(partner_path)
        if partner_src is None:
            partner_donor = existing_body_donor(partner_path)
            if partner_donor is None:
                return False
    mat = target.copy()
    if extra is not None:
        mat = Matrix.Translation(Vector(extra)) @ mat
    copy = _duplicate_rig(donor)
    other = None
    try:
        from .bridge_blender import write_clip_action

        if not write_clip_action(bpy.context, copy, path):
            _delete_copied_rig(copy)
            return False
        copy.matrix_world = mat
        if partner_src is not None and isinstance(partner_target, Matrix):
            other = _duplicate_rig(partner_src)
            other.matrix_world = partner_target.copy()
        elif partner_donor is not None and isinstance(partner_target, Matrix):
            other = _duplicate_rig(partner_donor)
            if not write_clip_action(bpy.context, other, partner_path):
                _delete_copied_rig(other)
                _delete_copied_rig(copy)
                return False
            other.matrix_world = partner_target.copy()
    except Exception:
        traceback.print_exc()
        _delete_copied_rig(other)
        _delete_copied_rig(copy)
        return False
    _gallery_load_stats_inc("same_body")
    print(f"[GR2 LAB] load same body {Path(path).name}", flush=True)
    return True


def _gallery_finish_copied_partner(job) -> None:
    name = str(job.get("copy_partner_from") or "")
    target = job.get("partner_target")
    if not name or not isinstance(target, Matrix) or bpy is None:
        return
    src = bpy.data.objects.get(name)
    if src is None:
        return
    copy = _duplicate_rig(src)
    copy.matrix_world = target.copy()
    print(f"[GR2 LAB] load copy partner {src.name}", flush=True)


def gallery_import_settled(context, *, ok: bool) -> None:
    """One queued clip finished. Move it, then start the next without nesting modals."""
    job = _GALLERY.get("load_job")
    if not job:
        return
    _GALLERY["load_job"] = None
    if ok:
        try:
            _gallery_shift_imported(
                job.get("before") or set(),
                job.get("target"),
                job.get("extra"),
                source_path=str(job.get("path") or ""),
                partner_target=None if job.get("copy_partner_from") else job.get("partner_target"),
            )
            _gallery_finish_copied_partner(job)
        except Exception:
            traceback.print_exc()
    else:
        _set_notice(f"Load failed {Path(str(job.get('path') or '')).name}")
    pending = list(_GALLERY.get("load") or [])
    if _GALLERY.get("cancel") or not pending:
        _GALLERY["cancel"] = False
        if ok and not pending:
            _set_notice("Load finished")
            _maybe_start_head_bake()
            _gallery_release_viewport()
        return
    _schedule_gallery_load()


def _gallery_holo_mats(path: str):
    """Hologram object matrices for this clip: primary, then partner."""
    want = _path_key(path)
    primary = None
    partner = None
    for item in list(_GALLERY.get("items") or []):
        if _path_key(str(item.get("path") or "")) != want:
            continue
        mat = item.get("matrix")
        if mat is None:
            continue
        if item.get("partner"):
            partner = mat.copy()
        else:
            primary = mat.copy()
    return primary, partner


def _gallery_ghost_translation(path: str):
    """World position of the hologram that is about to be imported."""
    primary, _partner = _gallery_holo_mats(path)
    if primary is None:
        return None
    return primary.translation.copy()


def _stamp_gallery_partners(items) -> None:
    """Pair each queued clip with the other hologram on the same beat."""
    paths = []
    seen = set()
    for item in list(items) + list(_GALLERY.get("items") or []):
        path = str(item.get("path") or "")
        key = _path_key(path)
        if path and key not in seen:
            seen.add(key)
            paths.append(path)
    for item in items:
        item["partner_path"] = _gallery_partner_path(str(item.get("path") or ""), paths)


def _gallery_load_item(path: str, mode: str = "here") -> dict:
    """One queued clip, remembering where its hologram stands."""
    mode = str(mode or "here")
    if mode not in {"center", "here", "shift"}:
        mode = "here"
    primary, partner = _gallery_holo_mats(path)
    return {
        "path": str(path),
        "mode": mode,
        "matrix": primary,
        "partner_matrix": partner,
    }


def _gallery_remove_ghost(path: str) -> None:
    """Drop the hologram for this clip. The imported rig stays."""
    want = _path_key(path)
    _GALLERY["items"] = [
        item
        for item in list(_GALLERY.get("items") or [])
        if _path_key(str(item.get("path") or "")) != want
    ]


def _gallery_imported_primary(new_objs, source_path: str):
    """The armature this clip imported, not its partner or tail."""
    want = _path_key(source_path) if source_path else ""
    arms = [
        obj
        for obj in new_objs
        if getattr(obj, "type", "") == "ARMATURE" and not obj.get("gr2lab_tail")
    ]
    if want:
        for arm in arms:
            src = _direct_rig_source(arm)
            if src and _path_key(src) == want:
                return arm
    active = getattr(getattr(bpy.context, "view_layer", None), "objects", None)
    active = getattr(active, "active", None)
    new_ids = {obj.as_pointer() for obj in new_objs}
    if (
        active is not None
        and active.as_pointer() in new_ids
        and getattr(active, "type", "") == "ARMATURE"
        and not active.get("gr2lab_tail")
    ):
        return active
    return arms[0] if arms else None


def _gallery_shift_imported(
    before: set, target, extra=None, source_path: str = "", partner_target=None
) -> None:
    """Put this import on the hologram transform. Center leaves the scene place."""
    if bpy is None:
        return
    new_objs = [obj for obj in bpy.data.objects if obj.as_pointer() not in before]
    if not new_objs:
        return
    new_ids = {obj.as_pointer() for obj in new_objs}
    primary = _gallery_imported_primary(new_objs, source_path)
    if primary is None or target is None:
        return
    if isinstance(target, Matrix):
        desired = target.copy()
        if extra is not None:
            desired = Matrix.Translation(Vector(extra)) @ desired
        fix = desired @ primary.matrix_world.inverted()
        moved = False
        for i in range(4):
            for j in range(4):
                if abs(float(fix[i][j]) - (1.0 if i == j else 0.0)) > 1.0e-5:
                    moved = True
                    break
            if moved:
                break
        if not moved:
            return
        for root in new_objs:
            parent = getattr(root, "parent", None)
            if parent is not None and parent.as_pointer() in new_ids:
                continue
            root.matrix_world = fix @ root.matrix_world
        _gallery_seat_partner(new_objs, source_path, partner_target)
        return
    delta = Vector(target) - primary.matrix_world.translation
    if extra is not None:
        delta = delta + Vector(extra)
    if delta.length_squared < 1.0e-8:
        return
    for root in new_objs:
        parent = getattr(root, "parent", None)
        if parent is not None and parent.as_pointer() in new_ids:
            continue
        world = root.matrix_world.copy()
        world.translation = world.translation + delta
        root.matrix_world = world
    _gallery_seat_partner(new_objs, source_path, partner_target)


def _gallery_seat_partner(new_objs, source_path: str, partner_target) -> None:
    """Drop the second body on its own hologram matrix. The pair offset is not a shared nudge."""
    if partner_target is None or not isinstance(partner_target, Matrix):
        return
    want = _path_key(source_path) if source_path else ""
    partner = None
    for obj in new_objs:
        if getattr(obj, "type", "") != "ARMATURE" or obj.get("gr2lab_tail"):
            continue
        src = _direct_rig_source(obj)
        if want and src and _path_key(src) == want:
            continue
        partner = obj
        break
    if partner is None:
        return
    partner.matrix_world = partner_target.copy()
    for obj in new_objs:
        if obj.get("gr2lab_tail") and str(obj.get("gr2lab_tail_of") or "") == partner.name:
            obj.matrix_world = partner.matrix_world.copy()


def _view3d_override():
    """A real 3D view so a timer can start the import modal."""
    wm = getattr(bpy.context, "window_manager", None) if bpy is not None else None
    for window in getattr(wm, "windows", []) or []:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type == "WINDOW":
                    return window, area, region
    return None, None, None


_WARM_PATHS: List[str] = []
_WARM_LOCK = threading.Lock()


def _pipeline_touch(path: str, body_base: Optional[str] = None, *, pack: bool = True) -> None:
    """Decode one GR2 into the pipeline cache. Pose pack is optional and never holds the decode lock."""
    from .bridge_blender import (
        FPS_DEFAULT,
        _resolve_body_base_for_import,
        ensure_pose_pack_on_doc,
    )
    from .local_pipeline import import_gr2_pipeline_local

    one = str(path or "").strip()
    if not one:
        return
    body = body_base
    if body is None:
        body = _resolve_body_base_for_import(
            choice="AUTO",
            bb_hint="",
            prefs_base="",
            source_gr2=one,
            explicit_choice=False,
        )
    with _DECODE_LOCK:
        _dec, doc = import_gr2_pipeline_local(one, body_base=body)
    if not isinstance(doc, dict) or not pack:
        return
    use = float(doc.get("densify_fps") or FPS_DEFAULT)
    ensure_pose_pack_on_doc(doc, use, gr2_path=one, body_base=body)


def _warm_one_clip(path: str, partner_path: str = "", *, pack: bool = True) -> None:
    """Decode this clip and its partner off the main thread. Later imports reuse it."""
    from .bridge_blender import _resolve_body_base_for_import

    if not pack or _GALLERY.get("load_job"):
        pack = False
    base = _resolve_body_base_for_import(
        choice="AUTO",
        bb_hint="",
        prefs_base="",
        source_gr2=path,
        explicit_choice=False,
    )
    _pipeline_touch(path, base, pack=pack)
    if _GALLERY.get("cancel"):
        return
    partner = Path(partner_path) if partner_path else None
    if partner is None or not partner.is_file():
        from . import scene_stage_empties

        partner = scene_stage_empties.find_partner_gr2(path)
    if partner is None:
        return
    pbase = _resolve_body_base_for_import(
        choice="AUTO",
        bb_hint="",
        prefs_base="",
        source_gr2=str(partner),
        explicit_choice=False,
    )
    _pipeline_touch(str(partner), pbase, pack=pack)


def _gallery_warm_load(paths: List[str], partners: Optional[Dict[str, str]] = None) -> None:
    """Decode the rest of the queue while the current clip is still building."""
    known = dict(partners or {})
    fresh = [(str(path), str(known.get(str(path)) or "")) for path in paths if path]
    if not fresh:
        return

    def _ensure() -> None:
        with _WARM_LOCK:
            if _GALLERY.get("warm_alive"):
                return
            _GALLERY["warm_alive"] = True

        def _run() -> None:
            try:
                while not _GALLERY.get("cancel"):
                    with _WARM_LOCK:
                        item = _WARM_PATHS.pop(0) if _WARM_PATHS else None
                    if not item:
                        break
                    path, partner_path = item if isinstance(item, tuple) else (str(item), "")
                    try:
                        _warm_one_clip(path, partner_path)
                    except Exception:
                        traceback.print_exc()
            finally:
                _GALLERY["warm_alive"] = False
                with _WARM_LOCK:
                    more = bool(_WARM_PATHS)
                if more and not _GALLERY.get("cancel"):
                    _ensure()

        threading.Thread(target=_run, name="gr2lab-load-warm", daemon=True).start()

    with _WARM_LOCK:
        have = {item[0] if isinstance(item, tuple) else str(item) for item in _WARM_PATHS}
        for path, partner_path in fresh:
            if path not in have:
                _WARM_PATHS.append((path, partner_path))
                have.add(path)
    _ensure()


def _schedule_gallery_load() -> None:
    """Start the next clip on an app timer, never from inside the gallery modal."""
    if _GALLERY.get("load_job"):
        left = len(_GALLERY.get("load") or [])
        _set_notice(f"Loading  {left} queued  Esc cancels")
        return
    if _GALLERY.get("load_kick"):
        return
    _GALLERY["load_kick"] = True
    try:
        bpy.app.timers.register(_pump_gallery_load, first_interval=0.0)
    except Exception:
        _GALLERY["load_kick"] = False
        traceback.print_exc()
        _set_notice("Load failed to start")


def _gallery_release_viewport() -> None:
    """Leave Load all in object mode, with nothing selected and no active rig.

    The race chip follows the active armature. A leftover active rig draws
    that block after every object has been deselected.
    """
    if bpy is None:
        return
    from .bridge_blender import _mode_set_safe

    ctx = bpy.context
    for obj in list(bpy.data.objects):
        if getattr(obj, "type", "") != "ARMATURE":
            continue
        if getattr(obj, "mode", "OBJECT") != "OBJECT":
            try:
                _mode_set_safe(ctx, "OBJECT", active=obj)
            except Exception:
                traceback.print_exc()
        pose = getattr(obj, "pose", None)
        if pose is not None:
            for pb in pose.bones:
                bone = getattr(pb, "bone", None)
                if bone is not None and getattr(bone, "select", False):
                    bone.select = False
        data = getattr(obj, "data", None)
        bones = getattr(data, "bones", None) if data is not None else None
        if bones is not None:
            try:
                bones.active = None
            except Exception:
                pass
    layer = getattr(ctx, "view_layer", None)
    if layer is None:
        return
    for obj in list(layer.objects):
        try:
            if obj.select_get():
                obj.select_set(False)
        except Exception:
            pass
    try:
        layer.objects.active = None
    except Exception:
        pass


def _iter_gallery_rigs():
    if bpy is None:
        return
    for obj in bpy.data.objects:
        if getattr(obj, "type", "") != "ARMATURE":
            continue
        name = str(getattr(obj, "name", "") or "")
        if (
            name.startswith("GR2LAB_")
            or obj.get("gr2lab_fps") is not None
            or obj.get("gr2lab_tail")
        ):
            yield obj


def _gallery_unpark() -> None:
    if bpy is None:
        return
    shown = 0
    for arm in _iter_gallery_rigs():
        try:
            if arm.hide_get():
                arm.hide_set(False)
                shown += 1
        except Exception:
            continue
        for child in getattr(arm, "children_recursive", ()) or ():
            try:
                if child.hide_get():
                    child.hide_set(False)
            except Exception:
                pass
    if shown:
        print(f"[GR2 LAB] show {shown} rigs", flush=True)


def _pump_gallery_load():
    """Open one stepped import. The bar advances on the import modal, not here."""
    _GALLERY["load_kick"] = False
    if not float(_GALLERY.get("load_wall_t0") or 0.0):
        _GALLERY["load_wall_t0"] = time.perf_counter()
    if not _ALIVE or bpy is None or _GALLERY.get("cancel") or _GALLERY.get("load_job"):
        if _GALLERY.get("cancel"):
            _GALLERY["load"] = []
        return None
    queue = list(_GALLERY.get("load") or [])
    if not queue:
        _set_notice("Load finished")
        _maybe_start_head_bake()
        _gallery_print_load_summary()
        return None
    item = queue.pop(0)
    path, mode = _gallery_load_job(item)
    _GALLERY["load"] = queue
    if not path:
        return 0.05
    done = int(_GALLERY.get("load_done") or 0) + 1
    _GALLERY["load_done"] = done
    total = max(int(_GALLERY.get("load_total") or 0), done + len(queue))
    _GALLERY["load_total"] = total
    name = Path(path).name
    left = len(queue)
    _set_notice(
        f"Loading {done}/{total}  {name}"
        + (f"  {left} left" if left else "")
        + "  Esc cancels"
    )
    print(f"[GR2 LAB] load {done}/{total} {name}", flush=True)
    _drop_gallery_path(path)
    target = None
    if mode != "center":
        if isinstance(item, dict) and item.get("matrix") is not None:
            target = item.get("matrix")
        else:
            target = _gallery_ghost_translation(path)
    extra = (3.0, 0.0, 0.0) if mode == "shift" else None
    partner_target = item.get("partner_matrix") if isinstance(item, dict) else None
    if isinstance(target, Matrix):
        try:
            known_partner = str(item.get("partner_path") or "") if isinstance(item, dict) else ""
            if _gallery_try_copy_pair(
                path,
                target,
                partner_target,
                extra,
                partner_path=known_partner,
            ) or _gallery_try_action_swap(
                path,
                target,
                partner_target,
                extra,
                partner_path=known_partner,
            ):
                _gallery_remove_ghost(path)
                _tag()
                _gallery_interleave_head_bake()
                if _GALLERY.get("load") and not _GALLERY.get("cancel"):
                    return 0.0
                _set_notice("Load finished")
                _maybe_start_head_bake()
                _gallery_unpark()
                _gallery_print_load_summary()
                return None
        except Exception:
            traceback.print_exc()
    before = {obj.as_pointer() for obj in bpy.data.objects}
    _gallery_remove_ghost(path)
    _GALLERY["load_job"] = {
        "path": path,
        "before": before,
        "target": target,
        "partner_target": partner_target,
        "partner_path": str(item.get("partner_path") or "") if isinstance(item, dict) else "",
        "extra": extra,
        "title": f"GR2 LAB  {done}/{total}",
    }
    window, area, region = _view3d_override()
    try:
        ctx = bpy.context
        if window is None:
            _import_clip_at(
                ctx, path, None, place=False, whole_scene=_browser_whole_scene(ctx)
            )
        else:
            with bpy.context.temp_override(window=window, area=area, region=region):
                _import_clip_at(
                    bpy.context,
                    path,
                    None,
                    place=False,
                    whole_scene=_browser_whole_scene(bpy.context),
                )
    except Exception:
        traceback.print_exc()
        _GALLERY["load_job"] = None
        _set_notice(f"Load failed {name}")
        if queue and not _GALLERY.get("cancel"):
            return 0.05
        return None
    try:
        from .import_progress_ui import active as overlay_active
        from .import_progress_ui import set_title

        job_now = _GALLERY.get("load_job")
        if not job_now:
            return None
        if not overlay_active():
            _GALLERY["load_job"] = None
            _set_notice(f"Load failed {name}")
            if queue and not _GALLERY.get("cancel"):
                return 0.05
            return None
        set_title(str(job_now["title"]))
    except Exception:
        traceback.print_exc()
    _tag()
    return None


def _gallery_load_job(item) -> Tuple[str, str]:
    """One queued import: path plus center, here, or shift."""
    if isinstance(item, dict):
        mode = str(item.get("mode") or "here")
        if mode not in {"center", "here", "shift"}:
            mode = "here"
        return str(item.get("path") or ""), mode
    return str(item or ""), "here"


def _paths_not_already_loaded(paths: List[str]) -> Tuple[List[str], List[str]]:
    """Clips with no body armature from that GR2 yet, and the ones already imported."""
    fresh: List[str] = []
    skipped: List[str] = []
    for path in paths:
        if not path:
            continue
        if existing_rig_for_path(path) is not None:
            skipped.append(path)
        else:
            fresh.append(path)
    return fresh, skipped


def _queue_gallery_load(paths: List[str]) -> None:
    fresh, skipped = _paths_not_already_loaded(paths)
    for path in skipped:
        _gallery_remove_ghost(path)
        print(f"[GR2 LAB] load skip (already loaded) {Path(path).name}", flush=True)
    if skipped:
        _tag()
    clean = [_gallery_load_item(path, "here") for path in fresh]
    _stamp_gallery_partners(clean)
    if not clean:
        if skipped:
            _set_notice(f"Already loaded ({len(skipped)})")
        else:
            _set_notice("No GR2 in this list")
        return
    _GALLERY["load"] = clean
    _GALLERY["cancel"] = False
    _GALLERY["load_total"] = len(clean)
    _GALLERY["load_done"] = 0
    _GALLERY["load_summary_printed"] = False
    _GALLERY["load_wall_t0"] = 0.0
    _GALLERY["head_curve_cache"] = {}
    _GALLERY["head_bake_keys"] = {}
    _GALLERY["head_bake_rigs"] = set()
    stats = _gallery_load_stats()
    stats["same_body"] = 0
    stats["copy_pair"] = 0
    stats["head_bake_ms"] = 0.0
    stats["head_bake_skip"] = 0
    prewarm = _gallery_collect_prewarm_paths(clean)
    _start_gallery_prewarm(prewarm)
    try:
        from .bridge_blender import _resolve_body_base_for_import
        from .rig_display.mesh_kits import preload_kit_library

        bases = []
        seen_bases = set()
        for item in clean:
            for raw in (item.get("path"), item.get("partner_path")):
                one = str(raw or "")
                if not one:
                    continue
                base = _resolve_body_base_for_import(
                    choice="AUTO",
                    bb_hint="",
                    prefs_base="",
                    source_gr2=one,
                    explicit_choice=False,
                )
                name = str(base or "")
                if name and name not in seen_bases:
                    seen_bases.add(name)
                    bases.append(name)
        if bases and bpy is not None:
            preload_kit_library(bpy.context, bases)
    except Exception:
        traceback.print_exc()
    placed = sum(1 for item in clean if item.get("matrix") is not None)
    notice = f"Loading {len(clean)}"
    if skipped:
        notice += f"  skipped {len(skipped)}"
    _set_notice(notice + "  Esc cancels")
    if placed:
        print(
            f"[GR2 LAB] load {placed}/{len(clean)} clips keep their hologram place",
            flush=True,
        )
    _schedule_gallery_load()


def _gallery_generate_one(path: str, mode: str = "here") -> None:
    """Import this one clip at center, on the hologram, or 3 m to the side."""
    path = str(path or "")
    mode = str(mode or "here")
    if mode not in {"center", "here", "shift"}:
        mode = "here"
    if not path or bpy is None:
        return
    pending = list(_GALLERY.get("load") or [])
    queued = {_path_key(_gallery_load_job(item)[0]) for item in pending}
    if _path_key(path) not in queued:
        pending.append(_gallery_load_item(path, mode))
        _stamp_gallery_partners(pending)
        _gallery_warm_load(
            [path],
            {path: str(pending[-1].get("partner_path") or "")},
        )
    _GALLERY["load"] = pending
    _GALLERY["cancel"] = False
    label = {"center": "Center", "here": "Here", "shift": "Shift"}.get(mode, "Generate")
    _set_notice(f"{label} {Path(path).name}")
    if not _GALLERY.get("load_job") and not _GALLERY.get("load_kick"):
        _GALLERY["load_done"] = 0
        _GALLERY["load_total"] = len(_GALLERY.get("load") or [])
    _schedule_gallery_load()


def _gallery_generate_all() -> None:
    """Import every hologram where it is standing."""
    rows = [item for item in list(_GALLERY.get("items") or []) if not item.get("partner")]
    rows.sort(key=lambda item: int(item.get("index") or 0))
    paths = []
    seen = set()
    for item in rows:
        path = str(item.get("path") or "")
        key = _path_key(path)
        if not path or key in seen:
            continue
        seen.add(key)
        paths.append(path)
    _queue_gallery_load(paths)


def _gallery_choose(path: str) -> None:
    """Keep the clicked clip, move it to Center, and drop every other hologram."""
    want = str(path or "")
    kept = [item for item in list(_GALLERY.get("items") or []) if str(item.get("path") or "") == want]
    if not kept:
        return
    names = set()
    for item in kept:
        item["matrix"] = _gallery_body_matrix(want, bool(item.get("partner"))).copy()
        item["index"] = 0
        item["slot"] = (0.0, 0.0, 0.0)
        names.add(str(item.get("name") or ""))
    _GALLERY["items"] = kept
    batches = _GALLERY.setdefault("batches", {})
    for name in list(batches):
        if name not in names:
            batches.pop(name, None)
    _set_notice(f"Chosen {Path(want).name}")
    _tag()


_GALLERY_PICK_BONES = (
    "Root_M",
    "Spine1_M",
    "Spine2_M",
    "Chest_M",
    "Neck_M",
    "Head_M",
    "Scapula_L",
    "Scapula_R",
    "Shoulder_L",
    "Shoulder_R",
    "Elbow_L",
    "Elbow_R",
    "ElbowPart1_L",
    "ElbowPart1_R",
    "Wrist_L",
    "Wrist_R",
    "Hip_L",
    "Hip_R",
    "Knee_L",
    "Knee_R",
    "Ankle_L",
    "Ankle_R",
)


def _hsv_rgb(hue: float, sat: float, val: float) -> Tuple[float, float, float]:
    hue = hue % 1.0
    if 0.02 < hue < 0.14:
        hue += 0.18
    sector = int(hue * 6.0) % 6
    frac = hue * 6.0 - int(hue * 6.0)
    pale = val * (1.0 - sat)
    fade = val * (1.0 - frac * sat)
    rise = val * (1.0 - (1.0 - frac) * sat)
    table = (
        (val, rise, pale),
        (fade, val, pale),
        (pale, val, rise),
        (pale, fade, val),
        (rise, pale, val),
        (val, pale, fade),
    )
    return table[sector]


def _gallery_group_parts(name: str) -> List[str]:
    beat = _stick_beat(name)
    if not beat:
        return [Path(name).stem.upper()]
    return [part for part in beat.split("_") if part]


_GALLERY_BRAND = (
    (0.45, 0.82, 1.00),
    (0.28, 0.58, 0.96),
    (0.68, 0.88, 1.00),
    (0.98, 0.72, 0.42),
    (0.98, 0.84, 0.52),
    (0.86, 0.55, 0.28),
    (0.55, 0.74, 0.92),
    (0.36, 0.50, 0.72),
    (0.94, 0.64, 0.40),
)


def _gallery_build_group_colors(paths: List[str]) -> None:
    """One color per action token shared by similarly named clips."""
    rows = [_gallery_group_parts(Path(path).name) for path in paths]
    filled = [parts for parts in rows if parts]
    prefix = 0
    if filled:
        while all(len(parts) > prefix and parts[prefix] == filled[0][prefix] for parts in filled):
            prefix += 1
        shortest = min(len(parts) for parts in filled)
        if prefix >= shortest:
            prefix = max(0, shortest - 1)
    keys: List[str] = []
    order: List[str] = []
    seen = set()
    for parts in rows:
        rest = parts[prefix:] if len(parts) > prefix else parts[-1:]
        key = rest[0] if rest else "CLIP"
        keys.append(key)
        if key not in seen:
            seen.add(key)
            order.append(key)
    palette = {}
    for index, key in enumerate(order):
        palette[key] = _GALLERY_BRAND[index % len(_GALLERY_BRAND)]
    painted = {}
    for path, key in zip(paths, keys):
        painted[_path_key(path)] = palette[key]
    _GALLERY["group_rgb"] = painted


def _gallery_rest_pick_points(item: dict) -> List[Tuple[float, float, float]]:
    bind = item.get("bind") or {}
    mn = bind.get("mn")
    mx = bind.get("mx")
    if mn is None or mx is None:
        return [(0.0, 0.9, 0.0)]
    x0 = float(mn[0]) + 0.45
    y0 = float(mn[1]) + 0.45
    z0 = float(mn[2]) + 0.45
    x1 = float(mx[0]) - 0.45
    y1 = float(mx[1]) - 0.45
    z1 = float(mx[2]) - 0.45
    cx = (x0 + x1) * 0.5
    cz = (z0 + z1) * 0.5
    span = max(0.2, y1 - y0)
    return [(cx, y0 + span * t, cz) for t in (0.08, 0.30, 0.52, 0.74, 0.92)]


def _gallery_refresh_pick_points(item: dict) -> None:
    """Posed joints the cursor matches. The padded rest box overlaps the next slot."""
    worlds = item.get("fk_worlds") or {}
    pts: List[Tuple[float, float, float]] = []
    for name in _GALLERY_PICK_BONES:
        mat = worlds.get(name)
        if mat is None:
            continue
        try:
            pts.append((float(mat[0, 3]), float(mat[1, 3]), float(mat[2, 3])))
        except Exception:
            continue
    if len(pts) < 3:
        pts = _gallery_rest_pick_points(item)
    item["pick_pts"] = pts


def _gallery_ray_box(origin, direction, mn, mx):
    tmin = 0.0
    tmax = 1.0e18
    for axis in range(3):
        origin_axis = float(origin[axis])
        step = float(direction[axis])
        low = float(mn[axis])
        high = float(mx[axis])
        if abs(step) < 1.0e-8:
            if origin_axis < low or origin_axis > high:
                return None
            continue
        near = (low - origin_axis) / step
        far = (high - origin_axis) / step
        if near > far:
            near, far = far, near
        tmin = max(tmin, near)
        tmax = min(tmax, far)
        if tmin > tmax:
            return None
    if tmax < 0.0:
        return None
    return tmin if tmin >= 0.0 else tmax


def _gallery_pick(context, mx: float, my: float) -> str:
    """The hologram whose posed body is under the cursor, not the neighbor's box."""
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return ""
    items = list(_GALLERY.get("items") or [])
    if not items:
        return ""
    try:
        origin = region_2d_to_origin_3d(region, rv3d, (float(mx), float(my)))
    except Exception:
        origin = None
    best = ""
    best_px = 1.0e18
    best_cam = 1.0e18
    for item in items:
        mat = item.get("matrix")
        if mat is None:
            continue
        pts = item.get("pick_pts")
        if not pts:
            _gallery_refresh_pick_points(item)
            pts = item.get("pick_pts") or []
        xs: List[float] = []
        ys: List[float] = []
        nearest = 1.0e18
        near_world = None
        for local in pts:
            world = mat @ Vector((float(local[0]), float(local[1]), float(local[2])))
            try:
                xy = location_3d_to_region_2d(region, rv3d, world)
            except Exception:
                xy = None
            if xy is None:
                continue
            x = float(xy[0])
            y = float(xy[1])
            xs.append(x)
            ys.append(y)
            dist = math.hypot(x - float(mx), y - float(my))
            if dist < nearest:
                nearest = dist
                near_world = world
        if not xs:
            continue
        pad_x = max(16.0, (max(xs) - min(xs)) * 0.28)
        pad_y = max(16.0, (max(ys) - min(ys)) * 0.22)
        if (
            float(mx) < min(xs) - pad_x
            or float(mx) > max(xs) + pad_x
            or float(my) < min(ys) - pad_y
            or float(my) > max(ys) + pad_y
        ):
            continue
        cam = (near_world - origin).length if near_world is not None and origin is not None else nearest
        closer = nearest + 12.0 < best_px
        stacked = abs(nearest - best_px) <= 12.0 and cam < best_cam
        if not best or closer or stacked:
            best = str(item.get("path") or "")
            best_px = nearest
            best_cam = cam
    return best


def _gallery_reveal(item) -> float:
    """Same sweep as one dragged GR2: 0 when the hologram appears, 1 after 0.36 s."""
    born = float(item.get("born") or 0.0)
    if born <= 0.0:
        return 1.0
    age = time.perf_counter() - born
    return max(0.0, min(1.0, age / _DRAG_REVEAL_SEC))


def _draw_gallery() -> None:
    items = list(_GALLERY.get("items") or [])
    if not items or bpy is None:
        return
    draw_mark = time.perf_counter()
    try:
        shader = _gallery_skin_shader()
    except Exception:
        traceback.print_exc()
        return
    context = bpy.context
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    pulse = 0.5 + 0.5 * math.sin(time.perf_counter() * 5.2)
    solid = bool(_STATE.get("holo_mesh"))
    gpu.state.blend_set("NONE" if solid else "ALPHA")
    try:
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.depth_mask_set(solid)
        # Pieces in one body do not share a winding. Culling either side
        # turns the other set inside out, so the solid path draws both.
        gpu.state.face_culling_set("NONE" if solid else "BACK")
    except Exception:
        pass
    revealing = False
    try:
        shader.bind()
        for item in items:
            bind = item.get("bind")
            tex = item.get("bones_tex")
            mat = item.get("matrix")
            if not bind or tex is None or mat is None:
                _gallery_perf_inc("draw_skip_nobone")
                continue
            if not _gallery_item_on_screen(item, region, rv3d):
                _gallery_perf_inc("draw_skip_offscreen")
                continue
            span_w, span_h = _gallery_item_screen_span(item, region, rv3d)
            if max(span_w, span_h) < 5.0:
                _gallery_perf_inc("draw_skip_tiny")
                continue
            reveal = _gallery_reveal(item)
            if reveal < 1.0:
                revealing = True
            gpu.matrix.push()
            try:
                gpu.matrix.multiply_matrix(mat)
                mv = gpu.matrix.get_model_view_matrix()
                proj = gpu.matrix.get_projection_matrix()
                shader.uniform_float("ModelViewMatrix", mv)
                shader.uniform_float("ModelViewProjectionMatrix", proj @ mv)
                hot = 1.0 if _gallery_marked(str(item.get("path") or "")) else 0.0
                store = item.setdefault("ubo", {})
                bones = float(bind.get("bones") or 0)
                shader.uniform_sampler("bones", tex)
                shader.uniform_block(
                    "gp",
                    _gallery_ubo(
                        store,
                        reveal,
                        bones,
                        hot,
                        pulse,
                        item.get("tint"),
                    ),
                )
                bind["batch"].draw(shader)
                _gallery_perf_inc("draw_calls")
                _gallery_perf_inc("draw_tris", int(bind.get("count") or 0))
            finally:
                gpu.matrix.pop()
    finally:
        try:
            gpu.state.face_culling_set("BACK")
            gpu.state.depth_mask_set(True)
            gpu.state.depth_test_set("NONE")
        except Exception:
            pass
        gpu.state.blend_set("NONE")
    _gallery_perf_inc("draw_frames")
    _gallery_perf_add_ms("draw_ms", (time.perf_counter() - draw_mark) * 1000.0)
    _gallery_perf_maybe_report()
    if revealing:
        _tag()


_GALLERY_PLANK_SHADER = None
_FONT5 = {
    " ": (0, 0, 0, 0, 0, 0, 0),
    "A": (14, 17, 17, 31, 17, 17, 17),
    "B": (30, 17, 17, 30, 17, 17, 30),
    "C": (14, 17, 16, 16, 16, 17, 14),
    "D": (30, 17, 17, 17, 17, 17, 30),
    "E": (31, 16, 16, 30, 16, 16, 31),
    "F": (31, 16, 16, 30, 16, 16, 16),
    "G": (14, 17, 16, 23, 17, 17, 14),
    "H": (17, 17, 17, 31, 17, 17, 17),
    "I": (14, 4, 4, 4, 4, 4, 14),
    "J": (7, 2, 2, 2, 2, 18, 12),
    "K": (17, 18, 20, 24, 20, 18, 17),
    "L": (16, 16, 16, 16, 16, 16, 31),
    "M": (17, 27, 21, 21, 17, 17, 17),
    "N": (17, 25, 21, 19, 17, 17, 17),
    "O": (14, 17, 17, 17, 17, 17, 14),
    "P": (30, 17, 17, 30, 16, 16, 16),
    "Q": (14, 17, 17, 17, 21, 18, 13),
    "R": (30, 17, 17, 30, 20, 18, 17),
    "S": (15, 16, 16, 14, 1, 1, 30),
    "T": (31, 4, 4, 4, 4, 4, 4),
    "U": (17, 17, 17, 17, 17, 17, 14),
    "V": (17, 17, 17, 17, 17, 10, 4),
    "W": (17, 17, 17, 21, 21, 21, 10),
    "X": (17, 17, 10, 4, 10, 17, 17),
    "Y": (17, 17, 10, 4, 4, 4, 4),
    "Z": (31, 1, 2, 4, 8, 16, 31),
    "0": (14, 17, 19, 21, 25, 17, 14),
    "1": (4, 12, 4, 4, 4, 4, 14),
    "2": (14, 17, 1, 6, 8, 16, 31),
    "3": (30, 1, 1, 14, 1, 1, 30),
    "4": (2, 6, 10, 18, 31, 2, 2),
    "5": (31, 16, 16, 30, 1, 1, 30),
    "6": (14, 16, 16, 30, 17, 17, 14),
    "7": (31, 1, 2, 4, 8, 8, 8),
    "8": (14, 17, 17, 14, 17, 17, 14),
    "9": (14, 17, 17, 15, 1, 1, 14),
    "-": (0, 0, 0, 31, 0, 0, 0),
    ".": (0, 0, 0, 0, 0, 12, 12),
    "/": (1, 2, 4, 4, 4, 8, 16),
}


def _gallery_plank_shader():
    global _GALLERY_PLANK_SHADER
    if _GALLERY_PLANK_SHADER is not None:
        return _GALLERY_PLANK_SHADER
    from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo

    iface = GPUStageInterfaceInfo("gr2lab_gallery_plank_730")
    iface.smooth("VEC2", "uvInterp")
    info = GPUShaderCreateInfo()
    info.vertex_in(0, "VEC3", "pos")
    info.vertex_in(1, "VEC2", "uv")
    info.vertex_out(iface)
    info.push_constant("MAT4", "ModelViewProjectionMatrix")
    info.sampler(0, "FLOAT_2D", "image")
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(
        "void main() {\n"
        "    uvInterp = uv;\n"
        "    gl_Position = ModelViewProjectionMatrix * vec4(pos, 1.0);\n"
        "}\n"
    )
    info.fragment_source(
        "void main() {\n"
        "    fragColor = texture(image, uvInterp);\n"
        "}\n"
    )
    _GALLERY_PLANK_SHADER = gpu.shader.create_from_info(info)
    return _GALLERY_PLANK_SHADER


def _gallery_plank_lines(label) -> Tuple[str, str]:
    action, scene_name, where = label
    action = " ".join(str(action).split())
    taken = str(where).replace("from", "").strip()
    second = str(scene_name).strip()
    if taken and taken.casefold() not in second.casefold():
        second = f"{second} / {taken}"
    return action[:22], second[:26]


def _gallery_bake_plank(label) -> object:
    """Small colored board. Text is rasterized once, then laid on the floor."""
    import gpu
    import numpy as np

    line_a, line_b = _gallery_plank_lines(label)
    scale = 2
    cell_w = 6 * scale
    cell_h = 8 * scale
    cols = 26
    width = 8 + cols * cell_w
    height = 8 + cell_h * 2
    image = np.zeros((height, width, 4), dtype=np.float32)
    image[..., 0] = 0.13
    image[..., 1] = 0.24
    image[..., 2] = 0.36
    image[..., 3] = 0.96
    edge = (0.55, 0.82, 1.0)
    image[0:2, :, 0:3] = edge
    image[-2:, :, 0:3] = edge
    image[:, 0:2, 0:3] = edge
    image[:, -2:, 0:3] = edge

    def paint(text: str, top: int, color) -> None:
        cursor = 6
        for char in text.upper():
            rows = _FONT5.get(char)
            if rows is None:
                cursor += cell_w
                continue
            for gy, bits in enumerate(rows):
                for gx in range(5):
                    if not (bits & (1 << (4 - gx))):
                        continue
                    x0 = cursor + gx * scale
                    y0 = top - (gy + 1) * scale
                    image[y0:y0 + scale, x0:x0 + scale, 0] = color[0]
                    image[y0:y0 + scale, x0:x0 + scale, 1] = color[1]
                    image[y0:y0 + scale, x0:x0 + scale, 2] = color[2]
                    image[y0:y0 + scale, x0:x0 + scale, 3] = 1.0
            cursor += cell_w

    paint(line_a, height - 4, (0.96, 0.98, 1.0))
    paint(line_b, height - 4 - cell_h, (0.62, 0.78, 0.90))
    buf = gpu.types.Buffer("FLOAT", image.shape, np.ascontiguousarray(image).reshape(-1))
    return gpu.types.GPUTexture((width, height), format="RGBA32F", data=buf)


def _gallery_label_column() -> Vector:
    """Stage point for the name tablets. One X for the whole line."""
    items = [it for it in list(_GALLERY.get("items") or []) if not it.get("partner") and it.get("matrix") is not None]
    if not items:
        return Vector((0.0, 0.0, 0.0))
    first = min(items, key=lambda it: int(it.get("index") or 0))
    slot = Vector(first.get("slot") or _gallery_slot(int(first.get("index") or 0)))
    return first["matrix"].translation - slot


def _gallery_label_anchor(item):
    """Name tablet on the Y line. X stays on the row; only Y steps."""
    mat = item.get("matrix")
    if mat is None:
        return None
    index = int(item.get("index") or 0)
    slot = Vector(item.get("slot") or _gallery_slot(index))
    base = _gallery_label_column()
    return Vector((base.x + slot.x, base.y + slot.y, base.z + 2.6))


def _gallery_banner_points():
    """Two world points above the middle of the row. Remove, then Generate."""
    items = [it for it in list(_GALLERY.get("items") or []) if not it.get("partner") and it.get("matrix") is not None]
    if not items:
        return ()
    base = _gallery_label_column()
    ys = []
    xs = []
    for item in items:
        slot = Vector(item.get("slot") or _gallery_slot(int(item.get("index") or 0)))
        xs.append(base.x + slot.x)
        ys.append(base.y + slot.y)
    mid_x = (min(xs) + max(xs)) * 0.5
    mid_y = (min(ys) + max(ys)) * 0.5
    height = base.z + 4.2
    return (
        Vector((mid_x, mid_y - 1.05, height)),
        Vector((mid_x, mid_y + 1.05, height)),
    )


def _gallery_clip_lines(path: str) -> Tuple[str, str, str]:
    """Three lines of the same clip name the list shows: you/npc plus the file."""
    name = Path(str(path or "")).name
    listed = [Path(item).name for item in list(_GALLERY.get("paths") or [])]
    dual = _scene_dual_char(listed) if listed else True
    role_label, _rgb = _role_clip_colors(name, dual)
    parts = name.split("_")
    if not parts:
        return role_label, "", ""
    cuts = []
    count = len(parts)
    if count < 3:
        body = parts + [""] * (3 - count)
    else:
        best = None
        for left in range(1, count - 1):
            for right in range(left + 1, count):
                chunks = (
                    "_".join(parts[:left]),
                    "_".join(parts[left:right]),
                    "_".join(parts[right:]),
                )
                score = max(len(chunk) for chunk in chunks)
                if best is None or score < best[0]:
                    best = (score, chunks)
        body = list(best[1])
    first = f"{role_label}  {body[0]}".strip() if body[0] else role_label
    return first, body[1], body[2]


def _gallery_ui_scale_from_pixels(pixels: float) -> float:
    """1.0 when one meter is about 100 px. Zoom in grows it, zoom out shrinks it."""
    if pixels < 1.0:
        return 0.35
    return max(0.35, min(5.0, float(pixels) / 100.0))


def _gallery_ui_scale(region, rv3d, anchor) -> float:
    """Screen scale of a meter at the tablet, so the text tracks the 3D view."""
    if anchor is None or rv3d is None or region is None:
        return 1.0
    try:
        right = rv3d.view_matrix.inverted().to_3x3() @ Vector((1.0, 0.0, 0.0))
    except Exception:
        return 1.0
    if right.length_squared < 1.0e-8:
        return 1.0
    right.normalize()
    try:
        near = location_3d_to_region_2d(region, rv3d, anchor)
        far = location_3d_to_region_2d(region, rv3d, anchor + right)
    except Exception:
        return 1.0
    if near is None or far is None:
        return 1.0
    pixels = math.hypot(float(far[0]) - float(near[0]), float(far[1]) - float(near[1]))
    return _gallery_ui_scale_from_pixels(pixels)


def _gallery_piece_group(item) -> List[dict]:
    """This hologram plus its partner body, so the card sits under the pair."""
    group = [item]
    index = int(item.get("index") or 0)
    for other in list(_GALLERY.get("items") or []):
        if other is item or not other.get("partner"):
            continue
        if int(other.get("index") or -1) == index:
            group.append(other)
    return group


def _gallery_body_screen(item, region, rv3d):
    """Screen center and the highest posed joint. None when the body is off camera."""
    xs: List[float] = []
    ys: List[float] = []
    acc = Vector((0.0, 0.0, 0.0))
    count = 0
    for piece in _gallery_piece_group(item):
        mat = piece.get("matrix")
        if mat is None:
            continue
        pts = piece.get("pick_pts")
        if not pts:
            _gallery_refresh_pick_points(piece)
            pts = piece.get("pick_pts") or []
        if not pts:
            bind = piece.get("bind") or {}
            mn, mx = bind.get("mn"), bind.get("mx")
            if mn is None or mx is None:
                continue
            pts = [(
                (float(mn[0]) + float(mx[0])) * 0.5,
                (float(mn[1]) + float(mx[1])) * 0.5,
                (float(mn[2]) + float(mx[2])) * 0.5,
            )]
        for local in pts:
            world = mat @ Vector((float(local[0]), float(local[1]), float(local[2])))
            try:
                xy = location_3d_to_region_2d(region, rv3d, world)
            except Exception:
                xy = None
            if xy is None:
                continue
            xs.append(float(xy[0]))
            ys.append(float(xy[1]))
            acc += world
            count += 1
    if not xs or count <= 0:
        return None
    return sum(xs) / float(len(xs)), max(ys), acc / float(count), min(xs), max(xs)


def _gallery_follow_xy(target_x: float, target_y: float) -> Tuple[float, float]:
    """Glide the card toward the body. A pointer on the card freezes it."""
    now = time.perf_counter()
    slot = _GALLERY.get("plaque_follow")
    if _GALLERY.get("plaque_lock") and slot:
        slot["t"] = now
        return float(slot["x"]), float(slot["y"])
    if not slot:
        _GALLERY["plaque_follow"] = {"x": float(target_x), "y": float(target_y), "t": now}
        return float(target_x), float(target_y)
    dt = min(0.05, max(0.0, now - float(slot.get("t") or now)))
    rate = 5.0 if _GALLERY.get("plaque_near") else 22.0
    alpha = 1.0 - math.exp(-rate * dt)
    x = float(slot["x"]) + (float(target_x) - float(slot["x"])) * alpha
    y = float(slot["y"]) + (float(target_y) - float(slot["y"])) * alpha
    _GALLERY["plaque_follow"] = {"x": x, "y": y, "t": now}
    if abs(x - float(target_x)) > 4.0 or abs(y - float(target_y)) > 4.0:
        _tag()
    return x, y


def _gallery_bridge_hit(region, mx: float, my: float) -> bool:
    """True between the body and the card, so the pointer can travel up to it."""
    box = (_GALLERY.get("plaque_bridge") or {}).get(region.as_pointer())
    return _gallery_box_hit(box, mx, my)


def _draw_gallery_name(cx: float, foot_y: float, path: str, hot: bool, region, scale: float = 1.0, under: bool = False) -> Tuple[float, float, float, float]:
    """Narrow name tablet: three lines, the full clip name, outline only."""
    first, second, third = _gallery_clip_lines(path)
    scale = max(0.35, float(scale))
    size = max(6, min(64, int(round(11.0 * scale))))
    font_id = _font(size)
    lines = (first, second, third)
    width = max((_text_width(font_id, line) for line in lines if line), default=0.0)
    pad_x = 6.0 * scale
    pad_y = 4.0 * scale
    gap = 2.0 * scale
    line_h = 12.0 * scale
    bw = width + pad_x * 2.0
    bh = pad_y * 2.0 + line_h * 3.0 + gap * 2.0
    x = cx - bw * 0.5
    if under:
        y = foot_y - 10.0 * scale - bh
    else:
        y = foot_y + 8.0 * scale
    margin = 8.0
    if y + bh > float(region.height) - margin:
        y = float(region.height) - margin - bh
    if y < margin:
        y = margin
    stroke = (1.0, 0.90, 0.55, 1.0) if hot else (0.86, 0.94, 1.0, 1.0)
    _polyline_2d(
        ((x, y), (x + bw, y), (x + bw, y + bh), (x, y + bh), (x, y)),
        stroke,
        2.0 * scale if hot else 1.75 * scale,
    )
    role_rgb = (0.94, 0.95, 0.96)
    try:
        listed = [Path(item).name for item in list(_GALLERY.get("paths") or [])]
        dual = _scene_dual_char(listed) if listed else True
        _label, role_rgb = _role_clip_colors(Path(path).name, dual)
    except Exception:
        pass

    def paint(text: str, tx: float, ty: float, color) -> None:
        _font(size)
        if hot:
            blf.color(font_id, 0.0, 0.0, 0.0, 0.9)
            blf.position(font_id, tx + 1.0, ty - 1.0, 0.0)
            blf.draw(font_id, text)
        blf.color(font_id, color[0], color[1], color[2], color[3])
        blf.position(font_id, tx, ty, 0.0)
        blf.draw(font_id, text)

    base_y = y + pad_y
    paint(third, x + pad_x, base_y, (0.94, 0.95, 0.96, 1.0))
    paint(second, x + pad_x, base_y + line_h + gap, (0.94, 0.95, 0.96, 1.0))
    head, sep, tail = first.partition("  ")
    if sep and tail:
        paint(head, x + pad_x, base_y + (line_h + gap) * 2.0, (role_rgb[0], role_rgb[1], role_rgb[2], 1.0))
        paint(tail, x + pad_x + _text_width(font_id, head + "  "), base_y + (line_h + gap) * 2.0, (1.0, 1.0, 1.0, 1.0))
    else:
        paint(first, x + pad_x, base_y + (line_h + gap) * 2.0, (1.0, 1.0, 1.0, 1.0))
    return x, y, bw, bh


def _draw_gallery_generate(plank, path: str, over: str, mode_over: str, scale: float = 1.0):
    """Generate: then Center and Here, under the tablet's right edge."""
    x, y, w, _h = plank
    scale = max(0.35, float(scale))
    chip = scale * 0.62
    size = max(6, min(48, int(round(12.0 * chip))))
    font_id = _font(size)
    gap = 3.0 * chip
    bh = 21.0 * chip
    label = "Generate:"
    label_w = _text_width(font_id, label)
    specs = []
    total = label_w
    for mode, text in (("center", "Center"), ("here", "Here")):
        bw = _text_width(font_id, text) + (8.0 * 2.0 + 3.0) * chip
        specs.append((mode, text, bw))
        total += gap + bw
    cursor = x + w - total
    by = y - 2.0 * scale - bh
    _font(size)
    blf.color(font_id, 0.0, 0.0, 0.0, 0.9)
    blf.position(font_id, cursor + 1.0, by + 4.0 * chip - 1.0, 0.0)
    blf.draw(font_id, label)
    blf.color(font_id, 1.0, 1.0, 1.0, 0.95)
    blf.position(font_id, cursor, by + 4.0 * chip, 0.0)
    blf.draw(font_id, label)
    cursor += label_w + gap
    boxes = []
    for mode, text, bw in specs:
        hot = path == over and mode == mode_over
        _draw_gallery_chip(font_id, cursor, by, text, hot, chip)
        boxes.append((cursor, by, bw, bh, path, mode))
        cursor += bw + gap
    return boxes


def _gallery_plank_quad(item):
    """Flat board on the floor, in front of the feet. Returns four world corners."""
    mat = item.get("matrix")
    if mat is None:
        return None
    bind = item.get("bind") or {}
    mn = bind.get("mn")
    foot_y = float(mn[1]) if mn is not None else 0.0
    foot = mat @ Vector((0.0, foot_y, 0.0))
    forward = mat.to_3x3() @ Vector((0.0, 0.0, 1.0))
    forward.z = 0.0
    if forward.length_squared < 1.0e-8:
        forward = Vector((0.0, 1.0, 0.0))
    else:
        forward.normalize()
    right = Vector((forward.y, -forward.x, 0.0))
    half_w = 0.50
    half_d = 0.16
    center = Vector((foot.x, foot.y, foot.z + 0.04)) + forward * (0.20 + half_d)
    text_up = -forward
    # Counter-clockwise from above so the colored face points up, not into the floor.
    return (
        center - right * half_w - text_up * half_d,
        center - right * half_w + text_up * half_d,
        center + right * half_w + text_up * half_d,
        center + right * half_w - text_up * half_d,
    )


def _draw_gallery_planks() -> None:
    items = [item for item in list(_GALLERY.get("items") or []) if not item.get("partner")]
    if not items:
        return
    try:
        shader = _gallery_plank_shader()
    except Exception:
        traceback.print_exc()
        return
    gpu.state.blend_set("ALPHA")
    try:
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.depth_mask_set(False)
        gpu.state.face_culling_set("NONE")
    except Exception:
        pass
    try:
        for item in items:
            corners = _gallery_plank_quad(item)
            if corners is None:
                continue
            if item.get("plank_tex") is None:
                label = item.get("label") or _gallery_label_lines(str(item.get("path") or ""))
                try:
                    item["plank_tex"] = _gallery_bake_plank(label)
                except Exception:
                    traceback.print_exc()
                    continue
            batch = batch_for_shader(
                shader,
                "TRI_FAN",
                {
                    "pos": [(co.x, co.y, co.z) for co in corners],
                    "uv": ((0.0, 0.0), (0.0, 1.0), (1.0, 1.0), (1.0, 0.0)),
                },
            )
            shader.bind()
            mvp = gpu.matrix.get_projection_matrix() @ gpu.matrix.get_model_view_matrix()
            shader.uniform_float("ModelViewProjectionMatrix", mvp)
            shader.uniform_sampler("image", item["plank_tex"])
            batch.draw(shader)
    finally:
        try:
            gpu.state.face_culling_set("BACK")
            gpu.state.depth_mask_set(True)
            gpu.state.depth_test_set("NONE")
        except Exception:
            pass
        gpu.state.blend_set("NONE")


def _gallery_label_lines(path: str) -> Tuple[str, str, str]:
    """Action name, scene name, and the folder the clip is taken from."""
    file_path = Path(path)
    beat = _stick_beat(file_path.name)
    role = _role(file_path.name)
    action = beat.replace("_", " ").title() if beat else file_path.stem
    if role == "player":
        action = f"{action}    player"
    elif role == "partner":
        action = f"{action}    partner"
    scene_name = ""
    folder = ""
    folded = str(file_path).replace("/", "\\").casefold()
    cache = _GALLERY.setdefault("label_cache", {})
    hit = cache.get(folded)
    if hit is not None:
        return hit
    best = ""
    for row in (_INDEX.get("data") or {}).get("scenes") or []:
        raw = str(row.get("dir") or "")
        key = raw.replace("/", "\\").casefold()
        if key and folded.startswith(key) and len(key) > len(best):
            best = key
            scene_name = str(row.get("name") or "")
            folder = raw
    if not scene_name:
        scene_name = file_path.parent.name.replace("_", " ")
        folder = str(file_path.parent)
    scene_name = scene_name.replace("_", " ")
    origin = Path(folder)
    taken = origin.parent.name.replace("_", " ")
    if not taken or taken.casefold() == scene_name.casefold():
        taken = origin.parent.parent.name.replace("_", " ")
    where = f"from   {taken}" if taken else f"from   {origin.name.replace('_', ' ')}"
    result = (action, scene_name, where)
    cache[folded] = result
    return result


def _gallery_box_hit(box, mx: float, my: float) -> bool:
    if not box:
        return False
    x, y, w, h = box
    return x <= mx <= x + w and y <= my <= y + h


def _gallery_cancel_hit(region, mx: float, my: float) -> bool:
    boxes = _GALLERY.get("cancel_boxes") or {}
    return _gallery_box_hit(boxes.get(region.as_pointer()), mx, my)


def _gallery_generate_hit(region, mx: float, my: float) -> Tuple[str, str]:
    rows = (_GALLERY.get("generate_boxes") or {}).get(region.as_pointer()) or []
    for row in rows:
        x, y, w, h, path, mode = row
        if _gallery_box_hit((x, y, w, h), mx, my):
            return str(path), str(mode)
    return "", ""


def _gallery_banner_hit(region, mx: float, my: float) -> str:
    rows = (_GALLERY.get("banner_boxes") or {}).get(region.as_pointer()) or []
    for x, y, w, h, kind in rows:
        if _gallery_box_hit((x, y, w, h), mx, my):
            return str(kind)
    return ""


def _draw_gallery_banner(region, rv3d) -> None:
    """Remove and Generate float above the row and scale with the camera."""
    points = _gallery_banner_points()
    labels = (("clear", "Remove holograms"), ("all", "Generate all"))
    hot = str(_GALLERY.get("banner_over") or "")
    boxes = []
    if rv3d is not None:
        for anchor, (kind, text) in zip(points, labels):
            try:
                xy = location_3d_to_region_2d(region, rv3d, anchor)
            except Exception:
                xy = None
            if xy is None:
                continue
            scale = max(0.35, _gallery_ui_scale(region, rv3d, anchor))
            size = max(8, min(64, int(round(16.0 * scale))))
            font_id = _font(size)
            pad = (8.0 * 2.0 + 3.0) * scale
            bw = _text_width(font_id, text) + pad
            bh = 21.0 * scale
            x = float(xy[0]) - bw * 0.5
            y = float(xy[1]) - bh * 0.5
            _font(size)
            _draw_gallery_chip(font_id, x, y, text, hot == kind, scale)
            boxes.append((x, y, bw, bh, kind))
    _GALLERY.setdefault("banner_boxes", {})[region.as_pointer()] = boxes


def _gallery_label_hit(region, mx: float, my: float) -> str:
    rows = (_GALLERY.get("label_boxes") or {}).get(region.as_pointer()) or []
    for x, y, w, h, path in rows:
        if _gallery_box_hit((x, y, w, h), mx, my):
            return str(path)
    return ""


def _gallery_follow_browser(path: str) -> None:
    """The clip chosen in the list lights the matching hologram."""
    want = _path_key(path)
    match = ""
    if want:
        for item in list(_GALLERY.get("items") or []):
            if item.get("partner"):
                continue
            item_path = str(item.get("path") or "")
            if _path_key(item_path) == want:
                match = item_path
                break
    if str(_GALLERY.get("picked_path") or "") == match:
        return
    _GALLERY["picked_path"] = match
    _tag()


def _gallery_sticky_path() -> str:
    """The hologram under the pointer, or the last one it rested on."""
    hover = str(_GALLERY.get("hover_path") or "")
    if hover:
        return hover
    last = str(_GALLERY.get("last_hover") or "")
    if last:
        return last
    return ""


def _gallery_marked(path: str) -> bool:
    """The active hologram stays lit after the pointer leaves it."""
    path = str(path or "")
    if not path:
        return False
    return path == _gallery_sticky_path()


def _gallery_hud_plaque_path() -> str:
    """Name card for the hologram under the pointer, else the last one hovered."""
    hover = str(_GALLERY.get("hover_path") or "")
    if hover:
        return hover
    gen = str(_GALLERY.get("generate_over") or "")
    if gen:
        return gen
    return str(_GALLERY.get("last_hover") or "")


def _gallery_show_clip(path: str) -> None:
    """Select the hovered hologram in the browser list and scroll it into view."""
    path = str(path or "").strip()
    if not path:
        return
    listed = list(_STATE.get("clip_paths") or [])
    want = _path_key(path)
    file_name = Path(path).name.casefold()
    match = ""
    index = -1
    for i, item in enumerate(listed):
        if _path_key(item) == want or Path(item).name.casefold() == file_name:
            match = item
            index = i
            break
    if match:
        path = match
    _preview_follow(path)
    if _path_key(path) != _path_key(str(_STATE.get("clip_path") or "")):
        _STATE["clip_path"] = path
    if index < 0:
        return
    scroll = int(_STATE.get("clip_scroll") or 0)
    visible = max(1, int(_STATE.get("clip_visible") or 8))
    if index < scroll or index >= scroll + visible:
        _STATE["clip_scroll"] = max(0, index - (visible // 3))


def _gallery_track_pointer(context, event) -> None:
    if not _GALLERY.get("items"):
        if _GALLERY.get("hover_path") or _GALLERY.get("cancel_over") or _GALLERY.get("generate_over") or _GALLERY.get("banner_over"):
            _GALLERY["hover_path"] = ""
            _GALLERY["cancel_over"] = False
            _GALLERY["generate_over"] = ""
            _GALLERY["generate_mode"] = ""
            _GALLERY["banner_over"] = ""
            _tag()
        return
    found = view3d_under_pointer(context, event)
    if found is None:
        return
    _area, region, mx, my = found
    if pointer_over_strip(region, mx, my):
        _GALLERY["plaque_lock"] = False
        _GALLERY["plaque_near"] = False
        if _GALLERY.get("hover_path") or _GALLERY.get("generate_over"):
            _GALLERY["hover_path"] = ""
            _GALLERY["generate_over"] = ""
            _GALLERY["generate_mode"] = ""
            _tag()
        return
    over_cancel = _gallery_cancel_hit(region, mx, my)
    banner = "" if over_cancel or pointer_over_strip(region, mx, my) else _gallery_banner_hit(region, mx, my)
    path = ""
    gen_path = ""
    gen_mode = ""
    label = ""
    if not over_cancel and not banner and not pointer_over_strip(region, mx, my):
        gen_path, gen_mode = _gallery_generate_hit(region, mx, my)
        label = _gallery_label_hit(region, mx, my)
        path = gen_path or label
        if not path:
            window = getattr(context, "window", None)
            try:
                with context.temp_override(window=window, area=_area, region=region):
                    path = _gallery_pick(bpy.context, mx, my)
            except Exception:
                path = ""
        if not path and _gallery_bridge_hit(region, mx, my):
            path = str(_GALLERY.get("plaque_hold") or "")
    lock = bool(gen_path or label)
    near = bool(path) and not lock and _gallery_bridge_hit(region, mx, my)
    if (
        path == str(_GALLERY.get("hover_path") or "")
        and over_cancel == bool(_GALLERY.get("cancel_over"))
        and gen_path == str(_GALLERY.get("generate_over") or "")
        and gen_mode == str(_GALLERY.get("generate_mode") or "")
        and banner == str(_GALLERY.get("banner_over") or "")
        and lock == bool(_GALLERY.get("plaque_lock"))
        and near == bool(_GALLERY.get("plaque_near"))
    ):
        return
    _GALLERY["hover_path"] = path
    if path:
        _GALLERY["last_hover"] = path
    _GALLERY["cancel_over"] = over_cancel
    _GALLERY["generate_over"] = gen_path
    _GALLERY["generate_mode"] = gen_mode
    _GALLERY["banner_over"] = banner
    _GALLERY["plaque_lock"] = lock
    _GALLERY["plaque_near"] = near
    if path:
        _gallery_show_clip(path)
    _tag()


def _draw_gallery_chip(font_id: int, x: float, y: float, text: str, hot: bool, scale: float = 1.0) -> Tuple[float, float]:
    """Race-menu chip. Returns width and height."""
    pad_x = 8.0 * scale
    bh = 21.0 * scale
    tw = _text_width(font_id, text)
    bw = tw + pad_x * 2.0 + 3.0 * scale
    chip = (0.18, 0.22, 0.28, 0.94) if hot else (0.07, 0.08, 0.10, 0.88)
    bar = (0.82, 0.94, 1.0, 1.0) if hot else (0.35, 0.55, 0.72, 0.95)
    _rect(x, y, bw, bh, chip)
    _rect(x, y, 3.0 * scale, bh, bar)
    if hot:
        _stroke_rect(x, y, bw, bh, (0.82, 0.94, 1.0, 1.0), max(1.25, 2.0 * scale))
    blf.color(font_id, 1.0, 1.0, 1.0, 1.0 if hot else 0.92)
    blf.position(font_id, x + pad_x + 2.0 * scale, y + 4.0 * scale, 0.0)
    blf.draw(font_id, text)
    return bw, bh


def _draw_gallery_hud() -> None:
    items = list(_GALLERY.get("items") or [])
    context = bpy.context
    region = getattr(context, "region", None)
    if region is None or not items:
        return
    hud_mark = time.perf_counter()
    rv3d = getattr(context, "region_data", None)
    boxes = []
    buttons = []
    seen = set()
    gen_over = str(_GALLERY.get("generate_over") or "")
    gen_mode = str(_GALLERY.get("generate_mode") or "")
    plaque_path = _gallery_hud_plaque_path()
    label_count = 0
    if rv3d is not None and plaque_path:
        for item in items:
            if item.get("partner"):
                continue
            path = str(item.get("path") or "")
            if not path or path in seen:
                continue
            if path != plaque_path:
                continue
            seen.add(path)
            marked = _gallery_marked(path) and path != gen_over
            if not _gallery_item_on_screen(item, region, rv3d):
                continue
            screen = _gallery_body_screen(item, region, rv3d)
            if screen is None:
                continue
            cx, head, world, body_left, body_right = screen
            scale = _gallery_ui_scale(region, rv3d, world)
            gen_h = 21.0 * max(0.35, scale) * 0.62
            anchor_y = float(head) + gen_h + 6.0 * scale
            cx, anchor_y = _gallery_follow_xy(cx, anchor_y)
            box = _draw_gallery_name(
                cx,
                anchor_y,
                path,
                marked,
                region,
                scale,
            )
            boxes.append((*box, path))
            added = _draw_gallery_generate(box, path, gen_over, gen_mode, scale)
            buttons.extend(added)
            pad = 22.0 * scale
            stack_bottom = min([float(box[1])] + [float(row[1]) for row in added])
            stack_top = float(box[1]) + float(box[3])
            left = min(float(box[0]), float(body_left)) - pad
            right = max(float(box[0]) + float(box[2]), float(body_right)) + pad
            low = min(stack_bottom, float(head)) - pad
            high = max(stack_top, float(head)) + pad
            _GALLERY.setdefault("plaque_bridge", {})[region.as_pointer()] = (left, low, right - left, high - low)
            _GALLERY["plaque_hold"] = path
            label_count += 1
    if label_count == 0:
        _GALLERY.setdefault("plaque_bridge", {}).pop(region.as_pointer(), None)
    _GALLERY.setdefault("label_boxes", {})[region.as_pointer()] = boxes
    _GALLERY.setdefault("generate_boxes", {})[region.as_pointer()] = buttons
    font_id = _font(12)
    cancel = "Cancel"
    tw = _text_width(font_id, cancel)
    bw = tw + 8.0 * 2.0 + 3.0
    bh = 21.0
    x = 16.0
    y = max(16.0, float(region.height) - 16.0 - bh)
    _draw_gallery_chip(font_id, x, y, cancel, bool(_GALLERY.get("cancel_over")))
    _GALLERY.setdefault("cancel_boxes", {})[region.as_pointer()] = (x, y, bw, bh)
    _draw_gallery_banner(region, rv3d)
    _gallery_perf_inc("hud_frames")
    _gallery_perf_inc("hud_labels", label_count)
    _gallery_perf_add_ms("hud_ms", (time.perf_counter() - hud_mark) * 1000.0)
    _gallery_perf_maybe_report()


def handle_strip_click(context, event, mx=None, my=None) -> bool:
    """True when the animation strip used this click."""
    if not _browser_on(context):
        return False
    region = getattr(context, "region", None)
    if region is None:
        return False
    refresh_strip_pick_data(context)
    layout = _LAYOUTS.get(region.as_pointer()) or {}
    if mx is None:
        mx = float(event.mouse_region_x)
    if my is None:
        my = float(event.mouse_region_y)
    mx = float(mx)
    my = float(my)
    _POINTER["mx"] = mx
    _POINTER["my"] = my
    strip = layout.get("strip")
    if not strip or not _over_box(strip, mx, my):
        return False
    eye = layout.get("preview_eye")
    if eye and _over_box(
        (eye[0] - 4.0, eye[1] - 4.0, eye[2] + 8.0, eye[3] + 8.0),
        mx,
        my,
    ):
        _flash_chip("preview_eye")
        _toggle_preview()
        return True
    which = _split_at(layout, mx, my)
    if which and getattr(event, "value", "PRESS") == "PRESS":
        try:
            bpy.ops.gr2lab.anim_pane_resize("INVOKE_DEFAULT", which=which)
        except Exception:
            traceback.print_exc()
        return True
    found = _hit(region, mx, my)
    if found is None:
        return False
    kind, payload = found
    menu_kinds = {"filter", "filter_cast", "filter_kind", "filter_who", "filter_clear"}
    if _STATE.get("filter_open") and kind not in menu_kinds:
        _STATE["filter_open"] = False
    if kind in _TOOLBAR_CHIP_KINDS | {"prepare", "gallery_add", "gallery_load", "preview_eye"} and not (kind == "recent" and payload):
        _flash_chip(kind)
    if kind == "prepare":
        try:
            bpy.ops.gr2lab.anim_prepare("INVOKE_DEFAULT")
        except RuntimeError:
            pass
        _tag()
        return True
    if kind == "act":
        query = (_STATE.get("query") or "").strip()
        _STATE["act_hold_until"] = time.time() + 2.0
        _STATE["scene_scroll"] = 0
        _STATE["clip_scroll"] = 0
        _STATE["filtered_key"] = ""
        if _STATE.get("act") == "All" and query:
            _apply_search_edit("")
            _set_search_caret(0)
            _STATE["search_sel"] = False
            _set_notice("All scenes")
        else:
            try:
                index = _ACTS.index(_STATE["act"])
            except ValueError:
                index = 0
            _STATE["act"] = _ACTS[(index + 1) % len(_ACTS)]
            label = "Every act" if _STATE["act"] == "All" else _STATE["act"]
            _set_notice(label)
    elif kind == "filter":
        _STATE["filter_open"] = not bool(_STATE.get("filter_open"))
    elif kind == "filter_cast":
        _toggle_cast(str(payload or ""))
        _STATE["filter_open"] = True
    elif kind == "filter_kind":
        _toggle_token("kind", str(payload or ""), {item[0] for item in _FILTER_KINDS})
        _STATE["filter_open"] = True
    elif kind == "filter_who":
        _toggle_token("who", str(payload or ""), set(_COMPANIONS))
        _STATE["filter_open"] = True
    elif kind == "filter_clear":
        _clear_filters()
        _STATE["filter_open"] = True
    elif kind == "whole":
        _STATE["whole_scene"] = not bool(_STATE.get("whole_scene"))
    elif kind == "rig":
        _STATE["rig_open"] = not bool(_STATE.get("rig_open"))
    elif kind == "rig_shapes":
        flags = _browser_rig_flags(context)
        _store_browser_rig(context, shapes=not flags["shapes"])
        _set_notice("Shapes on" if not flags["shapes"] else "Shapes off")
    elif kind == "rig_limbs":
        flags = _browser_rig_flags(context)
        _store_browser_rig(context, limbs=not flags["limbs"])
        _set_notice("Limbs IK on" if not flags["limbs"] else "Limbs IK off")
    elif kind == "rig_head":
        flags = _browser_rig_flags(context)
        _store_browser_rig(context, head=not flags["head"])
        _set_notice("Head IK on" if not flags["head"] else "Head IK off")
    elif kind == "rig_tail":
        flags = _browser_rig_flags(context)
        _store_browser_rig(context, tail=not flags["tail"])
        _set_notice("Tail on" if not flags["tail"] else "Tail off")
    elif kind == "rig_mesh":
        flags = _browser_rig_flags(context)
        order = ("BODY_CLOTH", "BODY", "NONE")
        nxt = order[(order.index(flags["meshes"]) + 1) % len(order)]
        _store_browser_rig(context, meshes=nxt)
        _set_notice(
            {"BODY_CLOTH": "Meshes: body and cloth", "BODY": "Meshes: body", "NONE": "Meshes: none"}[nxt]
        )
    elif kind == "rig_akelka":
        flags = _browser_rig_flags(context)
        _store_browser_rig(context, akelka=not flags["akelka"])
        _set_notice("AkELkA on" if not flags["akelka"] else "AkELkA off")
    elif kind == "center":
        has_holo = any(item.get("matrix") is not None for item in list(_GALLERY.get("items") or []))
        on_center = has_holo and _gallery_matches_slots(centered=True)
        on_corner = has_holo and _gallery_matches_slots(centered=False)
        if on_center and not on_corner:
            nxt = False
        elif has_holo and not on_center:
            nxt = True
        else:
            nxt = not bool(_STATE.get("center_parent"))
        _sync_browser_center_parent(context, nxt)
        _gallery_apply_center()
        _set_notice(
            "Holograms centered on the origin"
            if nxt
            else "Holograms back on the corner grid"
        )
    elif kind == "edit":
        _STATE["edit_copy"] = not bool(_STATE.get("edit_copy"))
    elif kind == "recent":
        _STATE["show_recent"] = not bool(_STATE.get("show_recent", False))
    elif kind == "gallery_add":
        _ask_gallery_bulk_again("add", 0)
    elif kind == "gallery_load":
        _ask_gallery_bulk_again("load", 0)
    elif kind == "glasses":
        try:
            from .scene_stage_empties import glasses_frame_sync_toggle

            _ok, msg = glasses_frame_sync_toggle(context)
            print(f"[GR2 LAB] {msg}", flush=True)
            _set_notice(msg)
        except Exception:
            traceback.print_exc()
            _set_notice("Glasses sync failed")
    elif kind == "holo_mesh":
        _STATE["holo_mesh"] = not bool(_STATE.get("holo_mesh"))
        _set_notice("Holograms: solid mesh" if _STATE["holo_mesh"] else "Holograms: transparent")
    elif kind == "preview_eye":
        _toggle_preview()
        return True
    elif kind == "preview_view":
        _preview_orbit_begin(event)
        try:
            bpy.ops.gr2lab.preview_orbit("INVOKE_DEFAULT")
        except Exception:
            traceback.print_exc()
            _PREVIEW["orbit"] = None
        return True
    elif kind == "explorer":
        if bpy is not None and not bpy.app.timers.is_registered(_explorer_open_timer):
            bpy.app.timers.register(_explorer_open_timer, first_interval=0.02)
    elif kind == "search":
        _begin_gpu_search(
            region,
            mx,
            extend=bool(getattr(event, "shift", False)),
            window_x=float(getattr(event, "mouse_x", mx)),
        )
        return True
    elif kind == "vscroll" and payload in {"scene", "clip"}:
        try:
            bpy.ops.gr2lab.anim_list_scroll("INVOKE_DEFAULT", which=str(payload))
        except Exception:
            traceback.print_exc()
        return True
    elif kind == "prev":
        _step_scene(-1)
    elif kind == "next":
        _step_scene(1)
    elif kind == "scene":
        _STATE["scene_id"] = payload
        _STATE["clip_scroll"] = 0
        if _search_tokens(_STATE.get("query") or ""):
            for index, entry in enumerate(_browser_clip_entries()):
                if str(entry.get("scene_id") or "") == str(payload):
                    _STATE["clip_scroll"] = index
                    break
    elif kind in {"clip", "recent"} and payload:
        ev_val = getattr(event, "value", "PRESS")
        if ev_val == "RELEASE":
            return False
        path = str(payload)
        if ev_val == "DOUBLE_CLICK":
            _clear_clip_arm()
            _select_strip_clip(context, path)
            _place_strip_clip_at_cursor(context, path)
            return True
        _arm_clip_press(context, event, region, path, mx, my)
        return True
    _tag()
    return True


def _on_click(context, event) -> set:
    if handle_strip_click(context, event):
        return {"FINISHED"}
    return {"PASS_THROUGH"}


class GR2LAB_OT_anim_pane_resize(bpy.types.Operator):
    """Drag the divider between animation-strip columns."""

    bl_idname = "gr2lab.anim_pane_resize"
    bl_label = "Resize animation strip columns"
    bl_options = {"INTERNAL"}

    which: bpy.props.StringProperty(options={"SKIP_SAVE"})

    def invoke(self, context, event):
        which = str(self.which or "")
        if which not in {"scene", "clip"}:
            return {"CANCELLED"}
        self._which = which
        self._scene = float(_STATE.get("pane_scene") or 0.38)
        self._clip = float(_STATE.get("pane_clip") or 0.26)
        try:
            context.window.cursor_modal_set("MOVE_X")
        except Exception:
            pass
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _restore_cursor(self) -> None:
        try:
            bpy.context.window.cursor_modal_restore()
        except Exception:
            pass

    def modal(self, context, event):
        region = getattr(context, "region", None)
        width = float(region.width) if region is not None else 0.0
        if event.type == "MOUSEMOVE" and width > 0.0:
            _set_pane_from_mouse(self._which, float(event.mouse_region_x), width)
            _tag()
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            self._restore_cursor()
            _tag()
            return {"FINISHED"}
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            _STATE["pane_scene"] = self._scene
            _STATE["pane_clip"] = self._clip
            self._restore_cursor()
            _tag()
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}


class GR2LAB_OT_anim_list_scroll(bpy.types.Operator):
    """Drag a scene or GR2 list scrollbar."""

    bl_idname = "gr2lab.anim_list_scroll"
    bl_label = "Scroll animation list"
    bl_options = {"INTERNAL"}

    which: bpy.props.StringProperty(options={"SKIP_SAVE"})

    def invoke(self, context, event):
        which = str(self.which or "")
        if which not in {"scene", "clip"}:
            return {"CANCELLED"}
        info = None
        region = getattr(context, "region", None)
        if region is not None:
            info = ((_LAYOUTS.get(region.as_pointer()) or {}).get("vscroll") or {}).get(which)
        if not info:
            return {"CANCELLED"}
        _tx, thumb_y, _tw, thumb_h = info["thumb"]
        my = float(event.mouse_region_y)
        if thumb_y <= my <= thumb_y + thumb_h:
            grab = my - thumb_y
        else:
            grab = thumb_h * 0.5
        self._which = which
        self._grab = grab
        _STATE["vscroll_drag"] = which
        _vscroll_apply(which, my, grab)
        try:
            context.window.cursor_modal_set("MOVE_Y")
        except Exception:
            pass
        context.window_manager.modal_handler_add(self)
        _tag()
        return {"RUNNING_MODAL"}

    def _restore_cursor(self) -> None:
        _STATE["vscroll_drag"] = ""
        try:
            bpy.context.window.cursor_modal_restore()
        except Exception:
            pass

    def modal(self, context, event):
        if event.type == "MOUSEMOVE":
            _vscroll_apply(self._which, float(event.mouse_region_y), self._grab)
            _tag()
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            self._restore_cursor()
            _tag()
            return {"FINISHED"}
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            self._restore_cursor()
            _tag()
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}


class GR2LAB_OT_anim_clip_drag(bpy.types.Operator):
    """Drag a cinematic clip from the strip into the 3D view."""

    bl_idname = "gr2lab.anim_clip_drag"
    bl_label = "Drag animation clip"
    bl_options = {"INTERNAL"}

    filepath: bpy.props.StringProperty(options={"SKIP_SAVE"})
    start_x: bpy.props.FloatProperty(default=0.0, options={"SKIP_SAVE"})
    start_y: bpy.props.FloatProperty(default=0.0, options={"SKIP_SAVE"})
    use_dialog: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    def _clear(self) -> None:
        pre = _DRAG.get("preload")
        if pre is not None and not pre.get("done"):
            _abort_clip_preload()
        else:
            _DRAG["preload"] = None
        _DRAG["preload_failed"] = ""
        timer = _DRAG.get("wm_timer")
        if timer is not None:
            try:
                bpy.context.window_manager.event_timer_remove(timer)
            except Exception:
                pass
        _DRAG["active"] = False
        _DRAG["filepath"] = ""
        _DRAG["label"] = ""
        _DRAG["point"] = None
        _DRAG["normal"] = None
        _DRAG["over_strip"] = False
        _DRAG["t0"] = 0.0
        _DRAG["wm_timer"] = None
        _DRAG["pair"] = None
        _DRAG["partner_fill"] = ""
        _DRAG["mesh_draw"] = None
        _DRAG["mesh_bucket"] = None
        _DRAG["mesh_clock"] = None
        _DRAG["mesh_fail"] = False
        _DRAG["mesh_logged"] = ""
        _DRAG_GPU.clear()
        try:
            bpy.context.window.cursor_modal_restore()
        except Exception:
            pass
        _tag()
        try:
            bpy.app.timers.register(_boot_browser_modal, first_interval=0.0)
        except Exception:
            pass

    def _sync_pointer(self, context, event) -> None:
        region = getattr(context, "region", None)
        if region is None:
            return
        mx = float(event.mouse_region_x)
        my = float(event.mouse_region_y)
        _DRAG["mx"] = mx
        _DRAG["my"] = my
        _DRAG["region"] = region.as_pointer()
        _DRAG["region_w"] = float(region.width)
        _DRAG["region_h"] = float(region.height)
        layout = _LAYOUTS.get(region.as_pointer()) or {}
        _DRAG["over_strip"] = _over_box(layout.get("strip"), mx, my)
        _DRAG["last_move_t"] = time.perf_counter()
        now = float(_DRAG["last_move_t"])
        last_hit = float(_DRAG.get("hit_t") or 0.0)
        hmx = float(_DRAG.get("hit_mx") or mx)
        hmy = float(_DRAG.get("hit_my") or my)
        ddx = mx - hmx
        ddy = my - hmy
        moved = (ddx * ddx + ddy * ddy) >= (
            CLIP_DRAG_HIT_MIN_PX * CLIP_DRAG_HIT_MIN_PX
        )
        old_grid = bool(_DRAG.get("grid_place"))
        grid_place = bool(getattr(event, "shift", False))
        _DRAG["grid_place"] = grid_place
        grid_changed = old_grid != grid_place
        origin, direction = _drop_view_ray(context, mx, my)
        plane_co = _DRAG.get("plane_co")
        plane_no = _DRAG.get("normal")
        if (
            not grid_place
            and origin is not None
            and plane_co is not None
            and plane_no is not None
        ):
            slid = _drop_on_plane(origin, direction, plane_co, plane_no)
            if slid is not None:
                _DRAG["point"] = slid
        if (
            plane_co is None
            or moved
            or grid_changed
            or (now - last_hit) >= CLIP_DRAG_HIT_INTERVAL_S
        ):
            point, normal = _resolve_drop_hit(
                context, mx, my, grid_place=bool(_DRAG.get("grid_place"))
            )
            _DRAG["point"] = point
            _DRAG["normal"] = normal
            _DRAG["plane_co"] = point.copy() if point is not None else None
            _DRAG["hit_mx"] = mx
            _DRAG["hit_my"] = my
            _DRAG["hit_t"] = now
        _tag()

    def invoke(self, context, event):
        path = str(self.filepath or "")
        if not path:
            return {"CANCELLED"}
        _DRAG["active"] = True
        _DRAG["filepath"] = path
        _DRAG["label"] = Path(path).stem
        _DRAG["sx"] = float(self.start_x or event.mouse_region_x)
        _DRAG["sy"] = float(self.start_y or event.mouse_region_y)
        _DRAG["use_dialog"] = bool(self.use_dialog)
        _DRAG["grid_place"] = bool(getattr(event, "shift", False))
        _DRAG["t0"] = time.perf_counter()
        _DRAG["last_move_t"] = _DRAG["t0"]
        _DRAG["hit_t"] = 0.0
        _DRAG["hit_mx"] = float(self.start_x or event.mouse_region_x)
        _DRAG["hit_my"] = float(self.start_y or event.mouse_region_y)
        _DRAG["timer_tick"] = 0
        _DRAG["pair"] = None
        _DRAG["partner_fill"] = ""
        _kill_stick_preview_proc()
        _HOVER["gen"] = int(_HOVER.get("gen") or 0) + 1
        _PREFETCH["gen"] = int(_PREFETCH.get("gen") or 0) + 1
        _PREFETCH["queue"] = []
        _ensure_drag_stick_preview(path)
        stick_ms = (time.perf_counter() - float(_DRAG["t0"])) * 1000.0
        print(f"[GR2 LAB drop] drag started {Path(path).name}", flush=True)
        slot_mark = time.perf_counter()
        _stick_pair_slot_matrices(path)
        slot_ms = (time.perf_counter() - slot_mark) * 1000.0
        _DRAG["mesh_draw"] = None
        _DRAG["mesh_bucket"] = None
        _DRAG["mesh_clock"] = None
        _DRAG["mesh_fail"] = False
        _DRAG["mesh_wait_logged"] = ""
        _DRAG["draw_logged"] = False
        _DRAG["pose_logged"] = False
        _DRAG["pose_samples"] = []
        _refresh_drag_mesh()
        mesh_ms = (time.perf_counter() - float(_DRAG["t0"])) * 1000.0 - stick_ms - slot_ms
        timer_mark = time.perf_counter()
        _DRAG["wm_timer"] = context.window_manager.event_timer_add(
            1.0 / 48.0, window=context.window
        )
        timer_ms = (time.perf_counter() - timer_mark) * 1000.0
        pointer_mark = time.perf_counter()
        self._sync_pointer(context, event)
        pointer_ms = (time.perf_counter() - pointer_mark) * 1000.0
        try:
            context.window.cursor_modal_set("HAND")
        except Exception:
            pass
        context.window_manager.modal_handler_add(self)
        _tag()
        print(
            "[GR2 LAB drop] open  "
            f"sticks {stick_ms:.2f}ms  "
            f"slot {slot_ms:.2f}ms  "
            f"hologram {mesh_ms:.2f}ms  "
            f"timer {timer_ms:.2f}ms  "
            f"pointer {pointer_ms:.2f}ms  "
            f"total {(time.perf_counter() - float(_DRAG['t0'])) * 1000.0:.2f}ms",
            flush=True,
        )
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not _ALIVE:
            self._clear()
            return {"CANCELLED"}
        if event.type == "TIMER":
            _DRAG["timer_tick"] = int(_DRAG.get("timer_tick") or 0) + 1
            if _DRAG.get("active"):
                _refresh_drag_mesh()
            pre = _DRAG.get("preload")
            if pre is not None and pre.get("commit") and not pre.get("done"):
                tick = int(_DRAG.get("timer_tick") or 0)
                if (tick % CLIP_PRELOAD_PUMP_EVERY) == 0:
                    _pump_clip_preload(context)
                pre = _DRAG.get("preload")
                failed = str(_DRAG.get("preload_failed") or "")
                if pre is not None and (
                    failed or pre.get("done")
                ):
                    self._clear()
                    if failed:
                        self.report({"ERROR"}, failed)
                        return {"CANCELLED"}
                    return {"FINISHED"}
            redraw_iv = 0.0
            _tag(redraw_iv)
            return {"RUNNING_MODAL"}
        waiting = _DRAG.get("preload") or {}
        if (
            not _DRAG.get("active")
            and waiting.get("commit")
            and not waiting.get("done")
        ):
            served = service_strip_during_modal(context, event)
            if served is not None:
                return served
            return {"PASS_THROUGH"}
        if event.type in {"LEFT_SHIFT", "RIGHT_SHIFT"}:
            self._sync_pointer(context, event)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE":
            self._sync_pointer(context, event)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            held = time.perf_counter() - float(_DRAG.get("t0") or time.perf_counter())
            print(
                f"[GR2 LAB drop] mouse up {Path(str(_DRAG.get('filepath') or '')).name}"
                f"  held {held:.2f}s",
                flush=True,
            )
            mx = float(event.mouse_region_x)
            my = float(event.mouse_region_y)
            dx = mx - float(_DRAG.get("sx") or 0.0)
            dy = my - float(_DRAG.get("sy") or 0.0)
            moved = (dx * dx + dy * dy) >= CLIP_DRAG_THRESHOLD * CLIP_DRAG_THRESHOLD
            path = str(_DRAG.get("filepath") or "")
            region = getattr(context, "region", None)
            layout = _LAYOUTS.get(region.as_pointer() if region else 0) or {}
            over_strip = _over_box(layout.get("strip"), mx, my)
            grid_place = bool(getattr(event, "shift", _DRAG.get("grid_place")))
            point, _normal = _resolve_drop_hit(context, mx, my, grid_place=grid_place)
            use_dialog = bool(_DRAG.get("use_dialog"))
            pre = _DRAG.get("preload")
            failed = str(_DRAG.get("preload_failed") or "")
            if failed:
                self._clear()
                self.report({"ERROR"}, failed)
                return {"CANCELLED"}
            if not path:
                self._clear()
                return {"CANCELLED"}
            if use_dialog and not moved:
                self._clear()
                bpy.ops.import_scene.gr2_full("INVOKE_DEFAULT", filepath=path)
                return {"FINISHED"}
            whole_scene = _browser_whole_scene(context)
            if not moved:
                self._clear()
                _place_strip_clip_at_cursor(context, path)
                return {"FINISHED"}
            if over_strip or point is None:
                self._clear()
                return {"CANCELLED"}
            if pre is not None:
                pre["commit"] = True
                pre["t_commit"] = time.perf_counter()
                pre["commit_point"] = point
                register_pending_clip_drop(
                    pre["path"], point, context, whole_scene=whole_scene
                )
                _DRAG["active"] = False
                if pre.get("ready"):
                    t_place = time.perf_counter()
                    _place_ready_drop(context, pre, point)
                    pre.setdefault("step_secs", {})[("place", 0)] = (
                        float((pre.get("step_secs") or {}).get(("place", 0)) or 0.0)
                        + (time.perf_counter() - t_place)
                    )
                    pre["timing_printed"] = False
                    _print_drop_report(pre, "on screen")
                    pre["done"] = True
                    _end_preload_ui(pre)
                    self._clear()
                    return {"FINISHED"}
                pre["state"]["preload_quiet"] = False
                pre["state"]["defer_clip_snap"] = False
                _show_preload_bar(context, pre)
                _pump_clip_preload(context)
                pre = _DRAG.get("preload")
                failed = str(_DRAG.get("preload_failed") or "")
                if failed:
                    self._clear()
                    self.report({"ERROR"}, failed)
                    return {"CANCELLED"}
                if pre is not None and not pre.get("done"):
                    _tag()
                    return {"RUNNING_MODAL"}
                self._clear()
                return {"FINISHED"}
            self._clear()
            _import_clip_at(
                context,
                path,
                point,
                place=True,
                whole_scene=whole_scene,
                replace_stack=True,
            )
            return {"FINISHED"}
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            self._clear()
            return {"CANCELLED"}
        if event.type in {
            "MIDDLEMOUSE",
            "WHEELUPMOUSE",
            "WHEELDOWNMOUSE",
            "TRACKPADPAN",
            "TRACKPADZOOM",
        }:
            return {"PASS_THROUGH"}
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        self._clear()


class GR2LAB_OT_anim_browser_modal(bpy.types.Operator):
    """Viewport modal so the animation strip receives clicks on every window."""

    bl_idname = "gr2lab.anim_browser_modal"
    bl_label = "GR2 animation browser modal"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        wm = context.window_manager
        booted = _modal_win_booted(wm, "gr2lab_browser_modal_wins")
        key = _window_ptr_key(context.window)
        if key in booted:
            return {"CANCELLED"}
        booted.add(key)
        _modal_win_set(wm, "gr2lab_browser_modal_wins", booted)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not _ALIVE:
            return {"CANCELLED"}
        if _track_search_drag(context, event):
            return {"RUNNING_MODAL"}
        captured = _search_capture_event(context, event)
        if captured is not None:
            return captured
        if event.type == "LEFTMOUSE" and event.value == "RELEASE" and _CLIP_ARM.get("path"):
            _finish_clip_arm(context)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE" and _try_armed_clip_drag(context, event):
            return {"RUNNING_MODAL"}
        if modal_strip_event(context, event):
            return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}

    def cancel(self, context):
        wm = context.window_manager
        booted = _modal_win_booted(wm, "gr2lab_browser_modal_wins")
        booted.discard(_window_ptr_key(context.window))
        _modal_win_set(wm, "gr2lab_browser_modal_wins", booted)
        return None


def _boot_browser_modal() -> None:
    wm = bpy.context.window_manager
    booted = _modal_win_booted(wm, "gr2lab_browser_modal_wins")
    for window in wm.windows:
        key = _window_ptr_key(window)
        if key in booted:
            continue
        launched = False
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            for region in area.regions:
                if region.type != "WINDOW":
                    continue
                try:
                    with bpy.context.temp_override(
                        window=window, area=area, region=region
                    ):
                        bpy.ops.gr2lab.anim_browser_modal("INVOKE_DEFAULT")
                    launched = True
                    break
                except Exception:
                    continue
            if launched:
                break
    return None


class GR2LAB_MT_anim_clip_menu(bpy.types.Menu):
    bl_label = "Animation clip"
    bl_idname = "GR2LAB_MT_anim_clip_menu"

    def draw(self, context):
        layout = self.layout
        op = layout.operator(
            "gr2lab.anim_clip_copy",
            text="Copy GR2 name",
            icon="COPYDOWN",
        )
        op.clip_path = _CLIP_MENU_PATH


class GR2LAB_OT_anim_clip_copy(bpy.types.Operator):
    """Copy the selected or hovered GR2 clip file name."""

    bl_idname = "gr2lab.anim_clip_copy"
    bl_label = "Copy GR2 clip name"
    bl_options = {"INTERNAL", "REGISTER"}

    clip_path: bpy.props.StringProperty(default="", options={"SKIP_SAVE", "HIDDEN"})

    @classmethod
    def poll(cls, context):
        return _browser_on(context)

    def execute(self, context):
        path = str(self.clip_path or "").strip() or _active_browser_clip_path()
        if not path:
            self.report({"WARNING"}, "No animation clip to copy")
            return {"CANCELLED"}
        if not copy_gr2_clip_name(path):
            self.report({"WARNING"}, "Copy failed")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Copied {Path(path).name}")
        return {"FINISHED"}

    def invoke(self, context, event):
        global _FORCE_XY
        path = _active_browser_clip_path()
        found = view3d_under_pointer(context, event)
        if found is not None:
            area, region, mx, my = found
            if pointer_over_strip(region, mx, my):
                window = getattr(context, "window", None)
                try:
                    with context.temp_override(
                        window=window, area=area, region=region
                    ):
                        _FORCE_XY = (mx, my)
                        refresh_strip_pick_data(context)
                        hit = _strip_clip_path_at(region, mx, my)
                        if hit:
                            path = hit
                except Exception:
                    traceback.print_exc()
                finally:
                    _FORCE_XY = None
        self.clip_path = path
        return self.execute(context)


_BULK_ASK = 100
_BULK_ASK_TWICE = 300


def _bulk_confirms_needed(count: int) -> int:
    """0 under 101, one confirm through 300, two confirms after that."""
    n = int(count)
    if n > _BULK_ASK_TWICE:
        return 2
    if n > _BULK_ASK:
        return 1
    return 0


def _ask_gallery_bulk_again(action: str, confirmed: int) -> None:
    """The first OK returns before a second popup can open."""
    def _run() -> None:
        wm = bpy.context.window_manager
        window = wm.windows[0] if wm.windows else None
        if window is None:
            return None
        area = next((item for item in window.screen.areas if item.type == "VIEW_3D"), None)
        region = None
        if area is not None:
            region = next((item for item in area.regions if item.type == "WINDOW"), None)
        try:
            with bpy.context.temp_override(window=window, area=area, region=region):
                bpy.ops.gr2lab.gallery_bulk(
                    "INVOKE_DEFAULT", action=str(action), confirmed=int(confirmed)
                )
        except Exception:
            traceback.print_exc()
        return None

    try:
        bpy.app.timers.register(_run, first_interval=0.05)
    except Exception:
        traceback.print_exc()


def _browser_mesh_mode(value: str, fallback: str = "BODY_CLOTH") -> str:
    mode = str(value or "").strip().upper()
    if mode in {"NONE", "BODY", "BODY_CLOTH"}:
        return mode
    return fallback


def _browser_rig_flags(context) -> dict:
    """One rig choice for every character a browser drop builds."""
    try:
        prefs = context.preferences.addons[__package__].preferences
    except Exception:
        prefs = None
    meshes = _browser_mesh_mode(getattr(prefs, "import_meshes", "BODY_CLOTH"))
    return {
        "shapes": bool(getattr(prefs, "rig_shapes", True)),
        "limbs": bool(getattr(prefs, "rig_ik_limbs", True)),
        "head": bool(getattr(prefs, "rig_ik_head", True)),
        "tail": bool(getattr(prefs, "import_tail", True)),
        "meshes": meshes,
        "akelka": bool(getattr(prefs, "import_akelka", True)),
    }


def _rig_bar_items(font_id, rig, mesh_label):
    """Labeled rig buttons. The words are the control; the hover box explains them."""
    rows = (
        ("rig_shapes", "Shapes", bool(rig["shapes"])),
        ("rig_limbs", "Limb IK", bool(rig["limbs"])),
        ("rig_head", "Head IK", bool(rig["head"])),
        ("rig_tail", "Tail", bool(rig["tail"])),
        ("rig_mesh", mesh_label, rig["meshes"] != "NONE"),
        ("rig_akelka", "AkELkA", bool(rig["akelka"])),
    )
    items = []
    total = 0.0
    for kind, label, on in rows:
        width = _text_width(font_id, label) + 16.0
        items.append((kind, label, width, on))
        total += width
    if items:
        total += 4.0 * (len(items) - 1)
    return items, total


def _draw_person_chip(hits, x, y, on: bool) -> None:
    bg = (0.24, 0.42, 0.62, 1.0) if on else (0.14, 0.16, 0.18, 1.0)
    _paint_button(x, y, 22.0, 20.0, "rig", bg, on=on)
    _draw_chip_icon("person", x, y, 22.0, 20.0)
    hits.append(("rig", x, y, 22.0, 20.0, ""))


def _draw_rig_bar(font_id, hits, x, y, items) -> None:
    for kind, label, width, on in items:
        bg = (0.24, 0.42, 0.62, 1.0) if on else (0.14, 0.16, 0.18, 1.0)
        _paint_button(x, y, width, 20.0, kind, bg, on=on)
        blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
        blf.position(font_id, x + 8.0, y + 4.0, 0.0)
        blf.draw(font_id, label)
        hits.append((kind, x, y, width, 20.0, ""))
        x += width + 4.0


def _tip_lines(font_id, text: str, max_w: float = 340.0) -> List[str]:
    words = str(text or "").split()
    lines: List[str] = []
    cur = ""
    for word in words:
        trial = word if not cur else f"{cur} {word}"
        if _text_width(font_id, trial) <= max_w:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines[:3]


def _rig_hover_text(kind: str, rig) -> str:
    if kind == "act":
        if _STATE.get("act") == "All" and (_STATE.get("query") or "").strip():
            return "Clear the search and show every scene."
        nxt = {"All": "Act 1", "Act01": "Act 2", "Act02": "Act 3", "Act03": "every act"}.get(
            str(_STATE.get("act") or "All"), "the next act"
        )
        return f"Showing {_STATE.get('act') or 'All'}. Click for {nxt}."
    if kind == "rig":
        if _STATE.get("rig_open"):
            return "Hide the rig options."
        return "Show the rig options for drag and drop."
    if kind == "rig_mesh":
        mode = str((rig or {}).get("meshes") or "BODY_CLOTH")
        return {
            "BODY_CLOTH": "Loads the body and the clothes. Click for the body only.",
            "BODY": "Loads the body without clothes. Click for a rig with no mesh.",
            "NONE": "Loads the rig with no body mesh. Click for body and clothes.",
        }.get(mode, "")
    return str(_CHIP_TIPS.get(kind) or "")


def _draw_hover_tip(font_id, hits, region, rig) -> None:
    """Box above the button under the cursor."""
    kind = str(_POINTER.get("hover_kind") or "")
    text = _rig_hover_text(kind, rig)
    if not text:
        return
    box = next((row for row in hits if row[0] == kind), None)
    if box is None:
        return
    _kind, x, y, w, h, _payload = box
    lines = _tip_lines(font_id, text)
    if not lines:
        return
    pad_x, pad_y, line_h = 8.0, 6.0, 15.0
    tw = max(_text_width(font_id, line) for line in lines)
    tip_w = tw + pad_x * 2.0
    tip_h = pad_y * 2.0 + line_h * len(lines)
    tip_x = x + w * 0.5 - tip_w * 0.5
    tip_y = y + h + 6.0
    rw = float(getattr(region, "width", 0) or 0)
    rh = float(getattr(region, "height", 0) or 0)
    if rh and tip_y + tip_h > rh - 4.0:
        tip_y = y - tip_h - 6.0
    if rw:
        tip_x = max(4.0, min(tip_x, rw - tip_w - 4.0))
    tip_y = max(4.0, tip_y)
    _rect(tip_x, tip_y, tip_w, tip_h, (0.07, 0.08, 0.10, 0.96))
    _rect(tip_x, tip_y + tip_h - 2.0, tip_w, 2.0, (0.45, 0.72, 0.95, 1.0))
    blf.color(font_id, 0.94, 0.96, 0.98, 1.0)
    for index, line in enumerate(lines):
        ly = tip_y + pad_y + line_h * (len(lines) - 1 - index)
        blf.position(font_id, tip_x + pad_x, ly, 0.0)
        blf.draw(font_id, line)


def _store_browser_rig(context, **patch) -> None:
    flags = _browser_rig_flags(context)
    flags.update(patch)
    try:
        prefs = context.preferences.addons[__package__].preferences
    except Exception:
        return
    meshes = _browser_mesh_mode(flags["meshes"])
    on = bool(flags["shapes"] or flags["limbs"] or flags["head"] or flags["tail"])
    setup = "ADVANCED" if on else "BASIC"
    prefs.rig_shapes = bool(flags["shapes"])
    prefs.rig_ik_limbs = bool(flags["limbs"])
    prefs.rig_ik_head = bool(flags["head"])
    prefs.import_tail = bool(flags["tail"])
    prefs.rig_setup = setup
    prefs.import_meshes = meshes
    prefs.import_akelka = bool(flags["akelka"])
    prefs.partner_rig_shapes = bool(flags["shapes"])
    prefs.partner_rig_ik_limbs = bool(flags["limbs"])
    prefs.partner_rig_ik_head = bool(flags["head"])
    prefs.partner_tail = bool(flags["tail"])
    prefs.partner_rig_setup = setup
    prefs.partner_meshes = meshes
    prefs.partner_akelka = bool(flags["akelka"])
    prefs.browser_rig_chosen = True


class GR2LAB_OT_gallery_bulk(bpy.types.Operator):
    """Ask before Add all or Load all when the list is long."""

    bl_idname = "gr2lab.gallery_bulk"
    bl_label = "GR2 LAB"
    bl_options = {"INTERNAL"}

    action: bpy.props.EnumProperty(
        items=(
            ("add", "Add", "Add the listed clips as holograms"),
            ("load", "Load", "Import the listed clips"),
        ),
        default="add",
        options={"SKIP_SAVE", "HIDDEN"},
    )
    confirmed: bpy.props.IntProperty(default=0, min=0, options={"SKIP_SAVE", "HIDDEN"})

    def _question(self, count: int) -> str:
        verb = "Add" if self.action == "add" else "Load"
        if count > _BULK_ASK_TWICE and int(self.confirmed) >= 1:
            return f"Really {verb.lower()} all {count} clips?"
        return f"{verb} all {count} clips?"

    def _bulk_paths(self) -> List[str]:
        paths = _listed_clip_paths()
        if self.action == "load":
            paths, _skipped = _paths_not_already_loaded(paths)
        return paths

    def invoke(self, context, event):
        count = len(self._bulk_paths())
        if count <= 0:
            listed = _listed_clip_paths()
            if self.action == "load" and listed:
                _set_notice(f"Already loaded ({len(listed)})")
            else:
                _set_notice("No GR2 in this list")
            return {"CANCELLED"}
        if int(self.confirmed) >= _bulk_confirms_needed(count):
            return self.execute(context)
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        self.layout.label(text=self._question(len(self._bulk_paths())))

    def execute(self, context):
        paths = self._bulk_paths()
        count = len(paths)
        need = _bulk_confirms_needed(count)
        got = int(self.confirmed) + (1 if need else 0)
        if got < need:
            _ask_gallery_bulk_again(str(self.action), got)
            return {"FINISHED"}
        if self.action == "add":
            _add_gallery(context)
        else:
            # Full list so already-imported clips drop their hologram and are skipped.
            _queue_gallery_load(_listed_clip_paths())
        return {"FINISHED"}


class GR2LAB_OT_gallery_load(bpy.types.Operator):
    """Import the queued clips. Escape stops the queue."""

    bl_idname = "gr2lab.gallery_load"
    bl_label = "Load listed GR2s"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        # The import operator is itself modal. A second modal here ate its
        # timer, so the bar sat on Starting… 0% until Blender looked frozen.
        _GALLERY["cancel"] = False
        _schedule_gallery_load()
        return {"FINISHED"}

    def modal(self, context, event):
        self._end(context)
        return {"FINISHED"}

    def cancel(self, context):
        _cancel_gallery_load()
        self._end(context)

    def _end(self, context) -> None:
        _GALLERY["modal"] = False
        timer = getattr(self, "_timer", None)
        if timer is None:
            return
        try:
            context.window_manager.event_timer_remove(timer)
        except Exception:
            pass
        self._timer = None


class GR2LAB_OT_gallery_clear(bpy.types.Operator):
    """Remove every hologram. Same as the Remove holograms button."""

    bl_idname = "gr2lab.gallery_clear"
    bl_label = "Remove holograms"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        if not _browser_on(context) or _search_active():
            return False
        return bool(
            _GALLERY.get("items")
            or _GALLERY.get("build")
            or _GALLERY.get("load")
            or _GALLERY.get("load_job")
        )

    def invoke(self, context, event):
        # Search keeps Escape. A panel or the header keeps it too.
        if _search_active():
            return {"PASS_THROUGH"}
        found = view3d_under_pointer(context, event)
        if found is None:
            return {"PASS_THROUGH"}
        _area, region, _mx, _my = found
        if getattr(region, "type", "") != "WINDOW":
            return {"PASS_THROUGH"}
        if not self.poll(context):
            return {"PASS_THROUGH"}
        return self.execute(context)

    def execute(self, context):
        gallery_load_abort()
        _clear_gallery()
        _set_notice("Holograms removed")
        _tag()
        return {"FINISHED"}


def _viewport_overlay_click(context, event, area, region, mx, my) -> bool:
    """Race menu and hologram buttons. True when the click was used.

    The search field is a modal, so a click on Generate all never reaches the
    window keymap unless this runs before that modal exits.
    """
    from .race_picker import try_race_click

    window = getattr(context, "window", None)
    try:
        with context.temp_override(window=window, area=area, region=region):
            if try_race_click(bpy.context, event, mx, my):
                return True
            if _gallery_cancel_hit(region, mx, my):
                _clear_gallery()
                _set_notice("Holograms cleared")
                return True
            banner = _gallery_banner_hit(region, mx, my)
            if banner == "clear":
                _clear_gallery()
                _set_notice("Holograms removed")
                return True
            if banner == "all":
                _gallery_generate_all()
                return True
            gen_path, gen_mode = _gallery_generate_hit(region, mx, my)
            if gen_path:
                _gallery_generate_one(gen_path, gen_mode)
                return True
            named = _gallery_label_hit(region, mx, my)
            if named:
                _gallery_choose(named)
                return True
            picked = _gallery_pick(bpy.context, mx, my)
            if picked:
                _gallery_choose(picked)
                return True
    except Exception:
        traceback.print_exc()
    return False


class GR2LAB_OT_preview_orbit(bpy.types.Operator):
    """Drag inside the clip preview to move its camera."""

    bl_idname = "gr2lab.preview_orbit"
    bl_label = "Preview camera"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        if not _PREVIEW.get("orbit"):
            return {"CANCELLED"}
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not _ALIVE or not _PREVIEW.get("orbit"):
            return {"FINISHED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            _preview_orbit_drag(event)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value in {"RELEASE", "CLICK"}:
            _PREVIEW["orbit"] = None
            _tag()
            return {"FINISHED"}
        if event.type == "ESC" and event.value == "PRESS":
            _PREVIEW["orbit"] = None
            _tag()
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}


class GR2LAB_OT_anim_browser_pointer(bpy.types.Operator):
    """Hover, scroll, and click the animation browser."""

    bl_idname = "gr2lab.anim_browser_pointer"
    bl_label = "GR2 animation browser"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        from .race_picker import note_pointer

        if _preview_orbit_event(event):
            return {"FINISHED"}
        if _track_search_drag(context, event):
            return {"FINISHED"}
        if _search_active() and event.type in {"LEFTMOUSE", "RIGHTMOUSE"} and event.value == "PRESS":
            found = view3d_under_pointer(context, event)
            if found is None:
                _blur_gpu_search()
            else:
                _area, region, mx, my = found
                if not pointer_over_strip(region, mx, my):
                    _blur_gpu_search()
        if event.type == "LEFTMOUSE" and event.value == "RELEASE" and _CLIP_ARM.get("path"):
            _finish_clip_arm(context)
            return {"FINISHED"}
        if event.type == "MOUSEMOVE":
            note_pointer(context, event)
            _gallery_track_pointer(context, event)
            if _browser_on(context) and _try_armed_clip_drag(context, event):
                return {"FINISHED"}
        if _browser_on(context) and modal_strip_event(context, event):
            return {"FINISHED"}
        if (
            event.type == "LEFTMOUSE"
            and event.value == "PRESS"
            and not event.shift
            and not event.alt
        ):
            found = view3d_under_pointer(context, event)
            if found is not None:
                area, region, mx, my = found
                if not pointer_over_strip(region, mx, my):
                    if _viewport_overlay_click(context, event, area, region, mx, my):
                        return {"FINISHED"}
        return {"PASS_THROUGH"}


class GR2LAB_OT_anim_search_drag(bpy.types.Operator):
    """Keep the search highlight moving until the mouse button is released."""

    bl_idname = "gr2lab.anim_search_drag"
    bl_label = "Search text drag"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _browser_on(context)

    def invoke(self, context, event):
        if not _SEARCH_DRAG.get("active"):
            return {"CANCELLED"}
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if not _ALIVE or not _SEARCH_DRAG.get("active"):
            return {"FINISHED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"} or (
            event.type == "LEFTMOUSE" and event.value in {"RELEASE", "CLICK"}
        ):
            _track_search_drag(context, event)
            if not _SEARCH_DRAG.get("active"):
                return {"FINISHED"}
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and event.value == "PRESS":
            _SEARCH_DRAG["active"] = False
            _tag()
            return {"CANCELLED"}
        return {"RUNNING_MODAL"}


class GR2LAB_OT_anim_browser_search_undo(bpy.types.Operator):
    """Undo in the animation strip search field."""

    bl_idname = "gr2lab.anim_browser_search_undo"
    bl_label = "Animation search undo"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _browser_on(context) and _search_active()

    def execute(self, context):
        _undo_search()
        return {"FINISHED"}


class GR2LAB_OT_anim_browser_search_redo(bpy.types.Operator):
    """Redo in the animation strip search field."""

    bl_idname = "gr2lab.anim_browser_search_redo"
    bl_label = "Animation search redo"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _browser_on(context) and _search_active()

    def execute(self, context):
        _redo_search()
        return {"FINISHED"}


class GR2LAB_OT_anim_browser_type(bpy.types.Operator):
    """Type into the GPU search field on the animation strip."""

    bl_idname = "gr2lab.anim_browser_type"
    bl_label = "Animation search type"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        if not _browser_on(context) or not _search_active():
            return False
        area = getattr(context, "area", None)
        if area is None:
            return True
        return getattr(area, "type", "") == "VIEW_3D"

    def invoke(self, context, event):
        _STATE["search_focus"] = True
        if _STATE.get("search_modal"):
            context.window_manager.modal_handler_add(self)
            return self.modal(context, event)
        # Glyphs arrive as TEXTINPUT. The matching key press is swallowed so
        # the 3D View keymap cannot run Grab / Rotate / Scale on the same key.
        if event.type == "TEXTINPUT":
            char = _search_event_char(event)
            if char and char.isprintable() and char not in "\t":
                _push_search_char(char)
        elif event.value in {"PRESS", "REPEAT", "CLICK"}:
            if event.type in {"BACK_SPACE", "BACKSPACE"}:
                _backspace_search()
            elif event.type in {"DELETE", "DEL"}:
                _delete_search()
            elif event.type in {"LEFT_ARROW", "RIGHT_ARROW"}:
                _move_search_caret(-1 if event.type == "LEFT_ARROW" else 1)
            elif event.type == "HOME":
                _STATE["search_sel"] = False
                _set_search_caret(0)
                _tag()
            elif event.type == "END":
                _STATE["search_sel"] = False
                _set_search_caret(len(_STATE.get("query") or ""))
                _tag()
            elif event.type == "ESC":
                _apply_search_edit("")
                _set_search_caret(0)
                self._stop()
                return {"FINISHED"}
            elif event.type in {"RET", "NUMPAD_ENTER"}:
                self._stop()
                return {"FINISHED"}
            elif _search_swallow_key(event.type):
                glyph = _search_key_glyph(event)
                if glyph and glyph.isprintable() and glyph not in "\t":
                    _push_search_char(glyph)
        _search_history_begin()
        _STATE["search_modal"] = True
        context.window_manager.modal_handler_add(self)
        _tag()
        return {"RUNNING_MODAL"}

    def _stop(self) -> None:
        _blur_gpu_search()

    def modal(self, context, event):
        if not _ALIVE or not _browser_on(context) or not _STATE.get("search_modal"):
            replay = None
            if event.type == "LEFTMOUSE" and event.value == "PRESS":
                found = view3d_under_pointer(context, event)
                if found is not None:
                    area, region, mx, my = found
                    if pointer_over_strip(region, mx, my):
                        replay = (
                            getattr(context, "window", None),
                            area,
                            region,
                            float(mx),
                            float(my),
                        )
            self._stop()
            if replay is not None:
                window, area, region, mx, my = replay

                def kick(window=window, area=area, region=region, mx=mx, my=my):
                    class _Click:
                        value = "PRESS"
                        mouse_region_x = mx
                        mouse_region_y = my

                    try:
                        with bpy.context.temp_override(
                            window=window, area=area, region=region
                        ):
                            handle_strip_click(bpy.context, _Click(), mx, my)
                    except Exception:
                        traceback.print_exc()
                    return None

                try:
                    bpy.app.timers.register(kick, first_interval=0.0)
                except Exception:
                    traceback.print_exc()
            return {"CANCELLED"}
        if event.type in {"MOUSEMOVE", "INBETWEEN_MOUSEMOVE"}:
            if _track_search_drag(context, event):
                return {"RUNNING_MODAL"}
            if event.type != "MOUSEMOVE":
                return {"PASS_THROUGH"}
            _on_move(context, event)
            return {"PASS_THROUGH"}
        if event.type in {
            "MIDDLEMOUSE",
            "RIGHTMOUSE",
            "WHEELUPMOUSE",
            "WHEELDOWNMOUSE",
            "TRACKPADPAN",
            "TRACKPADZOOM",
        }:
            if event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
                found = view3d_under_pointer(context, event)
                if found is not None:
                    _area, region, mx, my = found
                    if pointer_over_strip(region, mx, my):
                        handled = _on_wheel(context, event)
                        if handled == {"FINISHED"}:
                            return {"RUNNING_MODAL"}
            self._stop()
            return {"PASS_THROUGH"}
        if event.type == "LEFTMOUSE" and event.value in {"RELEASE", "CLICK", "DOUBLE_CLICK"}:
            _track_search_drag(context, event)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            found = view3d_under_pointer(context, event)
            if found is None:
                self._stop()
                return {"CANCELLED"}
            area, region, mx, my = found
            if not pointer_over_strip(region, mx, my):
                self._stop()
                _viewport_overlay_click(context, event, area, region, mx, my)
                return {"CANCELLED"}
            window = getattr(context, "window", None)
            try:
                with context.temp_override(window=window, area=area, region=region):
                    refresh_strip_pick_data(bpy.context)
                    hit = _hit(region, mx, my)
                    if hit is not None and hit[0] == "search":
                        _arm_search_drag(
                            region,
                            mx,
                            extend=bool(getattr(event, "shift", False)),
                            window_x=float(getattr(event, "mouse_x", mx)),
                        )
                        try:
                            bpy.ops.gr2lab.anim_search_drag("INVOKE_DEFAULT")
                        except Exception:
                            traceback.print_exc()
                        return {"RUNNING_MODAL"}
                    self._stop()
                    if hit is not None:
                        handle_strip_click(bpy.context, event, mx, my)
                    return {"CANCELLED"}
            except Exception:
                traceback.print_exc()
            self._stop()
            return {"CANCELLED"}
        if event.type == "TIMER":
            return {"PASS_THROUGH"}
        if _search_shortcut(event):
            return {"RUNNING_MODAL"}
        if event.type == "INSERT" and event.value == "PRESS" and event.shift:
            _paste_search()
            return {"RUNNING_MODAL"}
        if event.alt:
            return {"PASS_THROUGH"}
        if event.type in {"LEFT_ARROW", "RIGHT_ARROW"} and event.value in {"PRESS", "REPEAT"}:
            _move_search_caret(-1 if event.type == "LEFT_ARROW" else 1)
            return {"RUNNING_MODAL"}
        if event.type == "HOME" and event.value == "PRESS":
            _STATE["search_sel"] = False
            _set_search_caret(0)
            _tag()
            return {"RUNNING_MODAL"}
        if event.type == "END" and event.value == "PRESS":
            _STATE["search_sel"] = False
            _set_search_caret(len(_STATE.get("query") or ""))
            _tag()
            return {"RUNNING_MODAL"}
        if event.type in {"BACK_SPACE", "BACKSPACE"} and event.value in {"PRESS", "REPEAT", "CLICK"}:
            _backspace_search()
            return {"RUNNING_MODAL"}
        if event.type in {"DELETE", "DEL"} and event.value in {"PRESS", "REPEAT", "CLICK"}:
            _delete_search()
            return {"RUNNING_MODAL"}
        if event.type == "ESC" and event.value == "PRESS":
            _apply_search_edit("")
            _set_search_caret(0)
            self._stop()
            return {"CANCELLED"}
        if event.type in {"RET", "NUMPAD_ENTER"} and event.value == "PRESS":
            self._stop()
            return {"CANCELLED"}
        if event.type == "TEXTINPUT":
            char = _search_event_char(event)
            if char and char.isprintable() and char not in "\t":
                _push_search_char(char)
            return {"RUNNING_MODAL"}
        if event.value in {"PRESS", "REPEAT"} and _search_swallow_key(event.type):
            glyph = _search_key_glyph(event)
            if glyph and glyph.isprintable() and glyph not in "\t":
                _push_search_char(glyph)
            return {"RUNNING_MODAL"}
        if event.value in {"RELEASE", "CLICK"}:
            return {"RUNNING_MODAL"}
        if event.type in {
            "LEFT_SHIFT",
            "RIGHT_SHIFT",
            "LEFT_CTRL",
            "RIGHT_CTRL",
            "LEFT_ALT",
            "RIGHT_ALT",
            "OSKEY",
        }:
            return {"RUNNING_MODAL"}
        if event.type not in {"TIMER", "INBETWEEN_MOUSEMOVE", "MOUSEMOVE"}:
            self._stop()
            return {"CANCELLED"}
        return {"PASS_THROUGH"}

    def cancel(self, context):
        self._stop()


def _start_library_index(root: Path) -> bool:
    """Scan _Anims on a background thread and write anim_index.json."""
    if _PREP["running"]:
        return False
    with _PREP_LOCK:
        _PREP["running"] = True
        _PREP["done"] = False
        _PREP["cancel"] = False
        _PREP["error"] = ""
        _PREP["scenes"] = 0
        _PREP["phase"] = "starting"

    def cancel() -> bool:
        return bool(_PREP["cancel"])

    def run() -> None:
        try:
            data = build_index(root, cancel)
            if data is None:
                with _PREP_LOCK:
                    _PREP["error"] = "Prepare cancelled"
            else:
                index_path().write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
                with _PREP_LOCK:
                    _PREP["scenes"] = len(data.get("scenes") or [])
                    _PREP["phase"] = "done"
            with _PREP_LOCK:
                _PREP["done"] = True
        except Exception as exc:
            traceback.print_exc()
            with _PREP_LOCK:
                _PREP["error"] = str(exc)
                _PREP["done"] = True
        finally:
            with _PREP_LOCK:
                _PREP["running"] = False

    threading.Thread(target=run, name="gr2lab-anim-index", daemon=True).start()
    return True


def _kick_full_anim_index() -> Optional[float]:
    """Rebuild a cinematic-only index so body clips show up without a manual prepare."""
    if not _ALIVE or _PREP["running"]:
        return None
    data = _load_index()
    if data is None or int(data.get("version") or 0) >= _INDEX_VERSION:
        return None
    root = unpacked_root(bpy.context)
    if root is None:
        return 1.0
    print(
        "[GR2 LAB] animation index is cinematic-only, rebuilding the full _Anims library",
        flush=True,
    )
    _start_library_index(root)
    return None


class GR2LAB_OT_anim_prepare(bpy.types.Operator):
    """Index character animation folders in the unpacked data. Does not open GR2 files."""

    bl_idname = "gr2lab.anim_prepare"
    bl_label = "Prepare animation library"
    bl_options = {"REGISTER"}

    directory: bpy.props.StringProperty(
        name="Unpacked data",
        description="BG3 Multitool UnpackedData folder (contains Gustav/…/Timeline)",
        subtype="DIR_PATH",
        default="",
    )

    _timer = None

    def _start_index(self, context, root: Path):
        if not _start_library_index(root):
            self.report({"WARNING"}, "Library prepare is already running")
            return {"CANCELLED"}
        self._timer = context.window_manager.event_timer_add(0.3, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        root = unpacked_root(context)
        if root is None:
            from . import bg3_unpacked_resolve

            hint = _prefs_unpacked_raw(context)
            if not hint and bg3_unpacked_resolve.DEFAULT_UNPACKED.is_dir():
                hint = str(bg3_unpacked_resolve.DEFAULT_UNPACKED)
            if hint:
                self.directory = hint
            self.report({"INFO"}, "Choose BG3 unpacked data folder")
            context.window_manager.fileselect_add(self)
            return {"RUNNING_MODAL"}
        return self._start_index(context, root)

    def execute(self, context):
        path = (self.directory or "").strip()
        if not path:
            self.report({"ERROR"}, "Choose your BG3 UnpackedData folder")
            return {"CANCELLED"}
        folder = Path(path)
        if not folder.is_dir():
            self.report({"ERROR"}, f"Not a folder: {path}")
            return {"CANCELLED"}
        _set_prefs_unpacked_dir(context, str(folder))
        return self._start_index(context, folder)

    def modal(self, context, event):
        if event.type == "ESC" and event.value == "PRESS":
            _PREP["cancel"] = True
        if event.type != "TIMER":
            return {"PASS_THROUGH"}
        _tag()
        if not _PREP["done"]:
            return {"PASS_THROUGH"}
        self._remove_timer(context)
        _INDEX["data"] = None
        if _PREP["error"]:
            self.report({"WARNING"}, _PREP["error"])
        else:
            self.report({"INFO"}, f"Animation library: {_PREP['scenes']} scenes")
        _tag()
        return {"FINISHED"}

    def cancel(self, context):
        _PREP["cancel"] = True
        self._remove_timer(context)

    def _remove_timer(self, context):
        timer = getattr(self, "_timer", None)
        if timer is None:
            return
        try:
            context.window_manager.event_timer_remove(timer)
        except Exception:
            pass
        self._timer = None


def register() -> None:
    global _HANDLE, _VIEW_DRAG_HANDLE, _ALIVE
    _ALIVE = True
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        _STATE["center_parent"] = bool(getattr(prefs, "center_parent", True))
    except Exception:
        pass
    bpy.utils.register_class(GR2LAB_OT_anim_prepare)
    bpy.utils.register_class(GR2LAB_OT_anim_browser_search_undo)
    bpy.utils.register_class(GR2LAB_OT_anim_browser_search_redo)
    bpy.utils.register_class(GR2LAB_OT_anim_browser_type)
    bpy.utils.register_class(GR2LAB_OT_anim_search_drag)
    bpy.utils.register_class(GR2LAB_MT_anim_clip_menu)
    bpy.utils.register_class(GR2LAB_OT_anim_clip_copy)
    bpy.utils.register_class(GR2LAB_OT_anim_clip_drag)
    bpy.utils.register_class(GR2LAB_OT_anim_pane_resize)
    bpy.utils.register_class(GR2LAB_OT_anim_list_scroll)
    bpy.utils.register_class(GR2LAB_OT_anim_browser_modal)
    bpy.utils.register_class(GR2LAB_OT_gallery_bulk)
    bpy.utils.register_class(GR2LAB_OT_gallery_load)
    bpy.utils.register_class(GR2LAB_OT_gallery_clear)
    bpy.utils.register_class(GR2LAB_OT_preview_orbit)
    bpy.utils.register_class(GR2LAB_OT_anim_browser_pointer)
    if _HANDLE is None:
        _HANDLE = bpy.types.SpaceView3D.draw_handler_add(_draw, (), "WINDOW", "POST_PIXEL")
    if _VIEW_DRAG_HANDLE is None:
        _VIEW_DRAG_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            _draw_view_drop, (), "WINDOW", "POST_VIEW"
        )
    wm = bpy.context.window_manager
    # Only register on the addon keyconfig. Never use user/active Window maps.
    kc_win = addon_keyconfig(wm)
    if kc_win is not None:
        km_win = _ensure_keymap(kc_win, "Window", "EMPTY")
        for kmi in list(km_win.keymap_items):
            if kmi.idname == "gr2lab.anim_browser_pointer":
                km_win.keymap_items.remove(kmi)
        for event_name, value, shift, alt in (
            ("LEFTMOUSE", "PRESS", False, False),
            ("LEFTMOUSE", "PRESS", True, False),
            ("LEFTMOUSE", "PRESS", False, True),
            ("RIGHTMOUSE", "PRESS", False, False),
            ("WHEELUPMOUSE", "PRESS", False, False),
            ("WHEELDOWNMOUSE", "PRESS", False, False),
            ("MOUSEMOVE", "ANY", False, False),
        ):
            item = km_win.keymap_items.new(
                "gr2lab.anim_browser_pointer",
                event_name,
                value,
                shift=shift,
                alt=alt,
                head=True,
            )
            _KEYMAPS.append((km_win, item))
        for kmi in list(km_win.keymap_items):
            if kmi.idname == "gr2lab.gallery_clear":
                km_win.keymap_items.remove(kmi)
        try:
            clear_item = km_win.keymap_items.new(
                "gr2lab.gallery_clear",
                "ESC",
                "PRESS",
                head=True,
            )
            _KEYMAPS.append((km_win, clear_item))
        except Exception:
            traceback.print_exc()
    kc = view3d_keyconfig(wm)
    if kc is not None:
        km = _ensure_keymap(kc, "3D View", "VIEW_3D")
        for kmi in list(km.keymap_items):
            if kmi.idname in {
                "gr2lab.anim_clip_copy",
                "gr2lab.anim_browser_type",
                "gr2lab.anim_browser_search_undo",
                "gr2lab.anim_browser_search_redo",
                "gr2lab.gallery_clear",
            }:
                try:
                    km.keymap_items.remove(kmi)
                except Exception:
                    pass
        for ctrl, oskey in ((True, False), (False, True)):
            try:
                item = km.keymap_items.new(
                    "gr2lab.anim_clip_copy",
                    "C",
                    "PRESS",
                    ctrl=ctrl,
                    oskey=oskey,
                    head=True,
                )
            except Exception:
                continue
            _KEYMAPS.append((km, item))
        text = km.keymap_items.new(
            "gr2lab.anim_browser_type", "TEXTINPUT", "ANY", head=True
        )
        _KEYMAPS.append((km, text))
        swallow = [chr(code) for code in range(ord("A"), ord("Z") + 1)]
        swallow.extend(
            [
                "ZERO",
                "ONE",
                "TWO",
                "THREE",
                "FOUR",
                "FIVE",
                "SIX",
                "SEVEN",
                "EIGHT",
                "NINE",
            ]
        )
        swallow.extend(f"NUMPAD_{i}" for i in range(10))
        swallow.extend(_SEARCH_KEY_CHARS)
        swallow.extend(
            [
                "BACK_SPACE",
                "DEL",
                "LEFT_ARROW",
                "RIGHT_ARROW",
                "HOME",
                "END",
                "ESC",
                "RET",
                "NUMPAD_ENTER",
            ]
        )
        for event_name in swallow:
            for shift in (False, True):
                try:
                    item = km.keymap_items.new(
                        "gr2lab.anim_browser_type",
                        event_name,
                        "PRESS",
                        shift=shift,
                        head=True,
                    )
                except Exception:
                    continue
                _KEYMAPS.append((km, item))
        try:
            clear_item = km.keymap_items.new(
                "gr2lab.gallery_clear",
                "ESC",
                "PRESS",
                head=True,
            )
            _KEYMAPS.append((km, clear_item))
        except Exception:
            traceback.print_exc()
        for ctrl, oskey in ((True, False), (False, True)):
            undo = km.keymap_items.new(
                "gr2lab.anim_browser_search_undo",
                "Z",
                "PRESS",
                ctrl=ctrl,
                oskey=oskey,
                head=True,
            )
            _KEYMAPS.append((km, undo))
            redo_y = km.keymap_items.new(
                "gr2lab.anim_browser_search_redo",
                "Y",
                "PRESS",
                ctrl=ctrl,
                oskey=oskey,
                head=True,
            )
            _KEYMAPS.append((km, redo_y))
            redo_z = km.keymap_items.new(
                "gr2lab.anim_browser_search_redo",
                "Z",
                "PRESS",
                ctrl=ctrl,
                oskey=oskey,
                shift=True,
                head=True,
            )
            _KEYMAPS.append((km, redo_z))
    _ensure_timer()
    bpy.app.timers.register(_boot_browser_modal, first_interval=0.2)
    bpy.app.timers.register(_boot_browser_modal, first_interval=1.5)
    bpy.app.timers.register(_warm_preview_caches, first_interval=0.0)
    bpy.app.timers.register(_kick_full_anim_index, first_interval=0.8)


def unregister() -> None:
    global _HANDLE, _VIEW_DRAG_HANDLE, _ALIVE, _TIMER_ON
    _ALIVE = False
    stop_clip_hover_preview()
    try:
        bpy.app.timers.unregister(_warm_preview_caches)
    except Exception:
        pass
    try:
        bpy.app.timers.unregister(_warm_slot_plans)
    except Exception:
        pass
    try:
        bpy.app.timers.unregister(_kick_full_anim_index)
    except Exception:
        pass
    for _timer in (_pump_gallery_build, _pump_gallery_load, _pump_gallery_anim):
        try:
            bpy.app.timers.unregister(_timer)
        except Exception:
            pass
    _DRAG["active"] = False
    _STATE["search_modal"] = False
    _STATE["search_focus"] = False
    _PREP["cancel"] = True
    _HOVER["gen"] = int(_HOVER["gen"]) + 1
    _kill_stick_preview_proc()
    _clear_clip_arm()
    while _KEYMAPS:
        km, item = _KEYMAPS.pop()
        try:
            km.keymap_items.remove(item)
        except Exception:
            pass
    if _HANDLE is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_HANDLE, "WINDOW")
        except Exception:
            pass
        _HANDLE = None
    if _VIEW_DRAG_HANDLE is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_VIEW_DRAG_HANDLE, "WINDOW")
        except Exception:
            pass
        _VIEW_DRAG_HANDLE = None
    _HITS.clear()
    _LAYOUTS.clear()
    _TIMER_ON = False
    off = _PREVIEW.get("off")
    if off is not None:
        try:
            off.free()
        except Exception:
            pass
    _PREVIEW["off"] = None
    _PREVIEW["timer"] = False
    _PREVIEW["actors"] = []
    try:
        wm = bpy.context.window_manager
        wm["gr2lab_browser_modal_wins"] = []
    except Exception:
        pass
    for cls in (
        GR2LAB_OT_anim_pane_resize,
        GR2LAB_OT_anim_list_scroll,
        GR2LAB_MT_anim_clip_menu,
        GR2LAB_OT_anim_clip_copy,
        GR2LAB_OT_anim_clip_drag,
        GR2LAB_OT_anim_browser_modal,
        GR2LAB_OT_gallery_load,
        GR2LAB_OT_gallery_bulk,
        GR2LAB_OT_gallery_clear,
        GR2LAB_OT_anim_browser_pointer,
        GR2LAB_OT_preview_orbit,
        GR2LAB_OT_anim_search_drag,
        GR2LAB_OT_anim_browser_type,
        GR2LAB_OT_anim_browser_search_redo,
        GR2LAB_OT_anim_browser_search_undo,
        GR2LAB_OT_anim_prepare,
    ):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
