"""Background Blender entry: decode stick hover preview without blocking the open file."""
from __future__ import annotations

import os
import pickle
import sys
import traceback
from pathlib import Path


def main() -> None:
    argv = sys.argv[sys.argv.index("--") + 1 :]
    gr2_path, out_path = argv[0], argv[1]
    quick = (argv[2] if len(argv) > 2 else "1") == "1"
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import gr2lab_blender

    gr2lab_blender.register()
    from gr2lab_blender.anim_browser import build_stick_preview_data

    data, err = build_stick_preview_data(gr2_path, quick=quick)
    payload = {"path": gr2_path, "data": data, "err": err or ""}
    Path(out_path).write_bytes(pickle.dumps(payload, protocol=4))
    print("STICK_OK", flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        os._exit(1)
