"""Remove GR2 LAB entries from user/active keyconfigs (legacy builds broke F2/F3/Ctrl+S)."""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import bpy

_TREATED_MAPS = (
    ("Window", "EMPTY"),
    ("3D View", "VIEW_3D"),
)

# A real Blender user Window map has far more than a few strip-pointer bindings.
_MIN_WINDOW_ITEMS = 25


def _find_km(kc, name: str, space_type: str):
    if kc is None:
        return None
    try:
        return kc.keymaps.find(name=name, space_type=space_type)
    except TypeError:
        return kc.keymaps.find(name, space_type=space_type)


def _is_gr2lab_kmi(kmi) -> bool:
    return str(getattr(kmi, "idname", "") or "").startswith("gr2lab.")


def _keymap_looks_replaced(km) -> bool:
    if km is None:
        return False
    items = list(km.keymap_items)
    if not items:
        return True
    if km.name == "Window" and km.space_type == "EMPTY" and len(items) < _MIN_WINDOW_ITEMS:
        return True
    gr2 = sum(1 for kmi in items if _is_gr2lab_kmi(kmi))
    return gr2 > 0 and gr2 == len(items)


def user_window_keymap_needs_repair(wm=None) -> bool:
    wm = wm or bpy.context.window_manager
    if wm is None:
        return False
    kc = wm.keyconfigs.user
    km = _find_km(kc, "Window", "EMPTY")
    return _keymap_looks_replaced(km)


def strip_legacy_keymap_writes(wm=None) -> Dict[str, object]:
    """Drop GR2 LAB from user/active maps; remove tiny replacement Window maps."""
    wm = wm or bpy.context.window_manager
    report: Dict[str, object] = {
        "removed_items": 0,
        "removed_keymaps": [],
        "configs": [],
    }
    if wm is None:
        return report

    configs: List[Tuple[str, object]] = []
    kc_user = wm.keyconfigs.user
    if kc_user is not None:
        configs.append(("user", kc_user))
    kc_active = wm.keyconfigs.active
    if kc_active is not None and kc_active is not kc_user:
        configs.append(("active", kc_active))

    for label, kc in configs:
        for name, space in _TREATED_MAPS:
            km = _find_km(kc, name, space)
            if km is None:
                continue
            if _keymap_looks_replaced(km):
                for kmi in list(km.keymap_items):
                    try:
                        km.keymap_items.remove(kmi)
                    except Exception:
                        pass
                try:
                    kc.keymaps.remove(km)
                    report["removed_keymaps"].append(f"{label}:{name}")
                    if label not in report["configs"]:
                        report["configs"].append(label)
                except Exception:
                    pass
                continue
            for kmi in list(km.keymap_items):
                if not _is_gr2lab_kmi(kmi):
                    continue
                try:
                    km.keymap_items.remove(kmi)
                    report["removed_items"] = int(report["removed_items"]) + 1
                    if label not in report["configs"]:
                        report["configs"].append(label)
                except Exception:
                    pass
    return report


def reload_gr2lab_keymaps() -> None:
    from . import anim_browser
    from . import race_picker

    try:
        race_picker.unregister()
    except Exception:
        pass
    try:
        anim_browser.unregister()
    except Exception:
        pass
    anim_browser.register()
    race_picker.register()


class GR2LAB_OT_repair_blender_keymaps(bpy.types.Operator):
    """Remove broken GR2 LAB user keymaps so Blender defaults (F2, F3, save) work again."""

    bl_idname = "gr2lab.repair_blender_keymaps"
    bl_label = "Restore Blender shortcuts"
    bl_options = {"REGISTER", "INTERNAL"}

    def execute(self, context):
        report = strip_legacy_keymap_writes(context.window_manager)
        reload_gr2lab_keymaps()
        try:
            bpy.ops.wm.save_userpref()
        except Exception:
            pass
        n_maps = len(report.get("removed_keymaps") or [])
        n_items = int(report.get("removed_items") or 0)
        self.report(
            {"INFO"},
            f"Shortcuts repair: removed {n_items} GR2 LAB user bindings, "
            f"reset {n_maps} broken keymap(s). Try F2 / Ctrl+S.",
        )
        return {"FINISHED"}


_CLASSES = (GR2LAB_OT_repair_blender_keymaps,)


def register() -> None:
    for cls in _CLASSES:
        bpy.utils.register_class(cls)


def unregister() -> None:
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
